// Offline, dependency-free PNG report. Render saved data, not the viewport.
const SHOT_REPORT_TEXT = {
  en: {
    report: 'Shot report', espresso: 'Espresso shot', brewed: 'Brewed by', machine: 'Machine',
    yield: 'Yield', duration: 'Duration', average: 'Average flow', temperature: 'Temp. target',
    target: 'Target', flowNote: 'Recorded extraction flow', tempNote: 'Coffee boiler setting',
    note: 'Profile note', currentNote: 'Current profile note', dose: 'Dose', ratio: 'Brew ratio',
    prebrew: 'Pre-brewing', window: 'Time window', on: 'on', pause: 'pause', off: 'Off', unchanged: 'Unchanged',
    weightMode: 'Brew by weight', timeMode: 'Brew by time', curve: 'Extraction curve',
    flow: 'Flow', weight: 'Weight', ideal: 'Ideal flow', smoothing: 'Flow smoothing', samples: 'samples',
    time: 'Time from shot start', noSamples: 'No curve data recorded', analysis: 'Shot analysis',
    confidence: 'confidence', evidence: 'Evidence', recommend: 'Recommendation',
    detected: 'Detected', notDetected: 'Not detected', match: 'Settings match', mismatch: 'Settings differ',
    unknown: 'Settings unknown', recorded: 'Recorded with Shotdeck', secondary: 'Other observations',
    roasts: { LR: 'Light roast', MR: 'Medium roast', DR: 'Dark roast' },
  },
  de: {
    report: 'Shot-Bericht', espresso: 'Espresso-Shot', brewed: 'Gebrüht von', machine: 'Maschine',
    yield: 'Getränkemenge', duration: 'Dauer', average: 'Ø Fluss', temperature: 'Temperaturziel',
    target: 'Ziel', flowNote: 'Erfasster Extraktionsfluss', tempNote: 'Einstellung des Kaffeekessels',
    note: 'Profilnotiz', currentNote: 'Aktuelle Profilnotiz', dose: 'Dosis', ratio: 'Brühverhältnis',
    prebrew: 'Vorbrühen', window: 'Zeitfenster', on: 'an', pause: 'Pause', off: 'Aus', unchanged: 'Unverändert',
    weightMode: 'Brühen nach Gewicht', timeMode: 'Brühen nach Zeit', curve: 'Extraktionskurve',
    flow: 'Fluss', weight: 'Gewicht', ideal: 'Idealer Fluss', smoothing: 'Flussglättung', samples: 'Messwerte',
    time: 'Zeit ab Shot-Start', noSamples: 'Keine Kurvendaten erfasst', analysis: 'Shot-Analyse',
    confidence: 'Konfidenz', evidence: 'Indizien', recommend: 'Empfehlung',
    detected: 'Erkannt', notDetected: 'Nicht erkannt', match: 'Einstellungen passen', mismatch: 'Einstellungen weichen ab',
    unknown: 'Einstellungen unbekannt', recorded: 'Erfasst mit Shotdeck', secondary: 'Weitere Beobachtungen',
    roasts: { LR: 'Helle Röstung', MR: 'Mittlere Röstung', DR: 'Dunkle Röstung' },
  },
};

// Human-readable analyzer labels; unknown future keys retain their readable text.
const SHOT_REPORT_ANALYSIS_LABELS = {
  under_extraction: ['Under-extraction', 'Unterextraktion'],
  over_extraction: ['Over-extraction', 'Überextraktion'],
  channeling: ['Channeling', 'Channeling'],
  inconsistent_shot: ['Inconsistent shots', 'Unregelmäßige Shots'],
  weak_low_crema: ['Weak / low crema', 'Schwach / wenig Crema'],
  choking_no_flow: ['Choking / no flow', 'Blockiert / kein Fluss'],
  balanced: ['Good shot', 'Guter Shot'], unknown: ['Unknown', 'Unbekannt'],
  borderline_below_time_min: ['Slightly below the time window', 'Knapp unter dem Zeitfenster'],
  borderline_fast_shot: ['Slightly fast shot', 'Etwas schneller Shot'],
  below_time_min: ['Below the time window', 'Unter dem Zeitfenster'], fast_shot: ['Fast shot', 'Schneller Shot'],
  fast_flow: ['Fast flow', 'Schneller Fluss'], low_resistance_flow: ['Low puck resistance', 'Geringer Puck-Widerstand'],
  above_flow_range: ['Above the flow range', 'Über dem Flussbereich'],
  borderline_above_time_max: ['Slightly above the time window', 'Knapp über dem Zeitfenster'],
  above_time_max: ['Above the time window', 'Über dem Zeitfenster'], slow_flow: ['Slow flow', 'Langsamer Fluss'],
  low_flow: ['Low flow', 'Geringer Fluss'], delayed_first_flow: ['Delayed first flow', 'Verzögerter erster Fluss'],
  long_no_flow_start: ['Long start without flow', 'Langer Start ohne Fluss'], severe_no_flow: ['Little or no flow', 'Kaum oder kein Fluss'],
  stall_window: ['Flow stall', 'Flussunterbrechung'], possible_stall: ['Possible flow stall', 'Mögliche Flussunterbrechung'],
  slow_then_fast: ['Slow start, then fast flow', 'Langsamer Start, dann schneller Fluss'], flow_spike: ['Flow spikes', 'Flussspitzen'],
  delayed_ramp_without_prebrew: ['Delayed ramp without configured pre-brewing', 'Verzögerter Anstieg ohne eingestelltes Vorbrühen'],
  unstable_flow: ['Unstable flow', 'Instabiler Fluss'], erratic_flow: ['Irregular flow', 'Unregelmäßiger Fluss'],
  late_acceleration: ['Late flow acceleration', 'Späte Flussbeschleunigung'], below_flow_range: ['Below the flow range', 'Unter dem Flussbereich'],
  prebrew_detected: ['Pre-brewing detected', 'Vorbrühen erkannt'],
  prebrew_setting_mismatch: ['Pre-brewing settings differ', 'Vorbrüh-Einstellungen weichen ab'],
  weight_on_target: ['Yield on target', 'Getränkemenge im Zielbereich'], weight_near_target: ['Yield near target', 'Getränkemenge nahe am Ziel'],
  within_time_window: ['Within time window', 'Im Zeitfenster'], stable_flow: ['Stable flow', 'Stabiler Fluss'],
  grind_finer: ['Grind finer', 'Feiner mahlen'], dose_up: ['Increase the dose', 'Dosis erhöhen'],
  fresher_beans: ['Use fresher beans', 'Frischere Bohnen verwenden'], better_distribution: ['Improve distribution', 'Verteilung verbessern'],
  grind_coarser: ['Grind coarser', 'Gröber mahlen'], dose_down: ['Reduce the dose', 'Dosis reduzieren'],
  clean_basket: ['Clean the basket', 'Sieb reinigen'], rest_beans: ['Let the beans rest', 'Bohnen ruhen lassen'],
  do_wdt: ['Distribute with WDT', 'Mit WDT verteilen'], level_bed: ['Level the coffee bed', 'Kaffeebett ebnen'],
  tamp_straight: ['Tamp level', 'Gerade tampen'], clean_rim: ['Clean the basket rim', 'Siebrand reinigen'],
  reduce_variability: ['Keep preparation consistent', 'Zubereitung vereinheitlichen'], purge_grinder: ['Purge the grinder', 'Mühle kurz spülen'],
  weigh_dose: ['Weigh the dose', 'Dosis wiegen'], standardize_prep: ['Standardize preparation', 'Zubereitung standardisieren'],
  warm_machine: ['Warm the machine', 'Maschine aufwärmen'], dose_check: ['Check the dose', 'Dosis prüfen'],
  reduce_dose: ['Reduce the dose', 'Dosis reduzieren'], clean_machine: ['Clean the machine', 'Maschine reinigen'],
  descale: ['Descale the machine', 'Maschine entkalken'], keep_current_recipe: ['Keep the current recipe.', 'Aktuelles Rezept beibehalten.'],
};
const SHOT_REPORT_SUMMARIES_DE = {
  under_extraction: 'Wahrscheinliche Unterextraktion: Der Shot läuft für das eingestellte Ziel zu schnell.',
  over_extraction: 'Wahrscheinliche Überextraktion: Der Shot läuft langsam oder überschreitet das eingestellte Zeitfenster.',
  channeling: 'Wahrscheinliches Channeling: Der Fluss ist instabil oder beschleunigt nach einem langsamen Start stark.',
  inconsistent_shot: 'Wahrscheinlich unregelmäßige Zubereitung: Die Kurve zeigt starke Schwankungen bei dieser Extraktion.',
  weak_low_crema: 'Muster mit geringem Widerstand / wenig Crema: Der Fluss ist schnell und der Puck bietet wenig Widerstand.',
  choking_no_flow: 'Wahrscheinliche Blockierung: Der Fluss fehlt oder setzt zu lange aus.',
  balanced: 'Der Shot passt zum eingestellten Ziel und Flussmuster.',
};

function shotProfileNote(shot, profiles = []) {
  const profile = shot.settings?.profile || {};
  // An explicitly saved empty note must stay empty after a profile is edited.
  if (typeof profile.comment === 'string') return { text: profile.comment.trim(), current: false };
  const current = profiles.find(p => p.name === shot.profile_name);
  return { text: String(current?.comment || '').trim(), current: true };
}

async function createShotScreenshot({ shot, analysis = null, smoothing = 10, lang = 'en', note = { text: '', current: false } }) {
  if (!shot) throw new Error('Missing shot');
  const t = SHOT_REPORT_TEXT[lang] || SHOT_REPORT_TEXT.en;
  const analysisLabel = key => SHOT_REPORT_ANALYSIS_LABELS[key]?.[lang === 'de' ? 1 : 0] || String(key || '').replace(/_/g, ' ');
  const number = value => value == null || value === '' || !Number.isFinite(Number(value)) ? null : Number(value);
  const fmt = (value, digits = 1) => number(value) == null ? '—' : number(value).toFixed(digits);
  const style = getComputedStyle(document.documentElement);
  // Snapshot colours before awaiting assets: later theme changes cannot mix palettes.
  const c = {};
  for (const key of ['bg','card','inset','border','border-soft','fg','fg-dim','brass','success','success-soft','flow-curve','weight-curve','ideal-curve','grid']) c[key] = style.getPropertyValue('--' + key).trim();
  if (document.fonts) await Promise.all(['14px Inter','42px Fraunces','italic 31px Fraunces','32px "JetBrains Mono"'].map(font => document.fonts.load(font)));
  const logo = new Image();
  const logoLoaded = await new Promise(resolve => {
    const timeout = setTimeout(() => resolve(false), 5000);
    logo.onload = () => { clearTimeout(timeout); resolve(true); };
    logo.onerror = () => { clearTimeout(timeout); resolve(false); };
    logo.src = '/favicon.png';
  });
  const canvas = document.createElement('canvas');
  const scale = 2, width = 1000, margin = 48, inner = width - margin * 2;
  canvas.width = width * scale;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas unavailable');
  const commands = [];
  const fonts = { sans: 'Inter, system-ui, sans-serif', serif: 'Fraunces, Georgia, serif', mono: '"JetBrains Mono", monospace' };
  const font = (size, face = 'sans', italic = false) => (italic ? 'italic ' : '') + size + 'px ' + fonts[face];
  const measure = (value, size = 14, face = 'sans', italic = false) => { ctx.font = font(size, face, italic); return ctx.measureText(String(value)).width; };
  const text = (value, x, y, size = 14, color = c.fg, face = 'sans', align = 'left', italic = false) => commands.push(() => {
    ctx.font = font(size, face, italic); ctx.fillStyle = color; ctx.textAlign = align; ctx.textBaseline = 'top'; ctx.fillText(String(value), x, y);
  });
  const label = (value, x, y, size = 11, align = 'left') => text(String(value).toLocaleUpperCase(lang), x, y, size, c['fg-dim'], 'sans', align);
  const line = (x1, y1, x2, y2, color = c.border) => commands.push(() => { ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.strokeStyle = color; ctx.lineWidth = 1; ctx.stroke(); });
  const box = (x, y, w, h, fill = c.card, radius = 13, border = c.border) => commands.push(() => {
    ctx.beginPath(); ctx.roundRect(x,y,w,h,radius); ctx.fillStyle = fill; ctx.fill(); ctx.strokeStyle = border; ctx.lineWidth = 1; ctx.stroke();
  });
  const wrap = (value, maxWidth, size = 14, face = 'sans') => {
    const lines = [];
    for (const paragraph of String(value || '').split(/\r?\n/)) {
      let current = '';
      for (const word of paragraph.split(/\s+/).filter(Boolean)) {
        if (current && measure(current + ' ' + word, size, face) > maxWidth) { lines.push(current); current = ''; }
        if (measure(word, size, face) > maxWidth) {
          for (const char of Array.from(word)) {
            if (current && measure(current + char, size, face) > maxWidth) { lines.push(current); current = ''; }
            current += char;
          }
        } else current += (current ? ' ' : '') + word;
      }
      lines.push(current);
    }
    return lines;
  };
  const paragraph = (value, x, y, w, size = 14, color = c['fg-dim'], leading = 21, face = 'sans') => {
    const lines = wrap(value,w,size,face); lines.forEach((s,i) => text(s,x,y+i*leading,size,color,face)); return lines.length * leading;
  };
  const date = new Date(shot.started_at);
  const dateText = Number.isNaN(date.getTime()) ? '—' : date.toLocaleString(lang === 'de' ? 'de-DE' : 'en-GB', {
    day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',timeZoneName:'short',
  });
  if (logoLoaded) commands.push(() => ctx.drawImage(logo,margin,40,34,34));
  const brandX = margin + (logoLoaded ? 45 : 0);
  text('shot',brandX,36,31,c.brass,'serif','left',true);
  text('deck',brandX+measure('shot',31,'serif',true),36,31,c.fg,'serif');
  label(t.report + ' #' + shot.id,width-margin,42,11,'right');
  text(dateText,width-margin,65,13,c['fg-dim'],'sans','right');
  line(margin,108,width-margin,108);

  const profile = shot.settings?.profile || {};
  const machine = shot.settings?.machine?.machine || {};
  const machineName = machine.name || machine.model_name || '';
  let y = 137;
  label(t.espresso,margin,y);
  const titleHeight = paragraph(shot.profile_name || '—',margin,y+22,550,42,c.fg,50,'serif');
  const roast = t.roasts[shot.roast] || shot.roast || '';
  const subtitleHeight = paragraph([roast,shot.user_name ? t.brewed + ' ' + shot.user_name : ''].filter(Boolean).join(' · '),margin,y+24+titleHeight,550,14);
  let machineHeight = 0;
  if (machineName) {
    label(t.machine,700,y+10);
    machineHeight = paragraph(machineName,700,y+33,252,15,c.fg);
  }
  const mode = profile.brew_control_mode;
  const modeY = Math.max(75,33+machineHeight+8);
  if (mode === 'weight' || mode === 'time') text(mode === 'time' ? t.timeMode : t.weightMode,700,y+modeY,13,c['fg-dim']);
  y += Math.max(modeY+35,24+titleHeight+subtitleHeight+24);
  if (note.text) {
    const noteLines = wrap(note.text,inner-48,14), h = 48+noteLines.length*21;
    box(margin,y,inner,h,c.card);
    label(note.current ? t.currentNote : t.note,margin+24,y+16,10);
    noteLines.forEach((s,i) => text(s,margin+24,y+36+i*21,14,c['fg-dim']));
    y += h+22;
  }
  const target = number(shot.target_weight_g), final = number(shot.final_weight_g);
  const delta = final != null && target > 0 ? final-target : null;
  const deltaText = delta == null ? '' : ' · ' + (Math.round(delta*10) > 0 ? '+' : Math.round(delta*10) < 0 ? '−' : '±') + Math.abs(delta).toFixed(1) + ' g';
  const timeWindow = number(shot.target_time_min_s) != null && number(shot.target_time_max_s) > 0 ? fmt(shot.target_time_min_s,0)+'–'+fmt(shot.target_time_max_s,0)+' s' : '—';
  const metrics = [
    [t.yield,fmt(final),'g',t.target+' '+fmt(target)+' g'+deltaText],
    [t.duration,fmt(shot.duration_s),'s',t.target+' '+timeWindow],
    [t.average,fmt(shot.average_flow_g_s,2),'g/s',t.flowNote],
    [t.temperature,fmt(profile.coffee_target_temperature_c,0),'°C',t.tempNote],
  ];
  const metricWidth = inner/4;
  const metricHeight = Math.max(...metrics.map(m => wrap(m[3],metricWidth-44,11).length))*17+104;
  box(margin,y,inner,metricHeight);
  metrics.forEach(([name,value,unit,noteText],i) => {
    const x = margin+i*metricWidth+22;
    if (i) line(x-22,y,x-22,y+metricHeight);
    label(name,x,y+20,10);
    text(value,x,y+46,32,c.fg,'mono');
    text(unit,x+measure(value,32,'mono')+7,y+62,15,c['fg-dim']);
    if (i===0 && delta!=null && wrap(noteText,metricWidth-44,11).length===1) {
      const targetText=t.target+' '+fmt(target)+' g';
      text(targetText,x,y+92,11,c['fg-dim']);
      text(deltaText,x+measure(targetText,11),y+92,11,Math.abs(Math.round(delta*10)/10)<=0.2?c.success:c['fg-dim']);
    } else paragraph(noteText,x,y+92,metricWidth-44,11,c['fg-dim'],17);
  });
  y += metricHeight+22;
  const doseRaw = number(shot.grinder_telemetry?.grind?.grind_weight);
  const dose = doseRaw > 0 ? doseRaw/1000 : null;
  const recipe = [];
  if (dose != null) {
    recipe.push([t.dose,fmt(dose)+' g']);
    if (final > 0) recipe.push([t.ratio,'1 : '+fmt(final/dose,2)]);
  }
  const prebrewMode = profile.prebrew_mode;
  const prebrewText = prebrewMode === 'prebrewing'
    ? fmt(profile.prebrew_seconds_on)+' s '+t.on+' / '+fmt(profile.prebrew_seconds_off)+' s '+t.pause
    : prebrewMode === 'disabled' ? t.off : prebrewMode === 'no_change' ? t.unchanged : '—';
  recipe.push([t.prebrew,prebrewText],[t.window,timeWindow]);
  const recipeWidth = inner/recipe.length;
  let recipeHeight = 0;
  recipe.forEach(([name,value],i) => {
    const x = margin+i*recipeWidth;
    label(name,x,y,10);
    recipeHeight = Math.max(recipeHeight,paragraph(value,x,y+22,recipeWidth-16,13,c.fg,19,'mono'));
  });
  y += 22+recipeHeight+25;

  const samples = (shot.samples || []).filter(s => [s.time_s,s.weight_g,s.flow_g_s].every(v => number(v) != null)).slice().sort((a,b) => a.time_s-b.time_s);
  const ideal = profile.ideal_flow_enabled ? (profile.ideal_flow_profile || []).filter(s => number(s.time_s) != null && number(s.flow_g_s) != null) : [];
  const chartY = y;
  box(margin,y,inner,374,c.inset);
  text(t.curve,margin+24,y+22,22,c.fg,'serif');
  const legend = [[t.flow,c['flow-curve'],false],[t.weight,c['weight-curve'],false],...(ideal.length>1?[[t.ideal,c['ideal-curve'],true]]:[])];
  let lx = width-margin-24-legend.reduce((sum,[name]) => sum+measure(name,11)+41,0);
  legend.forEach(([name,color,dashed]) => {
    const x = lx;
    commands.push(() => { ctx.save(); ctx.setLineDash(dashed?[5,4]:[]); ctx.strokeStyle=color; ctx.lineWidth=2; ctx.beginPath();ctx.moveTo(x,chartY+35);ctx.lineTo(x+17,chartY+35);ctx.stroke();ctx.restore(); });
    text(name,lx+23,y+29,11,c['fg-dim']); lx += measure(name,11)+41;
  });
  const smoothingSize = Math.max(1,parseInt(smoothing,10)||1);
  text(t.smoothing+': '+(smoothingSize===1?t.off:smoothingSize+' '+t.samples),margin+27,y+347,10,c['fg-dim']);
  text(t.time,width-margin-27,y+347,10,c['fg-dim'],'sans','right');
  commands.push(() => {
    ctx.save(); ctx.translate(margin+24,chartY+64);
    const w = inner-48, h = 272, left = 43, right = 45, top = 25, bottom = 32;
    const plotW = w-left-right, plotH = h-top-bottom;
    if (!samples.length) {ctx.font=font(14);ctx.fillStyle=c['fg-dim'];ctx.textAlign='center';ctx.fillText(t.noSamples,w/2,h/2);ctx.restore();return;}
    const duration = Math.max(5,Math.ceil(samples[samples.length-1].time_s/5)*5);
    const maxWeight = Math.max(10,Math.ceil(((final != null && final>=0?final:Math.max(...samples.map(s=>Number(s.weight_g))))+4)/10)*10);
    const x = time => left+Number(time)/duration*plotW;
    const yf = flow => top+plotH-Number(flow)/4*plotH;
    const yw = weight => top+plotH-Number(weight)/maxWeight*plotH;
    ctx.font=font(11,'mono');ctx.textBaseline='top';ctx.textAlign='left';ctx.fillStyle=c['flow-curve'];ctx.fillText(t.flow+' · g/s',left,0);
    ctx.textAlign='right';ctx.fillStyle=c['weight-curve'];ctx.fillText(t.weight+' · g',w-right,0);
    for(let i=0;i<=4;i++){
      const gy=yf(i);ctx.beginPath();ctx.moveTo(left,gy);ctx.lineTo(w-right,gy);ctx.strokeStyle=c.grid;ctx.lineWidth=1;ctx.stroke();
      ctx.fillStyle=c['fg-dim'];ctx.textAlign='right';ctx.fillText(String(i),left-14,gy-5);ctx.textAlign='left';ctx.fillText(String(maxWeight*i/4),w-right+14,gy-5);
    }
    const timeStep = Math.max(5,Math.ceil(duration/30)*5);
    for(let time=0;time<=duration;time+=timeStep){
      ctx.save();ctx.setLineDash([2,5]);ctx.beginPath();ctx.moveTo(x(time),top);ctx.lineTo(x(time),h-bottom);ctx.strokeStyle=c.grid;ctx.stroke();ctx.restore();
      ctx.textAlign='center';ctx.fillStyle=c['fg-dim'];ctx.fillText(time+' s',x(time),h-bottom+14);
    }
    ctx.beginPath();ctx.rect(left,top,plotW,plotH);ctx.clip();
    const curve = (rows,key,axis) => rows.forEach((s,i) => {if(i)ctx.lineTo(x(s.time_s),axis(s[key]));else ctx.moveTo(x(s.time_s),axis(s[key]));});
    const flow = smoothFlowSamples(samples,smoothingSize);
    const gradient=ctx.createLinearGradient(0,top,0,h-bottom);gradient.addColorStop(0,c['flow-curve']+'33');gradient.addColorStop(1,c['flow-curve']+'00');
    ctx.beginPath();curve(flow,'flow_g_s',yf);ctx.lineTo(x(flow[flow.length-1].time_s),h-bottom);ctx.lineTo(x(flow[0].time_s),h-bottom);ctx.closePath();ctx.fillStyle=gradient;ctx.fill();
    ctx.lineJoin='round';ctx.lineCap='round';
    if(ideal.length>1){ctx.save();ctx.setLineDash([6,5]);ctx.beginPath();curve(ideal,'flow_g_s',yf);ctx.strokeStyle=c['ideal-curve'];ctx.lineWidth=2;ctx.stroke();ctx.restore();}
    ctx.beginPath();curve(samples,'weight_g',yw);ctx.strokeStyle=c['weight-curve'];ctx.lineWidth=2;ctx.stroke();
    ctx.beginPath();curve(flow,'flow_g_s',yf);ctx.strokeStyle=c['flow-curve'];ctx.lineWidth=2.6;ctx.stroke();ctx.restore();
  });
  y += 396;
  if (analysis) {
    const start = y;
    // Reserve the panel background first; its measured height is filled below.
    let panelHeight;
    commands.push(() => { ctx.beginPath();ctx.roundRect(margin,start,inner,panelHeight,13);ctx.fillStyle=c.card;ctx.fill();ctx.strokeStyle=c.border;ctx.stroke(); });
    label(t.analysis,margin+24,y+23);
    const title = lang === 'de' ? analysisLabel(analysis.primary_issue) : analysis.label || analysisLabel(analysis.primary_issue);
    const titleH = paragraph(title,margin+24,y+46,inner-280,27,c.fg,34,'serif');
    const confidence = Math.round(Math.max(0,Math.min(1,number(analysis.confidence)||0))*100)+'% '+t.confidence;
    const badgeWidth = measure(confidence,11)+36;
    box(width-margin-24-badgeWidth,y+33,badgeWidth,32,c['success-soft'],16);
    text(confidence,width-margin-24-badgeWidth/2,y+43,11,c.success,'sans','center');
    y += 56+titleH;
    const summary = lang === 'de' ? SHOT_REPORT_SUMMARIES_DE[analysis.primary_issue] || (analysis.primary_issue==='unknown'?'Für eine Analyse sind nicht genügend Messwerte vorhanden.':analysis.summary) : analysis.summary;
    if (summary) y += paragraph(summary,margin+24,y,inner-48,13,c['fg-dim'],21)+15;
    const prebrew = analysis.prebrewing || {};
    if (Object.keys(prebrew).length) {
      const state = [prebrew.detected?t.detected:t.notDetected,prebrew.unknown?t.unknown:prebrew.configured?(prebrew.match?t.match:t.mismatch):''].filter(Boolean).join(' · ');
      y += paragraph(t.prebrew+': '+state,margin+24,y,inner-48,12,c['fg-dim'],19)+15;
    }
    if (analysis.evidence?.length) {
      label(t.evidence,margin+24,y,10);y += 23;
      for(let i=0;i<analysis.evidence.length;i+=2){
        let rowH=0;
        for(let j=0;j<2&&i+j<analysis.evidence.length;j++){
          const x=margin+24+j*(inner-48)/2;
          text('•',x,y,14,c.brass);
          rowH=Math.max(rowH,paragraph(analysisLabel(analysis.evidence[i+j]),x+17,y,(inner-48)/2-32,12,c['fg-dim'],19));
        }
        y += rowH+8;
      }
    }
    if (analysis.recommendations?.length) {
      line(margin+24,y+8,width-margin-24,y+8,c['border-soft']);y += 25;
      label(t.recommend,margin+24,y,10);y += 23;
      y += paragraph(analysis.recommendations.map(analysisLabel).join(' · '),margin+24,y,inner-48,13,c.fg,21);
    }
    if (analysis.secondary_issues?.length) {
      y += 16;label(t.secondary,margin+24,y,10);y += 23;
      y += paragraph(analysis.secondary_issues.map(issue=>analysisLabel(issue.issue)).join(' · '),margin+24,y,inner-48,12,c['fg-dim'],19);
    }
    y += 24;panelHeight=y-start;y += 22;
  }
  label(t.recorded,margin,y+5,9);
  text('#'+shot.id,width-margin,y+5,10,c['fg-dim'],'mono','right');
  canvas.height = Math.ceil(y+42)*scale;
  ctx.setTransform(scale,0,0,scale,0,0);ctx.fillStyle=c.bg;ctx.fillRect(0,0,width,canvas.height/scale);
  commands.forEach(draw => draw());
  return canvas;
}

async function saveShotScreenshot(options) {
  const canvas = await createShotScreenshot(options);
  const blob = await new Promise((resolve,reject) => canvas.toBlob(value => value ? resolve(value) : reject(new Error('PNG export failed')), 'image/png'));
  const date = new Date(options.shot.started_at);
  const pad = value => String(value).padStart(2,'0');
  const stamp = Number.isNaN(date.getTime()) ? 'undated' : date.getFullYear()+'-'+pad(date.getMonth()+1)+'-'+pad(date.getDate())+'-'+pad(date.getHours())+pad(date.getMinutes());
  const url = URL.createObjectURL(blob), link = document.createElement('a');
  link.href=url;link.download='shotdeck-shot-'+options.shot.id+'-'+stamp+'.png';
  try {document.body.appendChild(link);link.click();} finally {link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
}

Object.assign(window,{createShotScreenshot,saveShotScreenshot,shotProfileNote});
