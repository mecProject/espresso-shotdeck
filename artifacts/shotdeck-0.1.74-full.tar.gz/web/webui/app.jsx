// ============================================================
// Shotdeck — main App: state, routing, mutations
// ============================================================
const { useState: uS, useEffect: uE, useRef: uR } = React;

function deepCopy(o) { return JSON.parse(JSON.stringify(o)); }
function initialLang() {
  const url = new URLSearchParams(window.location.search || '');
  const candidate = url.get('lang') || window.localStorage.getItem('sd_lang') || navigator.language || 'en';
  return String(candidate).toLowerCase().indexOf('de') === 0 ? 'de' : 'en';
}

function noticeKey(notice) {
  return `${String((notice && notice.id) || '')}:${Number((notice && notice.revision) || 1)}`;
}

function loadLegacyDismissedNotices() {
  try {
    const value = JSON.parse(window.localStorage.getItem('sd_dismissed_notices') || '{}');
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch (_) {
    return {};
  }
}

function localizedNoticeText(notice, field, lang) {
  if (!notice) return '';
  const localized = lang === 'de' ? notice[field + '_de'] : notice[field];
  return String(localized || notice[field] || '').trim();
}

function CustomerNoticeBanner({ notice, lang, onDismiss, dismissing = false }) {
  const [expanded, setExpanded] = uS(false);
  const [messageOverflows, setMessageOverflows] = uS(false);
  const messageRef = uR(null);
  const key = noticeKey(notice);

  uE(() => {
    setExpanded(false);
    setMessageOverflows(false);
  }, [key]);

  const message = localizedNoticeText(notice, 'message', lang);
  uE(() => {
    const element = messageRef.current;
    if (!element || expanded) return undefined;
    const measure = () => setMessageOverflows(element.scrollHeight > element.clientHeight + 1);
    measure();
    window.addEventListener('resize', measure);
    const observer = typeof ResizeObserver === 'undefined' ? null : new ResizeObserver(measure);
    if (observer) observer.observe(element);
    return () => {
      window.removeEventListener('resize', measure);
      if (observer) observer.disconnect();
    };
  }, [key, message, expanded]);

  if (!notice) return null;
  const severity = ['info', 'warning', 'critical'].includes(notice.severity) ? notice.severity : 'info';
  const title = localizedNoticeText(notice, 'title', lang);
  const dismissible = notice.dismissible !== false;
  const messageId = `sd-customer-notice-message-${key.replace(/[^a-zA-Z0-9_-]/g, '-')}`;
  const moreLabel = lang === 'de' ? 'Mehr anzeigen' : 'Show more';
  const lessLabel = lang === 'de' ? 'Weniger anzeigen' : 'Show less';
  return (
    <section
      className={'sd-customer-notice ' + severity}
      role={severity === 'critical' ? 'alert' : 'status'}
      aria-live={severity === 'critical' ? 'assertive' : 'polite'}>
      <div className="sd-customer-notice-copy">
        <strong>{title}</strong>
        {message && (
          <span
            id={messageId}
            ref={messageRef}
            className={'sd-customer-notice-message' + (expanded ? ' expanded' : '')}>
            {message}
          </span>
        )}
        {messageOverflows && (
          <button
            type="button"
            className="sd-customer-notice-more"
            aria-controls={messageId}
            aria-expanded={expanded}
            onClick={() => setExpanded(value => !value)}>
            {expanded ? lessLabel : moreLabel}
          </button>
        )}
      </div>
      {dismissible && (
        <button disabled={dismissing} onClick={() => onDismiss(notice)} aria-label={tr('dismiss')} title={tr('dismiss')}>
          <Icon name="close" size={18} />
        </button>
      )}
    </section>
  );
}

const INITIAL_LANG = initialLang();
window.__sdLang = INITIAL_LANG;

function App() {
  const [lang, setLangState] = uS(INITIAL_LANG);
  const [theme, setThemeState] = uS('espresso_dark');
  const [tab, setTab] = uS('brew');
  const [data, setData] = uS(null);
  const [loadErr, setLoadErr] = uS(false);
  const [helpSection, setHelpSection] = uS(null);
  const [feedbackShot, setFeedbackShot] = uS(null);
  const [diag, setDiag] = uS(false);
  const [toastMsg, setToastMsg] = uS(null);
  const [brewState, setBrewState] = uS(null);
  const [brewConfirm, setBrewConfirm] = uS(null);
  const [updateModal, setUpdateModal] = uS(null);
  const [openShotId, setOpenShotId] = uS(null);
  const [dismissingNotices, setDismissingNotices] = uS({});
  const legacyNoticeDismissals = uR(null);
  if (legacyNoticeDismissals.current === null) legacyNoticeDismissals.current = loadLegacyDismissedNotices();
  const noticeDismissalsPending = uR(new Set());
  const toastTimer = uR(null);
  const prevShotActive = uR(false);
  const updateAutoCheckStarted = uR(false);
  const statusRequestStarted = uR(0);
  const statusRequestApplied = uR(0);
  const notificationRequestStarted = uR(0);
  const notificationRequestApplied = uR(0);
  const displayBrightnessTimer = uR(null);
  const displayBrightnessPending = uR(null);
  const displayBrightnessPreview = uR(null);
  const displayBrightnessConfirmed = uR(null);
  const displayBrightnessPointerActive = uR(false);
  const displayBrightnessCommitRequested = uR(false);
  const displayBrightnessRequestActive = uR(false);

  // sync globals for tr() + ApiChip
  uE(() => { window.__sdLang = lang; }, [lang]);
  uE(() => { window.__sdApi = false; }, []);
  uE(() => { document.documentElement.setAttribute('data-theme', theme); }, [theme]);
  uE(() => { window.__sdLang = lang; document.documentElement.setAttribute('data-theme', theme); }, []);

  // ---- bootstrap: load real state from GET /api/status ----
  const boot = () => {
    setLoadErr(false);
    const requestId = ++statusRequestStarted.current;
    api('/api/status').then(d => {
      if (requestId < statusRequestApplied.current) return;
      statusRequestApplied.current = requestId;
      // A full status snapshot is authoritative. Ignore any lightweight notice
      // request that was already in flight when this snapshot was applied.
      notificationRequestApplied.current = notificationRequestStarted.current;
      setData(d);
      const initialBrightness = d && d.settings && d.settings.display
        ? Number(d.settings.display.brightness)
        : NaN;
      if (Number.isFinite(initialBrightness)) displayBrightnessConfirmed.current = initialBrightness;
      const t = d && d.settings && d.settings.display && d.settings.display.theme;
      if (t) setThemeState(t);
    }).catch(() => setLoadErr(true));
  };
  uE(() => { boot(); }, []);

  const refresh = async () => {
    const requestId = ++statusRequestStarted.current;
    try {
      const d = await api('/api/status');
      if (requestId < statusRequestApplied.current) return;
      statusRequestApplied.current = requestId;
      notificationRequestApplied.current = notificationRequestStarted.current;
      const acceptedBrightness = d && d.settings && d.settings.display
        ? Number(d.settings.display.brightness)
        : NaN;
      if (
        displayBrightnessPreview.current === null
        && Number.isFinite(acceptedBrightness)
      ) {
        displayBrightnessConfirmed.current = acceptedBrightness;
      }
      if (
        displayBrightnessPreview.current !== null
        && d && d.settings && d.settings.display
      ) {
        // A status poll may overlap a slider gesture or its final PATCH. Keep
        // the optimistic final value visible until the device has accepted it.
        d.settings.display.brightness = displayBrightnessPreview.current;
      }
      setData(d);
    } catch (e) {
      toast(e.message);
    }
  };

  const toast = (msg) => {
    setToastMsg(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastMsg(null), 1900);
  };
  const updateLocal = (fn) => setData(d => { const c = deepCopy(d); fn(c); return c; });

  const mergeNotifications = (payload, requestId) => {
    if (!payload) return;
    setData(current => {
      if (!current || requestId <= notificationRequestApplied.current) return current;
      notificationRequestApplied.current = requestId;
      const settings = (
        typeof payload.shot_active === 'boolean' && current.settings
          ? { ...current.settings, shot_active: payload.shot_active }
          : current.settings
      );
      return { ...current, notifications: payload, settings };
    });
  };

  // Notices are a lightweight local feed. Polling it also lets an idle web
  // client notice a physical-paddle brew without reloading all shot history.
  uE(() => {
    let cancelled = false;
    const load = () => {
      const requestId = ++notificationRequestStarted.current;
      return api('/api/notifications')
        .then(payload => { if (!cancelled) mergeNotifications(payload, requestId); })
        .catch(() => null);
    };
    const onVisibility = () => { if (document.visibilityState === 'visible') load(); };
    const id = setInterval(load, 5000);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      cancelled = true;
      clearInterval(id);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, []);

  const dismissNotice = async (notice, legacy = false) => {
    const key = noticeKey(notice);
    if (notice.dismissible === false || noticeDismissalsPending.current.has(key)) return;
    noticeDismissalsPending.current.add(key);
    setDismissingNotices(current => ({ ...current, [key]: true }));
    try {
      const payload = await api('/api/notifications/dismiss', {
        method: 'POST',
        body: JSON.stringify({ id: notice.id, revision: notice.revision }),
      });
      // Neither an older status response nor an older notice poll may restore
      // a notice after the device has durably acknowledged its dismissal.
      statusRequestApplied.current = ++statusRequestStarted.current;
      mergeNotifications(payload, ++notificationRequestStarted.current);
      delete legacyNoticeDismissals.current[key];
      try {
        window.localStorage.setItem('sd_dismissed_notices', JSON.stringify(legacyNoticeDismissals.current));
      } catch (_) {}
    } catch (_) {
      if (!legacy) toast(tr('notice_dismiss_failed'));
    } finally {
      noticeDismissalsPending.current.delete(key);
      setDismissingNotices(current => {
        const next = { ...current };
        delete next[key];
        return next;
      });
    }
  };

  // Older releases saved web closes only in this browser. Transfer matching
  // current revisions to Shotdeck when that browser next opens the app.
  uE(() => {
    const items = (((data || {}).notifications || {}).items) || [];
    const legacy = items.filter(notice => notice.dismissible !== false && legacyNoticeDismissals.current[noticeKey(notice)] === true);
    if (!legacy.length) return;
    (async () => { for (const notice of legacy) await dismissNotice(notice, true); })();
  }, [data && data.notifications]);

  const mergeUpdateStatus = (status) => {
    if (!status) return;
    updateLocal(c => {
      if (!c.settings.updates) c.settings.updates = {};
      c.settings.updates.status = status;
      c.settings.updates.updates_enabled = status.updates_enabled;
      c.settings.updates.auto_update = status.auto_update;
      c.settings.updates.beta_updates = status.beta_updates;
    });
  };

  const loadUpdateStatus = async () => {
    const status = await api('/api/updates');
    mergeUpdateStatus(status);
    return status;
  };

  const patchSettings = async (partial) => {
    try {
      await api('/api/settings', { method: 'PATCH', body: JSON.stringify(partial) });
      await refresh();
    } catch (e) {
      toast(e.message);
    }
  };

  const drainDisplayBrightness = async () => {
    clearTimeout(displayBrightnessTimer.current);
    displayBrightnessTimer.current = null;
    if (displayBrightnessPending.current === null) {
      displayBrightnessCommitRequested.current = false;
      return;
    }
    if (
      displayBrightnessRequestActive.current
      || !displayBrightnessCommitRequested.current
    ) return;

    const brightness = displayBrightnessPending.current;
    displayBrightnessPending.current = null;
    displayBrightnessCommitRequested.current = false;
    displayBrightnessRequestActive.current = true;
    let failed = false;
    try {
      // Brightness is previewed locally while the slider moves. Commit only
      // the newest value and do not follow it with a full status request.
      await api('/api/settings', {
        method: 'PATCH',
        body: JSON.stringify({ display: { brightness } }),
      });
      displayBrightnessConfirmed.current = brightness;
      if (displayBrightnessPending.current === null) {
        // Reject every status request that began before this PATCH completed,
        // then fetch one authoritative post-commit snapshot before removing
        // the optimistic preview.
        statusRequestApplied.current = Math.max(
          statusRequestApplied.current,
          statusRequestStarted.current + 1,
        );
        await refresh();
      }
    } catch (e) {
      failed = true;
      toast(e.message);
    } finally {
      displayBrightnessRequestActive.current = false;
      if (
        displayBrightnessCommitRequested.current
        && displayBrightnessPending.current !== null
      ) {
        drainDisplayBrightness();
      } else if (displayBrightnessPending.current === null) {
        if (failed) {
          const confirmed = displayBrightnessConfirmed.current;
          displayBrightnessPreview.current = null;
          if (confirmed !== null) {
            updateLocal(c => { c.settings.display.brightness = confirmed; });
          }
          refresh();
        } else if (displayBrightnessPreview.current === brightness) {
          displayBrightnessPreview.current = null;
        }
      }
    }
  };

  const flushDisplayBrightness = () => {
    displayBrightnessPointerActive.current = false;
    clearTimeout(displayBrightnessTimer.current);
    displayBrightnessTimer.current = null;
    if (displayBrightnessPending.current === null) {
      displayBrightnessCommitRequested.current = false;
      return;
    }
    displayBrightnessCommitRequested.current = true;
    drainDisplayBrightness();
  };

  const beginDisplayBrightness = (event) => {
    displayBrightnessPointerActive.current = true;
    displayBrightnessCommitRequested.current = false;
    clearTimeout(displayBrightnessTimer.current);
    displayBrightnessTimer.current = null;
    const target = event && event.currentTarget;
    if (
      target && typeof target.setPointerCapture === 'function'
      && event.pointerId !== undefined
    ) {
      try { target.setPointerCapture(event.pointerId); } catch (_) {}
    }
  };

  const setDisplayBrightness = (value) => {
    const brightness = Math.max(10, Math.min(100, Math.round(Number(value) || 0)));
    // A newer input supersedes any earlier queued commit that is still waiting
    // behind an in-flight request. Its own release/debounce will re-arm it.
    displayBrightnessCommitRequested.current = false;
    displayBrightnessPreview.current = brightness;
    displayBrightnessPending.current = brightness;
    updateLocal(c => { c.settings.display.brightness = brightness; });
    clearTimeout(displayBrightnessTimer.current);
    // Pointer drags are committed only once on release. The trailing debounce
    // handles keyboard changes, where no pointer gesture is active.
    if (!displayBrightnessPointerActive.current) {
      displayBrightnessTimer.current = setTimeout(flushDisplayBrightness, 250);
    }
  };

  uE(() => {
    if (!data || !data.settings) return;
    const active = !!data.settings.shot_active;
    if (active) {
      setBrewConfirm(null);
      setBrewState(s => (s && s.phase === 'live') ? s : {
        phase: 'live',
        profileIdx: ((data.profiles || []).find(p => p.selected) || data.profiles[0] || {}).index || 0,
        startedAt: Date.now(),
      });
    } else {
      setBrewState(s => (s && s.phase === 'live') ? null : s);
      if (prevShotActive.current) {
        setTimeout(refresh, 900);
      }
    }
    prevShotActive.current = active;
  }, [data && data.settings && data.settings.shot_active]);

  uE(() => {
    if (!data || !data.settings || !data.settings.shot_active) return;
    const id = setInterval(refresh, 500);
    return () => clearInterval(id);
  }, [data && data.settings && data.settings.shot_active]);

  const updatesEnabled = !!(data && data.settings && data.settings.updates && data.settings.updates.updates_enabled);
  const updateState = (data && data.settings && data.settings.updates && data.settings.updates.status && data.settings.updates.status.state) || 'unknown';

  // Queue at most one freshness-aware check per application load. The server
  // coalesces it with timer, touch-screen, and other browser requests.
  uE(() => {
    if (!updatesEnabled || updateAutoCheckStarted.current) return;
    updateAutoCheckStarted.current = true;
    api('/api/updates/check', { method: 'POST', body: JSON.stringify({ force: false }) })
      .then(mergeUpdateStatus)
      .catch(() => {});
  }, [updatesEnabled]);

  // Busy state is persisted by the device, so polling can continue across the
  // expected temporary disconnect while shotdeck.service restarts.
  uE(() => {
    if (!['checking', 'queued', 'installing'].includes(updateState)) return;
    let cancelled = false;
    const id = setInterval(() => {
      if (!cancelled) loadUpdateStatus().catch(() => null);
    }, 1500);
    return () => { cancelled = true; clearInterval(id); };
  }, [updateState]);

  // ---- real brew controls ----
  const brew = {
    state: brewState,
    confirm: (profileIdx) => setBrewConfirm({ profileIdx }),
    closeConfirm: () => setBrewConfirm(null),
    setConfirmProfile: (profileIdx) => {
      setBrewConfirm({ profileIdx });
    },
    start: async (profileIdx) => {
      try {
        await api('/api/brew/start', { method: 'POST', body: JSON.stringify({ profile_index: profileIdx }) });
        setBrewConfirm(null);
        await refresh();
      } catch (e) { toast(e.message); }
    },
    stop: async () => {
      try {
        await api('/api/brew/stop', { method: 'POST', body: JSON.stringify({}) });
        await refresh();
      } catch (e) { toast(e.message); }
    },
  };

  // ---- app object passed to screens ----
  const setLang = (l) => {
    window.__sdLang = l;
    window.localStorage.setItem('sd_lang', l);
    setLangState(l);
  };
  const app = {
    lang, theme, data, brew, brewConfirm, updateModal, openShotId,
    refresh,
    setLang,
    toggleLang: () => setLang(lang === 'en' ? 'de' : 'en'),
    setTheme: (t) => { document.documentElement.setAttribute('data-theme', t); setThemeState(t); patchSettings({ display: { theme: t } }); },
    toast,
    openHelp: (s) => setHelpSection(s),
    helpSection,
    openFeedback: (id) => setFeedbackShot(id),
    closeFeedback: () => setFeedbackShot(null),
    feedbackShot,
    openDiag: () => setDiag(true),
    closeDiag: () => setDiag(false),
    openShot: (id) => { setOpenShotId(id); setTab('shots'); },
    go: setTab,
    checkUpdates: async (force = true) => {
      try {
        const status = await api('/api/updates/check', {
          method: 'POST', body: JSON.stringify({ force }),
        });
        mergeUpdateStatus(status);
        return status;
      } catch (e) { toast(e.message); return null; }
    },
    openUpdateInstall: () => {
      const status = data.settings.updates.status || {};
      if (status.target_version) {
        setUpdateModal({ phase: 'confirm', targetVersion: status.target_version });
      }
    },
    closeUpdateInstall: () => setUpdateModal(null),
    installUpdate: async () => {
      const status = data.settings.updates.status || {};
      const targetVersion = (updateModal && updateModal.targetVersion) || status.target_version;
      if (!targetVersion) return;
      setUpdateModal({ phase: 'progress', targetVersion });
      try {
        const next = await api('/api/updates/install', {
          method: 'POST', body: JSON.stringify({ target_version: targetVersion }),
        });
        mergeUpdateStatus(next);
      } catch (e) {
        toast(e.message);
        setUpdateModal(null);
        loadUpdateStatus().catch(() => null);
      }
    },
    // profile mutations
    selectProfile: async (i) => {
      try { await api('/api/profiles/' + i, { method: 'PATCH', body: JSON.stringify({}) }); await refresh(); }
      catch (e) { toast(e.message); }
    },
    saveProfile: async (i, d) => {
      const body = {
        name: d.name, comment: d.comment || '', roast: d.roast, intelligence_mode: d.intelligence_mode,
        brew_control_mode: d.brew_control_mode,
        target_stop_time_s: d.target_stop_time_s,
        target_weight_g: d.target_weight_g, target_time_min_s: d.target_time_min_s, target_time_max_s: d.target_time_max_s,
        temperature_targets_enabled: d.temperature_targets_enabled,
        coffee_target_temperature_c: d.coffee_target_temperature_c,
        steam_target_temperature_c: d.steam_target_temperature_c,
        steam_target_level: d.steam_target_level,
        ideal_flow_enabled: d.ideal_flow_enabled,
        ideal_flow_profile: (d.ideal_flow_profile || []).map(r => ({ time_s: r.time_s, flow_g_s: r.flow_g_s, gradient_g_s2: r.gradient_g_s2 })),
        ideal_flow_profile_mode: 'flow',
        live_flow_smoothing_samples: d.live_flow_smoothing_samples,
        prebrew_preference: {
          enabled: !!(d.prebrew_preference && d.prebrew_preference.enabled),
          controller: d.prebrew_preference && d.prebrew_preference.controller === 'shotdeck' ? 'shotdeck' : 'lamarzocco',
        },
        prebrew_mode: d.prebrew_mode === 'prebrewing' ? 'prebrewing' : 'no_change',
        prebrew_seconds_on: d.prebrew_seconds_on, prebrew_seconds_off: d.prebrew_seconds_off,
        shotdeck_prebrew: {
          enabled: !!(d.prebrew_preference && d.prebrew_preference.enabled && d.prebrew_preference.controller === 'shotdeck'),
          pump_s: Number(d.shotdeck_prebrew && d.shotdeck_prebrew.pump_s || 2),
          pause_s: Number((d.shotdeck_prebrew && d.shotdeck_prebrew.pause_s) ?? 3),
        },
        color: d.color,
      };
      try { await api('/api/profiles/' + i, { method: 'PATCH', body: JSON.stringify(body) }); await refresh(); toast(tr('saved_toast')); }
      catch (e) { toast(e.message); }
    },
    addProfile: async () => {
      try { await api('/api/profiles', { method: 'POST', body: JSON.stringify({ name: tr('default_profile_name'), roast: 'MR' }) }); await refresh(); }
      catch (e) { toast(e.message); }
    },
    deleteProfile: async (i) => {
      if (!window.confirm(tr('delete_profile_confirm'))) return false;
      try {
        const result = await api('/api/profiles/' + i, { method: 'DELETE' });
        await refresh();
        toast(result && result.archived ? tr('archived') : tr('deleted'));
        return true;
      }
      catch (e) { toast(e.message); return false; }
    },
    restoreProfile: async (i) => {
      try { await api('/api/profiles/' + i, { method: 'PATCH', body: JSON.stringify({ archived: false }) }); await refresh(); toast(tr('saved_toast')); }
      catch (e) { toast(e.message); }
    },
    // users
    setActiveUser: async (id) => {
      try { await api('/api/users/active', { method: 'POST', body: JSON.stringify({ id }) }); await refresh(); }
      catch (e) { toast(e.message); }
    },
    deleteUser: async (id) => {
      try {
        const result = await api('/api/users/' + encodeURIComponent(id), { method: 'DELETE' });
        await refresh();
        toast(result && result.archived ? tr('archived') : tr('deleted'));
        return true;
      }
      catch (e) { toast(e.message); return false; }
    },
    restoreUser: async (id) => {
      try { await api('/api/users/' + encodeURIComponent(id), { method: 'PATCH', body: JSON.stringify({ archived: false }) }); await refresh(); toast(tr('saved_toast')); }
      catch (e) { toast(e.message); }
    },
    saveUser: async (id, d) => {
      try {
        await api('/api/users/' + encodeURIComponent(id), {
          method: 'PATCH',
          body: JSON.stringify({ name: d.name, color: d.color }),
        });
        await refresh();
        toast(tr('saved_toast'));
      } catch (e) { toast(e.message); }
    },
    addUser: async () => {
      const n = (data.users && data.users.items ? data.users.items.length : 0) + 1;
      try { await api('/api/users', { method: 'POST', body: JSON.stringify({ name: tr('default_user_name_prefix') + ' ' + n, color: '#7ba368' }) }); await refresh(); }
      catch (e) { toast(e.message); }
    },
    // roasts
    deleteRoast: async (name) => {
      if (!window.confirm(tr('delete_roast_confirm'))) return false;
      try { await api('/api/roast-types/' + encodeURIComponent(name), { method: 'DELETE' }); await refresh(); toast(tr('deleted')); }
      catch (e) { toast(e.message); }
    },
    addRoast: async () => {
      const n = (data.roast_types ? data.roast_types.length : 0);
      try { await api('/api/roast-types', { method: 'POST', body: JSON.stringify({ name: tr('default_roast_name') + n, min_flow_rate: 1.5, max_flow_rate: 2.2 }) }); await refresh(); }
      catch (e) { toast(e.message); }
    },
    saveRoast: async (name, d) => {
      try {
        await api('/api/roast-types/' + encodeURIComponent(name), {
          method: 'PATCH',
          body: JSON.stringify({ name: d.name || name, min_flow_rate: d.min_flow_rate, max_flow_rate: d.max_flow_rate }),
        });
        await refresh();
        toast(tr('saved_toast'));
      } catch (e) { toast(e.message); }
    },
    // settings
    setSetting: (k, v) => { updateLocal(c => { c.settings[k] = v; }); patchSettings({ [k]: v }); },
    setGbs: async (settings) => {
      try { await api('/api/gbs', { method: 'PATCH', body: JSON.stringify(settings) }); await refresh(); }
      catch (e) { toast(e.message); }
    },
    gbsAction: async (action, payload = {}) => {
      try { await api('/api/gbs/' + action, { method: 'POST', body: JSON.stringify(payload) }); await refresh(); }
      catch (e) { toast(e.message); }
    },
    setRinse: (k, v) => patchSettings({ rinse: { [k]: v } }),
    setManualPrebrewConfirmation: (confirmed) => patchSettings({ prebrew: { manual_confirmed: confirmed } }),
    setDisplay: (k, v) => { updateLocal(c => { c.settings.display[k] = v; }); patchSettings({ display: { [k]: v } }); },
    beginDisplayBrightness,
    setDisplayBrightness,
    flushDisplayBrightness,
    setUpdates: (k, v) => {
      if (k === 'updates_enabled') updateAutoCheckStarted.current = false;
      updateLocal(c => { c.settings.updates[k] = v; if (k === 'updates_enabled' && !v) c.settings.updates.auto_update = false; });
      const upd = { [k]: v };
      if (k === 'updates_enabled' && !v) upd.auto_update = false;
      patchSettings({ updates: upd });
    },
    setScreensaver: (k, v) => { updateLocal(c => { c.settings.screensaver[k] = v; }); patchSettings({ screensaver: { [k]: v } }); },
    uploadScreensaverPhotos: async (files) => {
      const list = Array.from(files || []);
      if (!list.length) return;
      try {
        for (const file of list) {
          const dataUrl = await new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = () => reject(reader.error || new Error(tr('upload_failed')));
            reader.readAsDataURL(file);
          });
          await api('/api/screensaver/photos', {
            method: 'POST',
            body: JSON.stringify({ name: file.name, data_url: dataUrl }),
          });
        }
        await refresh();
        toast(tr('saved_toast'));
      } catch (e) { toast(e.message); }
    },
    // LM
    lmLogin: async (u, p) => {
      try { await api('/api/lm/credentials', { method: 'POST', body: JSON.stringify({ username: u, password: p }) }); await refresh(); toast(tr('saved_toast')); }
      catch (e) { toast(e.message); }
    },
    lmClear: async () => {
      try { await api('/api/lm/credentials', { method: 'DELETE' }); await refresh(); toast(tr('clear')); }
      catch (e) { toast(e.message); }
    },
    lmRead: async () => {
      try { await api('/api/lm/refresh', { method: 'POST' }); await refresh(); toast(tr('saved_toast')); }
      catch (e) { toast(e.message); }
    },
    lmPower: async (on) => {
      try { await api('/api/lm/power', { method: 'POST', body: JSON.stringify({ enabled: on }) }); await refresh(); }
      catch (e) { toast(e.message); }
    },
    setSmartStandby: async (d) => {
      try {
        await api('/api/lm/smart-standby', { method: 'PATCH', body: JSON.stringify(d) });
        await refresh();
        toast(tr('saved_toast'));
      } catch (e) { toast(e.message); }
    },
    setLmTemp: async (kind, v) => {
      const body = kind === 'coffee' ? { coffee_target_temperature_c: v }
        : kind === 'steam' ? { steam_target_temperature_c: v }
        : { steam_target_level: v };
      try { await api('/api/lm/temperatures', { method: 'POST', body: JSON.stringify(body) }); await refresh(); }
      catch (e) { toast(e.message); }
    },
    // ---- shots (Phase 4) ----
    loadShots: async (dateStr) => {
      const qs = dateStr ? ('?date=' + encodeURIComponent(dateStr)) : '';
      const d = await api('/api/shots' + qs);
      return d.shots || [];
    },
    loadShotDetail: async (id) => api('/api/shots/' + id),
    loadAnalysis: async (id) => {
      const d = await api('/api/shots/' + id + '/analysis');
      return d.analysis || null;
    },
    loadFeedback: async (id) => {
      const d = await api('/api/shots/' + id + '/feedback');
      return d.feedback || null;
    },
    deleteShot: async (id) => {
      try {
        const result = await api('/api/shots/' + id, { method: 'DELETE' });
        await refresh();
        toast(tr('deleted'));
        return { ok: true, deleted: !!(result && result.deleted) };
      }
      catch (e) { toast(e.message); return { ok: false, deleted: false }; }
    },
    saveFeedback: async (id, fdata) => {
      try {
        if (fdata === null) {
          await api('/api/shots/' + id + '/feedback', { method: 'DELETE' });
        } else {
          const body = {
            issue: fdata.issue, taste: fdata.taste, visual: fdata.visual, prep: fdata.prep,
            grind_adjustment: fdata.grind_adjustment, rating: fdata.rating, notes: fdata.notes,
            user_name: (data.users && data.users.active && data.users.active.name) || '',
          };
          await api('/api/shots/' + id + '/feedback', { method: 'PUT', body: JSON.stringify(body) });
        }
        await refresh();
        setFeedbackShot(null);
        toast(tr('saved_toast'));
      } catch (e) { toast(e.message); }
    },
  };

  // ---- early render guard (after all hooks/handlers; hooks run unconditionally) ----
  if (loadErr) return <div className="sd-app"><ErrorState onRetry={boot} /></div>;
  if (!data) return <div className="sd-app"><Loading /></div>;

  // ---- top bar ----
  const lmPill = (() => {
    const l = data.lm;
    if (!l.configured || !l.enabled) return <Pill>{tr('lm_off')}</Pill>;
    if (lmOnline(app)) return <Pill variant="ok" dot>{tr('lm_online')}</Pill>;
    return <Pill>{tr('lm_unavailable')}</Pill>;
  })();
  const currentUpdateStatus = (data.settings.updates && data.settings.updates.status) || {};
  const updateAvailable = !!currentUpdateStatus.update_available;
  const goHome = () => {
    setOpenShotId(null);
    setTab('brew');
  };

  const TopBar = (
    <div className="sd-top">
      {/* Version lives in Settings → About; the brand row stays collision-free. */}
      <button type="button" className="sd-brand" onClick={goHome} aria-label={tr('tab_brew')} title={tr('tab_brew')}>
        <img className="sd-brandlogo" src="/favicon.png" alt="" />
        <span style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 2 }}>
          <span className="sd-wordmark">shot<b>deck</b></span>
          {tab !== 'shots' && app.data.settings?.gbs?.settings?.enabled && <span style={{ fontSize: 9, lineHeight: '12px', padding: '0 5px', borderRadius: 4, color: 'var(--primary)', border: '1px solid var(--primary)' }}>GBS</span>}
        </span>
      </button>
      <div className="sd-topicons">
        <button className="sd-iconbtn sd-supportbtn" onClick={() => setDiag(true)} title={tr('nav_diag')}><Icon name="support" size={19} /></button>
        <button className={'sd-iconbtn' + (tab === 'wifi' ? ' ' : '')} onClick={() => setTab('wifi')} title={tr('nav_wifi')} style={tab === 'wifi' ? { color: 'var(--primary)', background: 'var(--primary-soft)' } : null}><Icon name="wifi" size={19} /></button>
        <button className="sd-langbtn" onClick={app.toggleLang}>{lang === 'en' ? 'DE' : 'EN'}</button>
        {lmPill}
      </div>
    </div>
  );

  // ---- tab bar ----
  const tabs = [
    { id: 'brew', icon: 'brew', label: tr('tab_brew') },
    { id: 'profiles', icon: 'profiles', label: tr('tab_profiles') },
    { id: 'shots', icon: 'shots', label: tr('tab_shots') },
    { id: 'machine', icon: 'machine', label: tr('tab_machine') },
    { id: 'settings', icon: 'settings', label: tr('tab_settings') },
  ];
  const TabBar = (
    <div className="sd-tabbar">
      {tabs.map(t => (
        <button key={t.id} className={'sd-tab' + (tab === t.id ? ' active' : '')} onClick={() => setTab(t.id)}
          aria-label={t.label + (t.id === 'settings' && updateAvailable ? ' · ' + tr('update_available') : '')}>
          <span className="sd-tabicon"><Icon name={t.icon} size={20} />{t.id === 'settings' && updateAvailable && <span className="sd-update-badge" aria-hidden="true" />}</span>
          <span className="lbl">{t.label}</span>
        </button>
      ))}
    </div>
  );

  // ---- body router ----
  let body;
  if (tab === 'brew') body = <BrewScreen app={app} />;
  else if (tab === 'profiles') body = <ProfilesScreen app={app} />;
  else if (tab === 'shots') body = <ShotsScreen app={app} />;
  else if (tab === 'machine') body = <MachineScreen app={app} />;
  else if (tab === 'settings') body = <SettingsScreen app={app} />;
  else if (tab === 'wifi') body = <WifiScreen app={app} />;

  const liveBrewing = brewState && brewState.phase === 'live';
  const customerNotice = (((data.notifications || {}).items) || [])[0];
  const showCustomerNotice = !!customerNotice && !liveBrewing && !data.settings.shot_active;

  return (
    <div className="sd-app sd-stage">
      <div className="sd-phone">
        <div className="sd-screen">
          {TopBar}
          {showCustomerNotice && (
            <CustomerNoticeBanner notice={customerNotice} lang={lang} onDismiss={dismissNotice}
              dismissing={!!dismissingNotices[noticeKey(customerNotice)]} />
          )}
          {!liveBrewing && <PullToRefresh onRefresh={refresh}>{body}</PullToRefresh>}
          {liveBrewing && <LiveBrewView app={app} />}
          {!liveBrewing && TabBar}

          {/* overlays */}
          {brewConfirm && <BrewConfirmModal app={app} />}
          {helpSection && <HelpModal app={app} />}
          {feedbackShot && <FeedbackModal app={app} />}
          {diag && <DiagnosticsModal app={app} />}
          {updateModal && <UpdateInstallModal app={app} />}
          {toastMsg && <div className="sd-toast">{toastMsg}</div>}
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
