// ============================================================
// Shotdeck — hand-drawn <canvas> charts (dependency-free)
//   LiveBrewChart · ShotChart (dual-axis) · IdealCurveEditor
// All read theme colors from CSS vars so they follow the theme.
// ============================================================

function cssVar(name, fallback) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}
function setupCanvas(canvas, w, h) {
  const dpr = window.devicePixelRatio || 1;
  canvas.width = w * dpr; canvas.height = h * dpr;
  canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  return ctx;
}

// catmull-rom-ish smooth path through points (in px)
function smoothLine(ctx, pts) {
  if (pts.length < 2) return;
  ctx.moveTo(pts[0][0], pts[0][1]);
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
    for (let t = 0; t <= 1; t += 0.2) {
      const t2 = t * t, t3 = t2 * t;
      const x = 0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3);
      const y = 0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3);
      ctx.lineTo(x, y);
    }
  }
}

// Read-only view of a shot's initial tare. Match lib/shot_samples.py; shared
// regression fixtures cover both paths. Keep elapsed times and raw history.
function postTareSamples(samples, validity) {
  if (!samples || !samples.length) return [];
  validity = validity && typeof validity === 'object' ? validity : {};
  const number = value => !['number', 'string'].includes(typeof value) ||
    (typeof value === 'string' && !value.trim()) || !Number.isFinite(Number(value)) ? null : Number(value);
  const confirmedAt = number(validity.tare_zero_confirmed_at_s);
  let start = null;
  if (validity.tare_zero_confirmed === true && confirmedAt != null && confirmedAt >= 0) {
    start = samples.findIndex(sample => number(sample.time_s) != null && Number(sample.time_s) >= confirmedAt);
    if (start < 0) start = samples.length;
  } else if (validity.tare_failed !== true && validity.tare_requested !== false) {
    const firstWeight = number(samples[0].weight_g);
    if (firstWeight != null && Math.abs(firstWeight) > 5) {
      for (let i = 1; i < samples.length; i++) {
        const elapsed = number(samples[i].time_s), weight = number(samples[i].weight_g);
        if (elapsed != null && elapsed > 2) break;
        if (elapsed != null && elapsed >= 0 && weight != null && Math.abs(weight) <= 0.5) {
          start = i; break;
        }
      }
    }
  }
  const result = samples.slice(start == null ? 0 : start).map(sample => ({ ...sample }));
  if (start != null && result.length) result[0].flow_g_s = 0;
  return result;
}

function smoothFlowSamples(samples, windowSize) {
  const size = Math.max(1, parseInt(windowSize || 1, 10));
  if (!samples || size <= 1) return samples || [];
  return samples.map((sample, i) => {
    const j = Math.max(0, i - size + 1);
    const first = samples[j];
    const dt = Number(sample.time_s) - Number(first.time_s);
    const dw = Number(sample.weight_g) - Number(first.weight_g);
    const flow = dt > 0 ? Math.max(0, dw / dt) : Number(sample.flow_g_s || 0);
    return { ...sample, flow_g_s: +flow.toFixed(3) };
  });
}

// ──────────────────────────────────────────────────────────────
// LiveBrewChart — flow grows over elapsed time; ideal overlay; band
// ──────────────────────────────────────────────────────────────
function LiveBrewChart({ width, height, samples, duration, ideal, themeKey }) {
  const ref = useRef(null);
  useEffect(() => {
    const cv = ref.current; if (!cv) return;
    const ctx = setupCanvas(cv, width, height);
    const padL = 28, padR = 10, padT = 10, padB = 20;
    const W = width - padL - padR, H = height - padT - padB;
    const maxF = 4, dur = Math.max(duration, 8);
    const xAt = t => padL + (t / dur) * W;
    const yAt = f => padT + H - (f / maxF) * H;

    ctx.clearRect(0, 0, width, height);
    // grid
    ctx.strokeStyle = cssVar('--grid', '#2e2620'); ctx.lineWidth = 0.5;
    for (let g = 0; g <= 4; g++) { const y = padT + H * g / 4; ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(padL + W, y); ctx.stroke(); }
    ctx.fillStyle = cssVar('--fg-faint', '#8a7a63'); ctx.font = '9px JetBrains Mono, monospace';
    for (let g = 0; g <= 4; g++) { ctx.textAlign = 'right'; ctx.fillText(g, padL - 5, padT + H - (g / 4) * H + 3); }

    // ideal overlay (dashed)
    if (ideal && ideal.length > 1) {
      ctx.save(); ctx.setLineDash([4, 4]);
      ctx.strokeStyle = cssVar('--ideal-curve', '#b16625'); ctx.lineWidth = 1.5; ctx.globalAlpha = 0.7;
      ctx.beginPath();
      smoothLine(ctx, ideal.map(p => [xAt(p.time_s), yAt(p.flow_g_s)]));
      ctx.stroke(); ctx.restore();
    }

    // live flow curve + fill
    if (samples && samples.length > 1) {
      const pts = samples.map(s => [xAt(s.time_s), yAt(s.flow_g_s)]);
      const flowCol = cssVar('--flow-curve', '#cb974d');
      // fill
      const grad = ctx.createLinearGradient(0, padT, 0, padT + H);
      grad.addColorStop(0, flowCol + '55'); grad.addColorStop(1, flowCol + '00');
      ctx.beginPath(); smoothLine(ctx, pts);
      ctx.lineTo(pts[pts.length - 1][0], padT + H); ctx.lineTo(pts[0][0], padT + H); ctx.closePath();
      ctx.fillStyle = grad; ctx.fill();
      // line
      ctx.beginPath(); smoothLine(ctx, pts);
      ctx.strokeStyle = flowCol; ctx.lineWidth = 2.4; ctx.lineJoin = 'round'; ctx.stroke();
      // leading dot
      const last = pts[pts.length - 1];
      ctx.beginPath(); ctx.arc(last[0], last[1], 4.5, 0, 7); ctx.fillStyle = flowCol; ctx.fill();
      ctx.strokeStyle = cssVar('--bg', '#15110e'); ctx.lineWidth = 2; ctx.stroke();
    }
  }, [width, height, samples, duration, ideal, themeKey]);
  return <canvas ref={ref} style={{ display: 'block' }} />;
}

// ──────────────────────────────────────────────────────────────
// ShotChart — dual-axis: Flow g/s (L), Weight g (R), Time x; ideal dashed
// ──────────────────────────────────────────────────────────────
function ShotChart({ width, height, samples, finalWeight, ideal, themeKey, smoothing = 1, shotValidity }) {
  const ref = useRef(null);
  useEffect(() => {
    const cv = ref.current; if (!cv) return;
    const ctx = setupCanvas(cv, width, height);
    const padL = 30, padR = 34, padT = 14, padB = 24;
    const W = width - padL - padR, H = height - padT - padB;
    ctx.clearRect(0, 0, width, height);
    const plotSamples = postTareSamples(samples, shotValidity);
    if (!plotSamples.length) return;
    const flowSamples = smoothFlowSamples(plotSamples, smoothing);
    const dur = Math.ceil(samples[samples.length - 1].time_s / 5) * 5 || 30;
    // Pre-tare cup readings can dwarf the extraction. Scale to the saved result.
    const recordedWeight = Number(finalWeight);
    const reachedWeight = finalWeight != null && Number.isFinite(recordedWeight) && recordedWeight >= 0
      ? recordedWeight
      : plotSamples.reduce((max, s) => Number.isFinite(Number(s.weight_g)) ? Math.max(max, Number(s.weight_g)) : max, 0);
    const maxF = 4, maxW = Math.ceil((reachedWeight + 4) / 10) * 10;
    const xAt = t => padL + (t / dur) * W;
    const yF = f => padT + H - (f / maxF) * H;
    const yW = w => padT + H - (w / maxW) * H;

    ctx.clearRect(0, 0, width, height);
    // grid
    ctx.strokeStyle = cssVar('--grid', '#2e2620'); ctx.lineWidth = 0.5;
    for (let g = 0; g <= 4; g++) { const y = padT + H * g / 4; ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(padL + W, y); ctx.stroke(); }
    for (let t = 0; t <= dur; t += 10) { ctx.save(); ctx.setLineDash([2, 3]); ctx.beginPath(); ctx.moveTo(xAt(t), padT); ctx.lineTo(xAt(t), padT + H); ctx.stroke(); ctx.restore(); }

    const flowCol = cssVar('--flow-curve', '#cb974d');
    const wCol = cssVar('--weight-curve', '#dfad49');
    const idCol = cssVar('--ideal-curve', '#b16625');
    const faint = cssVar('--fg-faint', '#8a7a63');

    // axis labels
    ctx.font = '9px JetBrains Mono, monospace';
    ctx.fillStyle = flowCol; ctx.textAlign = 'right';
    for (let g = 0; g <= 4; g++) ctx.fillText(g, padL - 5, yF(g) + 3);
    ctx.fillStyle = wCol; ctx.textAlign = 'left';
    for (let g = 0; g <= maxW; g += maxW / 4) ctx.fillText(Math.round(g), padL + W + 5, yW(g) + 3);
    ctx.fillStyle = faint; ctx.textAlign = 'center';
    for (let t = 0; t <= dur; t += 10) ctx.fillText(t + 's', xAt(t), padT + H + 14);

    // Keep pre-tare readings and other outliers inside the plotting area.
    ctx.save(); ctx.beginPath(); ctx.rect(padL, padT, W, H); ctx.clip();
    // ideal dashed
    if (ideal && ideal.length > 1) {
      ctx.save(); ctx.setLineDash([4, 4]); ctx.globalAlpha = 0.75;
      ctx.strokeStyle = idCol; ctx.lineWidth = 1.5; ctx.beginPath();
      smoothLine(ctx, ideal.map(p => [xAt(p.time_s), yF(p.flow_g_s)])); ctx.stroke(); ctx.restore();
    }
    // weight (thin)
    ctx.beginPath(); smoothLine(ctx, plotSamples.map(s => [xAt(s.time_s), yW(s.weight_g)]));
    ctx.strokeStyle = wCol; ctx.lineWidth = 1.4; ctx.globalAlpha = 0.85; ctx.stroke(); ctx.globalAlpha = 1;
    // flow fill + line
    const pts = flowSamples.map(s => [xAt(s.time_s), yF(s.flow_g_s)]);
    const grad = ctx.createLinearGradient(0, padT, 0, padT + H);
    grad.addColorStop(0, flowCol + '44'); grad.addColorStop(1, flowCol + '00');
    ctx.beginPath(); smoothLine(ctx, pts); ctx.lineTo(pts[pts.length - 1][0], padT + H); ctx.lineTo(pts[0][0], padT + H); ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
    ctx.beginPath(); smoothLine(ctx, pts); ctx.strokeStyle = flowCol; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.stroke();
    ctx.restore();
  }, [width, height, samples, finalWeight, ideal, themeKey, smoothing, shotValidity]);
  return <canvas ref={ref} style={{ display: 'block' }} />;
}

// chart legend
function ChartLegend() {
  const items = [['--flow-curve', tr('flow') + ' g/s'], ['--weight-curve', tr('weight') + ' g'], ['--ideal-curve', tr('ideal_flow')]];
  return (
    <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginTop: 8 }}>
      {items.map(([v, l], i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <span style={{ width: 14, height: 0, borderTop: `2px ${i === 2 ? 'dashed' : 'solid'} var(${v})` }} />
          <span className="sd-micro" style={{ fontSize: 9, letterSpacing: '.08em' }}>{l}</span>
        </div>
      ))}
    </div>
  );
}

// ──────────────────────────────────────────────────────────────
// IdealCurveEditor — draggable points on canvas; emits new points
// ──────────────────────────────────────────────────────────────
function IdealCurveEditor({ width, height, points, onChange, themeKey, maxTime = 36 }) {
  const ref = useRef(null);
  const dragIx = useRef(null);
  const padL = 30, padR = 12, padT = 12, padB = 22;
  const W = width - padL - padR, H = height - padT - padB;
  const maxF = 4;
  const xAt = t => padL + (t / maxTime) * W;
  const yAt = f => padT + H - (f / maxF) * H;
  const tAt = x => Math.max(0, Math.min(maxTime, ((x - padL) / W) * maxTime));
  const fAt = y => Math.max(0, Math.min(maxF, ((padT + H - y) / H) * maxF));

  const draw = useCallback(() => {
    const cv = ref.current; if (!cv) return;
    const ctx = setupCanvas(cv, width, height);
    ctx.clearRect(0, 0, width, height);
    ctx.strokeStyle = cssVar('--grid', '#2e2620'); ctx.lineWidth = 0.5;
    for (let g = 0; g <= 4; g++) { const y = padT + H * g / 4; ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(padL + W, y); ctx.stroke(); }
    ctx.fillStyle = cssVar('--fg-faint', '#8a7a63'); ctx.font = '9px JetBrains Mono, monospace';
    ctx.textAlign = 'right'; for (let g = 0; g <= 4; g++) ctx.fillText(g, padL - 5, yAt(g) + 3);
    ctx.textAlign = 'center'; for (let t = 0; t <= maxTime; t += 10) ctx.fillText(t + 's', xAt(t), padT + H + 14);

    const idCol = cssVar('--ideal-curve', '#b16625');
    const pts = points.map(p => [xAt(p.time_s), yAt(p.flow_g_s)]);
    // fill
    const grad = ctx.createLinearGradient(0, padT, 0, padT + H);
    grad.addColorStop(0, idCol + '33'); grad.addColorStop(1, idCol + '00');
    ctx.beginPath(); smoothLine(ctx, pts); ctx.lineTo(pts[pts.length - 1][0], padT + H); ctx.lineTo(pts[0][0], padT + H); ctx.closePath(); ctx.fillStyle = grad; ctx.fill();
    // line
    ctx.beginPath(); smoothLine(ctx, pts); ctx.strokeStyle = idCol; ctx.lineWidth = 2.2; ctx.lineJoin = 'round'; ctx.stroke();
    // handles
    pts.forEach((p, i) => {
      ctx.beginPath(); ctx.arc(p[0], p[1], i === dragIx.current ? 8 : 6, 0, 7);
      ctx.fillStyle = cssVar('--card', '#211b17'); ctx.fill();
      ctx.strokeStyle = idCol; ctx.lineWidth = 2.4; ctx.stroke();
    });
  }, [width, height, points, themeKey]);

  useEffect(() => { draw(); }, [draw]);

  const evtPos = e => {
    const r = ref.current.getBoundingClientRect();
    const cx = (e.touches ? e.touches[0].clientX : e.clientX) - r.left;
    const cy = (e.touches ? e.touches[0].clientY : e.clientY) - r.top;
    return [cx, cy];
  };
  const onDown = e => {
    const [cx, cy] = evtPos(e);
    let best = -1, bd = 18;
    points.forEach((p, i) => { const d = Math.hypot(xAt(p.time_s) - cx, yAt(p.flow_g_s) - cy); if (d < bd) { bd = d; best = i; } });
    if (best >= 0) { dragIx.current = best; draw(); }
  };
  const onMove = e => {
    if (dragIx.current == null) return;
    e.preventDefault();
    const [cx, cy] = evtPos(e);
    const i = dragIx.current;
    const next = points.map((p, j) => {
      if (j !== i) return p;
      let t = i === 0 ? 0 : tAt(cx);
      // keep monotonic-ish ordering between neighbours
      if (i > 0) t = Math.max(points[i - 1].time_s + 0.5, t);
      if (i < points.length - 1) t = Math.min(points[i + 1].time_s - 0.5, t);
      return { ...p, time_s: +t.toFixed(1), flow_g_s: +fAt(cy).toFixed(2) };
    });
    onChange(next);
  };
  const onUp = () => { dragIx.current = null; draw(); };

  return (
    <canvas ref={ref} style={{ display: 'block', touchAction: 'none', cursor: 'pointer' }}
      onMouseDown={onDown} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp}
      onTouchStart={onDown} onTouchMove={onMove} onTouchEnd={onUp} />
  );
}

Object.assign(window, { LiveBrewChart, ShotChart, ChartLegend, IdealCurveEditor, cssVar, postTareSamples, smoothFlowSamples });
