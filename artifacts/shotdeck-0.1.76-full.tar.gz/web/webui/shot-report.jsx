// Offline PDF export. JPEG pages reuse the saved-shot renderer; no device-side
// PDF runtime, remote service, or third-party browser dependency is required.
const SHOT_PDF_COLORS = {
  bg: '#ffffff', card: '#ffffff', inset: '#faf8f5', border: '#d9d0c5',
  'border-soft': '#eae4dc', fg: '#251f19', 'fg-dim': '#695d50', brass: '#956027',
  success: '#286b43', 'success-soft': '#e8f3eb', 'flow-curve': '#a96923',
  'weight-curve': '#287ba0', 'ideal-curve': '#8b7861', grid: '#e4ddd3',
};
const SHOT_PDF_TEXT = {
  en: {
    title: 'Shot history report', summary: 'Your shots at a glance', all: 'All recorded dates',
    from: 'From', to: 'To', shots: 'Shots', days: 'Days with shots', total: 'Total yield',
    yield: 'Average yield', duration: 'Average duration', flow: 'Average flow', temp: 'Average brew temp.',
    window: 'Within time window', people: 'Brewing users', profiles: 'Profiles', users: 'Brewed by',
    values: 'recorded values', others: 'Other', unknown: 'Not recorded',
    note: 'Averages use recorded values only. Temperature is the saved target, not a measured extraction temperature.',
    details: 'Individual shot details and extraction curves follow. Dates use this browser’s local time.',
    generated: 'Created',
  },
  de: {
    title: 'Shot-Verlaufsbericht', summary: 'Deine Shots im Überblick', all: 'Alle erfassten Daten',
    from: 'Von', to: 'Bis', shots: 'Shots', days: 'Tage mit Shots', total: 'Gesamte Getränkemenge',
    yield: 'Ø Getränkemenge', duration: 'Ø Dauer', flow: 'Ø Fluss', temp: 'Ø Brühtemperatur',
    window: 'Im Zeitfenster', people: 'Brühende Personen', profiles: 'Profile', users: 'Gebrüht von',
    values: 'erfasste Werte', others: 'Weitere', unknown: 'Nicht erfasst',
    note: 'Mittelwerte berücksichtigen nur erfasste Werte. Die Temperatur ist der gespeicherte Sollwert, keine gemessene Extraktionstemperatur.',
    details: 'Es folgen Shot-Details und Extraktionskurven. Datumsangaben verwenden die Ortszeit dieses Browsers.',
    generated: 'Erstellt',
  },
};

function shotRangeParams(from = '', to = '') {
  if (from && to && from > to) throw new Error('Invalid date range');
  const params = new URLSearchParams();
  for (const [key, value, nextDay] of [['start', from, false], ['end', to, true]]) {
    if (!value) continue;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('Invalid date');
    const [y, m, d] = value.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    if (date.getFullYear() !== y || date.getMonth() !== m - 1 || date.getDate() !== d) throw new Error('Invalid date');
    // Calendar arithmetic preserves inclusive end dates across DST changes.
    if (nextDay) date.setDate(date.getDate() + 1);
    params.set(key, date.toISOString());
  }
  return params;
}

async function loadShotRange(fetchApi, from = '', to = '', all = false) {
  const params = shotRangeParams(from, to);
  const limit = all ? 200 : 50;
  params.set('limit', String(limit));
  if (all) params.set('paged', '1');
  const rows = [], ids = new Set(); let total = null;
  while (true) {
    params.set('offset', String(rows.length));
    const data = await fetchApi('/api/shots?' + params);
    if (!Array.isArray(data.shots)) throw new Error('Missing shot list');
    if (all) {
      if (!Number.isInteger(data.total) || data.total < 0) throw new Error('Missing shot count');
      if (total != null && data.total !== total) throw new Error('Shot history changed; retry export');
      total = data.total;
    }
    for (const shot of data.shots) {
      // Reject overlapping pages instead of silently including duplicate shots.
      if (ids.has(shot.id)) throw new Error('Shot history changed; retry export');
      ids.add(shot.id); rows.push(shot);
    }
    if (!all || data.shots.length < limit) {
      if (all && rows.length !== total) throw new Error('Incomplete shot history');
      return rows;
    }
    if (!Number.isInteger(data.snapshot) || data.snapshot < 0) throw new Error('Missing shot snapshot');
    params.set('snapshot', String(data.snapshot));
  }
}

function summarizeShotReport(shots) {
  const numeric = v => typeof v === 'number' && Number.isFinite(v);
  const metric = (key, positive = false) => {
    const values = shots.map(s => s[key]).filter(v => numeric(v) && (positive ? v > 0 : v >= 0));
    return { count: values.length, total: values.reduce((a, b) => a + b, 0),
      mean: values.length ? values.reduce((a, b) => a + b, 0) / values.length : null };
  };
  const groups = key => {
    const counts = new Map();
    for (const shot of shots) {
      const name = String(shot[key] || '').trim();
      counts.set(name, (counts.get(name) || 0) + 1);
    }
    return [...counts].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  };
  const dates = shots.map(s => new Date(s.started_at)).filter(d => !Number.isNaN(d.getTime()));
  const days = new Set(dates.map(d => [d.getFullYear(), d.getMonth(), d.getDate()].join('-'))).size;
  const timed = shots.filter(s => numeric(s.duration_s) && s.duration_s >= 0 && numeric(s.target_time_min_s)
    && numeric(s.target_time_max_s) && s.target_time_min_s >= 0 && s.target_time_max_s > 0 && s.target_time_max_s >= s.target_time_min_s);
  return { count: shots.length, days, yield: metric('final_weight_g'), duration: metric('duration_s'),
    flow: metric('average_flow_g_s', true), temperature: metric('brew_temperature_c', true),
    inWindow: timed.filter(s => s.duration_s >= s.target_time_min_s && s.duration_s <= s.target_time_max_s).length,
    timed: timed.length, profiles: groups('profile_name'), users: groups('user_name'),
    first: dates.length ? new Date(dates.reduce((n, d) => Math.min(n, Number(d)), Infinity)) : null,
    last: dates.length ? new Date(dates.reduce((n, d) => Math.max(n, Number(d)), -Infinity)) : null };
}

async function createShotReportSummary({ rows, from, to, lang = 'en' }) {
  const t = SHOT_PDF_TEXT[lang] || SHOT_PDF_TEXT.en, c = SHOT_PDF_COLORS;
  const summary = summarizeShotReport(rows);
  if (document.fonts) await document.fonts.load('16px Inter');
  const canvas = document.createElement('canvas');
  canvas.width = 2000; canvas.height = 2828;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas unavailable');
  ctx.scale(2, 2); ctx.fillStyle = c.bg; ctx.fillRect(0, 0, 1000, 1414);
  const text = (value, x, y, size = 15, color = c.fg) => {
    ctx.font = size + 'px Inter, sans-serif'; ctx.fillStyle = color; ctx.textBaseline = 'top';
    ctx.fillText(String(value), x, y);
  };
  const wrap = (value, x, y, width, size = 14, color = c['fg-dim']) => {
    ctx.font = size + 'px Inter, sans-serif'; let line = '';
    for (const word of String(value).split(/\s+/)) {
      if (line && ctx.measureText(line + ' ' + word).width > width) { text(line, x, y, size, color); y += size * 1.5; line = ''; }
      line += (line ? ' ' : '') + word;
    }
    text(line, x, y, size, color); return y + size * 1.5;
  };
  const box = (x, y, w, h) => {
    ctx.beginPath(); ctx.roundRect(x, y, w, h, 12); ctx.fillStyle = c.inset; ctx.fill();
    ctx.strokeStyle = c.border; ctx.lineWidth = 1; ctx.stroke();
  };
  const locale = lang === 'de' ? 'de-DE' : 'en-GB';
  const date = d => d ? d.toLocaleDateString(locale, { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
  const chosen = value => date(new Date(value + 'T12:00:00'));
  text('shotdeck', 48, 45, 25, c.brass);
  text(t.title, 48, 108, 34); text(t.summary, 48, 159, 17, c['fg-dim']);
  const range = from || to ? [from ? t.from + ' ' + chosen(from) : '', to ? t.to + ' ' + chosen(to) : ''].filter(Boolean).join(' · ')
    : t.all;
  text(range, 48, 205, 16);
  text(date(summary.first) + ' – ' + date(summary.last), 48, 233, 13, c['fg-dim']);
  const fmt = (n, digits = 1) => n == null ? '—' : n.toLocaleString(locale, { minimumFractionDigits: digits, maximumFractionDigits: digits });
  const recorded = metric => metric.count + ' ' + t.values;
  const cards = [
    [t.shots, fmt(summary.count, 0), t.profiles + ': ' + summary.profiles.filter(([name]) => name).length],
    [t.days, fmt(summary.days, 0), t.people + ': ' + summary.users.filter(([name]) => name).length],
    [t.total, (summary.yield.count ? fmt(summary.yield.total) : '—') + ' g', recorded(summary.yield)],
    [t.yield, fmt(summary.yield.mean) + ' g', recorded(summary.yield)],
    [t.duration, fmt(summary.duration.mean) + ' s', recorded(summary.duration)],
    [t.flow, fmt(summary.flow.mean, 2) + ' g/s', recorded(summary.flow)],
    [t.temp, fmt(summary.temperature.mean) + ' °C', recorded(summary.temperature)],
    [t.window, summary.timed ? Math.round(summary.inWindow / summary.timed * 100) + '%' : '—', summary.inWindow + ' / ' + summary.timed],
  ];
  cards.forEach(([label, value, note], i) => {
    const x = 48 + (i % 3) * 308, y = 292 + Math.floor(i / 3) * 132;
    box(x, y, 288, 112); text(label, x + 18, y + 17, 13, c['fg-dim']);
    // Keep unusually large counts and totals inside their card.
    let size = 30; ctx.font = size + 'px Inter';
    while (ctx.measureText(value).width > 252 && size > 16) { size--; ctx.font = size + 'px Inter'; }
    text(value, x + 18, y + 41, size); text(note, x + 18, y + 84, 11, c['fg-dim']);
  });
  const breakdown = (heading, groups, x) => {
    text(heading, x, 734, 21); let y = 779;
    const shown = groups.slice(0, 6);
    if (groups.length > 6) shown.push([t.others, groups.slice(6).reduce((sum, [, n]) => sum + n, 0)]);
    for (const [rawName, count] of shown) {
      let name = rawName || t.unknown; ctx.font = '14px Inter';
      while (ctx.measureText(name).width > 325 && name.length > 1) name = name.slice(0, -2) + '…';
      text(name, x, y, 14); text(count, x + 366, y, 14, c.brass);
      ctx.fillStyle = c.border; ctx.fillRect(x, y + 25, 400, 3);
      ctx.fillStyle = c.brass; ctx.fillRect(x, y + 25, 400 * count / rows.length, 3); y += 48;
    }
  };
  breakdown(t.profiles, summary.profiles, 48); breakdown(t.users, summary.users, 540);
  let y = wrap(t.note, 48, 1170, 904);
  y = wrap(t.details, 48, y + 16, 904);
  text(t.generated + ': ' + new Date().toLocaleString(locale), 48, Math.max(1310, y + 24), 12, c['fg-dim']);
  return canvas;
}

// A small image-only PDF writer. Binary byte lengths/offsets are computed from
// Uint8Arrays, including JPEG streams, so xref remains valid for Unicode reports.
function shotPdfDocument() {
  const images = [];
  return {
    async addPage(canvas) {
      const blob = await new Promise((resolve, reject) => canvas.toBlob(b => b ? resolve(b) : reject(new Error('PDF image failed')), 'image/jpeg', 0.94));
      images.push({ bytes: new Uint8Array(await blob.arrayBuffer()), width: canvas.width, height: canvas.height });
      canvas.width = canvas.height = 1;
    },
    finish() {
      const enc = new TextEncoder(), chunks = [], offsets = [0]; let length = 0;
      const append = data => { const bytes = typeof data === 'string' ? enc.encode(data) : data; chunks.push(bytes); length += bytes.length; };
      const object = (id, data) => { offsets[id] = length; append(id + ' 0 obj\n'); append(data); append('\nendobj\n'); };
      append('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
      object(1, '<< /Type /Catalog /Pages 2 0 R >>');
      object(2, '<< /Type /Pages /Count ' + images.length + ' /Kids [' + images.map((_, i) => (4 + i * 3) + ' 0 R').join(' ') + '] >>');
      object(3, '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>');
      images.forEach((img, i) => {
        const id = 4 + i * 3, scale = Math.min(547 / img.width, 782 / img.height);
        const w = img.width * scale, h = img.height * scale;
        const stream = `q ${w.toFixed(3)} 0 0 ${h.toFixed(3)} ${((595.28 - w) / 2).toFixed(3)} ${(817.89 - h).toFixed(3)} cm /ShotImage Do Q\nBT /F1 9 Tf 0.4 g 275 19 Td (${i + 1} / ${images.length}) Tj ET`;
        object(id, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /ShotImage ${id + 2} 0 R >> /Font << /F1 3 0 R >> >> /Contents ${id + 1} 0 R >>`);
        object(id + 1, `<< /Length ${enc.encode(stream).length} >>\nstream\n${stream}\nendstream`);
        offsets[id + 2] = length; append(`${id + 2} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${img.width} /Height ${img.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.bytes.length} >>\nstream\n`);
        append(img.bytes); append('\nendstream\nendobj\n');
      });
      const xref = length;
      append('xref\n0 ' + offsets.length + '\n0000000000 65535 f \n');
      offsets.slice(1).forEach(offset => append(String(offset).padStart(10, '0') + ' 00000 n \n'));
      append(`trailer\n<< /Size ${offsets.length} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
      return new Blob(chunks, { type: 'application/pdf' });
    },
  };
}

async function saveShotPdfReport({ rows, loadShot, profiles = [], from = '', to = '', lang = 'en', smoothing = 10, onProgress = () => {} }) {
  if (!rows.length) throw new Error('No shots to export');
  const pdf = shotPdfDocument();
  await pdf.addPage(await createShotReportSummary({ rows, from, to, lang }));
  for (let i = 0; i < rows.length; i++) {
    onProgress(i, rows.length);
    const shot = await loadShot(rows[i].id);
    if (!shot || shot.id !== rows[i].id) throw new Error('Shot is no longer available');
    await pdf.addPage(await createShotScreenshot({ shot, lang, smoothing, colors: SHOT_PDF_COLORS, note: shotProfileNote(shot, profiles) }));
    await new Promise(resolve => setTimeout(resolve, 0));
  }
  onProgress(rows.length, rows.length);
  const url = URL.createObjectURL(pdf.finish()), link = document.createElement('a');
  link.href = url; link.download = 'shotdeck-shots-' + (from || 'all') + '-to-' + (to || 'latest') + '.pdf';
  try { document.body.appendChild(link); link.click(); }
  finally { link.remove(); setTimeout(() => URL.revokeObjectURL(url), 60000); }
}

Object.assign(window, { shotRangeParams, loadShotRange, summarizeShotReport, createShotReportSummary, saveShotPdfReport });
