// ============================================================
// Shotdeck — Machine (La Marzocco) · Wi-Fi · Settings
// ============================================================

// ---- Machine ----
function lmMachineAwake(snapshot) {
  const status = snapshot && snapshot.status ? snapshot.status : {};
  const mode = String(status.mode || status.status || '').toLowerCase();
  if (!mode) return !!(snapshot && (snapshot.connected || snapshot.available));
  return mode.indexOf('standby') === -1 && mode.indexOf('stand by') === -1 && mode.indexOf('off') === -1;
}

function steamLevelValue(value, fallback = 1) {
  if (value == null || value === '') return String(fallback);
  const match = String(value).match(/\d+/);
  return match ? match[0] : String(value);
}

function prebrewModeText(value) {
  const raw = String(value || '').replace(/[_-]/g, ' ').toLowerCase();
  if (!raw) return '-';
  if (raw.indexOf('disabled') !== -1) return tr('pb_disabled');
  if (raw.indexOf('prebrewing') !== -1 || raw.indexOf('pre brewing') !== -1) return tr('pb_on');
  if (raw.indexOf('preinfusion') !== -1 || raw.indexOf('pre infusion') !== -1) return tr('preinfusion');
  return String(value);
}

function prebrewModeValue(value) {
  const raw = String(value || '').replace(/[_-\s]/g, '').toLowerCase();
  if (raw.indexOf('disabled') !== -1) return 'disabled';
  if (raw.indexOf('preinfusion') !== -1) return 'preinfusion';
  return 'prebrewing';
}

function prebrewModeOptions(pre) {
  const modes = Array.isArray(pre && pre.available_modes) && pre.available_modes.length
    ? pre.available_modes : [pre && pre.mode, 'Disabled'];
  const seen = new Set();
  return modes.map(mode => {
    const value = prebrewModeValue(mode);
    if (seen.has(value)) return null;
    seen.add(value);
    return { value, label: prebrewModeText(mode || value) };
  }).filter(Boolean);
}

function machineActiveProfile(app) {
  return app.data.profiles.find(p => p.selected && !p.archived) || app.data.profiles.find(p => !p.archived) || null;
}
function machineProfileBrewsByTime(p) {
  return String((p && p.brew_control_mode) || 'weight').toLowerCase() === 'time';
}
function machineBrewModeLabel(p) {
  return machineProfileBrewsByTime(p) ? tr('brew_by_time') : tr('brew_by_weight');
}

function prebrewTimeText(value) {
  if (value == null || value === '') return '-';
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  return n.toFixed(1).replace(/\.0$/, '') + 's';
}

function prebrewTimes(pre) {
  if (!pre) return { on: null, off: null };
  if (pre.seconds_on != null || pre.seconds_off != null) {
    return { on: pre.seconds_on, off: pre.seconds_off };
  }
  const entries = pre.times && (pre.times.pre_brewing || pre.times.preBrewing || pre.times.PreBrewing);
  const first = Array.isArray(entries) ? entries[0] : entries;
  const seconds = first && first.seconds ? first.seconds : {};
  return { on: seconds.In ?? seconds.in ?? null, off: seconds.Out ?? seconds.out ?? null };
}

function liveLmPrebrewSummary(guard) {
  const state = String((guard && guard.state) || 'unknown').toLowerCase();
  if (state === 'active') {
    const mode = prebrewModeText(guard.mode);
    const times = prebrewTimes(guard);
    const hasTimes = times.on != null || times.off != null;
    return {
      selection: `${tr('la_marzocco')} · ${mode}`,
      settings: hasTimes
        ? `${tr('on')} ${prebrewTimeText(times.on)} / ${tr('off')} ${prebrewTimeText(times.off)}`
        : mode,
    };
  }
  if (state === 'disabled') {
    return {
      selection: `${tr('la_marzocco')} · ${tr('pb_disabled')}`,
      settings: tr('pb_disabled'),
    };
  }
  if (state === 'unsupported') {
    return {
      selection: `${tr('la_marzocco')} · ${tr('not_supported')}`,
      settings: tr('not_supported'),
    };
  }
  return {
    selection: `${tr('la_marzocco')} · ${tr('status_unavailable')}`,
    settings: tr('status_unavailable'),
  };
}

function prebrewLimits(pre) {
  const entries = pre && pre.times && (pre.times.pre_brewing || pre.times.preBrewing || pre.times.PreBrewing);
  const first = Array.isArray(entries) ? entries[0] : entries;
  const min = first && first.seconds_min ? first.seconds_min : {};
  const max = first && first.seconds_max ? first.seconds_max : {};
  const step = first && first.seconds_step ? first.seconds_step : {};
  return {
    onMin: Number(min.In ?? min.in ?? 0),
    onMax: Number(max.In ?? max.in ?? 20),
    onStep: Number(step.In ?? step.in ?? 0.5),
    offMin: Number(min.Out ?? min.out ?? 0),
    offMax: Number(max.Out ?? max.out ?? 20),
    offStep: Number(step.Out ?? step.out ?? 0.5),
  };
}

function prebrewPayload(pre, patch) {
  const times = prebrewTimes(pre);
  const mode = patch.mode || prebrewModeValue(pre && pre.mode);
  const payload = { mode };
  if (mode !== 'disabled') {
    payload.seconds_on = patch.seconds_on ?? times.on ?? 2;
    payload.seconds_off = patch.seconds_off ?? times.off ?? 3;
  }
  return payload;
}

function smartStandbyAfterValue(value) {
  const raw = String(value || '').replace(/[_-\s]/g, '').toLowerCase();
  return raw.indexOf('poweron') !== -1 ? 'PowerOn' : 'LastBrewing';
}

function smartStandbyAfterLabel(value) {
  return smartStandbyAfterValue(value) === 'PowerOn' ? tr('power_on') : tr('last_brewing');
}

function smartStandbyPayload(smart, patch) {
  return {
    enabled: patch.enabled ?? !!smart.enabled,
    minutes: patch.minutes ?? smart.minutes ?? 10,
    after: patch.after ?? smartStandbyAfterValue(smart.after),
  };
}

function RinseSettingsCard({ app, lmConfigured, nativeRinse, rinseSettings, onUseShotdeck }) {
  const runtime = rinseSettings.runtime || {};
  const enabled = rinseSettings.quick_paddle_rinse_enabled === true;
  const controller = rinseSettings.quick_paddle_rinse_controller === 'machine'
    ? 'machine' : 'shotdeck';
  const machineControllerSupported = rinseSettings.machine_controller_supported === true;
  const duration = Number(rinseSettings.quick_paddle_rinse_duration_s ?? 2);
  const durationMin = Number(rinseSettings.duration_min_s ?? 0.5);
  const durationMax = Number(rinseSettings.duration_max_s ?? 10);
  const durationStep = Number(rinseSettings.duration_step_s ?? 0.5);
  const runtimeAvailable = runtime.available !== false;
  const availability = rinseSettings.availability || {};
  const prebrewBlocked = availability.blocked === true;
  const nativeRinseReported = nativeRinse.reported === true;
  const nativeRinseHasEnabled = nativeRinseReported && typeof nativeRinse.enabled === 'boolean';
  const nativeRinseDuration = nativeRinse.duration_s == null ? null : Number(nativeRinse.duration_s);
  const shotdeckRinseConflict = nativeRinse.enabled === true
    && enabled
    && controller === 'shotdeck';
  const controllerOptions = [
    ...(machineControllerSupported || controller === 'machine'
      ? [{ value: 'machine', label: tr('rinse_controller_machine'), disabled: !machineControllerSupported }]
      : []),
    { value: 'shotdeck', label: tr('rinse_controller_shotdeck') },
  ];

  return (
    <Card title={tr('paddle_rinse')} apiNote="PATCH /settings (rinse) · GET /lm">
      <ApiChip>PATCH /settings · rinse</ApiChip>
      <Row label={tr('rinse_enable')} sub={tr('rinse_paddle_hint')}>
        <Switch
          on={enabled}
          disabled={(!runtimeAvailable || prebrewBlocked) && !enabled}
          onChange={value => app.setRinse('quick_paddle_rinse_enabled', value)}
        />
      </Row>
      {!runtimeAvailable && <div className="sd-backup-warning" role="note" style={{ marginTop: 12 }}>
        <strong>{tr('rinse_runtime_unavailable')}</strong>
      </div>}
      {prebrewBlocked && <div className="sd-backup-warning" role="alert" style={{ marginTop: 12 }}>
        <strong>{tr('rinse_prebrew_locked')}</strong>
        <div className="sd-itemsub" style={{ marginTop: 6 }}>{tr('rinse_prebrew_recommend')}</div>
        {onUseShotdeck && <Btn variant="primary" className="sm" style={{ marginTop: 10 }} onClick={onUseShotdeck}>{tr('use_shotdeck_prebrew')}</Btn>}
      </div>}
      <div style={{ marginTop: 14 }}>
        <div className="sd-fieldlabel">{tr('rinse_controller')}</div>
        <Segmented
          value={controller}
          onChange={value => app.setRinse('quick_paddle_rinse_controller', value)}
          options={controllerOptions.map(option => ({ ...option, disabled: prebrewBlocked || option.disabled }))}
        />
        {!machineControllerSupported && <div className="sd-itemsub" style={{ marginTop: 8 }}>
          {tr('rinse_machine_unavailable')}
        </div>}
      </div>
      {controller === 'shotdeck' && <Row label={tr('rinse_duration')} sub={tr('rinse_duration_help')}>
        <Stepper
          value={Number.isFinite(duration) ? duration : 2}
          onChange={value => app.setRinse('quick_paddle_rinse_duration_s', value)}
          min={Number.isFinite(durationMin) ? durationMin : 0.5}
          max={Number.isFinite(durationMax) ? durationMax : 10}
          step={Number.isFinite(durationStep) ? durationStep : 0.5}
          width={130}
          disabled={prebrewBlocked}
        />
      </Row>}
      {lmConfigured && <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--border-soft)' }}>
        <Row
          label={tr('native_rinse_status')}
          sub={nativeRinseReported && nativeRinseDuration != null && Number.isFinite(nativeRinseDuration)
            ? `${nativeRinseDuration.toFixed(1)} s · ${tr('native_rinse_duration')}`
            : tr('native_rinse_status_unavailable')}
        >
          <Pill variant={nativeRinse.enabled === true ? 'good' : ''} dot={nativeRinseHasEnabled}>
            {nativeRinseHasEnabled ? (nativeRinse.enabled ? tr('on') : tr('off')) : tr('native_rinse_not_reported')}
          </Pill>
        </Row>
        <div className="sd-itemsub" style={{ marginTop: 10 }}>{tr('native_rinse_read_only')}</div>
        <div className="sd-itemsub" style={{ marginTop: 4 }}>{tr('native_rinse_live_unavailable')}</div>
        {shotdeckRinseConflict && <div className="sd-backup-warning" role="note" style={{ marginTop: 12 }}>
          <strong>{tr('native_rinse_shotdeck_warning')}</strong>
        </div>}
      </div>}
    </Card>
  );
}

function PrebrewSummaryCard({ app }) {
  const prebrew = (app.data.settings && app.data.settings.prebrew) || {};
  const active = prebrew.active_profile || {};
  const profile = machineActiveProfile(app);
  const preference = (profile && profile.prebrew_preference) || active;
  const enabled = preference.enabled === true;
  const controller = preference.controller === 'shotdeck' ? 'shotdeck' : 'lamarzocco';
  const lmMode = String((profile && profile.prebrew_mode) || active.lm_mode || 'no_change');
  const shotdeckRecipe = (profile && profile.shotdeck_prebrew) || {};
  const guard = prebrew.native_guard || {};

  let selection = tr('prebrew_off');
  let settings = `${tr('la_marzocco')} · ${tr('pb_disabled')}`;
  if (enabled && controller === 'shotdeck') {
    selection = `Shotdeck · ${tr('pb_on')}`;
    settings = `${tr('phase_pump_on')}: ${prebrewTimeText(shotdeckRecipe.pump_s ?? active.shotdeck_pump_s)} · ${tr('phase_soak')}: ${prebrewTimeText(shotdeckRecipe.pause_s ?? active.shotdeck_pause_s)}`;
  } else if (enabled) {
    if (lmMode === 'prebrewing') {
      selection = `${tr('la_marzocco')} · ${tr('pb_on')}`;
      settings = `${prebrewTimeText((profile && profile.prebrew_seconds_on) ?? active.lm_seconds_on)} / ${prebrewTimeText((profile && profile.prebrew_seconds_off) ?? active.lm_seconds_off)}`;
    } else {
      const liveLm = liveLmPrebrewSummary(guard);
      selection = liveLm.selection;
      settings = liveLm.settings;
    }
  }
  const native = guard.state === 'active'
    ? `${tr('la_marzocco')} · ${prebrewModeText(guard.mode)}`
    : guard.state === 'disabled' ? `${tr('la_marzocco')} · ${tr('pb_disabled')}`
    : guard.state === 'unsupported' ? tr('not_supported') : tr('status_unavailable');

  return <Card title={tr('prebrew_mode')} apiNote="GET /status · active profile">
    <div className="sd-sumgrid">
      <div className="sd-sumcell"><div className="sd-sumk">{tr('active_profile')}</div><div className="sd-sumv" style={{ fontSize: 14 }}>{(profile && profile.name) || active.name || '-'}</div></div>
      <div className="sd-sumcell"><div className="sd-sumk">{tr('selected')}</div><div className="sd-sumv" style={{ fontSize: 14 }}>{selection}</div></div>
      <div className="sd-sumcell"><div className="sd-sumk">{tr('settings')}</div><div className="sd-sumv" style={{ fontSize: 13 }}>{settings}</div></div>
      <div className="sd-sumcell"><div className="sd-sumk">{tr('native_guard')}</div><div className="sd-sumv" style={{ fontSize: 13 }}>{native}</div></div>
    </div>
    <div className="sd-itemsub" style={{ marginTop: 12 }}>{tr('machine_prebrew_read_only')}</div>
  </Card>;
}

function GbsSetupWizard({ app, state }) {
  const step = state.step;
  useEffect(() => {
    let pending = false;
    const timer = setInterval(async () => {
      if (pending) return;
      pending = true;
      try { await app.refresh(); } finally { pending = false; }
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  const de = app.lang === 'de';
  const field = step === 1 ? 'host_ip' : 'grinder_ip';
  const [value, setValue] = useState(state[field] || '');
  React.useLayoutEffect(() => { setValue(state[field] || ''); }, [field, state[field]]);
  const translated = [
    ['WLAN verbinden', 'E64 und Shotdeck mit demselben Heimnetz verbinden. An der E64 WLAN öffnen und ein 2,4-GHz-Netz auswählen. Kein Gastnetz verwenden.'],
    ['Mit Shotdeck verbinden', 'An der E64 Machine-to-Machine / Xenia öffnen. Die Shotdeck-IP unten als Maschinenadresse mit Port 80 eingeben. Im Router prüfen und bestätigen. Menünamen hängen von der Firmware ab.'],
    ['E64-Rezept aktivieren', 'Im E64-Rezept Enable GbS einschalten. Getränkegewicht und Brühzeit speichern. Das Gewicht mit dem Shotdeck-Profil abstimmen. Auch die Maschinenverbindung speichern.'],
    ['Mühlenadresse bestätigen', 'Die vorgeschlagene IP mit der E64-WLAN-Anzeige vergleichen. Nur bei Übereinstimmung bestätigen. Sonst die Stations-IP der E64 aus deren Netzwerkanzeige oder der Router-Geräteliste eingeben.'],
    ['Verbindung prüfen', 'Auf E64-Kontakt warten. Bei Problemen beide IPs prüfen, die Xenia-Verbindung an der E64 erneut speichern und sicherstellen, dass beide Geräte im selben Netz sind und Port 80 erreichbar ist.'],
    ['Verbunden', 'Waage verbinden. Mahlen, E64-Knopf drücken, optional spülen, dann im ursprünglichen Zeitfenster brühen. Shotdeck-Spülen erhält die Dosis. Mit Paddle AUS beendete Zyklen bis 5 Sekunden gelten als Spülen; für eine verworfene Dosis GbS-Meldung abbrechen wählen. Verbundene La Marzocco muss eingeschaltet und bereit sein. Ergebnisannahme an der E64 prüfen.'],
  ];
  return <div aria-label="Grinder connect setup">
    <h3>{step + 1}/6 · {de ? translated[step][0] : state.title}</h3>
    <p>{de ? translated[step][1] : state.instructions}</p>
    {(step === 1 || step === 3) && <>
      {step === 1 && !state.host_ip && <p role="status">{de ? 'Shotdeck im Router suchen und seine IPv4-Adresse unten eingeben.' : 'Find Shotdeck in your router device list and enter its IPv4 address below.'}</p>}
      {step === 3 && <p className="sd-itemsub">{de ? 'Verbindungsversuche (bitte prüfen): ' : 'Connection attempts (please verify): '}{state.candidates?.join(', ') || '—'}</p>}
      <label className="sd-fieldlabel" htmlFor="gbs-setup-ip">{step === 1 ? 'Shotdeck IP' : 'E64 IP'}</label>
      <input id="gbs-setup-ip" className="sd-input" inputMode="decimal" value={value} onInput={event => setValue(event.target.value)} />
      <Btn onClick={() => app.gbsAction('setup-address', { [field]: value.trim() })}>{de ? 'Adresse übernehmen' : 'Use address'}</Btn>
      {value.trim() !== state[field] && <p role="status">{de ? 'Adresse zuerst übernehmen.' : 'Use the edited address before continuing.'}</p>}
    </>}
    {step === 3 && !state.discovery_active && <p>{de ? 'Automatische Erkennung abgelaufen. IP manuell eingeben oder Assistenten neu starten.' : 'Discovery expired. Enter the IP manually or close and restart setup.'}</p>}
    {step === 4 && <p role="status">{state.connected ? (de ? 'E64-Kontakt empfangen.' : 'E64 contact received.') : (de ? 'Noch kein neuer E64-Kontakt.' : 'Waiting for fresh E64 contact.')}</p>}
    <div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}>
      {step > 0 && <Btn variant="ghost" onClick={() => app.gbsAction('setup-back')}>{de ? 'Zurück' : 'Back'}</Btn>}
      <Btn variant="ghost" onClick={() => app.gbsAction('setup-close')}>{de ? 'Schließen' : 'Close'}</Btn>
      <Btn disabled={(step === 4 && !state.connected) || ((step === 1 || step === 3) && (!value.trim() || value.trim() !== state[field]))}
        onClick={() => app.gbsAction(step === 5 ? 'setup-close' : 'setup-next')}>
        {step === 5 ? (de ? 'Fertig' : 'Done') : step === 3 ? (de ? 'Bestätigen & GbS aktivieren' : 'Confirm & enable GbS') : step === 1 ? (de ? 'IP bestätigt' : 'Confirm IP') : (de ? 'Weiter' : 'Next')}
      </Btn>
    </div>
    <p className="sd-itemsub">{de ? 'Nach der Adressbestätigung bleibt GbS beim Schließen aktiviert.' : 'After address confirmation, closing setup leaves GbS enabled.'}</p>
  </div>;
}

function GbsSettingsCard({ app }) {
  const state = app.data.settings?.gbs || {};
  const settings = state.settings || {};
  const de = app.lang === 'de';
  const [ip, setIp] = useState(settings.grinder_ip || '');
  useEffect(() => { setIp(settings.grinder_ip || ''); }, [settings.grinder_ip]);
  const setupActive = state.setup?.step != null;
  useEffect(() => {
    if (!settings.enabled || setupActive) return;
    let pending = false;
    const timer = setInterval(async () => {
      if (pending || document.visibilityState === 'hidden') return;
      pending = true;
      try { await app.refresh(); } finally { pending = false; }
    }, 1000);
    return () => clearInterval(timer);
  }, [settings.enabled, setupActive]);
  const transaction = state.transaction || {};
  if (state.setup?.step != null) return <Card title="E64 · Grind-by-Sync"><GbsSetupWizard key={state.setup.step} app={app} state={state.setup} /></Card>;
  return <Card title="E64 · Grind-by-Sync">
    <Btn onClick={() => app.gbsAction('setup-start')}>{de ? 'Mühle verbinden · Assistent starten' : 'Connect grinder · Start setup'}</Btn>
    <Row label={de ? 'GbS aktivieren' : 'Enable GbS'} sub={de ? 'Gilt für alle Brühprofile.' : 'Applies to all brew profiles.'}>
      <Switch on={settings.enabled === true} onChange={value => app.setGbs({ enabled: value })} />
    </Row>
    <label className="sd-fieldlabel" htmlFor="gbs-ip">{de ? 'E64 IP-Adresse' : 'E64 IP address'}</label>
    <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
      <input id="gbs-ip" className="sd-input" value={ip} inputMode="decimal" placeholder="192.168.178.62" onChange={event => setIp(event.target.value)} />
      <Btn onClick={() => app.setGbs({ grinder_ip: ip.trim() })}>{tr('save')}</Btn>
    </div>
    <Row label={de ? 'Zeit zum Brühstart' : 'Brew start window'} sub={de ? 'Nach dem E64-Knopfdruck · 10–120 Sekunden' : 'After pressing the E64 knob · 10–120 seconds'}>
      <select aria-label={de ? 'Zeit zum Brühstart' : 'Brew start window'} className="sd-input" style={{ width: 95 }} value={settings.brew_start_timeout_s ?? 30}
        onChange={event => app.setGbs({ brew_start_timeout_s: Number(event.target.value) })}>
        {Array.from(new Set([...Array.from({ length: 23 }, (_, i) => 10 + i * 5), settings.brew_start_timeout_s ?? 30])).sort((a,b) => a-b).map(value => <option key={value} value={value}>{value} s</option>)}
      </select>
    </Row>
    <div className="sd-itemsub" style={{ margin: '12px 0' }}>{de
      ? `Mahlen → E64-Drehknopf drücken → innerhalb von ${settings.brew_start_timeout_s ?? 30} Sekunden mit Paddle oder Shotdeck brühen. Die Mühle startet die Pumpe nicht.`
      : `Grind → press the E64 knob → brew with the paddle or Shotdeck within ${settings.brew_start_timeout_s ?? 30} seconds. The grinder does not start the pump.`}</div>
    <div className="sd-itemsub" style={{ marginBottom: 12 }}>{de
      ? 'Nach dem Knopfdruck ist ein Shotdeck-Spülgang möglich. Ein mit Paddle AUS beendeter Brühzyklus bis 5 Sekunden gilt als Spülen. Das Zeitfenster läuft weiter. Für einen verworfenen Bezug GbS-Meldung abbrechen wählen.'
      : 'After the knob press, a Shotdeck rinse is allowed. A paddle cycle ended with paddle OFF within 5 seconds counts as a rinse. The start window keeps running. For a discarded extraction, choose Cancel GbS reporting.'}</div>
    {settings.enabled && <>
      <Row label={de ? 'Maschinenbereitschaft · Automatisch' : 'Machine readiness · Automatic'}
        sub={state.readiness_source === 'lamarzocco'
          ? (de ? 'La Marzocco muss eingeschaltet, verbunden und heiß sein.' : 'La Marzocco must be on, connected, and hot.')
          : (de ? 'Bereit, wenn Shotdeck läuft.' : 'Ready while Shotdeck is running.')}>
        <Pill dot>{state.machine_ready ? (de ? 'Bereit' : 'Ready') : (de ? 'Nicht bereit' : 'Not ready')}</Pill>
      </Row>
      <div style={{ margin: '12px 0' }}><Pill dot>{state.phase || 'idle'}</Pill>
        <span className="sd-itemsub" style={{ marginLeft: 8 }}>{state.connection_age_s == null
          ? (de ? 'Noch kein Mühlenkontakt' : 'No grinder contact yet')
          : `${state.connection_age_s}s ${de ? 'seit Mühlenkontakt' : 'since grinder contact'}`}</span></div>
      {state.blocked_reason && <div className="sd-itemsub">{state.blocked_reason}</div>}
      {state.phase === 'armed' && <div role="status">{state.rinse_active
        ? (de ? 'Spülen · Dosis bleibt bereit' : 'Rinsing · dose retained')
        : state.rinse_recovering
          ? (de ? 'Dosis bleibt bereit · Maschine wird bereit' : 'Dose retained · waiting for machine Ready')
          : (de ? 'Dosis bereit · Spülen erlaubt' : 'Dose armed · rinse allowed')} · {state.arm_remaining_s}s</div>}
      {state.phase === 'candidate' && <div role="status">{de
        ? 'Kurzer Paddle-Zyklus · Spülgang wird geprüft (bis 5 s)'
        : 'Short paddle cycle · checking rinse (up to 5 s)'}</div>}
      {state.recipe_target_g != null && <div className="sd-itemsub">E64: {state.recipe_target_g} g · Shotdeck: {state.profile_target_g} g</div>}
      {state.target_mismatch && <div role="status">{de ? 'Rezept- und Profilziel weichen ab.' : 'Recipe and profile targets differ.'}</div>}
      {transaction.duration > 0 && <div>{transaction.duration.toFixed(2)} s · {transaction.weight.toFixed(2)} g</div>}
      {state.last_outcome && <div className="sd-itemsub" style={{ marginTop: 8 }}>{state.last_outcome.outcome} {state.last_outcome.reason}</div>}
      <div className="sd-itemsub" style={{ marginTop: 8 }}>{de ? 'Annahme und Mahlgradanpassung an der E64 prüfen.' : 'Check result acceptance and grind adjustment on the E64.'}</div>
      <Btn variant="ghost" onClick={() => app.gbsAction('cancel')}>{de ? 'GbS-Meldung abbrechen' : 'Cancel GbS reporting'}</Btn>
    </>}
  </Card>;
}

function MachineScreen({ app }) {
  const lm = app.data.lm;
  const snap = lm.snapshot;
  const online = lmOnline(app);
  const machineAwake = online && lmMachineAwake(snap);
  const credentialProvisioningAllowed = lm.credential_provisioning_allowed === true;
  const credentialTransportEncrypted = lm.credential_transport_encrypted === true;
  const [creds, setCreds] = useState({ username: lm.username || '', password: '' });
  const coffee = (snap && snap.coffee_boiler) || {};
  const steam = (snap && snap.steam_boiler) || {};
  const coffeeSettingsAvailable = coffee.supported === true && Number.isFinite(coffee.target_temperature_c);
  const steamLevel = snap && steamBoilerUsesLevel(snap.steam_boiler);
  const steamSettingsAvailable = steam.supported === true && (steamLevel ? steam.target_level != null : Number.isFinite(steam.target_temperature_c));
  const selectedSteamLevel = steamLevelValue(snap && snap.steam_boiler && (snap.steam_boiler.target_level ?? snap.steam_boiler.current_level));
  const smart = (snap && snap.smart_standby) || {};
  const schedules = (snap && snap.schedules) || [];
  const smartSupported = smart.supported === true;
  const smartMinutes = Number(smart.minutes || 10);
  const smartMin = Number(smart.minutes_min || 1);
  const smartMax = Number(smart.minutes_max || 240);
  const smartStep = Number(smart.minutes_step || 1);
  const rinseSettings = (app.data.settings && app.data.settings.rinse) || {};
  const nativeRinse = rinseSettings.machine_rinse || (snap && snap.machine_rinse) || {};

  return (
    <div className="sd-body sd-scroll">
      <Card title={tr('la_marzocco')} helpKey="machine" onHelp={app.openHelp} apiNote="GET /lm · POST /lm/credentials">
        <ApiChip>GET /lm · POST /lm/credentials</ApiChip>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <Pill variant={online ? 'good' : ''} dot>{lm.configured ? (online ? tr('lm_online') : tr('lm_unavailable')) : tr('not_connected')}</Pill>
          {lm.configured && <span className="sd-itemsub">{lm.username}</span>}
        </div>
        {!lm.configured ? (credentialProvisioningAllowed ?
          <form onSubmit={e => { e.preventDefault(); app.lmLogin(creds.username, creds.password); }}>
            {!credentialTransportEncrypted && <div className="sd-local-credential-note">{tr('lm_login_local_http_notice')}</div>}
            <div style={{ marginBottom: 12 }}><label className="sd-fieldlabel" htmlFor="lm-username">{tr('username')}</label>
              <input id="lm-username" name="username" className="sd-input" type="email" inputMode="email"
                autoComplete="username" autoCapitalize="none" spellCheck={false} required
                value={creds.username} onChange={e => setCreds({ ...creds, username: e.target.value })} /></div>
            <div style={{ marginBottom: 16 }}><label className="sd-fieldlabel" htmlFor="lm-password">{tr('password')}</label>
              <input id="lm-password" name="password" className="sd-input" type="password"
                autoComplete="current-password" required
                value={creds.password} onChange={e => setCreds({ ...creds, password: e.target.value })} /></div>
            <Btn type="submit" variant="primary" className="block">{tr('save_login')}</Btn>
          </form> : <EmptyState
          icon="machine"
          title={tr('lm_login_touchscreen_title')}
          sub={tr('lm_login_touchscreen_help')}
        />) : <>
          <Row label={tr('power')} sub={online ? (machineAwake ? tr('machine_on') : tr('machine_standby')) : tr('lm_unavailable')}>
            <Btn variant={machineAwake ? 'ghost' : 'primary'} className="sm" disabled={!online} onClick={() => app.lmPower(!machineAwake)}>
              <Icon name="power" size={16} /> {machineAwake ? tr('turn_off') : tr('turn_on')}
            </Btn>
          </Row>
          <div style={{ marginTop: 12 }}><Btn variant="danger" className="block sm" onClick={() => app.lmClear()}>{tr('lm_sign_out')}</Btn></div>
        </>}
      </Card>

      <PrebrewSummaryCard app={app} />

      {lm.configured && online && <>
        <Card title={tr('machine_info')} right={<Btn variant="ghost" className="sm" onClick={() => app.lmRead()}>{tr('read_settings')}</Btn>} apiNote="POST /lm/refresh">
          <ApiChip>GET /lm/refresh</ApiChip>
          <div className="sd-sumgrid">
            <div className="sd-sumcell"><div className="sd-sumk">{tr('model')}</div><div className="sd-sumv" style={{ fontSize: 14 }}>{snap.machine.model_name}</div></div>
            <div className="sd-sumcell"><div className="sd-sumk">{tr('type')}</div><div className="sd-sumv" style={{ fontSize: 14 }}>{snap.machine.name}</div></div>
            <div className="sd-sumcell"><div className="sd-sumk">{tr('serial')}</div><div className="sd-sumv" style={{ fontSize: 13 }}>{snap.machine.serial_number}</div></div>
            <div className="sd-sumcell"><div className="sd-sumk">{tr('location')}</div><div className="sd-sumv" style={{ fontSize: 13 }}>{snap.machine.location}</div></div>
          </div>
        </Card>

        <Card title={tr('machine_settings')} apiNote="POST /lm/temperatures">
          <ApiChip>POST /lm/temperatures</ApiChip>
          {!coffeeSettingsAvailable && !steamSettingsAvailable && <div className="sd-rowsub">{tr('status_unavailable')}</div>}
          {coffeeSettingsAvailable && <div className="sd-row"><div className="sd-rowlabel">{tr('coffee_c')}<div className="sd-rowsub">{tr('current')} {coffee.current_temperature_c ?? '-'}°</div></div>
            <Stepper value={coffee.target_temperature_c} onChange={v => app.setLmTemp('coffee', v)} min={coffee.raw?.target_temperature_min ?? 80} max={coffee.raw?.target_temperature_max ?? 100} /></div>}
          {steamSettingsAvailable && (steamLevel ? (
            <div style={{ marginTop: 14 }}><div className="sd-fieldlabel">{tr('steam_level')}</div>
              <Segmented value={selectedSteamLevel} onChange={v => app.setLmTemp('steam_level', +v)} options={[0, 1, 2, 3].map(n => ({ value: String(n), label: 'L' + n }))} /></div>
          ) : (
            <div className="sd-row" style={{ marginTop: 0 }}><div className="sd-rowlabel">{tr('steam_c')}<div className="sd-rowsub">{tr('current')} {steam.current_temperature_c ?? '-'}°</div></div>
              <Stepper value={steam.target_temperature_c} onChange={v => app.setLmTemp('steam', v)} min={100} max={140} /></div>
          ))}
        </Card>

        <Card title={tr('auto_standby')} apiNote="PATCH /lm/smart-standby">
          <ApiChip>PATCH /lm/smart-standby</ApiChip>
          <Row label={tr('auto_standby')} sub={smartSupported ? `${smartMinutes} ${tr('minutes')} · ${smartStandbyAfterLabel(smart.after)}` : tr('unavailable')}>
            <Switch on={!!smart.enabled} disabled={!smartSupported} onChange={v => app.setSmartStandby(smartStandbyPayload(smart, { enabled: v }))} />
          </Row>
          {smartSupported && <>
            <Row label={tr('minutes')}>
              <Stepper value={smartMinutes} min={smartMin} max={smartMax} step={smartStep} width={130}
                onChange={v => app.setSmartStandby(smartStandbyPayload(smart, { minutes: v }))} />
            </Row>
            <div style={{ marginTop: 12 }}>
              <div className="sd-fieldlabel">{tr('after')}</div>
              <Segmented value={smartStandbyAfterValue(smart.after)}
                onChange={v => app.setSmartStandby(smartStandbyPayload(smart, { after: v }))}
                options={[
                  { value: 'LastBrewing', label: tr('last_brewing') },
                  { value: 'PowerOn', label: tr('power_on') },
                ]} />
            </div>
          </>}
          <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--border-soft)' }}>
            <Row label={tr('schedule')} sub={schedules.length ? `${schedules.length}` : tr('no_schedules')}>
              <Pill variant={schedules.length ? 'ok' : ''} dot={false}>{schedules.length}</Pill>
            </Row>
            {schedules.map(item => (
              <div className="sd-item" key={item.id || `${item.on_time}-${item.off_time}`} style={{ paddingLeft: 0, paddingRight: 0 }}>
                <div style={{ flex: 1 }}>
                  <span className="sd-itemname">{item.on_time || '-'} / {item.off_time || '-'}</span>
                  <div className="sd-itemsub">{(item.days || []).join(', ') || '-'}</div>
                </div>
                <Pill variant={item.enabled ? 'good' : ''} dot>{item.enabled ? tr('on') : tr('off')}</Pill>
              </div>
            ))}
          </div>
        </Card>
      </>}

      <GbsSettingsCard app={app} />
      <RinseSettingsCard
        app={app}
        lmConfigured={lm.configured}
        nativeRinse={nativeRinse}
        rinseSettings={rinseSettings}
        onUseShotdeck={() => app.go('profiles')}
      />
    </div>
  );
}

// ---- Wi-Fi (reached from top-bar icon) — real /api/wifi/* ----
function WifiScreen({ app }) {
  const [mode, setMode] = useState('idle'); // idle | scanning | scanned | saved
  const [status, setStatus] = useState(null); // {connected,ssid,signal,...}
  const [networks, setNetworks] = useState([]);
  const [saved, setSaved] = useState([]);
  const [connecting, setConnecting] = useState(null); // network object pending password
  const [pw, setPw] = useState('');
  const [radioBusy, setRadioBusy] = useState(false);
  const [radioMessage, setRadioMessage] = useState('');
  const expectedDisconnect = useRef(false);

  const loadStatus = async () => {
    try {
      const s = await api('/api/wifi/status'); setStatus(s);
      if (!s.busy) {
        setRadioBusy(false); expectedDisconnect.current = false;
        if (radioBusy && !s.error && typeof s.enabled === 'boolean') setRadioMessage(tr(s.enabled ? 'wifi_on' : 'wifi_off'));
      }
      if (s.error) setRadioMessage(s.error);
      return s;
    } catch (e) {
      if (!expectedDisconnect.current) app.toast(e.message);
      return null;
    }
  };
  useEffect(() => { loadStatus(); }, []);
  useEffect(() => {
    if (!radioBusy) return;
    const timer = setInterval(loadStatus, 1500);
    // Stop polling a deliberately disconnected page; local controls or LAN
    // provide recovery. Do not turn this expected event into retry popups.
    const deadline = setTimeout(() => { clearInterval(timer); setRadioBusy(false); }, 15000);
    return () => { clearInterval(timer); clearTimeout(deadline); };
  }, [radioBusy]);
  const radioEnabled = !status || status.enabled !== false;
  const changeRadio = async () => {
    const enabled = !radioEnabled;
    if (!enabled && !window.confirm(tr('wifi_off_confirm'))) return;
    setRadioBusy(true); setMode('idle');
    setRadioMessage(tr(enabled ? 'wifi_turning_on' : 'wifi_turning_off'));
    expectedDisconnect.current = !enabled;
    try {
      await api('/api/wifi/radio', { method: 'POST', body: JSON.stringify({ enabled }) });
      if (!enabled) setRadioMessage(tr('wifi_off_recovery'));
    } catch (e) {
      if (e.status || !expectedDisconnect.current) { expectedDisconnect.current = false; app.toast(e.message); setRadioMessage(e.message); setRadioBusy(false); }
      else setRadioMessage(tr('wifi_off_recovery'));
    }
  };

  const scan = async () => {
    setMode('scanning'); setNetworks([]);
    const s = await loadStatus();
    try {
      const data = await api('/api/wifi/networks');
      setNetworks(data.networks || []);
      setMode('scanned');
    } catch (e) { app.toast(e.message); setMode('idle'); }
  };
  const loadSaved = async () => {
    await loadStatus();
    try { const data = await api('/api/wifi/saved'); setSaved(data.saved || []); setMode('saved'); }
    catch (e) { app.toast(e.message); }
  };
  const connectOpen = async (n) => {
    try {
      await api('/api/wifi/connect', { method: 'POST', body: JSON.stringify({ ssid: n.ssid, password: '' }) });
      app.toast(tr('wifi_switching')); setMode('idle');
    } catch (e) { app.toast(e.message); }
  };
  const pickNetwork = (n) => {
    if (n.requires_password) { setPw(''); setConnecting(n); }
    else connectOpen(n);
  };
  const submitPassword = async () => {
    const n = connecting; if (!n) return;
    setConnecting(null);
    try {
      await api('/api/wifi/connect', { method: 'POST', body: JSON.stringify({ ssid: n.ssid, password: pw }) });
      app.toast(tr('wifi_switching')); setMode('idle');
    } catch (e) { app.toast(e.message); }
  };
  const reconnect = async (c) => {
    try {
      await api('/api/wifi/saved-connect', { method: 'POST', body: JSON.stringify({ name: c.name, uuid: c.uuid, ssid: c.ssid }) });
      app.toast(tr('wifi_switching')); setMode('idle');
    } catch (e) { app.toast(e.message); }
  };
  const forget = async (c) => {
    if (!window.confirm(tr('forget_warn'))) return;
    try {
      await api('/api/wifi/forget', { method: 'POST', body: JSON.stringify({ name: c.name, uuid: c.uuid, ssid: c.ssid }) });
      app.toast(tr('forget')); await loadStatus(); loadSaved();
    } catch (e) { app.toast(e.message); }
  };
  const disconnect = async () => {
    try { await api('/api/wifi/disconnect', { method: 'POST' }); app.toast(tr('disconnect')); await loadStatus(); }
    catch (e) { app.toast(e.message); }
  };

  return (
    <div className="sd-body sd-scroll">
      <Card title={tr('wifi_radio')}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div className="sd-rowlabel">{tr(radioEnabled ? 'wifi_on' : 'wifi_off')}</div>
            <div className="sd-rowsub">{tr('wifi_radio_help')}</div>
          </div>
          <Btn variant={radioEnabled ? 'ghost' : 'primary'} className="sm"
            disabled={!status || radioBusy || (radioEnabled ? status.can_disable === false : status.available === false)}
            onClick={changeRadio}>{tr(radioEnabled ? 'wifi_turn_off' : 'wifi_turn_on')}</Btn>
        </div>
        {status && status.ethernet_connected && <div className="sd-rowsub" style={{ marginTop: 12 }}>{tr('wifi_ethernet')} {status.ethernet_address || ''}</div>}
        {radioMessage && <div role="status" className="sd-rowsub" style={{ marginTop: 12 }}>{radioMessage}</div>}
      </Card>
      <Card title={tr('wifi')} helpKey="wifi" onHelp={app.openHelp} apiNote="GET /wifi/status · /networks · /saved">
        <ApiChip>GET /wifi/status · /networks · /saved</ApiChip>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
          <Icon name="wifi" size={22} color={status && status.connected ? 'var(--success)' : 'var(--fg-faint)'} />
          {status && status.connected
            ? <div><div className="sd-rowlabel">{tr('connected')} · {status.ssid}</div><div className="sd-rowsub">{tr('signal')} {status.signal}%</div></div>
            : <div><div className="sd-rowlabel">{status && status.enabled === false ? tr('wifi_off') : (status && status.message) || tr('not_connected')}</div></div>}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="primary" className="block sm" disabled={!radioEnabled || radioBusy} onClick={scan}>{tr('scan')}</Btn>
          <Btn variant="ghost" className="block sm" onClick={loadSaved}>{tr('saved')}</Btn>
          <Btn variant="ghost" className="sm" disabled={radioBusy || !(status && status.connected)} onClick={disconnect}>{tr('disconnect')}</Btn>
        </div>
      </Card>

      {radioEnabled && mode === 'scanning' && <Card><Loading label={tr('scanning')} /></Card>}

      {radioEnabled && mode === 'scanned' && (
        <Card title={tr('scan')} flush apiNote="POST /wifi/connect">
          <div style={{ padding: '0 16px' }}><ApiChip>POST /wifi/connect</ApiChip></div>
          {networks.length === 0 && <div className="sd-item"><span className="sd-itemsub">{tr('no_networks')}</span></div>}
          {networks.map((n, i) => {
            const here = n.active || (status && status.ssid === n.ssid);
            return (
              <div className="sd-item" key={n.ssid + i} onClick={() => !here && pickNetwork(n)} style={{ cursor: here ? 'default' : 'pointer' }}>
                <Icon name="wifi" size={18} color={n.signal > 60 ? 'var(--fg)' : 'var(--fg-faint)'} />
                <div style={{ flex: 1 }}><span className="sd-itemname">{n.ssid}</span>{here && <span className="sd-itemsub"> · {tr('connected')}</span>}</div>
                <span className="sd-mono" style={{ color: 'var(--fg-faint)', fontSize: 12 }}>{n.signal}%</span>
              </div>
            );
          })}
        </Card>
      )}

      {mode === 'saved' && (
        <Card title={tr('saved')} flush apiNote="POST /wifi/saved-connect · /forget">
          <div style={{ padding: '0 16px' }}><ApiChip>POST /wifi/saved-connect · /forget</ApiChip></div>
          {saved.length === 0 && <div className="sd-item"><span className="sd-itemsub">{tr('no_networks')}</span></div>}
          {saved.map((c, i) => {
            const label = c.display_name || c.ssid || c.name;
            const here = status && c.display_name === status.ssid;
            return (
              <div className="sd-item" key={(c.uuid || c.name || c.ssid) + i}>
                <Icon name="wifi" size={18} color={here ? 'var(--success)' : 'var(--fg-faint)'} />
                <div style={{ flex: 1 }}><span className="sd-itemname">{label}</span>{here && <span className="sd-itemsub"> · {tr('connected')}</span>}</div>
                <Btn variant="ghost" className="sm" disabled={here || !radioEnabled || radioBusy} onClick={() => reconnect(c)}>{tr('reconnect')}</Btn>
                <Btn variant="danger" className="sm" onClick={() => forget(c)}>{tr('forget')}</Btn>
              </div>
            );
          })}
          <div style={{ padding: 14, borderTop: '1px solid var(--border-soft)' }}>
            <div className="sd-tags"><Tag warn>{tr('forget_warn')}</Tag></div>
          </div>
        </Card>
      )}

      {connecting && (
        <Modal title={connecting.ssid} onClose={() => setConnecting(null)}
          footer={<Btn variant="primary" className="block" onClick={submitPassword}>{tr('connect')}</Btn>}>
          <div className="sd-fieldlabel">{tr('enter_password')}</div>
          <input className="sd-input" type="password" autoFocus value={pw}
            onChange={e => setPw(e.target.value)} onKeyDown={e => e.key === 'Enter' && submitPassword()} />
        </Modal>
      )}
    </div>
  );
}

// ---- Settings ----
function updateStatusText(update) {
  const target = update.target_version ? ` v${update.target_version}` : '';
  if (update.state === 'checking') return tr('checking_updates');
  if (update.state === 'up_to_date') return tr('software_up_to_date');
  if (update.state === 'available') return tr('update_available') + target;
  if (update.state === 'unavailable') return tr('no_update_available');
  if (update.state === 'queued') return tr('preparing_update') + target;
  if (update.state === 'installing') return tr('installing_version') + target;
  if (update.state === 'installed') return tr('updated_to') + target;
  if (update.state === 'disabled') return tr('updates_disabled');
  if (update.state === 'blocked') return tr('updates_unavailable');
  if (update.state === 'error') return tr('update_failed');
  return tr('update_not_checked');
}

function backupDateText(app, value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString(app.lang === 'de' ? 'de-DE' : 'en-GB', {
    dateStyle: 'medium', timeStyle: 'short',
  });
}

function backupStateText(state) {
  const key = `backup_state_${String(state || 'idle').toLowerCase()}`;
  const value = tr(key);
  return value === key ? tr('backup_state_idle') : value;
}

function BackupRestoreCard({ app }) {
  const [status, setStatus] = useState({ state: 'loading' });
  const [personalDrive, setPersonalDrive] = useState({ provider: 'google_drive', connected: false, enabled: false, cadence: 'weekly', retention_count: 10 });
  const [nextcloudCredentials, setNextcloudCredentials] = useState({ server_url: '', username: '', app_password: '' });
  const [options, setOptions] = useState({
    include_photos: false,
    include_scale_binding: false,
    include_machine_learning: false,
  });
  const [busy, setBusy] = useState(false);
  const [recovery, setRecovery] = useState(null);
  const [recoverySaved, setRecoverySaved] = useState(false);
  const [restore, setRestore] = useState(() => {
    const restoreId = window.sessionStorage.getItem('shotdeck_restore_id');
    return restoreId ? { restore_id: restoreId, state: 'checking' } : null;
  });
  const [restorePin, setRestorePin] = useState('');
  const [deviceInput, setDeviceInput] = useState({ state: 'idle' });
  const restoreInput = useRef(null);
  const deviceInputCompletion = useRef('');
  const personalDriveDraftDirty = useRef(false);
  const active = ['preparing', 'encrypting', 'restoring', 'applying', 'queued'].includes(String(status.state));
  const recoveryStatus = status.recovery || {};
  const recoveryConfirmed = recoveryStatus.confirmed === true;
  const displaySize = String(app.data?.settings?.device?.display_size || '').toLowerCase();
  const nonTouchDisplay = !['3.5f', '3.5_f', '3.5-f'].includes(displaySize);

  const load = async () => {
    const [localResult, personalDriveResult] = await Promise.allSettled([
      api('/api/backups/status'), api('/api/backups/personal-drive'),
    ]);
    if (localResult.status === 'fulfilled') setStatus(localResult.value);
    if (personalDriveResult.status === 'fulfilled') {
      setPersonalDrive(current => personalDriveDraftDirty.current ? {
        ...personalDriveResult.value,
        provider: current.provider,
        cadence: current.cadence,
        retention_count: current.retention_count,
      } : personalDriveResult.value);
    }
  };

  useEffect(() => {
    load();
    const timer = window.setInterval(load, active ? 1200 : 10000);
    return () => window.clearInterval(timer);
  }, [active]);

  useEffect(() => {
    if (!['active', 'processing'].includes(String(deviceInput.state))) return undefined;
    let cancelled = false;
    const poll = async () => {
      try {
        const result = await api('/api/backups/device-input');
        if (cancelled) return;
        setDeviceInput(result);
        if (result.state === 'completed' && deviceInputCompletion.current !== result.purpose) {
          deviceInputCompletion.current = result.purpose;
          if (result.purpose === 'restore_recovery' && result.recovery_armed) {
            app.toast(tr('device_recovery_ready'));
          }
          await load();
        }
      } catch (error) {
        if (!cancelled) app.toast(error.message);
      }
    };
    poll();
    const timer = window.setInterval(poll, 800);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [deviceInput.state, deviceInput.purpose]);

  useEffect(() => {
    const restoreId = restore && (restore.restore_id || restore.id);
    const restoreState = String((restore && restore.state) || 'staged');
    if (!restoreId || !['checking', 'queued', 'applying', 'restoring', 'rollback'].includes(restoreState)) return undefined;
    let cancelled = false;
    const poll = async () => {
      try {
        const result = await api(`/api/backups/restore/${encodeURIComponent(restoreId)}/status`);
        if (!cancelled) setRestore(current => ({ ...(current || {}), ...result }));
        if (['complete', 'completed', 'failed', 'rolled_back'].includes(String(result.state))) {
          window.sessionStorage.removeItem('shotdeck_restore_id');
        }
      } catch (_error) {
        // The service intentionally restarts during apply. Keep polling so
        // this tab reconnects and reports the persisted result.
      }
    };
    poll();
    const timer = window.setInterval(poll, 1500);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [restore && restore.restore_id, restore && restore.state]);

  const mutate = async fn => {
    setBusy(true);
    try { await fn(); await load(); }
    catch (error) { app.toast(error.message); }
    finally { setBusy(false); }
  };

  const showPhysicalConfirmation = async purpose => {
    try {
      await api('/api/backups/confirmation', {
        method: 'POST', body: JSON.stringify({ purpose }),
      });
      return true;
    } catch (error) {
      app.toast(error.message);
      return false;
    }
  };

  const startDeviceInput = async purpose => {
    setBusy(true);
    deviceInputCompletion.current = '';
    try {
      const result = await api('/api/backups/device-input', {
        method: 'POST', body: JSON.stringify({ purpose }),
      });
      setDeviceInput(result);
    } catch (error) { app.toast(error.message); }
    finally { setBusy(false); }
  };

  const cancelDeviceInput = async () => {
    setBusy(true);
    try {
      const result = await api('/api/backups/device-input', { method: 'DELETE' });
      setDeviceInput(result);
    } catch (error) { app.toast(error.message); }
    finally { setBusy(false); }
  };

  const setupRecovery = () => mutate(async () => {
    const result = await api('/api/backups/recovery', {
      method: 'POST', body: JSON.stringify({ action: 'initialize' }),
    });
    setRecovery(result);
    setRecoverySaved(false);
  });

  const confirmRecovery = () => mutate(async () => {
    await api('/api/backups/recovery', {
      method: 'POST', body: JSON.stringify({ action: 'confirm' }),
    });
    setRecovery(null);
    app.toast(tr('recovery_confirmed'));
  });

  const revealRecovery = async () => {
    if (!await showPhysicalConfirmation('reveal_backup_recovery')) return;
    const confirmationPin = window.prompt(tr('physical_pin_prompt'));
    if (!confirmationPin) return;
    mutate(async () => {
      const result = await api('/api/backups/recovery', {
        method: 'POST', body: JSON.stringify({ action: 'reveal', confirmation_pin: confirmationPin }),
      });
      setRecovery({ ...result, mode: 'reveal' });
      setRecoverySaved(false);
    });
  };

  const createBackup = () => mutate(async () => {
    const result = await api('/api/backups', {
      method: 'POST', body: JSON.stringify(options),
    });
    setStatus(result);
  });

  const deleteBackup = async () => {
    if (!window.confirm(tr('backup_delete_confirm'))) return;
    if (!await showPhysicalConfirmation('delete_local_backup')) return;
    const confirmationPin = window.prompt(tr('physical_pin_prompt'));
    if (!confirmationPin) return;
    mutate(async () => {
      await api('/api/backups/latest', {
        method: 'DELETE', body: JSON.stringify({ confirmation_pin: confirmationPin }),
      });
      app.toast(tr('deleted'));
    });
  };

  const stageRestore = async file => {
    if (!file) return;
    setBusy(true);
    setRestore(null);
    try {
      const headers = {
        'Content-Type': 'application/octet-stream',
        'X-Shotdeck-CSRF': '1',
        'X-Shotdeck-Backup-Name': encodeURIComponent(file.name || 'backup.sdbak'),
      };
      const response = await fetch('/api/backups/restore', { method: 'POST', headers, body: file });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || tr('restore_stage_failed'));
      setRestore(result);
      if (result.restore_id || result.id) window.sessionStorage.setItem('shotdeck_restore_id', result.restore_id || result.id);
      await showPhysicalConfirmation('apply_restore');
      setDeviceInput({ state: 'idle' });
    } catch (error) { app.toast(error.message); }
    finally {
      setBusy(false);
      if (restoreInput.current) restoreInput.current.value = '';
    }
  };

  const applyRestore = () => mutate(async () => {
    const restoreId = restore && (restore.restore_id || restore.id);
    if (!restoreId) throw new Error(tr('restore_stage_failed'));
    const result = await api(`/api/backups/restore/${encodeURIComponent(restoreId)}/apply`, {
      method: 'POST', body: JSON.stringify({ confirmation_pin: restorePin.trim() }),
    });
    setRestore({ ...restore, ...result });
    window.sessionStorage.setItem('shotdeck_restore_id', result.restore_id || restoreId);
    setRestorePin('');
  });

  const personalDriveScope = () => ({
    include_photos: options.include_photos,
    include_scale_binding: options.include_scale_binding,
    include_machine_learning: options.include_machine_learning,
  });

  const connectPersonalDrive = () => {
    const nextcloud = personalDrive.provider === 'nextcloud';
    const authorizationWindow = nextcloud ? null : window.open('about:blank', '_blank');
    if (authorizationWindow) authorizationWindow.opener = null;
    mutate(async () => {
      let navigated = false;
      try {
        const result = await api('/api/backups/personal-drive/connect', {
          method: 'POST', body: JSON.stringify({
            provider: personalDrive.provider || 'google_drive',
            cadence: personalDrive.cadence || 'weekly',
            retention_count: Number(personalDrive.retention_count || 10),
            scope: personalDriveScope(),
            ...(nextcloud ? nextcloudCredentials : {}),
          }),
        });
        personalDriveDraftDirty.current = false;
        setPersonalDrive(result);
        if (nextcloud) setNextcloudCredentials(current => ({ ...current, app_password: '' }));
        if (authorizationWindow && result.authorization_url) authorizationWindow.location = result.authorization_url;
        else if (result.authorization_url) window.location.href = result.authorization_url;
        navigated = true;
      } finally {
        if (!navigated && authorizationWindow) authorizationWindow.close();
      }
    });
  };

  const finishPersonalDrive = () => mutate(async () => {
    const result = await api('/api/backups/personal-drive/complete', { method: 'POST', body: '{}' });
    setPersonalDrive(result);
  });

  const savePersonalDrive = (enabled = personalDrive.enabled) => mutate(async () => {
    const result = await api('/api/backups/personal-drive/settings', {
      method: 'POST', body: JSON.stringify({
        cadence: personalDrive.cadence,
        retention_count: Number(personalDrive.retention_count),
        enabled: !!enabled,
        scope: personalDriveScope(),
      }),
    });
    personalDriveDraftDirty.current = false;
    setPersonalDrive(result);
  });

  const disconnectPersonalDrive = () => {
    if (!window.confirm(tr('personal_drive_disconnect_confirm'))) return;
    mutate(async () => {
      const result = await api('/api/backups/personal-drive/disconnect', { method: 'POST', body: '{}' });
      setPersonalDrive(result);
    });
  };

  const runPersonalDrive = () => mutate(async () => {
    const result = await api('/api/backups/personal-drive/run', { method: 'POST', body: '{}' });
    setPersonalDrive(result);
  });

  const artifact = status.artifact || status.latest_artifact || {};
  const hasArtifact = !!artifact.filename;
  const rawProgress = Number(status.progress || 0);
  const progress = Math.max(0, Math.min(100, rawProgress > 0 && rawProgress <= 1 ? rawProgress * 100 : rawProgress));
  const restorePreview = (restore && restore.preview) || restore || {};
  const physicalInputActive = ['active', 'processing'].includes(String(deviceInput.state));
  const restoreDeviceInput = deviceInput.purpose === 'restore_recovery';
  return (
    <Card title={tr('backup_restore')} apiNote="/api/backups · /restore · /personal-drive"
      right={<Pill variant={status.state === 'ready' ? 'good' : active ? 'ok' : ''}>{backupStateText(status.state)}</Pill>}>
      <ApiChip>POST /backups · GET /backups/status · /latest</ApiChip>
      <div className="sd-backup-section">
        <div className="sd-backup-heading">
          <div className="sd-rowlabel">{tr('manual_backup')}</div>
          <div className="sd-rowsub">{tr('backup_desc')}</div>
        </div>
        <div className="sd-backup-includes">
          <span>{tr('backup_always_includes')}</span>
          <span>{tr('backup_always_excludes')}</span>
        </div>
        <Row label={tr('backup_photos')} sub={tr('backup_photos_sub')}>
          <Switch on={options.include_photos} disabled={active || busy} onChange={value => setOptions({ ...options, include_photos: value })} />
        </Row>
        <Row label={tr('backup_scale')} sub={tr('backup_scale_sub')}>
          <Switch on={options.include_scale_binding} disabled={active || busy} onChange={value => setOptions({ ...options, include_scale_binding: value })} />
        </Row>
        <Row label={tr('backup_learning')} sub={tr('backup_learning_sub')}>
          <Switch on={options.include_machine_learning} disabled={active || busy} onChange={value => setOptions({ ...options, include_machine_learning: value })} />
        </Row>
        {!recoveryConfirmed && (
          <div className="sd-backup-warning">
            <strong>{tr('recovery_required')}</strong>
            <span>{tr('recovery_required_desc')}</span>
            <Btn variant="primary" className="sm" disabled={busy} onClick={setupRecovery}>{tr('setup_recovery')}</Btn>
          </div>
        )}
        {recoveryConfirmed && <Btn variant="ghost" className="sm" disabled={busy || active} onClick={revealRecovery}>{tr('show_recovery_code')}</Btn>}
        {active && (
          <div className="sd-backup-progress" aria-live="polite">
            <div><span>{backupStateText(status.state)}</span><span>{progress}%</span></div>
            <progress max="100" value={progress} />
          </div>
        )}
        {status.error && <div className="sd-update-error" role="alert">{status.error}</div>}
        <div className="sd-backup-actions">
          <Btn variant="primary" className="block" disabled={busy || active || !recoveryConfirmed} onClick={createBackup}>{tr('create_backup')}</Btn>
          {hasArtifact && !active && (
            <a className="sd-btn ghost block sd-download-link" href="/api/backups/latest" download={artifact.filename || ''}>{tr('download_backup')}</a>
          )}
          {hasArtifact && !active && <Btn variant="danger" className="sm" disabled={busy} onClick={deleteBackup}>{tr('delete_local_copy')}</Btn>}
        </div>
        {artifact.created_at && <div className="sd-backup-meta">{tr('created')} · {backupDateText(app, artifact.created_at)}{artifact.size ? ` · ${(artifact.size / 1024 / 1024).toFixed(1)} MB` : ''}</div>}
      </div>

      <div className="sd-backup-section">
        <div className="sd-backup-heading">
          <div className="sd-rowlabel">{tr('restore_backup')}</div>
          <div className="sd-rowsub">{tr('restore_desc')}</div>
        </div>
        <div className="sd-backup-warning">
          <strong>{tr('physical_recovery_entry')}</strong>
          <span>{tr('physical_recovery_entry_desc')}</span>
        </div>
        {nonTouchDisplay ? <>
          {!restoreDeviceInput || !physicalInputActive ? <Btn variant="ghost" className="block" disabled={busy || active || physicalInputActive}
            onClick={() => startDeviceInput('restore_recovery')}>{tr('enter_recovery_on_device')}</Btn> : null}
          {restoreDeviceInput && physicalInputActive && <div className="sd-cloud-notice" aria-live="polite">
            <strong>{tr('device_input_in_progress')}</strong>
            <span>{deviceInput.entered_characters || 0} / {deviceInput.expected_characters || 60}</span>
            <span>{tr('device_input_controls')}</span>
            <Btn variant="ghost" className="sm" disabled={busy || deviceInput.state === 'processing'} onClick={cancelDeviceInput}>{tr('cancel')}</Btn>
          </div>}
          {restoreDeviceInput && deviceInput.state === 'completed' && deviceInput.recovery_armed &&
            <div className="sd-backup-note">{tr('device_recovery_ready')}</div>}
        </> : <div className="sd-backup-note">{tr('touch_recovery_entry')}</div>}
        <input ref={restoreInput} type="file" accept=".sdbak,application/octet-stream" style={{ display: 'none' }}
          onChange={event => stageRestore(event.target.files && event.target.files[0])} />
        <Btn variant="ghost" className="block" disabled={busy || active || (restoreDeviceInput && physicalInputActive)}
          onClick={() => restoreInput.current && restoreInput.current.click()}>{tr('choose_backup_file')}</Btn>
      </div>

      <div className="sd-backup-section">
        <div className="sd-cloud-head">
          <div className="sd-backup-heading"><div className="sd-rowlabel">{tr('personal_drive_title')}</div><div className="sd-rowsub">{tr('personal_drive_desc')}</div></div>
          <Pill variant={personalDrive.connected && personalDrive.enabled ? 'good' : ''}>
            {personalDrive.connected ? (personalDrive.enabled ? tr('personal_drive_enabled') : tr('personal_drive_paused')) : tr('personal_drive_not_connected')}
          </Pill>
        </div>
        {personalDrive.last_error && <div className="sd-update-error">{personalDrive.last_error}</div>}
        <div className="sd-cloud-grid">
          <span>{tr('personal_drive_provider')}</span>
          <select disabled={busy || personalDrive.connected || personalDrive.oauth_pending} value={personalDrive.provider || 'google_drive'} onChange={event => { personalDriveDraftDirty.current = true; setPersonalDrive({ ...personalDrive, provider: event.target.value }); }}>
            <option value="google_drive">Google Drive</option><option value="dropbox">Dropbox</option><option value="nextcloud">Nextcloud</option>
          </select>
          {!personalDrive.connected && personalDrive.provider === 'nextcloud' && <>
            <span>{tr('nextcloud_server')}</span>
            <input className="sd-input" type="url" inputMode="url" autoCapitalize="none" autoCorrect="off" spellCheck={false}
              placeholder="https://cloud.example.com" value={nextcloudCredentials.server_url}
              onChange={event => setNextcloudCredentials({ ...nextcloudCredentials, server_url: event.target.value })} />
            <span>{tr('nextcloud_username')}</span>
            <input className="sd-input" type="text" autoCapitalize="none" autoCorrect="off" spellCheck={false}
              value={nextcloudCredentials.username}
              onChange={event => setNextcloudCredentials({ ...nextcloudCredentials, username: event.target.value })} />
            <span>{tr('nextcloud_app_password')}</span>
            <input className="sd-input" type="password" autoComplete="new-password"
              value={nextcloudCredentials.app_password}
              onChange={event => setNextcloudCredentials({ ...nextcloudCredentials, app_password: event.target.value })} />
          </>}
          <span>{tr('cadence')}</span>
          <select disabled={busy || personalDrive.oauth_pending} value={personalDrive.cadence || 'weekly'} onChange={event => { personalDriveDraftDirty.current = true; setPersonalDrive({ ...personalDrive, cadence: event.target.value }); }}>
            <option value="daily">{tr('cadence_daily')}</option><option value="weekly">{tr('cadence_weekly')}</option><option value="monthly">{tr('cadence_monthly')}</option>
          </select>
          <span>{tr('personal_drive_keep')}</span>
          <select disabled={busy || personalDrive.oauth_pending} value={Number(personalDrive.retention_count || 10)} onChange={event => { personalDriveDraftDirty.current = true; setPersonalDrive({ ...personalDrive, retention_count: Number(event.target.value) }); }}>
            {[5, 10, 20, 50].map(count => <option key={count} value={count}>{count}</option>)}
          </select>
          <span>{tr('last_backup')}</span><strong>{backupDateText(app, personalDrive.last_success_at)}</strong>
          <span>{tr('next_backup')}</span><strong>{backupDateText(app, personalDrive.next_due_at)}</strong>
        </div>
        {!personalDrive.connected && personalDrive.provider === 'nextcloud' && <div className="sd-backup-note">{tr('nextcloud_app_password_hint')}</div>}
        {!personalDrive.connected && personalDrive.provider === 'nextcloud' && window.location.protocol !== 'https:' && <div className="sd-backup-warning" role="note">
          <strong>{tr('nextcloud_local_http_warning')}</strong>
        </div>}
        <div className="sd-backup-note">{tr('personal_drive_privacy')}</div>
        {!recoveryConfirmed && !personalDrive.connected && <div id="sd-personal-drive-recovery-required" className="sd-cloud-notice" role="note">
          <strong>{tr('personal_drive_recovery_required')}</strong>
        </div>}
        {!personalDrive.connected && !personalDrive.oauth_pending && <Btn variant="primary" className="block"
          aria-describedby={!recoveryConfirmed ? 'sd-personal-drive-recovery-required' : undefined}
          disabled={busy || !recoveryConfirmed} onClick={connectPersonalDrive}>{tr('personal_drive_connect')}</Btn>}
        {personalDrive.oauth_pending && <div className="sd-backup-actions">
          <Btn variant="primary" disabled={busy || !recoveryConfirmed} onClick={finishPersonalDrive}>{tr('personal_drive_finish')}</Btn>
          <Btn variant="ghost" disabled={busy || !recoveryConfirmed} onClick={connectPersonalDrive}>{tr('personal_drive_restart')}</Btn>
        </div>}
        {personalDrive.connected && <div className="sd-backup-actions">
          <Btn variant="ghost" disabled={busy} onClick={() => savePersonalDrive(personalDrive.enabled)}>{tr('save_settings')}</Btn>
          <Btn variant="ghost" disabled={busy || !personalDrive.enabled || personalDrive.run_requested} onClick={runPersonalDrive}>{tr('backup_now')}</Btn>
          <Btn variant="ghost" disabled={busy} onClick={() => savePersonalDrive(!personalDrive.enabled)}>{personalDrive.enabled ? tr('pause_uploads') : tr('resume_uploads')}</Btn>
          <Btn variant="danger" disabled={busy} onClick={disconnectPersonalDrive}>{tr('personal_drive_disconnect')}</Btn>
        </div>}
      </div>

      {recovery && (
        <Modal title={recovery.mode === 'reveal' ? tr('show_recovery_code') : tr('save_recovery_code')} onClose={() => setRecovery(null)} footer={recovery.mode === 'reveal'
          ? <Btn variant="primary" className="block" onClick={() => setRecovery(null)}>{tr('close')}</Btn>
          : <>
            <Btn variant="ghost" className="block" onClick={() => setRecovery(null)}>{tr('cancel')}</Btn>
            <Btn variant="primary" className="block" disabled={!recoverySaved || busy} onClick={confirmRecovery}>{tr('confirm_saved')}</Btn>
          </>}>
          <p className="sd-rowsub">{tr('recovery_code_desc')}</p>
          {recovery.recovery_code
            ? <div className="sd-recovery-code" aria-label={tr('recovery_code')}>{recovery.recovery_code}</div>
            : recovery.shown_on_device
              ? <div className="sd-backup-warning">{tr('recovery_on_device')}</div>
              : <div className="sd-backup-warning">{tr('recovery_display_required')}</div>}
          {recovery.mode !== 'reveal' && (recovery.recovery_code || recovery.shown_on_device) && <label className="sd-checkline"><input type="checkbox" checked={recoverySaved} onChange={event => setRecoverySaved(event.target.checked)} /> {tr('i_saved_recovery')}</label>}
        </Modal>
      )}

      {restore && (
        <Modal title={['queued', 'applying', 'restoring', 'rollback', 'checking'].includes(String(restore.state)) ? tr('restore_in_progress') : tr('confirm_restore')}
          dismissible={!['queued', 'applying', 'restoring', 'rollback'].includes(String(restore.state))}
          onClose={() => { window.sessionStorage.removeItem('shotdeck_restore_id'); setRestore(null); }}
          footer={['queued', 'applying', 'restoring', 'rollback', 'checking'].includes(String(restore.state)) ? null : <>
            <Btn variant="ghost" className="block" onClick={() => { window.sessionStorage.removeItem('shotdeck_restore_id'); setRestore(null); }}>{['complete', 'completed', 'failed', 'rolled_back'].includes(String(restore.state)) ? tr('dismiss') : tr('cancel')}</Btn>
            {!['complete', 'completed', 'failed', 'rolled_back'].includes(String(restore.state)) && <Btn variant="danger" className="block" disabled={!restorePin.trim() || busy} onClick={applyRestore}>{tr('restore_and_restart')}</Btn>}
          </>}>
          {['queued', 'applying', 'restoring', 'rollback', 'checking'].includes(String(restore.state)) ? (
            <div className="sd-update-progress" aria-live="polite">
              <div className="sd-spinner" aria-hidden="true" />
              <div className="sd-serif">{tr(`restore_state_${restore.state}`)}</div>
              <p>{tr('restore_reconnect')}</p>
              <div className="sd-update-power-warning">{tr('restore_power_warning')}</div>
            </div>
          ) : ['complete', 'completed'].includes(String(restore.state)) ? (
            <div className="sd-update-progress" aria-live="polite"><Icon name="check" size={42} color="var(--success)" /><div className="sd-serif">{tr('restore_complete')}</div></div>
          ) : restore.state === 'failed' || restore.state === 'rolled_back' ? (
            <div className="sd-update-progress" aria-live="polite"><Icon name="close" size={38} color="var(--destructive)" /><div className="sd-serif">{tr('restore_failed')}</div><p>{restore.error || restore.message}</p></div>
          ) : <>
            <div className="sd-backup-warning"><strong>{tr('restore_replaces')}</strong><span>{tr('restore_power_warning')}</span></div>
            <div className="sd-cloud-grid">
              <span>{tr('created')}</span><strong>{backupDateText(app, restorePreview.created_at)}</strong>
              <span>{tr('profiles')}</span><strong>{(restorePreview.counts && restorePreview.counts.profiles) ?? '-'}</strong>
              <span>{tr('shots_history')}</span><strong>{(restorePreview.counts && restorePreview.counts.shots) ?? '-'}</strong>
            </div>
            {restorePreview.scale_policy && <div className="sd-backup-warning">
              <strong>{tr('scale_settings')}</strong>
              <span>{restorePreview.scale_policy.mode === 'specific'
                ? tr('scale_restore_specific') + ' ' + (restorePreview.scale_policy.target?.name || '')
                : tr('scale_any')}</span>
            </div>}
            <div className="sd-fieldlabel sd-fieldlabel-sentence">{tr('physical_pin_prompt')}</div>
            <Btn variant="ghost" className="sm" onClick={() => showPhysicalConfirmation('apply_restore')}>{tr('show_confirmation_code')}</Btn>
            <input className="sd-input" inputMode="numeric" autoComplete="one-time-code" value={restorePin}
              onChange={event => setRestorePin(event.target.value.replace(/\D/g, '').slice(0, 12))} />
          </>}
        </Modal>
      )}
    </Card>
  );
}

function ScaleSettingsCard({ app }) {
  const [status, setStatus] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [nameDraft, setNameDraft] = useState('');
  const [renameStatus, setRenameStatus] = useState(null);
  const latest = useRef(null);
  const apply = value => {
    if (!value || typeof value.revision !== 'number') return;
    if (latest.current && value.revision < latest.current.revision) return;
    latest.current = value;
    setStatus(value);
  };
  useEffect(() => {
    let disposed = false;
    const load = () => api('/api/scale').then(value => { if (!disposed) apply(value); })
      .catch(e => { if (!disposed) setError(e.message); });
    load();
    const timer = setInterval(load, 1000);
    return () => {
      disposed = true;
      clearInterval(timer);
      const s = latest.current;
      if (s && s.active && s.owned) {
        api('/api/scale/setup/' + s.session_id + '/cancel', { method: 'POST', keepalive: true,
          body: JSON.stringify({ operation_id: (Date.now().toString(36) + Math.random().toString(36).slice(2)), revision: s.revision }) }).catch(() => {});
      }
    };
  }, []);
  const act = async (action, extra = {}, expectedStatus = null) => {
    const s = expectedStatus || latest.current;
    if (!s || busy) return;
    if (action === 'any' && !window.confirm(tr('scale_any_explain'))) return;
    setBusy(true); setError('');
    const path = action === 'rename' ? '/api/scale/name' : action === 'any' ? '/api/scale' : action === 'start' ? '/api/scale/setup'
      : '/api/scale/setup/' + s.session_id + '/' + action;
    try {
      apply(await api(path, { method: action === 'any' ? 'PUT' : 'POST', body: JSON.stringify({
        operation_id: (Date.now().toString(36) + Math.random().toString(36).slice(2)), revision: s.revision, identification: s.identification,
        ...(action === 'any' ? { mode: 'any' } : {}), ...extra,
      }) }));
      return true;
    } catch (e) {
      setError(e.message);
      try { apply(await api('/api/scale')); } catch (_) {}
      return false;
    } finally { setBusy(false); }
  };
  const s = status || {};
  const working = ['scanning', 'connecting', 'identifying', 'saving', 'cancelling'].includes(s.state);
  const canEdit = !busy && s.owned !== false;
  return <Card title={tr('scale_settings')}>
    <div className="sd-rowlabel">{s.mode === 'specific' ? tr('scale_only') + ' ' + (s.target?.name || '') : tr('scale_any')}</div>
    <div className="sd-rowsub" role="status">{s.waiting_for ? tr('scale_waiting') + ' ' + s.waiting_for : tr(s.connected ? 'connected' : 'not_connected')}</div>
    {s.target && <div className="sd-rowsub">{s.target.address}</div>}
    {s.family_filter && s.family_filter !== 'auto' && <div className="sd-rowsub">{tr('scale_family_filter')} {s.family_filter}</div>}
    {(error || s.error) && <div role="alert" className="sd-rowsub" style={{ marginTop: 10 }}>{error || s.error}</div>}
    {!s.active && !renameStatus && <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 14 }}>
      <Btn disabled={!status || busy} onClick={() => act('start')}>{tr('scale_choose')}</Btn>
      {s.target && !s.settings_error && <Btn variant="ghost" disabled={busy} onClick={() => {
        setNameDraft(s.target.name); setRenameStatus(s); setError('');
      }}>{tr('scale_rename')}</Btn>}
      <Btn variant="ghost" disabled={!status || busy} onClick={() => act('any')}>{tr('scale_use_any')}</Btn>
    </div>}
    {renameStatus && <form style={{ marginTop: 14 }} onSubmit={async event => {
      event.preventDefault();
      if (await act('rename', { name: nameDraft, kind: renameStatus.target.kind, address: renameStatus.target.address }, renameStatus)) setRenameStatus(null);
    }}>
      <label className="sd-rowsub" htmlFor="scale-custom-name">{tr('scale_name')}</label>
      <input id="scale-custom-name" className="sd-input" value={nameDraft} maxLength={128} required autoFocus
        disabled={busy || s.active} onInput={event => setNameDraft(event.target.value)} />
      <div className="sd-rowsub" style={{ marginTop: 6 }}>{tr('scale_name_help')}</div>
      <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
        <Btn type="submit" disabled={busy || s.active || !nameDraft.trim()}>{tr('scale_name_save')}</Btn>
        <Btn type="button" variant="ghost" disabled={busy} onClick={() => setRenameStatus(null)}>{tr('cancel')}</Btn>
      </div>
    </form>}
    {s.active && <div style={{ marginTop: 14 }}>
      <div className="sd-rowsub">{tr('scale_identify_help')}</div>
      {!s.owned && <div role="status">{tr('scale_other_client')}</div>}
      {working && <div role="status" style={{ marginTop: 10 }}>{tr('scale_state_' + s.state)}</div>}
      {s.state === 'choosing' && <div>
        {!(s.candidates || []).length && <div className="sd-rowsub">{tr('scale_empty')}</div>}
        {(s.candidates || []).map(candidate => <div className="sd-row" key={candidate.id}>
          <div><div className="sd-rowlabel">{candidate.name}</div>
            <div className="sd-rowsub">{candidate.kind} · {candidate.address}{candidate.saved ? ' · ' + tr('saved') : ''}{candidate.current ? ' · ' + tr('connected') : ''}</div></div>
          <Btn className="sm" disabled={!canEdit} onClick={() => act('select', { candidate_id: candidate.id })}>{tr('scale_select_tare')}</Btn>
        </div>)}
        <Btn variant="ghost" disabled={!canEdit} onClick={() => act('scan')}>{tr('scale_scan_again')}</Btn>
      </div>}
      {s.state === 'awaiting_confirmation' && <div style={{ marginTop: 12 }}>
        <div className="sd-rowlabel">{s.candidate?.name}</div>
        <div className="sd-rowsub">{s.candidate?.address} · {s.weight != null ? Number(s.weight).toFixed(1) + ' g' : tr('scale_no_weight')}</div>
        <p>{tr('scale_confirm_question')}</p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          <Btn disabled={!canEdit || !s.can_confirm} onClick={() => act('confirm')}>{tr('scale_save')}</Btn>
          <Btn variant="ghost" disabled={!canEdit} onClick={() => act('tare')}>{tr('scale_tare_again')}</Btn>
          <Btn variant="ghost" disabled={!canEdit} onClick={() => act('scan')}>{tr('scale_choose_another')}</Btn>
        </div>
      </div>}
      <Btn variant="ghost" style={{ marginTop: 12 }} disabled={!canEdit || s.state === 'cancelling'} onClick={() => act('cancel')}>{tr('cancel')}</Btn>
    </div>}
  </Card>;
}

function SettingsScreen({ app }) {
  const s = app.data.settings;
  const disp = s.display;
  const physical = s.bbw_control_mode === 'physical_gpio6';
  const activeProfile = machineActiveProfile(app);
  const ss = s.screensaver || {};
  const device = s.device || {};
  const photoAlbum = ss.photo_album_supported === true;
  const uploadRef = useRef(null);
  const update = (s.updates && s.updates.status) || {};
  const updateAvailable = !!update.update_available;
  const updateBusy = ['checking', 'queued', 'installing'].includes(update.state);
  const checkedAt = update.checked_at ? new Date(update.checked_at) : null;
  const checkedLabel = checkedAt && !Number.isNaN(checkedAt.getTime())
    ? checkedAt.toLocaleString(app.lang === 'de' ? 'de-DE' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' })
    : '';
  return (
    <div className="sd-body sd-scroll">
      <ScaleSettingsCard app={app} />
      <Card title={tr('display')} helpKey="display" onHelp={app.openHelp} apiNote="PATCH /settings (display)">
        <ApiChip>PATCH /settings · display</ApiChip>
        <div className="sd-row"><div className="sd-rowlabel">{tr('theme')}</div>
          <Select value={disp.theme} onChange={v => app.setTheme(v)} style={{ width: 160 }}
            options={disp.theme_options.map(o => ({ value: o.value, label: o.label }))} /></div>
        <div className="sd-row"><div className="sd-rowlabel">{tr('brew_ui')}</div>
          <Select value={disp.brew_ui_preset || 'full'} onChange={v => app.setDisplay('brew_ui_preset', v)} style={{ width: 160 }}
            options={(disp.brew_ui_preset_options || []).map(o => ({ value: o.value, label: tr('brew_ui_' + o.value) || o.label }))} /></div>
        <div className="sd-row"><div className="sd-rowlabel">{tr('rotation')}</div>
          <Select value={String(disp.rotation)} onChange={v => app.setDisplay('rotation', +v)} style={{ width: 100 }}
            options={[0, 90, 180, 270].map(n => ({ value: String(n), label: n + '°' }))} /></div>
        <div className="sd-row"><div className="sd-rowlabel">{tr('sleep_after')}</div>
          <Select value={String(disp.sleep_after_minutes)} onChange={v => app.setDisplay('sleep_after_minutes', +v)} disabled={disp.always_on} style={{ width: 110 }}
            options={[1, 5, 10, 30].map(n => ({ value: String(n), label: n + ' ' + tr('minutes') }))} /></div>
        <div style={{ padding: '14px 0 8px', borderTop: '1px solid var(--border-soft)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span className="sd-rowlabel">{tr('brightness')}</span>
            <span className="sd-mono" style={{ color: 'var(--primary)' }}>{disp.brightness}%</span>
          </div>
          <input
            type="range"
            className="sd-range"
            min={10}
            max={100}
            value={disp.brightness}
            onPointerDown={app.beginDisplayBrightness}
            onTouchStart={app.beginDisplayBrightness}
            onChange={e => app.setDisplayBrightness(+e.target.value)}
            onPointerUp={app.flushDisplayBrightness}
            onPointerCancel={app.flushDisplayBrightness}
            onLostPointerCapture={app.flushDisplayBrightness}
            onTouchEnd={app.flushDisplayBrightness}
            onTouchCancel={app.flushDisplayBrightness}
            onKeyUp={app.flushDisplayBrightness}
            onBlur={app.flushDisplayBrightness}
          />
        </div>
        <Row label={tr('always_on')} sub={tr('always_on_sub')}><Switch on={disp.always_on} onChange={v => app.setDisplay('always_on', v)} /></Row>
      </Card>

      <Card title={tr('brew_control')} helpKey="bbw" onHelp={app.openHelp} apiNote="PATCH /settings (bbw_enabled)"
        right={activeProfile && <Pill variant={machineProfileBrewsByTime(activeProfile) ? 'good' : ''} dot>{machineBrewModeLabel(activeProfile)}</Pill>}>
        <ApiChip>PATCH /settings · bbw_enabled</ApiChip>
        {activeProfile && <div className="sd-rowsub" style={{ marginBottom: 8 }}>{activeProfile.name} · {machineBrewModeLabel(activeProfile)}</div>}
        <Row label={tr('bbw_enable')} sub={physical ? tr('bbw_physical') : null}>
          <Switch on={s.bbw_enabled} disabled={physical} onChange={v => app.setSetting('bbw_enabled', v)} />
        </Row>
      </Card>

      <Card title={tr('updates')} helpKey="updates" onHelp={app.openHelp} apiNote="GET/POST /updates"
        className={updateAvailable ? 'sd-update-card available' : 'sd-update-card'}
        right={updateAvailable ? <Pill variant="ok" dot>{tr('update_available')}</Pill> : null}>
        <ApiChip>PATCH /settings · updates</ApiChip>
        <Row label={tr('updates_enabled')}><Switch on={s.updates.updates_enabled} disabled={updateBusy} onChange={v => app.setUpdates('updates_enabled', v)} /></Row>
        <Row label={tr('beta_updates')} sub={tr('beta_updates_sub')}><Switch on={s.updates.beta_updates} disabled={!s.updates.updates_enabled || updateBusy} onChange={v => app.setUpdates('beta_updates', v)} /></Row>
        <Row label={tr('auto_update')}><Switch on={s.updates.auto_update} disabled={!s.updates.updates_enabled || updateBusy} onChange={v => app.setUpdates('auto_update', v)} /></Row>
        <div className="sd-update-status" aria-live="polite">
          <div className="sd-update-versions">
            <div><span>{tr('installed_version')}</span><strong>v{update.current_version || s.version}</strong></div>
            {update.target_version && update.target_version !== (update.current_version || s.version) &&
              <div><span>{tr('available_version')}</span><strong>v{update.target_version}</strong></div>}
          </div>
          <div className="sd-update-message">
            {updateBusy && <span className="sd-spinner inline" aria-hidden="true" />}
            <span>{updateStatusText(update)}</span>
          </div>
          {update.error && <div className="sd-update-error">{update.error}</div>}
          {checkedLabel && <div className="sd-micro">{tr('last_checked')} · {checkedLabel}</div>}
        </div>
        <div className="sd-update-actions">
          <Btn variant="ghost" disabled={!s.updates.updates_enabled || updateBusy} onClick={() => app.checkUpdates(true)}>{update.state === 'checking' ? tr('checking_updates') : tr('check_now')}</Btn>
          {updateAvailable && <Btn variant="primary" disabled={updateBusy || s.shot_active} onClick={app.openUpdateInstall}>{tr('update_now')}</Btn>}
        </div>
        {updateAvailable && s.shot_active && <div className="sd-rowsub" style={{ marginTop: 8 }}>{tr('update_after_brew')}</div>}
      </Card>

      <Card title={tr('screensaver')} apiNote="GET/PATCH /screensaver">
        <ApiChip>PATCH /screensaver</ApiChip>
        <div className="sd-fieldlabel">{tr('screensaver')}</div>
        <Select value={ss.mode || 'default'} onChange={v => app.setScreensaver('mode', v)}
          options={[
            { value: 'default', label: tr('ss_clock') },
            ...(photoAlbum ? [{ value: 'photo_album', label: tr('ss_photos') }] : []),
          ]} />
        {photoAlbum && ss.mode === 'photo_album' && (
          <div style={{ marginTop: 14 }}>
            <Row label={tr('interval')}><Select value={String(ss.photo_interval_s || 60)} onChange={v => app.setScreensaver('photo_interval_s', +v)} style={{ width: 120 }} options={(ss.intervals || [15, 30, 60, 120, 300, 600]).map(n => ({ value: String(n), label: n < 60 ? n + 's' : (n / 60) + ' ' + tr('minutes') }))} /></Row>
            <input ref={uploadRef} type="file" accept="image/*" multiple style={{ display: 'none' }} onChange={e => app.uploadScreensaverPhotos(e.target.files)} />
            <Btn variant="ghost" className="block" style={{ marginTop: 12 }} onClick={() => uploadRef.current && uploadRef.current.click()}><Icon name="upload" size={18} /> {tr('upload_photo')}</Btn>
            {(ss.photos || []).map(photo => (
              <div className="sd-item" key={photo.name} style={{ paddingLeft: 0, paddingRight: 0 }}>
                <img src={photo.url} alt="" style={{ width: 52, height: 38, objectFit: 'cover', borderRadius: 6, border: '1px solid var(--border)' }} />
                <div style={{ flex: 1 }}><span className="sd-itemname">{photo.name.replace(/^\d+-/, '')}</span></div>
              </div>
            ))}
          </div>
        )}
        {!photoAlbum && <div className="sd-rowsub" style={{ marginTop: 10 }}>{tr('unavailable')}</div>}
      </Card>

      <BackupRestoreCard app={app} />

      <Card title={tr('language')}>
        <Segmented value={app.lang} onChange={v => app.setLang(v)} options={[{ value: 'en', label: 'English' }, { value: 'de', label: 'Deutsch' }]} />
        <div className="sd-rowsub" style={{ marginTop: 10 }}>{tr('language_scope')}</div>
      </Card>

      <Card title={tr('about')}>
        <Row label={tr('version')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{s.version}</span></Row>
        {device.hostname && <Row label={tr('device_name')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.hostname}</span></Row>}
        {device.local_url && <Row label={tr('local_url')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.local_url}</span></Row>}
        {device.device_short_id && <Row label={tr('device_id')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.device_short_id}</span></Row>}
        {device.display_size && <Row label={tr('display_size')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.display_size}</span></Row>}
        {device.hardware && <Row label={tr('hardware')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.hardware}</span></Row>}
        <div style={{ marginTop: 12 }}>
          <Btn variant="ghost" className="block sm" onClick={() => { window.location.href = '/license'; }}>{tr('lic_title')}</Btn>
          <Btn variant="ghost" className="block sm" style={{ marginTop: 8 }} onClick={() => app.go('wifi')}>{tr('ob_title')}</Btn>
        </div>
      </Card>
    </div>
  );
}

function UpdateInstallModal({ app }) {
  const update = (app.data.settings.updates && app.data.settings.updates.status) || {};
  const modal = app.updateModal || {};
  const target = modal.targetVersion || update.target_version || '';
  const busy = ['checking', 'queued', 'installing'].includes(update.state)
    || (modal.phase === 'progress' && update.state === 'available');
  const installed = update.state === 'installed' && update.current_version === target;
  const failed = update.state === 'error';
  const progressMessage = modal.phase === 'progress' && update.state === 'available'
    ? `${tr('preparing_update')} v${target}`
    : updateStatusText(update);

  if (modal.phase === 'confirm') {
    return (
      <Modal title={tr('confirm_update_title')} onClose={app.closeUpdateInstall} footer={<>
        <Btn variant="ghost" className="block" onClick={app.closeUpdateInstall}>{tr('cancel')}</Btn>
        <Btn variant="primary" className="block" onClick={app.installUpdate}>{tr('install_update')}</Btn>
      </>}>
        <div className="sd-update-confirm-version">v{target}</div>
        <p className="sd-update-confirm-copy">{tr('update_restart_warning')}</p>
        <div className="sd-update-power-warning">{tr('update_power_warning')}</div>
      </Modal>
    );
  }

  const footer = (installed || failed)
    ? <Btn variant="ghost" className="block" onClick={app.closeUpdateInstall}>{tr('dismiss')}</Btn>
    : null;
  return (
    <Modal title={installed ? tr('update_complete') : failed ? tr('update_failed') : tr('installing_update')}
      onClose={app.closeUpdateInstall} dismissible={!busy} footer={footer}>
      <div className="sd-update-progress" aria-live="polite">
        {busy && <div className="sd-spinner" aria-hidden="true" />}
        {installed && <Icon name="check" size={42} color="var(--success)" />}
        {failed && <Icon name="close" size={38} color="var(--destructive)" />}
        <div className="sd-serif">{installed ? `${tr('updated_to')} v${target}` : progressMessage}</div>
        {busy && <p>{tr('update_reconnect_notice')}</p>}
        {failed && update.error && <p>{update.error}</p>}
        {busy && <div className="sd-update-power-warning">{tr('update_power_warning')}</div>}
      </div>
    </Modal>
  );
}

Object.assign(window, { MachineScreen, WifiScreen, SettingsScreen, UpdateInstallModal, BackupRestoreCard, lmMachineAwake, steamLevelValue, prebrewModeText, prebrewModeValue, prebrewModeOptions, prebrewTimeText, prebrewTimes, prebrewLimits, prebrewPayload, smartStandbyAfterValue, smartStandbyAfterLabel, smartStandbyPayload });
