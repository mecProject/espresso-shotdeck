// ============================================================
// Shotdeck — Shots tab: sticky chart · list (swipe-delete) ·
//   analysis panel · feedback modal
// ============================================================

function fmtTime(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const loc = window.__sdLang === 'de' ? 'de-DE' : 'en-GB';
  const time = d.toLocaleTimeString(loc, { hour: '2-digit', minute: '2-digit' });
  // Day distance by local calendar date (DST-safe), not raw ms.
  const now = new Date();
  const midnight = x => new Date(x.getFullYear(), x.getMonth(), x.getDate());
  const days = Math.round((midnight(now) - midnight(d)) / 86400000);
  if (days === 0) return tr('today_at') + ' ' + time;
  if (days === 1) return tr('yesterday_at') + ' ' + time;
  return d.toLocaleString(loc, { hour: '2-digit', minute: '2-digit', day: '2-digit', month: 'short' });
}

function fmtAvgFlow(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n.toFixed(2) + 'g/s' : '—';
}

// Weight-vs-target badge: signed grams off target. Green inside ±0.2 g; over
// target trends red, under target trends blue — the further off, the stronger
// the hue. Colors are theme-aware (warm-dark wants light text on a dark tint;
// light theme wants dark text on a light tint), mirroring the token pattern.
function weightDeltaBadge(shot, dark) {
  const target = Number(shot.target_weight_g);
  const final = Number(shot.final_weight_g);
  if (!Number.isFinite(target) || target <= 0 || !Number.isFinite(final)) return null;
  const delta = final - target;
  const r = Math.round(delta * 10) / 10;            // display to 0.1 g
  const sign = r > 0 ? '+' : r < 0 ? '−' : '±';
  const text = sign + Math.abs(r).toFixed(1) + 'g';
  const a = Math.abs(delta);
  // Green zone keyed off the displayed value so the colour always matches the
  // number shown (and ±0.2 g reads green despite float error like 0.2000…0284).
  const onTarget = Math.abs(r) <= 0.2;
  const hue = onTarget ? 130 : (delta > 0 ? 8 : 212); // green · red · blue
  const t = onTarget ? 0 : Math.min(1, (a - 0.2) / 1.8); // intensity, full ≈2 g off
  const sat = Math.round(55 + t * 35);
  const color = dark
    ? `hsl(${hue} ${Math.min(95, sat + 5)}% ${Math.round(72 - t * 6)}%)`
    : `hsl(${hue} ${sat}% ${Math.round(34 - t * 8)}%)`;
  const bg = dark
    ? `hsl(${hue} ${sat}% ${Math.round(14 + t * 4)}%)`
    : `hsl(${hue} ${Math.max(40, sat - 15)}% ${Math.round(92 - t * 4)}%)`;
  const border = dark
    ? `hsl(${hue} ${sat}% ${Math.round(30 + t * 8)}%)`
    : `hsl(${hue} ${sat}% ${Math.round(72 - t * 8)}%)`;
  return { text, color, bg, border };
}

function ShotsScreen({ app }) {
  const [sel, setSel] = useState(app.openShotId || null);
  const [smooth, setSmooth] = useState('10');
  const [dateF, setDateF] = useState('');
  const [analyzed, setAnalyzed] = useState(false);
  const [shots, setShots] = useState(app.data.shots || []);
  const [detail, setDetail] = useState(null);
  const [analysisState, setAnalysisState] = useState(null);
  const [analysisRequest, setAnalysisRequest] = useState(0);
  const [exporting, setExporting] = useState(false);
  const exportBusy = useRef(false);
  const analysis = analysisState?.shotId === sel && analysisState.status === 'ready' ? analysisState.result : null;
  const analysisLoading = analysisState?.shotId === sel && analysisState.status === 'loading';

  useEffect(() => { if (app.openShotId) { setSel(app.openShotId); setAnalyzed(true); app.openShotId = null; } }, [app.openShotId]);

  // (re)load the shot list when the date filter changes
  useEffect(() => {
    let cancelled = false;
    app.loadShots(dateF).then(rows => { if (!cancelled) setShots(rows); }).catch(() => {});
    return () => { cancelled = true; };
  }, [dateF, app.data.shots]);

  // load the full shot (samples + settings.profile) when a row is selected
  useEffect(() => {
    if (sel == null) { setDetail(null); setAnalysisState(null); return; }
    let cancelled = false;
    let timer;
    const started = Date.now();
    setDetail(null); setAnalysisState(null);
    const load = () => app.loadShotDetail(sel).then(d => {
      if (cancelled) return;
      if (!d || d.id !== sel) return;
      setDetail(d);
      setShots(rows => rows.map(row => row.id === d.id ? { ...row, gbs_status: d.gbs_status } : row));
      // Receipt collection completes after reporting; refresh only recent
      // shots, with a fixed bound, so selecting a shot never starts an export.
      const recent = Date.now() - new Date(d.ended_at || d.started_at).getTime() < 120000;
      const pending = !d.grinder_telemetry || d.grinder_telemetry.collection?.status === 'pending';
      if (recent && pending && Date.now() - started < 60000) timer = setTimeout(load, 2000);
    }).catch(() => {});
    load();
    return () => { cancelled = true; clearTimeout(timer); };
  }, [sel]);

  // fetch analysis when Analyze is pressed for the selected shot
  useEffect(() => {
    if (!analyzed || sel == null) { return; }
    let cancelled = false;
    setAnalysisState({ shotId: sel, status: 'loading' });
    app.loadAnalysis(sel).then(a => {
      if (!cancelled) setAnalysisState({ shotId: sel, status: a ? 'ready' : 'error', result: a });
    }).catch(() => { if (!cancelled) setAnalysisState({ shotId: sel, status: 'error' }); });
    return () => { cancelled = true; };
  }, [analyzed, sel, analysisRequest]);

  const selShot = shots.find(s => s.id === sel) || null;
  const profForShot = detail && detail.settings ? detail.settings.profile : null;
  const ideal = profForShot && profForShot.ideal_flow_enabled ? profForShot.ideal_flow_profile : null;
  const dark = !/light/.test(app.theme || '');
  const detailReady = detail && detail.id === sel;
  const saveScreenshot = async () => {
    if (!detailReady || exportBusy.current || analysisLoading || (analyzed && !analysis)) return;
    exportBusy.current = true; setExporting(true);
    try {
      await saveShotScreenshot({ shot: detail, analysis, smoothing: Number(smooth), lang: app.lang,
        note: shotProfileNote(detail, app.data.profiles || []) });
      app.toast(tr('screenshot_saved'));
    } catch { app.toast(tr('screenshot_failed')); }
    finally { exportBusy.current = false; setExporting(false); }
  };
  const saveButton = <Btn variant="ghost" className="sm sd-shot-save" onClick={saveScreenshot}
    disabled={!detailReady || exporting || analysisLoading || (analyzed && !analysis)}
    title={tr('save_screenshot')} aria-label={tr('save_screenshot')} aria-busy={exporting}>
    <Icon name="download" size={14} /><span className="sd-shot-save-label">{tr(exporting ? 'saving_screenshot' : 'save_screenshot')}</span>
  </Btn>;

  if (!shots.length && !dateF) {
    return <div className="sd-body sd-scroll"><Card className="sd-shot-history-card" title={tr('shots_history')} helpKey="shots" onHelp={app.openHelp} right={saveButton}>
      <EmptyState icon="shots" title={tr('no_shots')} sub={tr('no_shots_sub')} /></Card></div>;
  }

  return (
    <div className="sd-body sd-scroll" style={{ paddingTop: 12 }}>
      {/* Sticky chart card */}
      <div style={{ position: detail ? 'relative' : 'sticky', top: detail ? undefined : -16, zIndex: 5, marginBottom: 14 }}>
        <Card flush className="sd-shot-history-card">
          <div style={{ padding: '14px 16px 0' }}>
            <div className="sd-cardhead" style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span className="sd-cardtitle">{tr('shots_history')}</span>
                <button className="sd-helpbtn" onClick={() => app.openHelp('shots')}>?</button>
              </div>
              {saveButton}
            </div>
            <ApiChip>GET /shots?date= · GET /shots/{'{id}'} · /analysis</ApiChip>
            {/* labeled controls — Date filters the list, Flow smoothing shapes the chart */}
            <div style={{ display: 'flex', gap: 12, marginBottom: 12, alignItems: 'flex-end' }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div className="sd-fieldlabel">{tr('filter_date')}</div>
                <div style={{ display: 'flex', gap: 6 }}>
                  <input type="date" className="sd-input" style={{ flex: 1, minWidth: 0 }} value={dateF} onChange={e => setDateF(e.target.value)} />
                  {dateF && <Btn variant="ghost" className="sm" onClick={() => setDateF('')}>{tr('all_shots')}</Btn>}
                </div>
              </div>
              <div style={{ width: 104 }}>
                <div className="sd-fieldlabel">{tr('smooth_short')}</div>
                <Select value={smooth} onChange={setSmooth} style={{ width: '100%' }}
                  options={[1, 3, 5, 10, 20].map(n => ({ value: String(n), label: n === 1 ? tr('off') : n + '×' }))} />
              </div>
            </div>
          </div>
          {/* chart */}
          <div style={{ background: 'var(--inset)', padding: 8 }}>
            {detail ? (
              <ShotChart width={330} height={170} samples={detail.samples} finalWeight={detail.final_weight_g} ideal={ideal} themeKey={app.theme} smoothing={Number(smooth)} />
            ) : (
              <div style={{ height: 170, display: 'grid', placeItems: 'center' }}><span className="sd-micro">{tr('select_shot')}</span></div>
            )}
          </div>
          <div style={{ padding: '12px 16px 14px' }}>
            <ChartLegend />
            {/* Primary action sits with the chart it acts on */}
            <Btn variant={sel ? 'primary' : 'ghost'} className="block" disabled={!detailReady || analysisLoading}
              onClick={() => { setAnalysisState({ shotId: sel, status: 'loading' }); setAnalyzed(true); setAnalysisRequest(n => n + 1); }}
              style={{ marginTop: 12 }}>{tr(analysisLoading ? 'analyzing_shot' : 'analyze')}</Btn>
          </div>
        </Card>
      </div>

      {detailReady && analyzed && analysis && <AnalysisPanel analysis={analysis} app={app} onClose={() => setAnalyzed(false)} />}
      {detailReady && analyzed && analysisState?.status === 'error' && <p role="alert" className="sd-itemsub">{tr('shot_analysis_failed')}</p>}

      {detail && <GrinderShotDetails key={detail.id} shot={detail} />}

      {/* Shot list */}
      <div className="sd-eyebrow" style={{ margin: '4px 4px 8px' }}>{shots.length} {tr('tab_shots')}</div>
      {shots.map(s => (
        <ShotRow key={s.id} shot={s} selected={s.id === sel} dark={dark}
          gbsEnabled={!!app.data.settings?.gbs?.settings?.enabled}
          onSelect={() => {
            if (s.id !== sel) { setSel(s.id); setDetail(null); setAnalysisState(null); }
            setAnalyzed(false);
          }}
          onDelete={async () => {
            const previousShots = shots;
            const previousDetail = detail;
            const previousAnalysis = analysisState;
            const previousAnalyzed = analyzed;
            setShots(rows => rows.filter(row => row.id !== s.id));
            if (sel === s.id) {
              setSel(null);
              setDetail(null);
              setAnalysisState(null);
              setAnalyzed(false);
            }
            const result = await app.deleteShot(s.id);
            if (result && result.ok) return;
            setShots(previousShots);
            if (sel === s.id) {
              setSel(s.id);
              setDetail(previousDetail);
              setAnalysisState(previousAnalysis);
              setAnalyzed(previousAnalyzed);
            }
          }}
          onFeedback={() => app.openFeedback(s.id)} />
      ))}
    </div>
  );
}

function ShotGbsBadge({ status, enabled }) {
  const labels = { successful: 'shot_gbs_successful', failed: 'shot_gbs_failed', unconfirmed: 'shot_gbs_unconfirmed' };
  if (!enabled || !labels[status]) return null;
  return <span className={'sd-pill sd-shot-gbs ' + (status === 'successful' ? 'good' : status)}
    data-gbs-status={status} title={tr(labels[status])} aria-label={tr(labels[status])}>
    <span className="dot" aria-hidden="true" />GBS
  </span>;
}

function GrinderShotDetails({ shot }) {
  const data = shot.grinder_telemetry;
  const fmt = (v, unit, digits = 2) => typeof v === 'number' && Number.isFinite(v) ? v.toFixed(digits) + ' ' + unit : '—';
  const rawUnit = (v, unit, divisor = 1000) => typeof v === 'number' ? fmt(v / divisor, unit) : '—';
  const row = (label, value) => <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, padding: '6px 0', borderBottom: '1px solid var(--border-soft)' }}>
    <dt className="sd-itemsub" style={{ flex: 1 }}>{label}</dt><dd className="sd-mono" style={{ margin: 0, textAlign: 'right', fontSize: 12, overflowWrap: 'anywhere', maxWidth: '60%' }}>{value}</dd>
  </div>;
  const report = data?.reporting || {};
  const grind = data?.grind || {};
  const recipe = data?.recipe || {};
  const brew = data?.brew_event || {};
  const before = data?.before?.recipe_gbs?.coursenessDeciMym;
  const after = data?.after?.recipe_gbs?.coursenessDeciMym;
  const beforeKnown = typeof before === 'number' && Number.isFinite(before);
  const afterKnown = typeof after === 'number' && Number.isFinite(after);
  const targetChanged = beforeKnown && afterKnown ? before !== after : null;
  const states = {result_served: 'grinder_report_served', delivery_incomplete: 'grinder_report_incomplete',
    captured: 'grinder_report_captured', rejected: 'grinder_report_rejected'};
  const receipt = data?.receipt || 'unconfirmed';
  const collecting = data?.collection?.status === 'pending' && Date.now() - new Date(data.collection.updated_at).getTime() < 120000;
  const validity = shot.settings?.shot_validity;
  return <Card title={tr('grinder_shot_title')}>
    <div className="sd-itemsub" style={{ marginBottom: 10 }}>#{shot.id} · {shot.profile_name}</div>
    {!data ? <div className="sd-itemsub">{tr('grinder_no_capture')}</div> : <>
      <div className="sd-grinder-status" style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: 12, marginBottom: 10 }}>
        <div><div className="sd-fieldlabel">{tr('grinder_shot_report')}</div><Pill variant={report.outcome === 'result_served' ? 'good' : ''}>
          {tr(states[report.outcome] || 'grinder_report_captured')}</Pill></div>
        <div><div className="sd-fieldlabel">{tr('grinder_shot_receipt')}</div><Pill variant={receipt === 'recorded_valid' ? 'good' : ''}>
          {tr(receipt === 'recorded_valid' ? 'grinder_receipt_valid' : receipt === 'recorded_invalid' ? 'grinder_receipt_invalid' : 'grinder_receipt_unknown')}</Pill></div>
      </div>
      {collecting && <p className="sd-itemsub">{tr('grinder_collecting')}</p>}
      {(data.collection?.error || data.collection?.baseline_error) && <p className="sd-itemsub">{tr('grinder_export_unavailable')}</p>}
      {report.reason && <p className="sd-itemsub" style={{ overflowWrap: 'anywhere' }}>{report.reason}</p>}
      <dl style={{ margin: '8px 0 12px' }}>
        {row(tr('grinder_reported_brew'), fmt(report.duration_s, 's', 3) + ' / ' + fmt(report.weight_g, 'g'))}
        {data.brew_event && row(tr('grinder_received_brew'), rawUnit(brew.brew_duration, 's') + ' / ' + rawUnit(brew.brew_mass, 'g'))}
        {row(tr('grinder_brew_target'), rawUnit(recipe.recipe_brew_time, 's') + ' / ' + rawUnit(recipe.recipe_brew_weight, 'g'))}
        {typeof report.duration_s === 'number' && typeof recipe.recipe_brew_time === 'number' && row(tr('grinder_time_error'),
          (report.duration_s - recipe.recipe_brew_time / 1000 > 0 ? '+' : '') + fmt(report.duration_s - recipe.recipe_brew_time / 1000, 's'))}
      </dl>
      <details>
        <summary style={{ cursor: 'pointer', color: 'var(--primary)', fontSize: 13, padding: '4px 0' }}>{tr('grinder_dose_adjustment')}</summary>
        <dl style={{ margin: '8px 0' }}>
          {row(tr('grinder_linked_dose'), grind.grind_id != null ? '#' + grind.grind_id : '—')}
          {row(tr('grinder_dose_time'), fmtTime(grind.grind_date_time) || '—')}
          {row(tr('grinder_dose_weight'), rawUnit(grind.grind_weight, 'g') + ' / ' + rawUnit(recipe.recipe_amount, 'g'))}
          {row(tr('grinder_grind_duration'), rawUnit(grind.grind_duration, 's'))}
          {row(tr('grinder_trigger'), grind.trigger || '—')}
          {row(tr('grinder_dose_success'), grind.grind_successfull == null ? '—' : tr(grind.grind_successfull === 1 ? 'grinder_yes' : 'grinder_no'))}
          {row(tr('grinder_recipe_slot'), grind.recipe_index ?? '—')}
          {row(tr('grinder_gbs_enabled'), grind.recipe_gbs_enabled == null ? '—' : tr(grind.recipe_gbs_enabled === 1 ? 'grinder_yes' : 'grinder_no'))}
          {row(tr('grinder_gbs_mode'), data.after?.recipe_gbs?.gbsMode || data.before?.recipe_gbs?.gbsMode || '—')}
          {row(tr('grinder_initial_dd'), fmt(recipe.recipe_coarseness, 'µm', 1))}
          {row(tr('grinder_target_before'), rawUnit(before, 'µm', 10))}
          {row(tr('grinder_target_after'), rawUnit(after, 'µm', 10))}
          {row(tr('grinder_target_change'), targetChanged == null ? tr('grinder_not_comparable') : tr(targetChanged ? 'grinder_target_changed' : 'grinder_target_unchanged'))}
          {row(tr('grinder_effective_dd'), fmt(data.after?.settings?.['Gbs.State.EffectiveGrindSizePrediction']?.grindSizeUm, 'µm'))}
          {row(tr('grinder_raw_dd'), grind.grind_ddd ?? '—')}
          {row(tr('grinder_scale_capture'), validity ? tr(validity.valid_for_learning === true ? 'grinder_capture_valid' : 'grinder_capture_check') : '—')}
        </dl>
        <p className="sd-itemsub">{tr('grinder_motion_unconfirmed')}</p>
        {data.after?.captured_at && <p className="sd-micro">{tr('grinder_snapshot_time')} {fmtTime(data.after.captured_at)}</p>}
        {!!data.alerts?.length && <div className="sd-itemsub">{tr('grinder_new_alerts')}: {data.alerts.map(a => a.type || a.alert_type_id).join(', ')}</div>}
        <details style={{ marginTop: 12 }}><summary className="sd-itemsub" style={{ cursor: 'pointer' }}>{tr('grinder_technical_details')}</summary>
          <pre style={{ fontSize: 11, whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', background: 'var(--inset)', borderRadius: 'var(--r-md)', padding: 12, maxHeight: 300, overflow: 'auto' }}>{JSON.stringify(data, null, 2)}</pre>
        </details>
      </details>
    </>}
  </Card>;
}

function ShotRow({ shot, selected, dark, gbsEnabled, onSelect, onDelete, onFeedback }) {
  const [dx, setDx] = useState(0);
  const start = useRef(null);
  const onStart = e => { start.current = (e.touches ? e.touches[0].clientX : e.clientX); };
  const onMove = e => {
    if (start.current == null) return;
    const x = (e.touches ? e.touches[0].clientX : e.clientX);
    setDx(Math.max(-84, Math.min(0, x - start.current)));
  };
  const onEnd = () => { setDx(d => (d < -50 ? -76 : 0)); start.current = null; };
  // Green time pill = pull landed inside the profile's own target window.
  // Fall back to the conventional 25–32 s if a shot has no stored targets.
  const tMin = shot.target_time_min_s > 0 ? shot.target_time_min_s : 25;
  const tMax = shot.target_time_max_s > 0 ? shot.target_time_max_s : 32;
  const inWindow = shot.duration_s >= tMin && shot.duration_s <= tMax;
  const wBadge = weightDeltaBadge(shot, dark);
  return (
    <div className="sd-shot-row" data-shot-id={shot.id} style={{ position: 'relative', marginBottom: 8 }}>
      {/* delete bg */}
      <button onClick={onDelete} style={{
        position: 'absolute', right: 0, top: 0, bottom: 0, width: 76, border: 'none',
        background: 'var(--danger-surface)', color: 'var(--danger-text)', borderRadius: 'var(--r-md)',
        display: 'grid', placeItems: 'center', cursor: 'pointer',
      }}><Icon name="trash" size={20} /></button>
      <div onClick={() => dx === 0 && onSelect()}
        onMouseDown={onStart} onMouseMove={onMove} onMouseUp={onEnd} onMouseLeave={() => start.current && onEnd()}
        onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd}
        style={{
          transform: `translateX(${dx}px)`, transition: start.current ? 'none' : 'transform .2s',
          background: 'var(--card)', border: '1px solid ' + (selected ? 'var(--primary)' : 'var(--border)'),
          borderRadius: 'var(--r-md)', padding: '12px 14px', cursor: 'pointer', position: 'relative',
          boxShadow: selected ? 'var(--glow)' : 'none',
        }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="sd-shot-identity" style={{ display: 'flex', alignItems: 'center', gap: 8, minHeight: 24 }}>
              <span className="sd-itemname" style={{ flex: '0 1 auto', minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{shot.user_name}</span>
              <span className="sd-itemsub" style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>· {shot.profile_name}</span>
              <ShotGbsBadge status={shot.gbs_status} enabled={gbsEnabled} />
            </div>
            <div className="sd-shot-metrics" style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6, minHeight: 28 }}>
              <span className="sd-mono" style={{ flexShrink: 0, color: 'var(--primary)', fontSize: 15 }}>{shot.final_weight_g}g</span>
              {wBadge && (
                <span className="sd-mono" title={tr('target') + ' ' + shot.target_weight_g + 'g'}
                  style={{
                    flex: 'none', display: 'inline-flex', alignItems: 'center', height: 28, padding: '0 10px',
                    borderRadius: 'var(--r-pill)', fontSize: 11, fontWeight: 600, letterSpacing: '.02em',
                    color: wBadge.color, background: wBadge.bg, border: '1px solid ' + wBadge.border,
                    whiteSpace: 'nowrap',
                  }}>{wBadge.text}</span>
              )}
              <span style={{ marginLeft: 'auto', display: 'inline-flex', flexShrink: 0 }}>
                <Pill variant={inWindow ? 'good' : ''} dot>{shot.duration_s.toFixed(1)}s</Pill>
              </span>
            </div>
            <div className="sd-itemsub" style={{ marginTop: 6, display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 6 }}>
              <span>{fmtTime(shot.started_at)} · {shot.roast} · {tr('avg_flow')} {fmtAvgFlow(shot.average_flow_g_s)}</span>
              {typeof shot.brew_temperature_c === 'number' && Number.isFinite(shot.brew_temperature_c) &&
                <span className="sd-shot-temperature" title={tr(shot.brew_temperature_source === 'profile' ? 'shot_profile_temperature' : 'shot_brew_temperature')}>
                  · {shot.brew_temperature_c.toFixed(1)} °C{shot.brew_temperature_source === 'profile' ? ' (' + tr('shot_temperature_profile') + ')' : ''}
                </span>}
              {/* The action link is the single feedback affordance; its label
                  already says whether feedback exists. */}
              <button onClick={e => { e.stopPropagation(); onFeedback(); }} style={{ marginLeft: 'auto', flexShrink: 0, background: 'none', border: 'none', color: 'var(--primary)', fontWeight: 600, fontSize: 12, cursor: 'pointer' }}>
                {shot.has_feedback ? tr('edit_feedback') : tr('feedback')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function AnalysisPanel({ analysis, app, onClose }) {
  const evidence = analysis.evidence || [];
  const recommendations = analysis.recommendations || [];
  const prebrewing = analysis.prebrewing || {};
  return (
    <div style={{ marginTop: 14, marginBottom: 12, padding: 14, background: 'var(--card-2)', borderRadius: 'var(--r-md)', border: '1px solid var(--border-soft)', animation: 'sd-rise .2s ease' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <span className="sd-serif" style={{ fontStyle: 'italic', fontSize: 18, color: 'var(--fg)' }}>{analysis.label || analysis.primary_issue}</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Pill variant="ok" dot>{Math.round((analysis.confidence || 0) * 100)}% {tr('confidence')}</Pill>
          <button className="sd-iconbtn" onClick={onClose} title={tr('dismiss')}><Icon name="close" size={16} /></button>
        </div>
      </div>
      <p style={{ margin: '0 0 12px', fontSize: 13, lineHeight: 1.5, color: 'var(--fg-dim)' }}>{analysis.summary}</p>
      <div style={{ marginBottom: 10 }}>
        <Tag>{tr('prebrew_detected')}: {prebrewing.detected ? '●' : '○'} {tr('prebrew')} {prebrewing.match ? '✓' : '✕'}</Tag>
      </div>
      <div className="sd-micro" style={{ marginBottom: 6 }}>{tr('evidence')}</div>
      <div className="sd-tags" style={{ marginBottom: 12 }}>{evidence.map((e, i) => <Tag key={i}>{e}</Tag>)}</div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
        <span className="sd-micro" style={{ color: 'var(--primary)' }}>{tr('recommend')}:</span>
        <span style={{ fontSize: 13, color: 'var(--fg)' }}>{recommendations.join(' · ')}</span>
      </div>
    </div>
  );
}

// ---- Feedback modal ----
const FB_DEFAULTS = { issue: 'none', taste: 'not_tasted', visual: 'normal', prep: 'normal', grind_adjustment: 'none', rating: 0, notes: '' };

function FeedbackModal({ app }) {
  const shotId = app.feedbackShot;
  const [f, setF] = useState(null);
  const [existing, setExisting] = useState(false);

  // load any saved feedback for this shot on open to seed the form
  useEffect(() => {
    if (shotId == null) { setF(null); setExisting(false); return; }
    let cancelled = false;
    setF(null); setExisting(false);
    app.loadFeedback(shotId).then(fb => {
      if (cancelled) return;
      setExisting(!!fb);
      setF({ ...FB_DEFAULTS, ...(fb || {}) });
    }).catch(() => {
      if (cancelled) return;
      setF({ ...FB_DEFAULTS });
    });
    return () => { cancelled = true; };
  }, [shotId]);

  if (!f) {
    return (
      <Modal title={tr('fb_title')} onClose={() => app.closeFeedback()}>
        <EmptyState icon="shots" title={tr('loading')} />
      </Modal>
    );
  }

  const set = (k, v) => setF(s => ({ ...s, [k]: v }));
  const sel = (key, label) => (
    <div style={{ marginBottom: 14 }}>
      <div className="sd-fieldlabel">{label}</div>
      <Select value={f[key]} onChange={v => set(key, v)} options={FB_OPTIONS[key].map(o => ({ value: o, label: fbLabel(o) }))} />
    </div>
  );
  return (
    <Modal title={tr('fb_title')} onClose={() => app.closeFeedback()}
      footer={<>
        {existing && <Btn variant="danger" onClick={() => { app.saveFeedback(shotId, null); }}>{tr('delete')}</Btn>}
        <Btn variant="primary" className="block" onClick={() => app.saveFeedback(shotId, f)}>{tr('save')}</Btn>
      </>}>
      <ApiChip>PUT /shots/{shotId}/feedback</ApiChip>
      {sel('issue', tr('fb_issue'))}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {sel('taste', tr('fb_taste'))}
        {sel('visual', tr('fb_visual'))}
      </div>
      {sel('prep', tr('fb_prep'))}
      <div style={{ marginBottom: 14 }}>
        <div className="sd-fieldlabel">{tr('fb_grind')}</div>
        <Segmented value={f.grind_adjustment} onChange={v => set('grind_adjustment', v)}
          options={[{ value: 'finer_next', label: tr('fb_finer') }, { value: 'none', label: tr('fb_same') }, { value: 'coarser_next', label: tr('fb_coarser') }]} />
      </div>
      <div style={{ marginBottom: 14 }}>
        <div className="sd-fieldlabel">{tr('fb_rating')}</div>
        <div style={{ display: 'flex', gap: 8 }}>
          {[1, 2, 3, 4, 5].map(n => (
            <button key={n} onClick={() => set('rating', n)} style={{ flex: 1, minHeight: 46, background: 'var(--input)', border: '1px solid var(--input-border)', borderRadius: 'var(--r-sm)', cursor: 'pointer', display: 'grid', placeItems: 'center' }}>
              <Icon name="star" size={22} color={n <= f.rating ? 'var(--primary)' : 'var(--fg-faint)'} fill={n <= f.rating ? 'var(--primary)' : 'none'} />
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className="sd-fieldlabel">{tr('fb_notes')} · ≤1000</div>
        <textarea className="sd-input" maxLength={1000} value={f.notes} onChange={e => set('notes', e.target.value)}
          style={{ height: 80, padding: 12, resize: 'none', fontFamily: 'var(--sans)' }} />
      </div>
    </Modal>
  );
}

Object.assign(window, { ShotsScreen, ShotRow, AnalysisPanel, FeedbackModal, fmtTime, fmtAvgFlow });
