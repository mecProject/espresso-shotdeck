// ============================================================
// Shotdeck — Machine (La Marzocco) · Wi-Fi
// ============================================================

// ---- Machine ----
function lmMachineAwake(snapshot) {
  const status = snapshot && snapshot.status ? snapshot.status : {};
  const mode = String(status.mode || status.status || '').toLowerCase();
  if (!mode) return !!(snapshot && (snapshot.connected || snapshot.available));
  return mode.indexOf('standby') === -1 && mode.indexOf('stand by') === -1 && mode.indexOf('off') === -1;
}

function steamLevelValue(value, fallback = 1) {
  if (value == null || value === '') return String(fallback);
  const match = String(value).match(/\d+/);
  return match ? match[0] : String(value);
}

function prebrewModeText(value) {
  const raw = String(value || '').replace(/[_-]/g, ' ').toLowerCase();
  if (!raw) return '-';
  if (raw.indexOf('disabled') !== -1) return tr('pb_disabled');
  if (raw.indexOf('prebrewing') !== -1 || raw.indexOf('pre brewing') !== -1) return tr('pb_on');
  if (raw.indexOf('preinfusion') !== -1 || raw.indexOf('pre infusion') !== -1) return tr('preinfusion');
  return String(value);
}

function prebrewModeValue(value) {
  const raw = String(value || '').replace(/[_-\s]/g, '').toLowerCase();
  if (raw.indexOf('disabled') !== -1) return 'disabled';
  if (raw.indexOf('preinfusion') !== -1) return 'preinfusion';
  return 'prebrewing';
}

function prebrewModeOptions(pre) {
  const modes = Array.isArray(pre && pre.available_modes) && pre.available_modes.length
    ? pre.available_modes : [pre && pre.mode, 'Disabled'];
  const seen = new Set();
  return modes.map(mode => {
    const value = prebrewModeValue(mode);
    if (seen.has(value)) return null;
    seen.add(value);
    return { value, label: prebrewModeText(mode || value) };
  }).filter(Boolean);
}

function machineActiveProfile(app) {
  return app.data.profiles.find(p => p.selected && !p.archived) || app.data.profiles.find(p => !p.archived) || null;
}
function machineProfileBrewsByTime(p) {
  return String((p && p.brew_control_mode) || 'weight').toLowerCase() === 'time';
}
function machineBrewModeLabel(p) {
  return machineProfileBrewsByTime(p) ? tr('brew_by_time') : tr('brew_by_weight');
}

function prebrewTimeText(value) {
  if (value == null || value === '') return '-';
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  return n.toFixed(1).replace(/\.0$/, '') + 's';
}

function prebrewTimes(pre) {
  if (!pre) return { on: null, off: null };
  if (pre.seconds_on != null || pre.seconds_off != null) {
    return { on: pre.seconds_on, off: pre.seconds_off };
  }
  const entries = pre.times && (pre.times.pre_brewing || pre.times.preBrewing || pre.times.PreBrewing);
  const first = Array.isArray(entries) ? entries[0] : entries;
  const seconds = first && first.seconds ? first.seconds : {};
  return { on: seconds.In ?? seconds.in ?? null, off: seconds.Out ?? seconds.out ?? null };
}

function liveLmPrebrewSummary(guard) {
  const state = String((guard && guard.state) || 'unknown').toLowerCase();
  if (state === 'active') {
    const mode = prebrewModeText(guard.mode);
    const times = prebrewTimes(guard);
    const hasTimes = times.on != null || times.off != null;
    return {
      selection: `${tr('la_marzocco')} · ${mode}`,
      settings: hasTimes
        ? `${tr('on')} ${prebrewTimeText(times.on)} / ${tr('off')} ${prebrewTimeText(times.off)}`
        : mode,
    };
  }
  if (state === 'disabled') {
    return {
      selection: `${tr('la_marzocco')} · ${tr('pb_disabled')}`,
      settings: tr('pb_disabled'),
    };
  }
  if (state === 'unsupported') {
    return {
      selection: `${tr('la_marzocco')} · ${tr('not_supported')}`,
      settings: tr('not_supported'),
    };
  }
  return {
    selection: `${tr('la_marzocco')} · ${tr('status_unavailable')}`,
    settings: tr('status_unavailable'),
  };
}

function prebrewLimits(pre) {
  const entries = pre && pre.times && (pre.times.pre_brewing || pre.times.preBrewing || pre.times.PreBrewing);
  const first = Array.isArray(entries) ? entries[0] : entries;
  const min = first && first.seconds_min ? first.seconds_min : {};
  const max = first && first.seconds_max ? first.seconds_max : {};
  const step = first && first.seconds_step ? first.seconds_step : {};
  return {
    onMin: Number(min.In ?? min.in ?? 0),
    onMax: Number(max.In ?? max.in ?? 20),
    onStep: Number(step.In ?? step.in ?? 0.5),
    offMin: Number(min.Out ?? min.out ?? 0),
    offMax: Number(max.Out ?? max.out ?? 20),
    offStep: Number(step.Out ?? step.out ?? 0.5),
  };
}

function prebrewPayload(pre, patch) {
  const times = prebrewTimes(pre);
  const mode = patch.mode || prebrewModeValue(pre && pre.mode);
  const payload = { mode };
  if (mode !== 'disabled') {
    payload.seconds_on = patch.seconds_on ?? times.on ?? 2;
    payload.seconds_off = patch.seconds_off ?? times.off ?? 3;
  }
  return payload;
}

function smartStandbyAfterValue(value) {
  const raw = String(value || '').replace(/[_-\s]/g, '').toLowerCase();
  return raw.indexOf('poweron') !== -1 ? 'PowerOn' : 'LastBrewing';
}

function smartStandbyAfterLabel(value) {
  return smartStandbyAfterValue(value) === 'PowerOn' ? tr('power_on') : tr('last_brewing');
}

function smartStandbyPayload(smart, patch) {
  return {
    enabled: patch.enabled ?? !!smart.enabled,
    minutes: patch.minutes ?? smart.minutes ?? 10,
    after: patch.after ?? smartStandbyAfterValue(smart.after),
  };
}

// Disclosures keep drafts mounted and remember their presentation across tabs.
function MachineDisclosure({ app, id, title, children, className = '' }) {
  const [open, setOpen] = useState(!!app.machineView?.current.details[id]);
  return <details className={'sd-machine-details ' + className} open={open} onToggle={event => {
    const next = event.currentTarget.open;
    setOpen(next);
    if (app.machineView) app.machineView.current.details[id] = next;
  }}><summary>{title}<Icon name="chevron" size={16} /></summary><div className="sd-machine-details-content">{children}</div></details>;
}

// Phones show secondary machine settings as one-line rows that open in
// place; sections that need attention start open. Wider screens show all.
function usePhoneLayout() {
  const query = '(max-width: 759px)';
  const [phone, setPhone] = useState(() => !!(window.matchMedia && window.matchMedia(query).matches));
  useEffect(() => {
    if (!window.matchMedia) return;
    const media = window.matchMedia(query);
    const update = () => setPhone(media.matches);
    update();
    if (media.addEventListener) { media.addEventListener('change', update); return () => media.removeEventListener('change', update); }
    media.addListener(update); return () => media.removeListener(update);
  }, []);
  return phone;
}
function PhoneFold({ app, id, summary, attention = false, children }) {
  const phone = usePhoneLayout();
  const key = 'fold-' + id;
  const remembered = app.machineView?.current.details[key];
  const [open, setOpen] = useState(!!attention || !!remembered);
  useEffect(() => {
    if (attention) {
      setOpen(true);
      if (app.machineView) app.machineView.current.details[key] = true;
    }
  }, [attention]);
  if (!phone) return children;
  return <details className={'sd-machine-fold' + (attention ? ' attention' : '')} open={open} onToggle={event => {
    const next = event.currentTarget.open;
    setOpen(next);
    if (app.machineView) app.machineView.current.details[key] = next;
  }}><summary><span className="sd-machine-fold-summary">{summary}</span><Icon name="chevron" size={16} /></summary>
    <div className="sd-machine-fold-content">{children}</div></details>;
}

function MachineFeedback({ app, name }) {
  const operation = app.machineOperations?.[name];
  if (!operation) return null;
  return <div className={'sd-machine-feedback' + (operation.error || operation.unconfirmed ? ' attention' : '')}
    role={operation.error ? 'alert' : 'status'}>{operation.pending ? tr('saving') : operation.error || operation.message}</div>;
}

function machineOperatingState(app) {
  if (!lmOnline(app)) return { label: tr('status_unavailable'), ready: false };
  const snapshot = app.data.lm.snapshot;
  if (!lmMachineAwake(snapshot)) return { label: tr('machine_standby'), ready: false };
  const boiler = snapshot.coffee_boiler;
  if (!boiler || (!boiler.status && !boiler.warmup_estimate &&
    (boiler.current_temperature_c == null || boiler.target_temperature_c == null))) {
    return { label: tr('status_unavailable'), ready: false };
  }
  const ready = boilerReady(boiler);
  return { label: ready ? tr('machine_ready') : tr('machine_heating'), ready };
}

function RinseSettingsCard({ app, lmConfigured, nativeRinse, rinseSettings, onUseShotdeck }) {
  const runtime = rinseSettings.runtime || {};
  const enabled = rinseSettings.quick_paddle_rinse_enabled === true;
  const controller = rinseSettings.quick_paddle_rinse_controller === 'machine' ? 'machine' : 'shotdeck';
  const machineControllerSupported = rinseSettings.machine_controller_supported === true;
  const duration = Number(rinseSettings.quick_paddle_rinse_duration_s ?? 2);
  const durationMin = Number(rinseSettings.duration_min_s ?? 0.5);
  const durationMax = Number(rinseSettings.duration_max_s ?? 10);
  const durationStep = Number(rinseSettings.duration_step_s ?? 0.5);
  const runtimeAvailable = runtime.available !== false;
  const availability = rinseSettings.availability || {};
  const prebrewBlocked = availability.blocked === true;
  const nativeRinseReported = nativeRinse.reported === true;
  const nativeRinseHasEnabled = nativeRinseReported && typeof nativeRinse.enabled === 'boolean';
  const nativeRinseDuration = nativeRinse.duration_s == null ? null : Number(nativeRinse.duration_s);
  const shotdeckRinseConflict = nativeRinse.enabled === true && enabled && controller === 'shotdeck';
  const saving = app.settingsSaving > 0;
  const controllerOptions = [
    ...(machineControllerSupported || controller === 'machine'
      ? [{ value: 'machine', label: tr('rinse_controller_machine'), disabled: !machineControllerSupported }] : []),
    { value: 'shotdeck', label: tr('rinse_controller_shotdeck') },
  ];
  const unavailable = !runtimeAvailable || (controller === 'machine' && !machineControllerSupported);
  const state = prebrewBlocked ? tr('machine_blocked') : unavailable ? tr('status_unavailable')
    : !enabled ? tr('off') : (rinseSettings.machine_standby || runtime.machine_standby) ? tr('machine_standby')
    : (rinseSettings.effective_enabled === true || runtime.effective_enabled === true || availability.available === true) ? tr('machine_available') : tr('status_unavailable');
  return <Card title={tr('paddle_rinse')} headingLevel={2} className="sd-machine-rinse">
    <PhoneFold app={app} id="rinse" attention={prebrewBlocked ? 'prebrew-blocked' : !runtimeAvailable ? 'unavailable' : ''}
      summary={<>{enabled ? tr('on') : tr('off')}{enabled && controller === 'shotdeck' && Number.isFinite(duration) ? ` · ${duration.toFixed(1)} s` : ''}{prebrewBlocked && <span className="sd-pill"><span className="dot" />{tr('machine_blocked')}</span>}</>}>
    <Row label={tr('rinse_enable')} sub={tr('rinse_paddle_hint')}>
      <Switch on={enabled} disabled={saving || ((!runtimeAvailable || prebrewBlocked) && !enabled)}
        onChange={value => app.setRinse('quick_paddle_rinse_enabled', value)} />
    </Row>
    <div className="sd-machine-sub sd-machine-effective">{tr('machine_rinse_state')}: <strong>{state}</strong>{saving && ` · ${tr('saving')}`}</div>
    {!runtimeAvailable && <div className="sd-machine-warning" role="note">{tr('rinse_runtime_unavailable')}</div>}
    {prebrewBlocked && <div className="sd-machine-warning" role="alert">
      <strong>{tr('rinse_prebrew_locked')}</strong>
      <p>{tr('rinse_prebrew_recommend')}</p>
      {onUseShotdeck && <Btn id="machine-review-profile" className="block" disabled={!app.data.profiles.some(p => p.selected && !p.archived) || app.data.settings.shot_active}
        onClick={onUseShotdeck}>{tr('machine_review_profile')} <Icon name="chevron" size={16} /></Btn>}
    </div>}
    <div className="sd-machine-field">
      {controllerOptions.length > 1 ? <>
        <div className="sd-fieldlabel">{tr('rinse_controller')}</div>
        <Segmented label={tr('rinse_controller')} value={controller} onChange={value => app.setRinse('quick_paddle_rinse_controller', value)}
          options={controllerOptions.map(option => ({ ...option, disabled: saving || prebrewBlocked || option.disabled }))} />
        {!machineControllerSupported && <p className="sd-machine-sub">{tr('rinse_machine_unavailable')}</p>}
      </> : <div className="sd-machine-sub">{tr('rinse_controller')}: <strong>Shotdeck</strong></div>}
    </div>
    {controller === 'shotdeck' && <Row label={tr('rinse_duration')} sub={tr('rinse_duration_help')}>
      <Stepper label={tr('rinse_duration')} commitOnBlur value={Number.isFinite(duration) ? duration : 2}
        onChange={value => app.setRinse('quick_paddle_rinse_duration_s', value)}
        min={Number.isFinite(durationMin) ? durationMin : 0.5} max={Number.isFinite(durationMax) ? durationMax : 10}
        step={Number.isFinite(durationStep) ? durationStep : 0.5} width={142} disabled={saving || prebrewBlocked} />
    </Row>}
    {shotdeckRinseConflict && <div className="sd-machine-warning" role="note">{tr('native_rinse_shotdeck_warning')}</div>}
    {lmConfigured && <MachineDisclosure app={app} id="native-rinse" title={tr('machine_native_rinse_details')}>
      <Row label={tr('native_rinse_status')} sub={nativeRinseReported && nativeRinseDuration != null && Number.isFinite(nativeRinseDuration)
        ? `${nativeRinseDuration.toFixed(1)} s · ${tr('native_rinse_duration')}` : tr('native_rinse_status_unavailable')}>
        <Pill variant={nativeRinse.enabled === true ? 'good' : ''} dot={nativeRinseHasEnabled}>
          {nativeRinseHasEnabled ? (nativeRinse.enabled ? tr('on') : tr('off')) : tr('native_rinse_not_reported')}
        </Pill>
      </Row>
      <p className="sd-machine-sub">{tr('native_rinse_read_only')}</p>
      <p className="sd-machine-sub">{tr('native_rinse_live_unavailable')}</p>
    </MachineDisclosure>}
    </PhoneFold>
  </Card>;
}

function PrebrewSummaryCard({ app }) {
  const prebrew = (app.data.settings && app.data.settings.prebrew) || {};
  const active = prebrew.active_profile || {};
  const profile = machineActiveProfile(app);
  const preference = (profile && profile.prebrew_preference) || active;
  const enabled = preference.enabled === true;
  const controller = preference.controller === 'shotdeck' ? 'shotdeck' : 'lamarzocco';
  const lmMode = String((profile && profile.prebrew_mode) || active.lm_mode || 'no_change');
  const shotdeckRecipe = (profile && profile.shotdeck_prebrew) || {};
  const guard = prebrew.native_guard || {};

  let selection = tr('prebrew_off');
  let settings = tr('pb_no_change');
  let timing = null;  // [pump_s, soak_s] when the profile defines them
  if (enabled && controller === 'shotdeck') timing = [shotdeckRecipe.pump_s ?? active.shotdeck_pump_s, shotdeckRecipe.pause_s ?? active.shotdeck_pause_s];
  else if (enabled && lmMode === 'prebrewing') timing = [(profile && profile.prebrew_seconds_on) ?? active.lm_seconds_on, (profile && profile.prebrew_seconds_off) ?? active.lm_seconds_off];
  if (timing && !(Number(timing[0]) > 0)) timing = null;
  if (enabled && controller === 'shotdeck') {
    selection = `Shotdeck · ${tr('pb_on')}`;
    settings = `${tr('phase_pump_on')}: ${prebrewTimeText(shotdeckRecipe.pump_s ?? active.shotdeck_pump_s)} · ${tr('phase_soak')}: ${prebrewTimeText(shotdeckRecipe.pause_s ?? active.shotdeck_pause_s)}`;
  } else if (enabled) {
    if (lmMode === 'prebrewing') {
      selection = `${tr('la_marzocco')} · ${tr('pb_on')}`;
      settings = `${tr('phase_pump_on')}: ${prebrewTimeText((profile && profile.prebrew_seconds_on) ?? active.lm_seconds_on)} · ${tr('phase_soak')}: ${prebrewTimeText((profile && profile.prebrew_seconds_off) ?? active.lm_seconds_off)}`;
    } else {
      const liveLm = liveLmPrebrewSummary(guard);
      selection = liveLm.selection;
      settings = liveLm.settings;
    }
  }
  const native = guard.state === 'active'
    ? `${tr('la_marzocco')} · ${prebrewModeText(guard.mode)}`
    : guard.state === 'disabled' ? `${tr('la_marzocco')} · ${tr('pb_disabled')}`
    : guard.state === 'unsupported' ? tr('not_supported') : tr('status_unavailable');

  const warning = enabled && controller === 'shotdeck'
    ? (profile?.shotdeck_prebrew?.supported !== true ? tr('shotdeck_prebrew_unavailable_short')
      : guard.state === 'active' ? tr('lm_override')
      : (!guard.state || guard.state === 'unknown') && !guard.manually_confirmed ? tr('local_prebrew_paused') : '') : '';
  return <Card title={tr('prebrew_mode')} headingLevel={2} className="sd-machine-prebrew">
    <PhoneFold app={app} id="prebrew" attention={warning} summary={<>{selection}{timing ? ` · ${prebrewTimeText(timing[0])} / ${prebrewTimeText(timing[1])}` : ''}</>}>
    <div className="sd-machine-kicker">{tr('active_profile')}</div>
    <div className="sd-machine-profile">{(profile && profile.name) || active.name || '—'}</div>
    <div className="sd-machine-recipe">{selection}</div>
    <div className="sd-machine-sub">{settings}</div>
    {timing && <div className="sd-glass sd-prebrew-timing" aria-hidden="true"
      style={{ gridTemplateColumns: `${Math.max(1, Number(timing[0]))}fr ${Math.max(1, Number(timing[1]) || 0)}fr 7fr` }}>
      <span className="pump">{tr('phase_pump_on')} {prebrewTimeText(timing[0])}</span>
      <span className="soak">{tr('phase_soak')} {prebrewTimeText(timing[1])}</span>
      <span className="ext">{tr('phase_extraction')}</span>
    </div>}
    <div className="sd-machine-native"><span>{tr('machine_prebrew_state')}</span><span>{native}</span></div>
    {warning && <div className="sd-machine-warning" role="status">{warning}</div>}
    <p className="sd-machine-sub">{tr('machine_prebrew_read_only')}</p>
    <Btn id="machine-edit-profile" className="block" disabled={!app.data.profiles.some(p => p.selected && !p.archived) || app.data.settings.shot_active}
      onClick={() => app.openMachineProfile('machine-edit-profile')}>{tr('machine_edit_profile')} <Icon name="chevron" size={16} /></Btn>
    </PhoneFold>
  </Card>;
}

function GbsSetupWizard({ app, state }) {
  const step = state.step;
  const de = app.lang === 'de';
  const field = step === 1 ? 'host_ip' : 'grinder_ip';
  const [value, setValue] = useState(state[field] || '');
  React.useLayoutEffect(() => { setValue(state[field] || ''); }, [field, state[field]]);
  const translated = [
    ['WLAN verbinden', 'E64 und Shotdeck mit demselben Heimnetz verbinden. An der E64 WLAN öffnen und ein 2,4-GHz-Netz auswählen. Kein Gastnetz verwenden.'],
    ['Mit Shotdeck verbinden', 'An der E64 Machine-to-Machine / Xenia öffnen. Die Shotdeck-IP unten als Maschinenadresse mit Port 80 eingeben. Im Router prüfen und bestätigen. Menünamen hängen von der Firmware ab.'],
    ['E64-Rezept aktivieren', 'Im E64-Rezept Enable GbS einschalten. Getränkegewicht und Brühzeit speichern. Das Gewicht mit dem Shotdeck-Profil abstimmen. Auch die Maschinenverbindung speichern.'],
    ['Mühlenadresse bestätigen', 'Die vorgeschlagene IP mit der E64-WLAN-Anzeige vergleichen. Nur bei Übereinstimmung bestätigen. Sonst die Stations-IP der E64 aus deren Netzwerkanzeige oder der Router-Geräteliste eingeben.'],
    ['Verbindung prüfen', 'Auf E64-Kontakt warten. Bei Problemen beide IPs prüfen, die Xenia-Verbindung an der E64 erneut speichern und sicherstellen, dass beide Geräte im selben Netz sind und Port 80 erreichbar ist.'],
    ['Verbunden', 'Waage verbinden. Mahlen, E64-Knopf drücken, optional spülen, dann im ursprünglichen Zeitfenster brühen. Shotdeck-Spülen erhält die Dosis. Mit Paddle AUS beendete Zyklen bis 5 Sekunden gelten als Spülen; für eine verworfene Dosis GbS-Meldung abbrechen wählen. Verbundene La Marzocco muss eingeschaltet und bereit sein. Ergebnisannahme an der E64 prüfen.'],
  ];
  return <div aria-label="Grinder connect setup">
    <h3>{step + 1}/6 · {de ? translated[step][0] : state.title}</h3>
    <p>{de ? translated[step][1] : state.instructions}</p>
    {(step === 1 || step === 3) && <>
      {step === 1 && !state.host_ip && <p role="status">{de ? 'Shotdeck im Router suchen und seine IPv4-Adresse unten eingeben.' : 'Find Shotdeck in your router device list and enter its IPv4 address below.'}</p>}
      {step === 3 && <p className="sd-itemsub">{de ? 'Verbindungsversuche (bitte prüfen): ' : 'Connection attempts (please verify): '}{state.candidates?.join(', ') || '—'}</p>}
      <label className="sd-fieldlabel" htmlFor="gbs-setup-ip">{step === 1 ? 'Shotdeck IP' : 'E64 IP'}</label>
      <input id="gbs-setup-ip" className="sd-input" inputMode="decimal" value={value} onInput={event => setValue(event.target.value)} />
      <Btn onClick={() => app.gbsAction('setup-address', { [field]: value.trim() })}>{de ? 'Adresse übernehmen' : 'Use address'}</Btn>
      {value.trim() !== state[field] && <p role="status">{de ? 'Adresse zuerst übernehmen.' : 'Use the edited address before continuing.'}</p>}
    </>}
    {step === 3 && !state.discovery_active && <p>{de ? 'Automatische Erkennung abgelaufen. IP manuell eingeben oder Assistenten neu starten.' : 'Discovery expired. Enter the IP manually or close and restart setup.'}</p>}
    {step === 4 && <p role="status">{state.connected ? (de ? 'E64-Kontakt empfangen.' : 'E64 contact received.') : (de ? 'Noch kein neuer E64-Kontakt.' : 'Waiting for fresh E64 contact.')}</p>}
    <div style={{ display: 'flex', gap: 8, marginTop: 16, flexWrap: 'wrap' }}>
      {step > 0 && <Btn variant="ghost" onClick={() => app.gbsAction('setup-back')}>{de ? 'Zurück' : 'Back'}</Btn>}
      <Btn variant="ghost" onClick={() => app.gbsAction('setup-close')}>{de ? 'Schließen' : 'Close'}</Btn>
      <Btn disabled={(step === 4 && !state.connected) || ((step === 1 || step === 3) && (!value.trim() || value.trim() !== state[field]))}
        onClick={() => app.gbsAction(step === 5 ? 'setup-close' : 'setup-next')}>
        {step === 5 ? (de ? 'Fertig' : 'Done') : step === 3 ? (de ? 'Bestätigen & GbS aktivieren' : 'Confirm & enable GbS') : step === 1 ? (de ? 'IP bestätigt' : 'Confirm IP') : (de ? 'Weiter' : 'Next')}
      </Btn>
    </div>
    <p className="sd-itemsub">{de ? 'Nach der Adressbestätigung bleibt GbS beim Schließen aktiviert.' : 'After address confirmation, closing setup leaves GbS enabled.'}</p>
  </div>;
}

function gbsPhaseText(phase) {
  return tr(({ idle: 'gbs_idle', armed: 'gbs_armed', candidate: 'gbs_candidate', brewing: 'gbs_brewing',
    recipe: 'gbs_recipe', extracting: 'gbs_brewing', settling: 'gbs_settling', publishing: 'gbs_reporting',
    reporting: 'gbs_reporting', completed: 'gbs_complete', aborted: 'gbs_cancelled', expired: 'gbs_expired',
    error: 'gbs_failed', failed: 'gbs_failed' })[phase] || 'status_unavailable');
}
function gbsOutcomeText(outcome, reason = '') {
  if (outcome === 'rejected') return tr(reason.toLowerCase().includes('cancel') ? 'gbs_cancelled' : 'gbs_rejected');
  return tr(({ aborted: 'gbs_cancelled', successful: 'gbs_complete', result_served: 'gbs_result_sent',
    armed: 'gbs_armed', extracting: 'gbs_brewing', captured: 'gbs_captured', delivery_incomplete: 'gbs_unconfirmed',
    completed: 'gbs_complete', expired: 'gbs_expired', failed: 'gbs_failed', unconfirmed: 'gbs_unconfirmed' })[outcome] || 'gbs_unconfirmed');
}

function GbsSettingsCard({ app }) {
  const state = app.data.settings?.gbs || {};
  const settings = state.settings || {};
  const de = app.lang === 'de';
  const [ip, setIp] = useState(app.machineView?.current.grinderIp ?? settings.grinder_ip ?? '');
  const dirty = useRef(app.machineView?.current.grinderIp != null && app.machineView.current.grinderIp !== (settings.grinder_ip || ''));
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { if (!dirty.current) setIp(settings.grinder_ip || ''); }, [settings.grinder_ip]);
  const setupActive = state.setup?.step != null;
  useEffect(() => {
    if (!settings.enabled && !setupActive) return;
    let pending = false, cancelled = false;
    const load = async () => {
      if (pending || cancelled || document.visibilityState === 'hidden') return;
      pending = true;
      try { await app.refresh(); } finally { pending = false; }
    };
    const timer = setInterval(load, 1000);
    document.addEventListener('visibilitychange', load);
    return () => { cancelled = true; clearInterval(timer); document.removeEventListener('visibilitychange', load); };
  }, [settings.enabled, setupActive]);
  const saveIp = async () => {
    if (saving) return;
    const submitted = ip.trim();
    setSaving(true); setError('');
    try {
      if (await app.setGbs({ grinder_ip: submitted })) {
        dirty.current = false; setIp(submitted);
        if (app.machineView) app.machineView.current.grinderIp = null;
      } else setError(tr('machine_command_failed'));
    } finally { setSaving(false); }
  };
  const transaction = state.transaction || {};
  const configured = !!settings.grinder_ip;
  return <Card title="E64 · Grind-by-Sync" headingLevel={2} className={'sd-machine-grinder' + (setupActive ? ' setup-active' : '')}>
    <fieldset className="sd-machine-form" aria-label="E64 · Grind-by-Sync" disabled={!!app.grinderBusy}>
    {setupActive ? <GbsSetupWizard key={state.setup.step} app={app} state={state.setup} /> : <>
      {(configured || settings.enabled) && <Row label={de ? 'GbS aktivieren' : 'Enable GbS'} sub={de ? 'Gilt für alle Brühprofile.' : 'Applies to all brew profiles.'}>
        <Switch on={settings.enabled === true} onChange={value => app.setGbs({ enabled: value })} />
      </Row>}
      {!configured && !settings.enabled && <p className="sd-machine-sub">{tr('gbs_connect_help')}</p>}
      {(configured || settings.enabled) && <div className="sd-machine-grinder-status">
        <Pill dot={settings.enabled === true}>{settings.enabled ? gbsPhaseText(state.phase) : tr('off')}</Pill>
        <span className="sd-machine-sub">{state.connection_age_s == null ? tr('gbs_no_contact')
          : tr('gbs_contact_age').replace('{seconds}', state.connection_age_s)}</span>
      </div>}
      {settings.enabled && <>
        <Row label={de ? 'Maschinenbereitschaft · Automatisch' : 'Machine readiness · Automatic'}>
          <Pill variant={state.machine_ready ? 'good' : ''} dot>{state.machine_ready ? tr('machine_ready') : tr('gbs_not_ready')}</Pill>
        </Row>
        <p className="sd-machine-sub">{state.readiness_source === 'lamarzocco'
          ? (de ? 'La Marzocco muss eingeschaltet, verbunden und heiß sein.' : 'La Marzocco must be on, connected, and hot.')
          : (de ? 'Bereit, wenn Shotdeck läuft.' : 'Ready while Shotdeck is running.')}</p>
        {state.blocked_reason && <div className="sd-machine-warning">{de ? tr('gbs_not_ready_help') : state.blocked_reason}</div>}
        {state.phase === 'armed' && <div className="sd-machine-warning" role="status">{state.rinse_active
          ? (de ? 'Spülen · Dosis bleibt bereit' : 'Rinsing · dose retained')
          : state.rinse_recovering ? (de ? 'Dosis bleibt bereit · Maschine wird bereit' : 'Dose retained · waiting for machine Ready')
          : (de ? 'Dosis bereit · Spülen erlaubt' : 'Dose armed · rinse allowed')} · {state.arm_remaining_s ?? '—'}s</div>}
        {state.phase === 'candidate' && <div className="sd-machine-warning" role="status">{de
          ? 'Kurzer Paddle-Zyklus · Spülgang wird geprüft (bis 5 s)' : 'Short paddle cycle · checking rinse (up to 5 s)'}</div>}
        {state.recipe_target_g != null && <p className="sd-machine-sub">E64: {state.recipe_target_g} g · Shotdeck: {state.profile_target_g ?? '—'} g</p>}
        {state.target_mismatch && <div className="sd-machine-warning" role="status">{de ? 'Rezept- und Profilziel weichen ab.' : 'Recipe and profile targets differ.'}</div>}
        {transaction.duration > 0 && <p className="sd-machine-sub">{transaction.duration.toFixed(2)} s · {Number.isFinite(transaction.weight) ? transaction.weight.toFixed(2) : '—'} g</p>}
        {state.last_outcome && <p className="sd-machine-sub">{gbsOutcomeText(state.last_outcome.outcome, state.last_outcome.reason)}</p>}
        <p className="sd-machine-sub">{de ? 'Annahme und Mahlgradanpassung an der E64 prüfen.' : 'Check result acceptance and grind adjustment on the E64.'}</p>
        <Btn className="block" onClick={() => app.gbsAction('cancel')}>{de ? 'GbS-Meldung abbrechen' : 'Cancel GbS reporting'}</Btn>
      </>}
      {!configured && !settings.enabled && <Btn className="block" onClick={() => app.gbsAction('setup-start')}>{tr('gbs_connect')}</Btn>}
      <MachineDisclosure app={app} id="grinder-settings" title={tr('gbs_settings')}>
        <Btn className="block" onClick={() => app.gbsAction('setup-start')}>{de ? 'Mühle verbinden · Assistent starten' : 'Connect grinder · Start setup'}</Btn>
        <label className="sd-fieldlabel" htmlFor="gbs-ip">{de ? 'E64 IP-Adresse' : 'E64 IP address'}</label>
        <div className="sd-machine-ip">
          <input id="gbs-ip" className="sd-input" value={ip} inputMode="decimal" placeholder="192.168.178.62" disabled={saving}
            onChange={event => { dirty.current = true; setIp(event.target.value); if (app.machineView) app.machineView.current.grinderIp = event.target.value; }} />
          <Btn disabled={saving} onClick={saveIp}>{saving ? tr('saving') : tr('save')}</Btn>
        </div>
        {error && <p role="alert" className="sd-machine-warning">{error}</p>}
        <Row label={de ? 'Zeit zum Brühstart' : 'Brew start window'} sub={de ? 'Nach dem E64-Knopfdruck · 10–120 Sekunden' : 'After pressing the E64 knob · 10–120 seconds'}>
          <select aria-label={de ? 'Zeit zum Brühstart' : 'Brew start window'} className="sd-input" value={settings.brew_start_timeout_s ?? 30}
            onChange={event => app.setGbs({ brew_start_timeout_s: Number(event.target.value) })}>
            {Array.from(new Set([...Array.from({ length: 23 }, (_, i) => 10 + i * 5), settings.brew_start_timeout_s ?? 30])).sort((a,b) => a-b).map(value => <option key={value} value={value}>{value} s</option>)}
          </select>
        </Row>
        <p className="sd-machine-sub">{de
          ? `Mahlen → E64-Drehknopf drücken → innerhalb von ${settings.brew_start_timeout_s ?? 30} Sekunden mit Paddle oder Shotdeck brühen. Die Mühle startet die Pumpe nicht.`
          : `Grind → press the E64 knob → brew with the paddle or Shotdeck within ${settings.brew_start_timeout_s ?? 30} seconds. The grinder does not start the pump.`}</p>
        <p className="sd-machine-sub">{de
          ? 'Nach dem Knopfdruck ist ein Shotdeck-Spülgang möglich. Ein mit Paddle AUS beendeter Brühzyklus bis 5 Sekunden gilt als Spülen. Das Zeitfenster läuft weiter. Für einen verworfenen Bezug GbS-Meldung abbrechen wählen.'
          : 'After the knob press, a Shotdeck rinse is allowed. A paddle cycle ended with paddle OFF within 5 seconds counts as a rinse. The start window keeps running. For a discarded extraction, choose Cancel GbS reporting.'}</p>
        {state.last_outcome && <div className="sd-machine-sub">{tr('gbs_diagnostics')}: {state.last_outcome.outcome} {state.last_outcome.reason}</div>}
      </MachineDisclosure>
    </>}
    </fieldset>
  </Card>;
}

function MachineScreen({ app }) {
  const lm = app.data.lm || {};
  const snap = lm.snapshot || {};
  const online = lmOnline(app);
  const machineAwake = online && lmMachineAwake(snap);
  const state = machineOperatingState(app);
  const credentialProvisioningAllowed = lm.credential_provisioning_allowed === true;
  const credentialTransportEncrypted = lm.credential_transport_encrypted === true;
  const [creds, setCreds] = useState({ username: lm.username || '', password: '' });
  const root = useRef(null);
  const fallbackView = useRef({ scroll: 0, focus: null });
  const view = app.machineView || fallbackView;
  React.useLayoutEffect(() => {
    const node = root.current;
    if (!node) return;
    node.scrollTop = view.current.scroll || 0;
    const frame = requestAnimationFrame(() => {
      if (view.current.focus) node.querySelector('#' + view.current.focus)?.focus({ preventScroll: true });
      view.current.focus = null;
    });
    return () => { cancelAnimationFrame(frame); view.current.scroll = node.scrollTop; };
  }, []);
  const coffee = snap.coffee_boiler || {};
  const steam = snap.steam_boiler || {};
  const coffeeSettingsAvailable = online && coffee.supported === true && Number.isFinite(coffee.target_temperature_c);
  const steamLevel = steamBoilerUsesLevel(steam);
  const steamSettingsAvailable = online && steam.supported === true && (steamLevel ? steam.target_level != null : Number.isFinite(steam.target_temperature_c));
  const selectedSteamLevel = steamLevelValue(steam.target_level ?? steam.current_level);
  const smart = snap.smart_standby || {};
  const schedules = Array.isArray(snap.schedules) ? snap.schedules : [];
  const smartSupported = online && smart.supported === true;
  const smartMinutes = Number(smart.minutes || 10);
  const smartMin = Number(smart.minutes_min || 1);
  const smartMax = Number(smart.minutes_max || 240);
  const smartStep = Number(smart.minutes_step || 1);
  const rinseSettings = app.data.settings.rinse || {};
  const nativeRinse = rinseSettings.machine_rinse || snap.machine_rinse || {};
  const machine = snap.machine || {};
  const disabled = !!app.machineBusy || !!app.data.settings.shot_active;
  const grinder = app.data.settings.gbs || {};
  const formatTemperature = value => Number.isFinite(value) ? new Intl.NumberFormat(app.lang, { maximumFractionDigits: 1 }).format(value) + '°C' : '—';
  const dayText = value => {
    const names = { monday: 0, mon: 0, tuesday: 1, tue: 1, wednesday: 2, wed: 2, thursday: 3, thu: 3, friday: 4, fri: 4, saturday: 5, sat: 5, sunday: 6, sun: 6 };
    const day = names[String(value).toLowerCase()];
    return day == null ? String(value) : new Intl.DateTimeFormat(app.lang, { weekday: 'short', timeZone: 'UTC' }).format(new Date(Date.UTC(2026, 9, 26 + day)));
  };

  return <div ref={root} className="sd-body sd-scroll sd-machine-screen" onScroll={event => { view.current.scroll = event.currentTarget.scrollTop; }}>
    <header className="sd-machine-header"><div className="sd-machine-kicker">SHOTDECK</div><h1>{tr('tab_machine')}</h1></header>
    <Card className="sd-machine-overview" helpKey="machine" onHelp={app.openHelp} headingLevel={2} title={machine.name || machine.model_name || tr('la_marzocco')}>
      <div className="sd-machine-overview-state">
        <Pill variant={state.ready ? 'good' : ''} dot={online}>{lm.configured ? state.label : tr('not_connected')}</Pill>
        <span className="sd-machine-sub">{lm.configured ? (online ? tr('machine_lm_connected') : tr('lm_unavailable')) : tr('machine_connect_help')}</span>
      </div>
      {lm.configured ? <div className="sd-machine-actions">
        <Btn disabled={!!app.machineBusy} onClick={() => app.lmRead()}>{app.machineOperations?.refresh?.pending ? tr('machine_refreshing') : tr('machine_refresh')}</Btn>
        <Btn variant={machineAwake ? 'ghost' : 'primary'} disabled={!online || !!app.machineBusy || (!!app.data.settings.shot_active && !machineAwake)} onClick={() => app.lmPower(!machineAwake)}>
          <Icon name="power" size={16} /> {machineAwake ? tr('turn_off') : tr('turn_on')}
        </Btn>
      </div> : <MachineDisclosure app={app} id="lm-connect" title={tr('machine_connect')}>
        {credentialProvisioningAllowed ? <form onSubmit={async e => {
          e.preventDefault();
          const result = await app.lmLogin(creds.username, creds.password);
          if (result?.ok) setCreds(current => ({ ...current, password: '' }));
        }}>
          {!credentialTransportEncrypted && <div className="sd-local-credential-note">{tr('lm_login_local_http_notice')}</div>}
          <div className="sd-machine-field"><label className="sd-fieldlabel" htmlFor="lm-username">{tr('username')}</label>
            <input id="lm-username" name="username" className="sd-input" type="email" inputMode="email"
              autoComplete="username" autoCapitalize="none" spellCheck={false} required disabled={!!app.machineBusy}
              value={creds.username} onChange={e => setCreds({ ...creds, username: e.target.value })} /></div>
          <div className="sd-machine-field"><label className="sd-fieldlabel" htmlFor="lm-password">{tr('password')}</label>
            <input id="lm-password" name="password" className="sd-input" type="password"
              autoComplete="current-password" required disabled={!!app.machineBusy}
              value={creds.password} onChange={e => setCreds({ ...creds, password: e.target.value })} /></div>
          <Btn type="submit" variant="primary" className="block" disabled={!!app.machineBusy}>{app.machineBusy ? tr('saving') : tr('save_login')}</Btn>
        </form> : <EmptyState icon="machine" title={tr('lm_login_touchscreen_title')} sub={tr('lm_login_touchscreen_help')} />}
      </MachineDisclosure>}
      <MachineFeedback app={app} name="refresh" /><MachineFeedback app={app} name="power" />
      {!lm.configured && <MachineFeedback app={app} name="account" />}
    </Card>

    {grinder.settings?.enabled && ['armed', 'candidate', 'extracting', 'settling', 'publishing', 'reporting'].includes(grinder.phase) && <button className="sd-machine-attention" onClick={() => {
      document.getElementById('machine-grinder')?.scrollIntoView({ block: 'start', behavior: 'auto' });
      document.getElementById('machine-grinder')?.focus({ preventScroll: true });
    }}><Icon name="scale" size={18} /><span>E64 · {gbsPhaseText(grinder.phase)}</span><Icon name="chevron" size={16} /></button>}

    {lm.configured && <Card title={tr('machine_boilers')} headingLevel={2} className="sd-machine-boilers">
      {!online ? <p className="sd-machine-sub">{tr('lm_unavailable')}</p> : <div className="sd-machine-boiler-grid">
        <section aria-label={tr('coffee_c')}>
          <div className="sd-machine-kicker">{tr('coffee_c')}</div>
          <div className="sd-machine-reading">{formatTemperature(coffee.current_temperature_c)}<span>{tr('current')}</span></div>
          {coffeeSettingsAvailable ? <Row label={tr('machine_coffee_target')}>
            <Stepper label={tr('machine_coffee_target')} commitOnBlur value={coffee.target_temperature_c}
              onChange={v => app.setLmTemp('coffee', v)} min={coffee.raw?.target_temperature_min ?? 80} max={coffee.raw?.target_temperature_max ?? 100}
              disabled={disabled} width={150} />
          </Row> : <p className="sd-machine-sub">{tr('status_unavailable')}</p>}
          <MachineFeedback app={app} name="coffee" />
        </section>
        <section aria-label={steamLevel ? tr('steam_level') : tr('steam_c')}>
          <div className="sd-machine-kicker">{steamLevel ? tr('steam_level') : tr('steam_c')}</div>
          {steamLevel ? <>
            <div className="sd-machine-reading">{steam.current_level != null ? 'L' + steamLevelValue(steam.current_level) : '—'}<span>{tr('current')}</span></div>
            {steamSettingsAvailable ? <div className="sd-machine-steam-level"><div className="sd-machine-sub">{tr('target')}</div>
              <Segmented label={tr('steam_level')} value={selectedSteamLevel} onChange={v => app.setLmTemp('steam_level', +v)}
                options={[0, 1, 2, 3].map(n => ({ value: String(n), label: n === 0 ? tr('off') : 'L' + n, disabled }))} />
            </div> : <p className="sd-machine-sub">{tr('status_unavailable')}</p>}
          </> : <>
            <div className="sd-machine-reading">{formatTemperature(steam.current_temperature_c)}<span>{tr('current')}</span></div>
            {steamSettingsAvailable ? <Row label={tr('machine_steam_target')}>
              <Stepper label={tr('machine_steam_target')} commitOnBlur value={steam.target_temperature_c}
                onChange={v => app.setLmTemp('steam', v)} min={steam.raw?.target_temperature_min ?? 100} max={steam.raw?.target_temperature_max ?? 140}
                disabled={disabled} width={150} />
            </Row> : <p className="sd-machine-sub">{tr('status_unavailable')}</p>}
          </>}
          <MachineFeedback app={app} name="steam" />
        </section>
      </div>}
      {online && !machineAwake && <p className="sd-machine-sub">{tr('machine_standby_targets')}</p>}
      {app.data.settings.shot_active && <p className="sd-machine-sub">{tr('locked_shot')}</p>}
    </Card>}

    <PrebrewSummaryCard app={app} />
    <RinseSettingsCard
      app={app} lmConfigured={lm.configured} nativeRinse={nativeRinse} rinseSettings={rinseSettings}
      onUseShotdeck={() => app.openMachineProfile('machine-review-profile')} />

    {lm.configured && <Card title={tr('auto_standby')} headingLevel={2} className="sd-machine-energy">
      <PhoneFold app={app} id="standby" summary={<>{smart.enabled ? `${tr('on')} · ${smartMinutes} ${tr('minutes')}` : tr('off')}{online && schedules.length ? ` · ${tr('schedule')} ${schedules.length}` : ''}</>}>
      <Row label={tr('auto_standby')} sub={smartSupported ? tr(smartStandbyAfterValue(smart.after) === 'PowerOn' ? 'machine_standby_power' : 'machine_standby_brew').replace('{minutes}', smartMinutes) : online ? tr('unavailable') : tr('lm_unavailable')}>
        <Switch on={!!smart.enabled} disabled={!smartSupported || disabled} onChange={v => app.setSmartStandby(smartStandbyPayload(smart, { enabled: v }))} />
      </Row>
      {smartSupported && <MachineDisclosure app={app} id="auto-standby" title={tr('machine_adjust_standby')}>
        <Row label={tr('minutes')}><Stepper label={tr('minutes')} commitOnBlur value={smartMinutes} min={smartMin} max={smartMax} step={smartStep} width={142}
          disabled={disabled} onChange={v => app.setSmartStandby(smartStandbyPayload(smart, { minutes: v }))} /></Row>
        <div className="sd-fieldlabel">{tr('after')}</div>
        <Segmented label={tr('after')} value={smartStandbyAfterValue(smart.after)} onChange={v => app.setSmartStandby(smartStandbyPayload(smart, { after: v }))}
          options={[{ value: 'LastBrewing', label: tr('last_brewing'), disabled }, { value: 'PowerOn', label: tr('power_on'), disabled }]} />
      </MachineDisclosure>}
      <MachineFeedback app={app} name="standby" />
      <MachineDisclosure app={app} id="schedules" title={`${tr('schedule')} · ${online ? schedules.length : '—'}`}>
        <p className="sd-machine-sub">{online ? schedules.length ? tr('machine_schedules_readonly') : tr('machine_no_schedules') : tr('lm_unavailable')}</p>
        {online && schedules.map((item, index) => <div className="sd-machine-schedule" key={item.id || index}>
          <div><strong>{tr('on')} {item.on_time || '—'} · {tr('off')} {item.off_time || '—'}</strong><p className="sd-machine-sub">{(item.days || []).map(dayText).join(', ') || '—'}</p></div>
          <Pill variant={item.enabled ? 'good' : ''} dot={false}>{item.enabled ? tr('on') : tr('off')}</Pill>
        </div>)}
      </MachineDisclosure>
      </PhoneFold>
    </Card>}

    <div id="machine-grinder" tabIndex={-1} className={'sd-machine-grinder-wrap' + (grinder.setup?.step != null ? ' setup-active' : '')}><GbsSettingsCard app={app} /></div>
    <div className="sd-machine-account">
      <MachineDisclosure app={app} id="machine-account" title={tr('machine_details_account')}>
        <dl className="sd-machine-info">
          {[[tr('model'), machine.model_name], [tr('type'), machine.name], [tr('serial'), machine.serial_number], [tr('location'), machine.location], [tr('machine_account'), lm.username]].map(([label, value]) =>
            <div key={label}><dt>{label}</dt><dd>{value || '—'}</dd></div>)}
        </dl>
        <Btn onClick={() => app.openHelp('machine')}>{tr('help')}</Btn>
        {lm.configured && <div className="sd-machine-signout"><Btn variant="danger" disabled={disabled} onClick={() => app.lmClear()}>{tr('lm_sign_out')}</Btn></div>}
        <MachineFeedback app={app} name="account" />
      </MachineDisclosure>
    </div>
  </div>;
}

// ---- Wi-Fi (reached from top-bar icon) — real /api/wifi/* ----
function WifiScreen({ app, embedded = false }) {
  const [mode, setMode] = useState('idle'); // idle | scanning | scanned | saved
  const [status, setStatus] = useState(null); // {connected,ssid,signal,...}
  const [networks, setNetworks] = useState([]);
  const [saved, setSaved] = useState([]);
  const [connecting, setConnecting] = useState(null); // network object pending password
  const [pw, setPw] = useState('');
  const [radioBusy, setRadioBusy] = useState(false);
  const [radioMessage, setRadioMessage] = useState('');
  const expectedDisconnect = useRef(false);

  const loadStatus = async () => {
    try {
      const s = await api('/api/wifi/status'); setStatus(s);
      if (!s.busy) {
        setRadioBusy(false); expectedDisconnect.current = false;
        if (radioBusy && !s.error && typeof s.enabled === 'boolean') setRadioMessage(tr(s.enabled ? 'wifi_on' : 'wifi_off'));
      }
      if (s.error) setRadioMessage(s.error);
      return s;
    } catch (e) {
      if (!expectedDisconnect.current) app.toast(e.message);
      return null;
    }
  };
  useEffect(() => { loadStatus(); }, []);
  useEffect(() => {
    if (!radioBusy) return;
    const timer = setInterval(loadStatus, 1500);
    // Stop polling a deliberately disconnected page; local controls or LAN
    // provide recovery. Do not turn this expected event into retry popups.
    const deadline = setTimeout(() => { clearInterval(timer); setRadioBusy(false); }, 15000);
    return () => { clearInterval(timer); clearTimeout(deadline); };
  }, [radioBusy]);
  const radioEnabled = !status || status.enabled !== false;
  const changeRadio = async () => {
    const enabled = !radioEnabled;
    if (!enabled && !window.confirm(tr('wifi_off_confirm'))) return;
    setRadioBusy(true); setMode('idle');
    setRadioMessage(tr(enabled ? 'wifi_turning_on' : 'wifi_turning_off'));
    expectedDisconnect.current = !enabled;
    try {
      await api('/api/wifi/radio', { method: 'POST', body: JSON.stringify({ enabled }) });
      if (!enabled) setRadioMessage(tr('wifi_off_recovery'));
    } catch (e) {
      if (e.status || !expectedDisconnect.current) { expectedDisconnect.current = false; app.toast(e.message); setRadioMessage(e.message); setRadioBusy(false); }
      else setRadioMessage(tr('wifi_off_recovery'));
    }
  };

  const scan = async () => {
    setMode('scanning'); setNetworks([]);
    const s = await loadStatus();
    try {
      const data = await api('/api/wifi/networks');
      setNetworks(data.networks || []);
      setMode('scanned');
    } catch (e) { app.toast(e.message); setMode('idle'); }
  };
  const loadSaved = async () => {
    await loadStatus();
    try { const data = await api('/api/wifi/saved'); setSaved(data.saved || []); setMode('saved'); }
    catch (e) { app.toast(e.message); }
  };
  const connectOpen = async (n) => {
    try {
      await api('/api/wifi/connect', { method: 'POST', body: JSON.stringify({ ssid: n.ssid, password: '' }) });
      app.toast(tr('wifi_switching')); setMode('idle');
    } catch (e) { app.toast(e.message); }
  };
  const pickNetwork = (n) => {
    if (n.requires_password) { setPw(''); setConnecting(n); }
    else connectOpen(n);
  };
  const submitPassword = async () => {
    const n = connecting; if (!n) return;
    setConnecting(null);
    try {
      await api('/api/wifi/connect', { method: 'POST', body: JSON.stringify({ ssid: n.ssid, password: pw }) });
      app.toast(tr('wifi_switching')); setMode('idle');
    } catch (e) { app.toast(e.message); }
  };
  const reconnect = async (c) => {
    try {
      await api('/api/wifi/saved-connect', { method: 'POST', body: JSON.stringify({ name: c.name, uuid: c.uuid, ssid: c.ssid }) });
      app.toast(tr('wifi_switching')); setMode('idle');
    } catch (e) { app.toast(e.message); }
  };
  const forget = async (c) => {
    if (!window.confirm(tr('forget_warn'))) return;
    try {
      await api('/api/wifi/forget', { method: 'POST', body: JSON.stringify({ name: c.name, uuid: c.uuid, ssid: c.ssid }) });
      app.toast(tr('forget')); await loadStatus(); loadSaved();
    } catch (e) { app.toast(e.message); }
  };
  const disconnect = async () => {
    try { await api('/api/wifi/disconnect', { method: 'POST' }); app.toast(tr('disconnect')); await loadStatus(); }
    catch (e) { app.toast(e.message); }
  };

  return (
    <div className={embedded ? "sd-settings-wifi" : "sd-body sd-scroll"}>
      <Card title={tr('wifi_radio')}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div className="sd-rowlabel">{tr(radioEnabled ? 'wifi_on' : 'wifi_off')}</div>
            <div className="sd-rowsub">{tr('wifi_radio_help')}</div>
          </div>
          <Btn variant={radioEnabled ? 'ghost' : 'primary'} className="sm"
            disabled={!status || radioBusy || (radioEnabled ? status.can_disable === false : status.available === false)}
            onClick={changeRadio}>{tr(radioEnabled ? 'wifi_turn_off' : 'wifi_turn_on')}</Btn>
        </div>
        {status && status.ethernet_connected && <div className="sd-rowsub" style={{ marginTop: 12 }}>{tr('wifi_ethernet')} {status.ethernet_address || ''}</div>}
        {radioMessage && <div role="status" className="sd-rowsub" style={{ marginTop: 12 }}>{radioMessage}</div>}
      </Card>
      <Card title={tr('wifi')} helpKey="wifi" onHelp={app.openHelp} apiNote="GET /wifi/status · /networks · /saved">
        <ApiChip>GET /wifi/status · /networks · /saved</ApiChip>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16 }}>
          <Icon name="wifi" size={22} color={status && status.connected ? 'var(--success)' : 'var(--fg-faint)'} />
          {status && status.connected
            ? <div><div className="sd-rowlabel">{tr('connected')} · {status.ssid}</div><div className="sd-rowsub">{tr('signal')} {status.signal}%</div></div>
            : <div><div className="sd-rowlabel">{status && status.enabled === false ? tr('wifi_off') : (status && status.message) || tr('not_connected')}</div></div>}
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <Btn variant="primary" className="block sm" disabled={!radioEnabled || radioBusy} onClick={scan}>{tr('scan')}</Btn>
          <Btn variant="ghost" className="block sm" onClick={loadSaved}>{tr('saved')}</Btn>
          <Btn variant="ghost" className="sm" disabled={radioBusy || !(status && status.connected)} onClick={disconnect}>{tr('disconnect')}</Btn>
        </div>
      </Card>

      {radioEnabled && mode === 'scanning' && <Card><Loading label={tr('scanning')} /></Card>}

      {radioEnabled && mode === 'scanned' && (
        <Card title={tr('scan')} flush apiNote="POST /wifi/connect">
          <div style={{ padding: '0 16px' }}><ApiChip>POST /wifi/connect</ApiChip></div>
          {networks.length === 0 && <div className="sd-item"><span className="sd-itemsub">{tr('no_networks')}</span></div>}
          {networks.map((n, i) => {
            const here = n.active || (status && status.ssid === n.ssid);
            return (
              <div className="sd-item" key={n.ssid + i} onClick={() => !here && pickNetwork(n)} style={{ cursor: here ? 'default' : 'pointer' }}>
                <Icon name="wifi" size={18} color={n.signal > 60 ? 'var(--fg)' : 'var(--fg-faint)'} />
                <div style={{ flex: 1 }}><span className="sd-itemname">{n.ssid}</span>{here && <span className="sd-itemsub"> · {tr('connected')}</span>}</div>
                <span className="sd-mono" style={{ color: 'var(--fg-faint)', fontSize: 12 }}>{n.signal}%</span>
              </div>
            );
          })}
        </Card>
      )}

      {mode === 'saved' && (
        <Card title={tr('saved')} flush apiNote="POST /wifi/saved-connect · /forget">
          <div style={{ padding: '0 16px' }}><ApiChip>POST /wifi/saved-connect · /forget</ApiChip></div>
          {saved.length === 0 && <div className="sd-item"><span className="sd-itemsub">{tr('no_networks')}</span></div>}
          {saved.map((c, i) => {
            const label = c.display_name || c.ssid || c.name;
            const here = status && c.display_name === status.ssid;
            return (
              <div className="sd-item" key={(c.uuid || c.name || c.ssid) + i}>
                <Icon name="wifi" size={18} color={here ? 'var(--success)' : 'var(--fg-faint)'} />
                <div style={{ flex: 1 }}><span className="sd-itemname">{label}</span>{here && <span className="sd-itemsub"> · {tr('connected')}</span>}</div>
                <Btn variant="ghost" className="sm" disabled={here || !radioEnabled || radioBusy} onClick={() => reconnect(c)}>{tr('reconnect')}</Btn>
                <Btn variant="danger" className="sm" onClick={() => forget(c)}>{tr('forget')}</Btn>
              </div>
            );
          })}
          <div style={{ padding: 14, borderTop: '1px solid var(--border-soft)' }}>
            <div className="sd-tags"><Tag warn>{tr('forget_warn')}</Tag></div>
          </div>
        </Card>
      )}

      {connecting && (
        <Modal title={connecting.ssid} onClose={() => setConnecting(null)}
          footer={<Btn variant="primary" className="block" onClick={submitPassword}>{tr('connect')}</Btn>}>
          <div className="sd-fieldlabel">{tr('enter_password')}</div>
          <input className="sd-input" type="password" autoFocus value={pw}
            onChange={e => setPw(e.target.value)} onKeyDown={e => e.key === 'Enter' && submitPassword()} />
        </Modal>
      )}
    </div>
  );
}

Object.assign(window, { machineActiveProfile, machineProfileBrewsByTime, machineBrewModeLabel, MachineScreen, WifiScreen, lmMachineAwake, steamLevelValue, prebrewModeText, prebrewModeValue, prebrewModeOptions, prebrewTimeText, prebrewTimes, prebrewLimits, prebrewPayload, smartStandbyAfterValue, smartStandbyAfterLabel, smartStandbyPayload });
