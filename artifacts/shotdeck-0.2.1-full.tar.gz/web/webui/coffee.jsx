// Coffee catalogue and shared preparation controls. No image leaves this device.
const COFFEE_TEXT = {
 en: { beans:'Beans', bean:'Bean', roaster:'Roaster', add_bean:'Add bean', bean_search:'Search beans', all_beans:'All beans', unassigned:'No bean recorded', preparation:'Preparation used', preparation_defaults:'Preparation for future shots', grind_used:'Grind setting used', grinder_name:'Grinder', roast_date:'Roast date', dose_used:'Dose (g)', bean_roast:'Bean roast classification', use_bean_roast:'Use bean roast for this profile', bean_roast_hint:'Choosing a bean does not change the profile’s roast or machine settings.', bean_missing:'This bean is archived or unavailable. Choose another for future shots.', view_shots:'View shots', take_photo:'Take photo', choose_photo:'Choose photo', remove_photo:'Remove photo', grinder_photo:'Grinder setting photo', photo_help:'One photo for this shot only. JPEG, PNG or WebP, up to 12 MiB. Stored locally without camera metadata; included in encrypted backups. Total photo storage: 64 MiB.', photo_error:'Choose a JPEG, PNG or WebP photo up to 12 MiB. Convert HEIC first.', zoom:'Zoom', retry:'Retry', delete_taste:'Remove taste feedback', review_conflict:'This shot changed in another editor. Your draft is still here. Reload before saving again.', reload_review:'Reload saved review (discards draft)', include_photos:'Include photos in exports', min_rating:'Minimum rating', all_ratings:'All ratings', newest:'Newest first', best_rated:'Best rated first', sort:'Order', more_filters:'More filters', load_more:'Load more', history_changed:'History changed. Reload the list before continuing.', reload_history:'Reload history', saved_recipe:'Saved recipe', no_coffee:'No preparation recorded', manual_value:'Corrected after the shot', captured_value:'Recorded at shot start', storage_used:'Photo storage', prep_saved_hint:'Changes apply to future shots using this profile.', no_rating:'Unrated', all_values:'All', bean_notes:'Bean notes', all_grinders:'All grinders', no_grinder:'No grinder recorded', filters:'Filters', shot_detail:'Shot' },
 de: { beans:'Bohnen', bean:'Bohne', roaster:'Röster', add_bean:'Bohne anlegen', bean_search:'Bohnen suchen', all_beans:'Alle Bohnen', unassigned:'Keine Bohne erfasst', preparation:'Verwendete Zubereitung', preparation_defaults:'Zubereitung für kommende Shots', grind_used:'Verwendeter Mahlgrad', grinder_name:'Mühle', roast_date:'Röstdatum', dose_used:'Dosis (g)', bean_roast:'Röstklasse der Bohne', use_bean_roast:'Röstklasse für dieses Profil übernehmen', bean_roast_hint:'Die Bohnenauswahl ändert weder Profilröstung noch Maschineneinstellungen.', bean_missing:'Diese Bohne ist archiviert oder nicht verfügbar. Für kommende Shots bitte eine andere wählen.', view_shots:'Shots anzeigen', take_photo:'Foto aufnehmen', choose_photo:'Foto auswählen', remove_photo:'Foto entfernen', grinder_photo:'Foto der Mühleneinstellung', photo_help:'Ein Foto nur für diesen Shot. JPEG, PNG oder WebP, bis 12 MiB. Lokal ohne Kamerametadaten gespeichert; in verschlüsselten Backups enthalten. Fotospeicher insgesamt: 64 MiB.', photo_error:'Bitte JPEG, PNG oder WebP bis 12 MiB wählen. HEIC vorher konvertieren.', zoom:'Zoom', retry:'Erneut versuchen', delete_taste:'Geschmacksfeedback entfernen', review_conflict:'Dieser Shot wurde in einem anderen Editor geändert. Dein Entwurf bleibt erhalten. Vor erneutem Speichern bitte neu laden.', reload_review:'Gespeicherten Stand laden (verwirft Entwurf)', include_photos:'Fotos in Exporte aufnehmen', min_rating:'Mindestbewertung', all_ratings:'Alle Bewertungen', newest:'Neueste zuerst', best_rated:'Beste Bewertung zuerst', sort:'Reihenfolge', more_filters:'Weitere Filter', load_more:'Mehr laden', history_changed:'Der Verlauf wurde geändert. Bitte die Liste neu laden.', reload_history:'Verlauf neu laden', saved_recipe:'Gespeichertes Rezept', no_coffee:'Keine Zubereitung erfasst', manual_value:'Nach dem Shot korrigiert', captured_value:'Bei Shot-Start erfasst', storage_used:'Fotospeicher', prep_saved_hint:'Änderungen gelten für kommende Shots mit diesem Profil.', no_rating:'Unbewertet', all_values:'Alle', bean_notes:'Bohnennotizen', all_grinders:'Alle Mühlen', no_grinder:'Keine Mühle erfasst', filters:'Filter', shot_detail:'Shot' }
};
Object.assign(COFFEE_TEXT.en, {
 grinders:'Grinders', add_grinder:'Add grinder', grinder_search:'Search grinders', grinder_notes:'Grinder notes',
 burrs:'Burrs', burr_option:'Burr option', add_burr:'Add burr option', remove_burr:'Remove burr option',
 rpm:'RPM', rpm_settings:'Available RPM settings', rpm_help:'Separate whole RPM values with commas or new lines. Leave empty for a grinder without selectable speed.',
 grinder_manual:'No catalogue grinder / manual entry', grinder_manual_name:'Manual grinder name', not_recorded:'Not recorded',
 grinder_missing:'This grinder or one of its options is unavailable. Select available options for future shots; past shots keep their recorded settings.',
 recorded_option:'Recorded / unavailable', grinder_hint:'These choices record your preparation. Set the burrs, speed and grind on your grinder yourself.',
 grinder_edit_hint:'Renaming or removing options keeps past shots unchanged. Profiles using a removed option need a new selection.',
});
Object.assign(COFFEE_TEXT.de, {
 grinders:'Mühlen', add_grinder:'Mühle anlegen', grinder_search:'Mühlen suchen', grinder_notes:'Mühlennotizen',
 burrs:'Mahlscheiben / Mahlwerk', burr_option:'Mahlwerkoption', add_burr:'Mahlwerkoption hinzufügen', remove_burr:'Mahlwerkoption entfernen',
 rpm:'Drehzahl (U/min)', rpm_settings:'Verfügbare Drehzahlen (U/min)', rpm_help:'Ganze Drehzahlen durch Komma oder Zeilenumbruch trennen. Bei einer Mühle ohne wählbare Drehzahl leer lassen.',
 grinder_manual:'Keine Katalogmühle / manuelle Eingabe', grinder_manual_name:'Manueller Mühlenname', not_recorded:'Nicht erfasst',
 grinder_missing:'Diese Mühle oder eine ihrer Optionen ist nicht verfügbar. Für kommende Shots verfügbare Optionen wählen; frühere Shots behalten ihre gespeicherten Einstellungen.',
 recorded_option:'Erfasst / nicht verfügbar', grinder_hint:'Diese Auswahl dokumentiert die Zubereitung. Mahlwerk, Drehzahl und Mahlgrad bitte selbst an der Mühle einstellen.',
 grinder_edit_hint:'Umbenennen oder Entfernen von Optionen ändert frühere Shots nicht. In Profilen mit entfernter Option bitte neu auswählen.',
});
for (const lang of ['en','de']) Object.assign(T[lang], COFFEE_TEXT[lang]);
const coffeeFields = ['bean_id','grinder','grinder_id','burr_id','grinder_rpm','grind_setting','dose_g','roast_date'];
const coffeeDraft = value => Object.fromEntries(coffeeFields.map(k => [k, value?.[k] ?? null]));
const beanLabel = b => [b.name,b.roaster].filter(Boolean).join(' · ') + (b.archived ? ' ('+tr('archived')+')' : '');
function CoffeeField({label,children}) { return <label className="sd-coffee-field"><span className="sd-fieldlabel">{label}</span>{React.cloneElement(children, {'aria-label':label})}</label>; }
function PreparationFields({value = {}, onChange, beans = [], grinders = [], recorded = {}, history = false, disabled = false}) {
 const [search,setSearch]=useState('');
 const set=(k,v)=>onChange({...value,[k]:v === '' ? null : v});
 const known=beans.find(b=>b.id===value.bean_id);
 const choices=beans.filter(b=>(history || !b.archived || b.id===value.bean_id) && (b.id===value.bean_id || beanLabel(b).toLocaleLowerCase().includes(search.toLocaleLowerCase())));
 return <div className="sd-coffee-fields"><CoffeeField label={tr('bean_search')}><input type="search" className="sd-input" disabled={disabled} value={search} onChange={e=>setSearch(e.target.value)}/></CoffeeField>
  <CoffeeField label={tr('bean')}><select className="sd-input" disabled={disabled} value={value.bean_id || ''} onChange={e=>set('bean_id',e.target.value)}>
   <option value="">{tr('unassigned')}</option>{value.bean_id&&!known&&<option value={value.bean_id}>{tr('bean_missing')}</option>}{choices.map(b=><option key={b.id} value={b.id}>{beanLabel(b)}</option>)}
  </select></CoffeeField>
  {!history && value.bean_id && (!known || known.archived) && <p role="status" className="sd-fieldhelp">{tr('bean_missing')}</p>}
  <GrinderFields value={value} onChange={onChange} grinders={grinders} recorded={recorded} history={history} disabled={disabled}/>
  <CoffeeField label={tr('grind_used')}><input className="sd-input" disabled={disabled} maxLength={80} placeholder="18.5 / 12 clicks / 1.2.0" value={value.grind_setting || ''} onChange={e=>set('grind_setting',e.target.value)}/></CoffeeField>
  <CoffeeField label={tr('dose_used')}><input className="sd-input" disabled={disabled} type="number" min="0.1" max="100" step="0.01" value={value.dose_g ?? ''} onChange={e=>set('dose_g',e.target.value)}/></CoffeeField>
  <CoffeeField label={tr('roast_date')}><input className="sd-input" disabled={disabled} type="date" value={value.roast_date || ''} onChange={e=>set('roast_date',e.target.value)}/></CoffeeField>
 </div>;
}
function BeanEditor({app,bean,onSaved,onCancel}) {
 const [d,setD]=useState(bean || {name:'',roaster:'',roast_type:'',notes:''}); const [error,setError]=useState(''); const [busy,setBusy]=useState(false);
 const set=(k,v)=>setD(s=>({...s,[k]:v}));
 return <form className="sd-coffee-editor" onSubmit={async e=>{e.preventDefault();setBusy(true);setError('');try {onSaved(await app.saveBean(d));}catch(e){setError(e.message);}finally{setBusy(false);}}}>
  {['name','roaster'].map(k=><CoffeeField key={k} label={tr(k)}><input required={k==='name'} className="sd-input" maxLength={80} value={d[k]} onChange={e=>set(k,e.target.value)}/></CoffeeField>)}
  <CoffeeField label={tr('bean_roast')}><select className="sd-input" value={d.roast_type} onChange={e=>set('roast_type',e.target.value)}><option value="">—</option>{(app.data.roast_types || []).map(r=><option key={r.name} value={r.name}>{r.name}</option>)}</select></CoffeeField>
  <CoffeeField label={tr('bean_notes')}><textarea className="sd-input" rows={3} maxLength={1000} value={d.notes} onChange={e=>set('notes',e.target.value)}/></CoffeeField>
  {error&&<p role="alert">{error}</p>}<div className="sd-coffee-actions"><button className="sd-btn primary" type="submit" disabled={busy}>{tr('save')}</button><Btn type="button" variant="ghost" onClick={onCancel} disabled={busy}>{tr('cancel')}</Btn></div>
 </form>;
}
function CoffeeNavigation({app}) {return <div className="sd-coffee-actions sd-coffee-nav" style={{gridColumn:'1 / -1'}}><div className="sd-seg">{['profiles','beans','grinders'].map(s=><button type="button" key={s} className={app.profilesSection===s?'on':''} aria-pressed={app.profilesSection===s} onClick={()=>app.setProfilesSection(s)}>{tr(s==='profiles'?'tab_profiles':s)}</button>)}</div></div>;}
function BeansPanel({app}) {
 const [search,setSearch]=useState('');const [archived,setArchived]=useState(false);const [editing,setEditing]=useState(null);const [error,setError]=useState('');
 const beans=app.data.beans || [];
 return <Card title={tr('beans')}><input className="sd-input" type="search" aria-label={tr('bean_search')} placeholder={tr('bean_search')} value={search} onChange={e=>setSearch(e.target.value)}/>
  <label className="sd-coffee-check"><input type="checkbox" checked={archived} onChange={e=>setArchived(e.target.checked)}/>{tr('archived')}</label>
  {error&&<p role="alert">{error}</p>}
  {editing?<BeanEditor key={editing.id || 'new'} app={app} bean={editing.id?editing:null} onCancel={()=>setEditing(null)} onSaved={()=>setEditing(null)}/>:<Btn onClick={()=>setEditing({})}>{tr('add_bean')}</Btn>}
  {beans.filter(b=>(archived||!b.archived)&&[b.name,b.roaster,b.notes].join(' ').toLocaleLowerCase().includes(search.toLocaleLowerCase())).map(b=><div className="sd-coffee-bean" key={b.id}><strong>{beanLabel(b)}</strong>{b.roast_type&&<span> · {b.roast_type}</span>}{b.notes&&<p className="sd-itemsub">{b.notes}</p>}<div className="sd-coffee-actions"><Btn variant="ghost" onClick={()=>setEditing(b)}>{tr('edit')}</Btn><Btn variant="ghost" onClick={()=>app.showBeanShots(b.id)}>{tr('view_shots')}</Btn><Btn variant="ghost" onClick={async()=>{try{await app.saveBean({...b,archived:!b.archived});setError('');}catch(e){setError(e.message);}}}>{tr(b.archived?'restore':'archive')}</Btn></div></div>)}
 </Card>;
}
function GrinderFields({value, onChange, grinders, recorded, history, disabled}) {
 const grinder = grinders.find(g => g.id === value.grinder_id);
 const burrs = grinder?.burrs || [];
 const rpms = grinder?.rpm_settings || [];
 const missingBurr = value.burr_id && !burrs.some(b => b.id === value.burr_id);
 const missingRpm = value.grinder_rpm != null && !rpms.includes(Number(value.grinder_rpm));
 const set = (k,v) => onChange({...value,[k]:v === '' ? null : v});
 return <>
  <CoffeeField label={tr('grinder_name')}><select className="sd-input" disabled={disabled} value={value.grinder_id || ''}
   onChange={e=>onChange({...value,grinder_id:e.target.value || null,grinder:null,burr_id:null,grinder_rpm:null,grind_setting:null})}>
   <option value="">{tr('grinder_manual')}</option>
   {value.grinder_id && !grinder && <option value={value.grinder_id}>{value.grinder || tr('recorded_option')}</option>}
   {grinders.filter(g=>history || !g.archived || g.id===value.grinder_id).map(g=><option key={g.id} value={g.id}>{g.name}{g.archived?' ('+tr('archived')+')':''}</option>)}
  </select></CoffeeField>
  {!value.grinder_id ? <CoffeeField label={tr('grinder_manual_name')}><input className="sd-input" disabled={disabled} maxLength={80} value={value.grinder || ''} onChange={e=>set('grinder',e.target.value)}/></CoffeeField> : <>
   <CoffeeField label={tr('burrs')}><select className="sd-input" disabled={disabled} value={value.burr_id || ''} onChange={e=>set('burr_id',e.target.value)}>
    <option value="">{tr('not_recorded')}</option>
    {missingBurr && <option value={value.burr_id}>{recorded.burr || tr('recorded_option')} ({tr('recorded_option')})</option>}
    {burrs.map(b=><option key={b.id} value={b.id}>{b.name}</option>)}
   </select></CoffeeField>
   <CoffeeField label={tr('rpm')}><select className="sd-input" disabled={disabled} value={value.grinder_rpm ?? ''} onChange={e=>set('grinder_rpm',e.target.value===''?null:Number(e.target.value))}>
    <option value="">{tr('not_recorded')}</option>
    {missingRpm && <option value={value.grinder_rpm}>{value.grinder_rpm} ({tr('recorded_option')})</option>}
    {rpms.map(r=><option key={r} value={r}>{r}</option>)}
   </select></CoffeeField>
   {!history && (!grinder || grinder.archived || missingBurr || missingRpm) && <p role="status" className="sd-fieldhelp">{tr('grinder_missing')}</p>}
  </>}
  <p className="sd-fieldhelp">{tr('grinder_hint')}</p>
 </>;
}
function GrinderEditor({app,grinder,onSaved,onCancel}) {
 const [d,setD]=useState(()=>grinder?{...grinder,burrs:grinder.burrs.map(b=>({...b}))}:{name:'',notes:'',burrs:[],rpm_settings:[]});
 const [rpms,setRpms]=useState((grinder?.rpm_settings||[]).join(', '));
 const [error,setError]=useState(''),[busy,setBusy]=useState(false);
 const set=(k,v)=>setD(s=>({...s,[k]:v}));
 return <form className="sd-coffee-editor" onSubmit={async e=>{
  e.preventDefault();setBusy(true);setError('');
  try {await app.saveGrinder({...d,rpm_settings:rpms.trim()?rpms.trim().split(/[,;\s]+/):[]});onSaved();}
  catch(e){setError(e.message);}finally{setBusy(false);}
 }}>
  <fieldset className="sd-grinder-editor" disabled={busy}>
   <CoffeeField label={tr('name')}><input className="sd-input" required maxLength={80} value={d.name} onChange={e=>set('name',e.target.value)}/></CoffeeField>
   <div className="sd-fieldlabel">{tr('burrs')}</div>
   {d.burrs.map((b,i)=><div className="sd-grinder-option" key={b.id||'new-'+i}>
    <CoffeeField label={tr('burr_option')+' '+(i+1)}><input className="sd-input" required maxLength={80} value={b.name} onChange={e=>set('burrs',d.burrs.map((v,n)=>n===i?{...v,name:e.target.value}:v))}/></CoffeeField>
    <Btn type="button" variant="ghost" onClick={()=>set('burrs',d.burrs.filter((_,n)=>n!==i))}>{tr('remove_burr')}</Btn>
   </div>)}
   <Btn type="button" variant="ghost" disabled={d.burrs.length>=32} onClick={()=>set('burrs',[...d.burrs,{name:''}])}>{tr('add_burr')}</Btn>
   <CoffeeField label={tr('rpm_settings')}><textarea className="sd-input" rows={2} maxLength={1000} value={rpms} onChange={e=>setRpms(e.target.value)} placeholder="400, 800, 1200"/></CoffeeField>
   <p className="sd-fieldhelp">{tr('rpm_help')}</p>
   <CoffeeField label={tr('grinder_notes')}><textarea className="sd-input" rows={3} maxLength={1000} value={d.notes} onChange={e=>set('notes',e.target.value)}/></CoffeeField>
   <p className="sd-fieldhelp">{tr('grinder_edit_hint')}</p>
   {error&&<p role="alert">{error}</p>}
   <div className="sd-coffee-actions"><button className="sd-btn primary" type="submit">{tr('save')}</button><Btn type="button" variant="ghost" onClick={onCancel}>{tr('cancel')}</Btn></div>
  </fieldset>
 </form>;
}
function GrindersPanel({app}) {
 const [search,setSearch]=useState(''),[archived,setArchived]=useState(false),[editing,setEditing]=useState(null),[error,setError]=useState('');
 const grinders=(app.data.grinders||[]).filter(g=>(archived||!g.archived)&&[g.name,g.notes,...g.burrs.map(b=>b.name)].join(' ').toLocaleLowerCase().includes(search.toLocaleLowerCase()));
 return <Card title={tr('grinders')}>
  <input className="sd-input" type="search" aria-label={tr('grinder_search')} placeholder={tr('grinder_search')} value={search} onChange={e=>setSearch(e.target.value)}/>
  <label className="sd-coffee-check"><input type="checkbox" checked={archived} onChange={e=>setArchived(e.target.checked)}/>{tr('archived')}</label>
  {error&&<p role="alert">{error}</p>}
  {editing?<GrinderEditor key={editing.id||'new'} app={app} grinder={editing.id?editing:null} onCancel={()=>setEditing(null)} onSaved={()=>setEditing(null)}/>:<Btn onClick={()=>setEditing({})}>{tr('add_grinder')}</Btn>}
  {grinders.map(g=><div className="sd-coffee-bean" key={g.id}>
   <strong>{g.name}{g.archived?' ('+tr('archived')+')':''}</strong>
   {g.burrs.length>0&&<p className="sd-itemsub">{tr('burrs')}: {g.burrs.map(b=>b.name).join(' · ')}</p>}
   {g.rpm_settings.length>0&&<p className="sd-itemsub">{tr('rpm')}: {g.rpm_settings.join(' · ')}</p>}
   {g.notes&&<p className="sd-itemsub">{g.notes}</p>}
   <div className="sd-coffee-actions"><Btn variant="ghost" onClick={()=>setEditing(g)}>{tr('edit')}</Btn><Btn variant="ghost" onClick={async()=>{try{await app.saveGrinder({...g,archived:!g.archived});setError('');}catch(e){setError(e.message);}}}>{tr(g.archived?'restore':'archive')}</Btn></div>
  </div>)}
 </Card>;
}
function BrewPreparation({app,profile}) {
 const [editing,setEditing]=useState(false);const [draft,setDraft]=useState({});const [error,setError]=useState('');const [busy,setBusy]=useState(false);
 const bean=(app.data.beans||[]).find(b=>b.id===profile.coffee_defaults?.bean_id);
 const defaults=profile.coffee_defaults||{},grinder=(app.data.grinders||[]).find(g=>g.id===defaults.grinder_id),burr=grinder?.burrs.find(b=>b.id===defaults.burr_id);
 const unavailable=defaults.grinder_id&&(!grinder||grinder.archived||(defaults.burr_id&&!burr)||(defaults.grinder_rpm!=null&&!grinder.rpm_settings.includes(Number(defaults.grinder_rpm))));
 const equipment=[grinder?.name||defaults.grinder,burr?.name,defaults.grinder_rpm!=null?defaults.grinder_rpm+' '+tr('rpm'):null].filter(Boolean).join(' · ');
 return <><div className="sd-coffee-brief"><span>{bean?beanLabel(bean):tr('unassigned')}{profile.coffee_defaults?.grind_setting?' · '+tr('grind_used')+': '+profile.coffee_defaults.grind_setting:''}{equipment&&<><br/>{equipment}</>}</span>{unavailable&&<p role="status" className="sd-fieldhelp">{tr('grinder_missing')}</p>}<div className="sd-coffee-actions"><Btn className="sm" variant="ghost" disabled={app.data.settings.shot_active} onClick={()=>{setDraft(coffeeDraft(profile.coffee_defaults));setEditing(true);setError('');}}>{tr('preparation_defaults')}</Btn><Btn className="sm" variant="ghost" onClick={app.showBeans}>{tr('beans')}</Btn><Btn className="sm" variant="ghost" onClick={()=>{app.setProfilesSection('grinders');app.go('profiles');}}>{tr('grinders')}</Btn></div></div>
 {editing&&<Modal title={tr('preparation_defaults')} onClose={()=>!busy&&setEditing(false)} footer={<Btn disabled={busy} onClick={async()=>{setBusy(true);try{await app.saveProfileFields(profile.index,{coffee_defaults:draft});setEditing(false);}catch(e){setError(e.message);}finally{setBusy(false);}}}>{tr('save')}</Btn>}><p className="sd-fieldhelp">{tr('prep_saved_hint')}</p><PreparationFields value={draft} onChange={setDraft} beans={app.data.beans} grinders={app.data.grinders} disabled={busy}/><p className="sd-fieldhelp">{tr('bean_roast_hint')}</p>{error&&<p role="alert">{error}</p>}</Modal>}</>;
}
function PhotoViewer({photo,onClose}) {
 const [zoom,setZoom]=useState(1);return <Modal title={tr('grinder_photo')} onClose={onClose}><CoffeeField label={tr('zoom')}><input type="range" min="1" max="4" step="0.25" value={zoom} onChange={e=>setZoom(Number(e.target.value))}/></CoffeeField><div style={{overflow:'auto',maxHeight:'65vh'}}><img src={photo.url} alt={tr('grinder_photo')} style={{width:zoom*100+'%',maxWidth:'none',display:'block'}}/></div></Modal>;
}
function GrindPhotoInput({photo,dataUrl,remove,onChange,disabled,onLoading=()=>{}}) {
 const camera=useRef(null),gallery=useRef(null);const [error,setError]=useState('');
 const read=async e=>{const f=e.target.files?.[0];e.target.value='';if(!f)return;if(f.size>12*1024*1024 || !['image/jpeg','image/png','image/webp'].includes(f.type)){setError(tr('photo_error'));return;}onLoading(true);try {const value=await new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(f);});onChange(value,false);setError('');}catch{setError(tr('photo_error'));}finally{onLoading(false);}};
 const src=dataUrl||(!remove&&photo?.thumbnail_url);
 return <div className="sd-coffee-photo"><div className="sd-fieldlabel">{tr('grinder_photo')}</div>{src&&<img src={src} alt={tr('grinder_photo')} style={{maxWidth:'100%',maxHeight:220,objectFit:'contain'}}/>}<input ref={camera} type="file" accept="image/*" capture="environment" hidden onChange={read}/><input ref={gallery} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={read}/><div className="sd-coffee-actions"><Btn disabled={disabled} variant="ghost" onClick={()=>camera.current.click()}>{tr('take_photo')}</Btn><Btn disabled={disabled} variant="ghost" onClick={()=>gallery.current.click()}>{tr('choose_photo')}</Btn>{src&&<Btn disabled={disabled} variant="ghost" onClick={()=>onChange(null,true)}>{tr('remove_photo')}</Btn>}</div><p className="sd-fieldhelp">{tr('photo_help')}</p>{error&&<p role="alert">{error}</p>}</div>;
}
function coffeeReportLines(shot,lang='en') {
 const t=COFFEE_TEXT[lang]||COFFEE_TEXT.en,c=shot.coffee||{},f=shot.feedback;const lines=[];
 if(c.bean)lines.push([t.bean,[c.bean.name,c.bean.roaster,c.bean.roast_type].filter(Boolean).join(' · ')+(c.sources?.bean_id==='manual'?' *':'')]);
 for(const [key,label] of [['grinder','grinder_name'],['burr','burrs'],['grinder_rpm','rpm'],['grind_setting','grind_used'],['dose_g','dose_used'],['roast_date','roast_date']])if(c[key]!=null&&c[key]!=='')lines.push([t[label],String(c[key])+(c.sources?.[key==='burr'?'burr_id':key]==='manual'?' *':'')]);
 if(f){lines.push([lang==='de'?'Bewertung':'Rating',f.rating?f.rating+' / 5':t.no_rating]);for(const key of ['taste','issue','visual','prep','grind_adjustment'])if(f[key]&&!['none','normal','not_tasted'].includes(f[key]))lines.push([(T[lang]||T.en)['fb_'+({grind_adjustment:'grind'}[key]||key)]||key,(FB_LABELS[lang]||FB_LABELS.en)[f[key]]||f[key]]);if(f.notes)lines.push([(T[lang]||T.en).fb_notes,f.notes]);}
 if(Object.values(c.sources||{}).includes('manual'))lines.push(['*',t.manual_value]);return lines;
}
function savedPrebrewText(profile,lang='en') {
 if (profile.prebrew_enabled===false || profile.prebrew_preference?.enabled===false) return lang==='de'?'Profil aus · Maschine unverändert':'Profile off · machine unchanged';
 const controller=profile.prebrew_controller || profile.prebrew_preference?.controller;
 if (controller==='shotdeck') return 'Shotdeck · '+(profile.shotdeck_prebrew_pump_s ?? profile.shotdeck_prebrew?.pump_s ?? '—')+' s / '+(profile.shotdeck_prebrew_pause_s ?? profile.shotdeck_prebrew?.pause_s ?? '—')+' s';
 if (profile.prebrew_mode==='prebrewing')return 'La Marzocco · '+(profile.prebrew_seconds_on ?? '—')+' s / '+(profile.prebrew_seconds_off ?? '—')+' s';
 return profile.prebrew_mode==='no_change'?(lang==='de'?'Nicht ändern':'Do not change'):'—';
}
// Closing a detail panel keeps a compact, accessible way to reopen it.
function ShotDetailsPanel({title,className='',children}) {
 const [open,setOpen]=useState(true);
 if(!open)return <Btn variant="ghost" className={'sm sd-shot-detail-restore '+className} aria-expanded={false} onClick={()=>setOpen(true)}><Icon name="chevron" size={14}/>{title}</Btn>;
 return <Card title={title} className={className} right={<button className="sd-iconbtn" title={tr('dismiss')} aria-label={tr('dismiss')+' · '+title} aria-expanded={true} onClick={()=>setOpen(false)}><Icon name="close" size={16}/></button>}>{children}</Card>;
}
function CoffeeShotDetails({shot,app}) {
 const [photo,setPhoto]=useState(null);const p=shot.settings?.profile||{};const lines=coffeeReportLines(shot,app.lang);
 return <ShotDetailsPanel title={tr('preparation')} className="sd-preparation-shot-details"><dl className="sd-coffee-details">{lines.length?lines.map(([k,v],i)=><React.Fragment key={i}><dt>{k}</dt><dd>{v}</dd></React.Fragment>):<p>{tr('no_coffee')}</p>}</dl>{shot.coffee?.photo&&<button className="sd-coffee-thumb" onClick={()=>setPhoto(shot.coffee.photo)}><img loading="lazy" src={shot.coffee.photo.thumbnail_url} alt={tr('grinder_photo')}/><span>{tr('grinder_photo')}</span></button>}<details><summary>{tr('saved_recipe')}</summary><dl className="sd-coffee-details">{[['name',shot.profile_name],['profile_comment',p.comment],['roast',shot.roast],['target',shot.target_weight_g+' g'],['time',shot.target_time_min_s+'–'+shot.target_time_max_s+' s'],['brew_mode',p.brew_control_mode],['drip_intel',p.intelligence_mode],['prebrew',savedPrebrewText(p,app.lang)],['coffee',shot.brew_temperature_c==null?'—':shot.brew_temperature_c+' °C ('+tr(shot.brew_temperature_source==='profile'?'shot_temperature_profile':'shot_brew_temperature')+')'],['ideal_flow',p.ideal_flow_enabled?tr('on'):tr('off')]].map(([k,v])=><React.Fragment key={k}><dt>{tr(k)}</dt><dd>{v||'—'}</dd></React.Fragment>)}</dl></details><Btn variant="ghost" onClick={()=>app.openFeedback(shot.id)}>{tr('edit_feedback')}</Btn>{photo&&<PhotoViewer photo={photo} onClose={()=>setPhoto(null)}/>}</ShotDetailsPanel>;
}
async function loadCoffeeShotPage(fetchApi,{from='',to='',...filters}={}) {
 const params=window.__sdTimezone?new URLSearchParams({...from?{from}:{},...to?{to}:{}}):shotRangeParams(from,to);params.set('consistent','1');params.set('limit','50');for(const [k,v]of Object.entries(filters))if(v!==''&&v!=null)params.set(k,String(v));return fetchApi('/api/shots?'+params);
}
async function loadCoffeeShotRange(fetchApi,filters) {
 const rows=[],ids=new Set();let page=null;
 do {const next=await loadCoffeeShotPage(fetchApi,{...filters,limit:200,offset:rows.length,...(page?{snapshot:page.snapshot,revision:page.revision}:{})});if(!Number.isInteger(next.revision)||!Number.isInteger(next.total)||!Array.isArray(next.shots)|| (page&&next.total!==page.total))throw new Error('Incomplete shot history');page=next;for(const shot of page.shots){if(ids.has(shot.id))throw new Error('Duplicate shot');ids.add(shot.id);rows.push(shot);}if(!page.shots.length&&rows.length<page.total)throw new Error('Incomplete shot history');}while(rows.length<page.total);
 if(rows.length!==page.total)throw new Error('Incomplete shot history');return {rows,revision:page.revision};
}
async function loadGrindPhoto(photo,revision) {
 const url=new URL(photo.url,location.href);if(revision!=null)url.searchParams.set('revision',String(revision));const response=await fetch(url);if(!response.ok)throw new Error('Photo changed or unavailable');const blob=await response.blob(),objectUrl=URL.createObjectURL(blob);try{return await new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=reject;im.src=objectUrl;});}finally{URL.revokeObjectURL(objectUrl);}
}
Object.assign(window,{ShotDetailsPanel,savedPrebrewText,CoffeeField,beanLabel,PreparationFields,BeanEditor,CoffeeNavigation,BeansPanel,GrindersPanel,BrewPreparation,GrindPhotoInput,PhotoViewer,CoffeeShotDetails,coffeeDraft,coffeeReportLines,loadCoffeeShotPage,loadCoffeeShotRange,loadGrindPhoto});
