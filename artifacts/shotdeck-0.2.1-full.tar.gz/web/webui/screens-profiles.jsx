// ============================================================
// Shotdeck — Profiles tab: list · editor (progressive disclosure)
//   · ideal-flow curve editor + mini-table · Users · Roasts
// ============================================================

function Accordion({ title, open, onToggle, children, sub }) {
  return (
    <div style={{ borderTop: '1px solid var(--border-soft)' }}>
      <button onClick={onToggle} style={{
        width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '15px 2px', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--fg)',
      }}>
        <div style={{ textAlign: 'left' }}>
          <div style={{ fontSize: 15, fontWeight: 600 }}>{title}</div>
          {sub && <div className="sd-rowsub">{sub}</div>}
        </div>
        <span style={{ transform: open ? 'rotate(90deg)' : 'none', transition: 'transform .2s', color: 'var(--fg-faint)' }}><Icon name="chevron" size={18} /></span>
      </button>
      {open && <div style={{ padding: '2px 2px 18px', animation: 'sd-rise .2s ease' }}>{children}</div>}
    </div>
  );
}

function profilesBrewByTime(p) {
  return String((p && p.brew_control_mode) || 'weight').toLowerCase() === 'time';
}
function profilesTargetText(p) {
  if (!p) return '-';
  if (profilesBrewByTime(p)) return `${Number(p.target_stop_time_s || p.target_time_max_s || 30).toFixed(0)}s`;
  return `${Number(p.target_weight_g || 0).toFixed(1)}g`;
}
function profilesBrewModeLabel(p) {
  return profilesBrewByTime(p) ? tr('brew_by_time') : tr('brew_by_weight');
}
function profilesTimingText(p) {
  if (!p) return '-';
  if (profilesBrewByTime(p)) return profilesTargetText(p);
  return `${profilesTargetText(p)} · ${p.target_time_min_s}–${p.target_time_max_s}s`;
}

function profilePrebrewText(p) {
  const preference = (p && p.prebrew_preference) || {};
  if (preference.enabled !== true) return tr('prebrew_off');
  if (preference.controller === 'shotdeck') return `Shotdeck ${tr('prebrew')}`;
  if (p.prebrew_mode === 'prebrewing') {
    return `${tr('la_marzocco')} ${Number(p.prebrew_seconds_on ?? 2).toFixed(1)}/${Number(p.prebrew_seconds_off ?? 3).toFixed(1)}s`;
  }
  return `${tr('la_marzocco')} · ${tr('pb_no_change')}`;
}

function profileShotdeckPrebrewUnavailable(p) {
  const preference = (p && p.prebrew_preference) || {};
  const local = (p && p.shotdeck_prebrew) || {};
  return preference.enabled === true
    && preference.controller === 'shotdeck'
    && local.supported !== true;
}

function shotdeckPrebrewUnavailableText(local) {
  return local && local.unavailable_reason === 'holding_relay_required'
    ? tr('shotdeck_prebrew_holding_required')
    : tr('shotdeck_prebrew_release_required');
}

function ProfilesScreen({ app }) {
  const [editing, setEditing] = useState(null); // profile index
  const [showArchived, setShowArchived] = useState(false);
  const activeProfiles = app.data.profiles.filter(p => !p.archived);
  const archivedProfiles = app.data.profiles.filter(p => p.archived);
  if (app.profileDestination) {
    const destination = app.profileDestination;
    const profile = activeProfiles.find(item => item.index === destination.index);
    if (!profile) return <div className="sd-body sd-scroll">
      <EmptyState icon="profiles" title={tr('no_profiles')} />
      <Btn onClick={app.returnToMachine}>{tr('machine_back')}</Btn>
    </div>;
    return <ProfileEditor key={profile.index} app={app} profile={profile}
      initialSection={destination.section} backLabel={tr('machine_back')} onBack={app.returnToMachine} />;
  }
  if (app.profilesSection === 'grinders') return <div className="sd-body sd-scroll sd-coffee-catalogue"><CoffeeNavigation app={app}/><GrindersPanel app={app}/></div>;
  if (app.profilesSection === 'beans') return <div className="sd-body sd-scroll sd-coffee-catalogue"><CoffeeNavigation app={app}/><BeansPanel app={app}/></div>;
  if (editing != null) {
    const prof = app.data.profiles.find(p => p.index === editing);
    if (!prof) { setEditing(null); return null; }
    return <ProfileEditor app={app} profile={prof} onBack={() => setEditing(null)} />;
  }
  return (
    <div className="sd-body sd-scroll sd-profile-grid">
      <CoffeeNavigation app={app}/>
      <Card title={tr('tab_profiles')} helpKey="profiles" onHelp={app.openHelp} flush className="sd-profile-panel">
        <div style={{ padding: '14px 16px 0' }}><ApiChip>GET /profiles · POST /profiles</ApiChip></div>
        <div className="sd-profile-list">
          {activeProfiles.map(p => (
            <SwipeActionRow key={p.index}
              onClick={() => setEditing(p.index)}
              onDelete={activeProfiles.length > 1 && !['DR', 'MR', 'LR'].includes(p.name) ? () => app.deleteProfile(p.index) : null}>
              {/* Thumbnail window: the ideal curve, or the stop time for brew-by-time profiles */}
              <div className={'sd-glass sd-profile-thumb' + (p.selected ? ' active' : '')} aria-hidden="true">
                {profilesBrewByTime(p) || !profileIdealCurve(p) ? <span>{profileTargetText(p)}</span>
                  : <LiveBrewChart width={88} height={48} samples={profileIdealCurve(p)} duration={36} ideal={null} band={roastFlowBand(app, p)} axes={false} themeKey={app.theme} />}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                  <span className="sd-dot" style={{ background: p.color, width: 10, height: 10 }} />
                  <span className="sd-itemname">{p.name}</span>
                  {p.selected && <Pill variant="ok" dot>{tr('active')}</Pill>}
                  <Pill variant={profilesBrewByTime(p) ? 'good' : ''} dot>{profilesBrewModeLabel(p)}</Pill>
                </div>
                <div className="sd-itemsub">{profilesTimingText(p)} · {p.roast}{p.ideal_flow_enabled ? ' · ' + tr('ideal_flow') : ''} · {profilePrebrewText(p)}</div>
                {p.comment && <div className="sd-itemsub" style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{p.comment}</div>}
                {profileShotdeckPrebrewUnavailable(p) && <div className="sd-itemsub sd-profile-warn" role="note">{tr('shotdeck_prebrew_unavailable_short')}</div>}
              </div>
              <Icon name="chevron" size={16} color="var(--fg-faint)" />
            </SwipeActionRow>
          ))}
        </div>
        <div className="sd-profile-actions" style={{ padding: 12, borderTop: '1px solid var(--border-soft)' }}>
          <Btn variant="ghost" className="block" onClick={() => app.addProfile()}><Icon name="plus" size={18} /> {tr('add_profile')}</Btn>
          {archivedProfiles.length > 0 && (
            <button onClick={() => setShowArchived(!showArchived)} style={{ marginTop: 10, width: '100%', background: 'none', border: 'none', color: 'var(--fg-faint)', cursor: 'pointer', fontSize: 13 }}>{tr('archived')} ({archivedProfiles.length})</button>
          )}
          {showArchived && archivedProfiles.map(p => (
            <div className="sd-item" key={p.index} style={{ opacity: 0.68, marginTop: 8 }}>
              <span className="sd-dot" style={{ background: p.color }} />
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span className="sd-itemname">{p.name}</span>
                  <Pill variant={profilesBrewByTime(p) ? 'good' : ''} dot>{profilesBrewModeLabel(p)}</Pill>
                </div>
                <div className="sd-itemsub">{profilesTimingText(p)} · {p.roast}</div>
              </div>
              <Btn variant="ghost" className="sm" onClick={() => app.restoreProfile(p.index)}>{tr('restore')}</Btn>
            </div>
          ))}
        </div>
      </Card>

      <UsersCard app={app} />
      <RoastsCard app={app} />
    </div>
  );
}

// Numeric cell for the ideal-flow mini-table. Keeps the raw string while
// focused so intermediate states like "1." survive typing; commits every
// valid parse so the plot tracks live; reverts to the canonical value on blur.
function CurveNumInput({ value, onCommit, style }) {
  const [draft, setDraft] = useState(null);
  return (
    <input className="sd-input mono" inputMode="decimal" style={style}
      value={draft !== null ? draft : String(value)}
      onChange={e => {
        const raw = e.target.value;
        setDraft(raw);
        const n = parseFloat(raw);
        if (Number.isFinite(n)) onCommit(n);
      }}
      onBlur={() => setDraft(null)} />
  );
}

function ProfilePrebrewFields({ draft: d, onChange }) {
  const setShotdeckPrebrew = (k, v) => onChange(s => ({ ...s, shotdeck_prebrew: { ...s.shotdeck_prebrew, [k]: v } }));
  const setPrebrewPreference = (k, v) => onChange(s => ({ ...s, prebrew_preference: { ...s.prebrew_preference, [k]: v } }));
  const set = (k, v) => onChange(s => ({ ...s, [k]: v }));
  const prebrewEnabled = d.prebrew_preference.enabled === true;
  const prebrewController = d.prebrew_preference.controller === 'shotdeck' ? 'shotdeck' : 'lamarzocco';
  const shotdeckPrebrewSupported = d.shotdeck_prebrew.supported === true;
  return (
            <div style={{ marginTop: 8, padding: 12, border: '1px solid var(--border-soft)', borderRadius: 'var(--r-sm)' }}>
              <Row label={tr('prebrew_mode')} sub={tr('profile_prebrew_help')}>
                <Switch on={prebrewEnabled} onChange={v => setPrebrewPreference('enabled', v)} />
              </Row>
              {prebrewEnabled && <>
                <div style={{ marginTop: 12 }}>
                  <div className="sd-fieldlabel">{tr('prebrew_controller')}</div>
                  <Segmented value={prebrewController} onChange={v => setPrebrewPreference('controller', v)}
                    options={[{ value: 'lamarzocco', label: tr('la_marzocco') }, { value: 'shotdeck', label: 'Shotdeck', disabled: !shotdeckPrebrewSupported }]} />
                  {!shotdeckPrebrewSupported && (
                    <div role="alert" className="sd-rowsub" style={{ marginTop: 8, color: 'var(--danger-text)' }}>
                      {shotdeckPrebrewUnavailableText(d.shotdeck_prebrew)}
                    </div>
                  )}
                </div>
                {prebrewController === 'lamarzocco' ? <div style={{ marginTop: 14 }}>
                  <div className="sd-fieldlabel">{tr('lm_profile_prebrew')}</div>
                  <Select value={d.prebrew_mode === 'prebrewing' ? 'prebrewing' : 'no_change'} onChange={v => set('prebrew_mode', v)}
                    options={[{ value: 'no_change', label: tr('pb_no_change') }, { value: 'prebrewing', label: tr('pb_on') }]} />
                  <div className="sd-itemsub" style={{ marginTop: 7 }}>{tr('lm_profile_prebrew_help')}</div>
                  {d.prebrew_mode === 'prebrewing' && (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 10, marginTop: 12 }}>
                  <div style={{ minWidth: 0 }}><div className="sd-fieldlabel">{tr('pb_on_s')}</div>
                    <Stepper width="100%" value={d.prebrew_seconds_on ?? 2} onChange={v => set('prebrew_seconds_on', v)} min={0} max={20} step={0.5} /></div>
                  <div style={{ minWidth: 0 }}><div className="sd-fieldlabel">{tr('pb_off_s')}</div>
                    <Stepper width="100%" value={d.prebrew_seconds_off ?? 3} onChange={v => set('prebrew_seconds_off', v)} min={0} max={20} step={0.5} /></div>
                </div>
                  )}
                </div> : <div style={{ marginTop: 14 }}>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 10 }}>
                    <div><div className="sd-fieldlabel">{tr('prebrew_pump')}</div>
                      <Stepper width="100%" value={d.shotdeck_prebrew.pump_s} onChange={v => setShotdeckPrebrew('pump_s', v)} min={0.5} max={20} step={0.5} /></div>
                    <div><div className="sd-fieldlabel">{tr('prebrew_pause')}</div>
                      <Stepper width="100%" value={d.shotdeck_prebrew.pause_s} onChange={v => setShotdeckPrebrew('pause_s', v)} min={0} max={20} step={0.5} /></div>
                  </div>
                  <div className="sd-itemsub" style={{ marginTop: 10 }}>{tr('prebrew_sequence_help')}</div>
                </div>}
              </>}
            </div>
  );
}

// ---- Profile editor ----
function ProfileEditor({ app, profile, onBack, initialSection, backLabel }) {
  const [d, setD] = useState({
    brew_control_mode: 'weight',
    target_stop_time_s: profile.target_time_max_s || 30,
    ...profile,
    prebrew_preference: {
      enabled: true, controller: 'lamarzocco',
      ...(profile.prebrew_preference || {}),
    },
    shotdeck_prebrew: {
      enabled: false, pump_s: 2, pause_s: 3,
      ...(profile.shotdeck_prebrew || {}),
    },
  });
  const [open, setOpen] = useState(initialSection === 'prebrew' ? 'advanced' : 'basics');
  const [saving, setSaving] = useState(false);
  const prebrewRef = useRef(null);
  useEffect(() => {
    if (initialSection !== 'prebrew') return;
    const frame = requestAnimationFrame(() => {
      prebrewRef.current?.focus({ preventScroll: true });
      prebrewRef.current?.scrollIntoView({ block: 'start' });
    });
    return () => cancelAnimationFrame(frame);
  }, [initialSection]);
  const [showPlot, setShowPlot] = useState(d.ideal_flow_enabled);
  const set = (k, v) => setD(s => ({ ...s, [k]: v }));
  const prebrewEnabled = d.prebrew_preference.enabled === true;
  const prebrewController = d.prebrew_preference.controller === 'shotdeck'
    ? 'shotdeck' : 'lamarzocco';
  const shotdeckPrebrewSupported = d.shotdeck_prebrew.supported === true;
  const shotdeckPrebrewSelectionUnavailable = prebrewEnabled
    && prebrewController === 'shotdeck'
    && !shotdeckPrebrewSupported;
  const online = lmOnline(app);
  const steamLevel = online && steamBoilerUsesLevel(app.data.lm.snapshot.steam_boiler);
  const acc = (id) => ({ open: open === id, onToggle: () => setOpen(open === id ? null : id) });

  const maxTime = Math.max(36, Number(profilesBrewByTime(d) ? d.target_stop_time_s : d.target_time_max_s) + 6);
  const setCurve = pts => set('ideal_flow_profile', pts);
  const addPoint = () => {
    const pts = [...d.ideal_flow_profile];
    const lastT = pts.length ? pts[pts.length - 1].time_s : 0;
    pts.push({ time_s: Math.min(maxTime, lastT + 6), flow_g_s: 1.5, gradient_g_s2: 0 });
    setCurve(pts);
  };
  const delPoint = i => setCurve(d.ideal_flow_profile.filter((_, j) => j !== i));
  const editCell = (i, key, n) => setCurve(d.ideal_flow_profile.map((p, j) => j === i ? { ...p, [key]: n } : p));

  return (
    <div className="sd-body sd-scroll">
      {backLabel && <Btn className="sd-profile-machine-back" disabled={saving} onClick={onBack}><Icon name="back" size={18} />{backLabel}</Btn>}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
        {!backLabel && <button className="sd-iconbtn" aria-label={tr('cancel')} disabled={saving} onClick={onBack}><Icon name="back" size={20} /></button>}
        <span className="sd-serif" style={{ fontStyle: 'italic', fontSize: 22 }}>{d.name || tr('edit')}</span>
        <Pill variant={profilesBrewByTime(d) ? 'good' : ''} dot>{profilesBrewModeLabel(d)}</Pill>
        <span className="sd-dot" style={{ background: d.color, width: 14, height: 14, marginLeft: 'auto' }} />
        {!d.archived && !['DR', 'MR', 'LR'].includes(d.name) && app.data.profiles.filter(p => !p.archived).length > 1 &&
          <button className="sd-iconbtn" onClick={async () => { if (await app.deleteProfile(d.index)) onBack(); }}><Icon name="trash" size={18} color="var(--danger-text)" /></button>}
      </div>

      <Card flush apiNote={`PATCH /profiles/${d.index}`}>
        <div style={{ padding: '4px 16px' }}><ApiChip>{`PATCH /profiles/${d.index}`}</ApiChip></div>

        <div style={{ padding: '0 16px' }}>
          <Accordion title={tr('preparation_defaults')} {...acc('coffee')}>
            <PreparationFields value={d.coffee_defaults || {}} onChange={v=>set('coffee_defaults',v)} beans={app.data.beans} grinders={app.data.grinders}/>
            <p className="sd-fieldhelp">{tr('prep_saved_hint')} {tr('bean_roast_hint')}</p>
            {(app.data.beans || []).find(b=>b.id===d.coffee_defaults?.bean_id)?.roast_type && <Btn variant="ghost" onClick={()=>set('roast',app.data.beans.find(b=>b.id===d.coffee_defaults.bean_id).roast_type)}>{tr('use_bean_roast')}</Btn>}
          </Accordion>
          <Accordion title={tr('basics')} sub={`${tr('name')} · ${tr('roast')} · ${tr('drip_intel')}`} {...acc('basics')}>
            <div style={{ marginBottom: 14 }}>
              <div className="sd-fieldlabel">{tr('name')}</div>
              <input className="sd-input" maxLength={8} value={d.name} onChange={e => set('name', e.target.value)} />
              <div className="sd-fieldhelp">{tr('profile_name_limit')}</div>
            </div>
            <div style={{ marginBottom: 14 }}>
              <div className="sd-fieldlabel">{tr('profile_comment')}</div>
              <textarea className="sd-input" maxLength={120} rows={3} value={d.comment || ''}
                placeholder={tr('profile_comment_hint')} onChange={e => set('comment', e.target.value)}
                style={{ height: 76, resize: 'vertical' }} />
              <div className="sd-fieldhelp">{tr('profile_comment_limit')}</div>
            </div>
            <div style={{ marginBottom: 14 }}>
              <div className="sd-fieldlabel">{tr('color')}</div>
              <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                {['#b16625', '#7ba368', '#9f6ed1', '#4f8fba', '#c85f5f', '#6b7280'].map(color => (
                  <button key={color} className="sd-iconbtn" onClick={() => set('color', color)} style={{ borderColor: d.color === color ? 'var(--primary)' : 'var(--border)' }}>
                    <span className="sd-dot" style={{ background: color, boxShadow: 'none' }} />
                  </button>
                ))}
              </div>
              <input className="sd-input mono" value={d.color || ''} onChange={e => set('color', e.target.value)} />
            </div>
            <div className="sd-row"><div className="sd-rowlabel">{tr('roast')}</div>
              <Select value={d.roast} onChange={v => set('roast', v)} style={{ width: 130 }}
                options={app.data.roast_types.map(r => ({ value: r.name, label: r.name }))} /></div>
            <div style={{ marginTop: 14 }}>
              <div className="sd-fieldlabel">{tr('drip_intel')}</div>
              <Segmented value={d.intelligence_mode} onChange={v => set('intelligence_mode', v)}
                options={[{ value: 'nominal', label: tr('nominal') }, { value: 'explore', label: tr('explore') }]} />
            </div>
          </Accordion>

          <Accordion title={tr('timing')} sub={`${profilesBrewModeLabel(d)} · ${profilesTimingText(d)}`} {...acc('timing')}>
            <div style={{ marginBottom: 14 }}>
              <div className="sd-fieldlabel">{tr('stop_by')}</div>
              <Segmented value={profilesBrewByTime(d) ? 'time' : 'weight'} onChange={v => set('brew_control_mode', v)}
                options={[{ value: 'weight', label: tr('weight') }, { value: 'time', label: tr('time') }]} />
            </div>
            {profilesBrewByTime(d) ? (
              <div className="sd-row"><div className="sd-rowlabel">{tr('target_time')}</div>
                <Stepper width={146} value={d.target_stop_time_s || d.target_time_max_s || 30} onChange={v => set('target_stop_time_s', v)} min={1} max={120} /></div>
            ) : (
              <div className="sd-row"><div className="sd-rowlabel">{tr('weight_g')}</div>
                <Stepper width={146} value={d.target_weight_g} onChange={v => set('target_weight_g', v)} min={0} max={100} step={0.5} /></div>
            )}
            {!profilesBrewByTime(d) && <>
              <div className="sd-row"><div className="sd-rowlabel">{tr('time_min')}</div>
                <Stepper value={d.target_time_min_s} onChange={v => set('target_time_min_s', Math.min(v, d.target_time_max_s - 1))} min={5} max={120} /></div>
              <div className="sd-row"><div className="sd-rowlabel">{tr('time_max')}</div>
                <Stepper value={d.target_time_max_s} onChange={v => set('target_time_max_s', Math.max(v, d.target_time_min_s + 1))} min={6} max={120} /></div>
            </>}
            <div style={{ marginTop: 14 }}>
              <div className="sd-fieldlabel">{tr('smoothing')}</div>
              <Segmented value={String(d.live_flow_smoothing_samples)} onChange={v => set('live_flow_smoothing_samples', +v)}
                options={[1, 3, 5, 10, 20].map(n => ({ value: String(n), label: n === 1 ? tr('off') : String(n) }))} />
            </div>
          </Accordion>

          <Accordion title={tr('advanced')} sub={`${tr('temp_override')} · ${tr('prebrew_mode')}`} {...acc('advanced')}>
            <Row label={tr('temp_override')}>
              <Switch on={d.temperature_targets_enabled} onChange={v => set('temperature_targets_enabled', v)} />
            </Row>
            {d.temperature_targets_enabled && (
              <div style={{ padding: '12px 0', opacity: online ? 1 : .5 }}>
                <div className="sd-row"><div className="sd-rowlabel">{tr('coffee_c')}</div>
                  <Stepper value={d.coffee_target_temperature_c || 93} onChange={v => set('coffee_target_temperature_c', v)} min={80} max={104} /></div>
                {steamLevel ? (
                  <div style={{ marginTop: 14 }}><div className="sd-fieldlabel">{tr('steam_level')}</div>
                    <Segmented value={String(d.steam_target_level ?? 1)} onChange={v => set('steam_target_level', +v)}
                      options={[0, 1, 2, 3].map(n => ({ value: String(n), label: 'L' + n }))} /></div>
                ) : (
                  <div className="sd-row"><div className="sd-rowlabel">{tr('steam_c')}</div>
                    <Stepper value={d.steam_target_temperature_c || 123} onChange={v => set('steam_target_temperature_c', v)} min={100} max={140} /></div>
                )}
                {!online && <div className="sd-rowsub" style={{ marginTop: 8 }}>{tr('lm_off')} — {tr('unavailable')}</div>}
              </div>
            )}
            <div ref={prebrewRef} tabIndex={-1} aria-label={tr('prebrew_mode')} className="sd-profile-prebrew-destination">
              <ProfilePrebrewFields draft={d} onChange={setD} />
            </div>
          </Accordion>

          <Accordion title={tr('ideal_flow')} sub={d.ideal_flow_enabled ? tr('enable') : tr('off')} {...acc('ideal')}>
            <Row label={tr('enable')}><Switch on={d.ideal_flow_enabled} onChange={v => { set('ideal_flow_enabled', v); if (v && !d.ideal_flow_profile.length) setCurve([...IDEAL_ESPR]); }} /></Row>
            {d.ideal_flow_enabled && <>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', margin: '12px 0 8px' }}>
                <span className="sd-micro">{tr('drag_hint')}</span>
                <Btn variant="ghost" className="sm" onClick={() => setShowPlot(!showPlot)}>{showPlot ? tr('hide_plot') : tr('show_plot')}</Btn>
              </div>
              {showPlot && (
                <div style={{ background: 'var(--inset)', borderRadius: 'var(--r-md)', padding: 8, marginBottom: 12 }}>
                  <IdealCurveEditor width={326} height={180} points={d.ideal_flow_profile} onChange={setCurve} themeKey={app.theme} maxTime={maxTime} />
                </div>
              )}
              {/* mini-table */}
              <div style={{ border: '1px solid var(--border-soft)', borderRadius: 'var(--r-sm)', overflow: 'hidden' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 40px', background: 'var(--card-2)' }}>
                  {[tr('col_time'), tr('col_flow'), tr('col_grad'), ''].map((h, i) => <div key={i} className="sd-micro" style={{ padding: '8px 10px', fontSize: 9 }}>{h}</div>)}
                </div>
                {d.ideal_flow_profile.map((pt, i) => (
                  <div key={i} style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 40px', borderTop: '1px solid var(--border-soft)', alignItems: 'center' }}>
                    <CurveNumInput style={{ height: 38, border: 'none', borderRadius: 0, background: 'transparent' }} value={pt.time_s} onCommit={n => editCell(i, 'time_s', n)} />
                    <CurveNumInput style={{ height: 38, border: 'none', borderRadius: 0, background: 'transparent' }} value={pt.flow_g_s} onCommit={n => editCell(i, 'flow_g_s', n)} />
                    <CurveNumInput style={{ height: 38, border: 'none', borderRadius: 0, background: 'transparent' }} value={pt.gradient_g_s2} onCommit={n => editCell(i, 'gradient_g_s2', n)} />
                    <button className="sd-iconbtn" style={{ width: 38, height: 38 }} disabled={d.ideal_flow_profile.length <= 2} onClick={() => delPoint(i)}><Icon name="trash" size={15} /></button>
                  </div>
                ))}
              </div>
              <Btn variant="ghost" className="sm block" style={{ marginTop: 10 }} onClick={addPoint}><Icon name="plus" size={16} /> {tr('add_point')}</Btn>
            </>}
          </Accordion>
        </div>

        <div style={{ display: 'flex', gap: 10, padding: 16, borderTop: '1px solid var(--border-soft)' }}>
          <Btn variant="ghost" disabled={saving} onClick={onBack}>{tr('cancel')}</Btn>
          <Btn variant="primary" className="block" disabled={saving || shotdeckPrebrewSelectionUnavailable}
            onClick={async () => { setSaving(true); try { if (await app.saveProfile(d.index, d)) onBack(); } finally { setSaving(false); } }}>{saving ? tr('saving') : tr('save')}</Btn>
        </div>
      </Card>
    </div>
  );
}

// ---- Users card ----
function UsersCard({ app }) {
  const u = app.data.users;
  const [showArch, setShowArch] = useState(false);
  const [editing, setEditing] = useState(null);
  const editingUser = editing ? u.items.find(x => x.id === editing) : null;
  const archived = u.items.filter(x => x.archived);
  return (
    <Card title={tr('users')} flush apiNote="GET /users · POST /users/active" className="sd-profile-panel">
      <div className="sd-profile-top" style={{ padding: '14px 16px 0' }}><ApiChip>GET /users · POST /users/active</ApiChip>
        <div className="sd-fieldlabel">{tr('active_user')}</div>
        <Select value={u.active.id} onChange={id => app.setActiveUser(id)} disabled={app.data.settings.shot_active}
          options={u.items.filter(x => !x.archived).map(x => ({ value: x.id, label: x.name }))} />
      </div>
      <div className="sd-profile-list" style={{ marginTop: 12 }}>
        {u.items.filter(x => !x.archived).map(x => (
          <SwipeActionRow key={x.id} onClick={() => setEditing(x.id)} onDelete={() => app.deleteUser(x.id)}>
            <span className="sd-dot" style={{ background: x.color }} />
            <div style={{ flex: 1 }}><span className="sd-itemname">{x.name}</span>{x.id === u.active.id && <span className="sd-itemsub"> · {tr('active_user')}</span>}</div>
          </SwipeActionRow>
        ))}
      </div>
      <div className="sd-profile-actions" style={{ padding: 12, borderTop: '1px solid var(--border-soft)' }}>
        <Btn variant="ghost" className="block" onClick={() => app.addUser()}><Icon name="plus" size={18} /> {tr('add_user')}</Btn>
        {archived.length > 0 && (
          <button onClick={() => setShowArch(!showArch)} style={{ marginTop: 10, width: '100%', background: 'none', border: 'none', color: 'var(--fg-faint)', cursor: 'pointer', fontSize: 13 }}>{tr('archived')} ({archived.length})</button>
        )}
        {showArch && archived.map(x => (
          <div className="sd-item" key={x.id} style={{ opacity: .65 }}>
            <span className="sd-dot" style={{ background: x.color }} />
            <div style={{ flex: 1 }}><span className="sd-itemname">{x.name}</span></div>
            <Btn variant="ghost" className="sm" onClick={() => app.restoreUser(x.id)}>{tr('restore')}</Btn>
          </div>
        ))}
      </div>
      {editingUser && <UserEditorModal app={app} user={editingUser} onClose={() => setEditing(null)} />}
    </Card>
  );
}

function UserEditorModal({ app, user, onClose }) {
  const [d, setD] = useState({ name: user.name, color: user.color });
  const colors = ['#7ba368', '#b16625', '#9f6ed1', '#4f8fba', '#c85f5f', '#6b7280'];
  return (
    <Modal title={tr('edit')} onClose={onClose}
      footer={<>
        <Btn variant="danger" onClick={async () => { if (await app.deleteUser(user.id)) onClose(); }}>{tr('delete')}</Btn>
        <Btn variant="primary" className="block" onClick={() => { app.saveUser(user.id, d); onClose(); }}>{tr('save')}</Btn>
      </>}>
      <ApiChip>PATCH /users/{user.id} · DELETE /users/{user.id}</ApiChip>
      <div style={{ marginBottom: 14 }}>
        <div className="sd-fieldlabel">{tr('name')}</div>
        <input className="sd-input" maxLength={16} value={d.name} onChange={e => setD({ ...d, name: e.target.value })} />
      </div>
      <div className="sd-fieldlabel">{tr('color')}</div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        {colors.map(color => (
          <button key={color} className="sd-iconbtn" onClick={() => setD({ ...d, color })} style={{ borderColor: d.color === color ? 'var(--primary)' : 'var(--border)' }}>
            <span className="sd-dot" style={{ background: color, boxShadow: 'none' }} />
          </button>
        ))}
      </div>
      <input className="sd-input mono" value={d.color} onChange={e => setD({ ...d, color: e.target.value })} />
    </Modal>
  );
}

// ---- Roasts card ----
function RoastsCard({ app }) {
  const [editing, setEditing] = useState(null);
  const roast = editing ? app.data.roast_types.find(r => r.name === editing) : null;
  return (
    <Card title={tr('roast_types')} helpKey="roasts" onHelp={app.openHelp} flush apiNote="GET /roast-types" className="sd-profile-panel">
      <div style={{ padding: '0 16px' }}><ApiChip>GET /roast-types · PATCH /roast-types/{'{name}'}</ApiChip></div>
      <div className="sd-profile-list">
        {app.data.roast_types.map(r => (
          <SwipeActionRow key={r.name}
            onClick={() => setEditing(r.name)}
            onDelete={!r.protected ? () => app.deleteRoast(r.name) : null}
            itemStyle={{ alignItems: 'center' }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span className="sd-itemname">{r.name}</span>
                {r.protected && <Tag>{tr('protected')}</Tag>}
              </div>
              <div className="sd-itemsub">{tr('min_flow')} {r.min_flow_rate} · {tr('max_flow')} {r.max_flow_rate} g/s</div>
            </div>
            {/* Flow window drawn on a 0–4 g/s scale */}
            <div className="sd-glass sd-roast-range" aria-hidden="true">
              <i style={{ left: Math.max(0, Math.min(100, Number(r.min_flow_rate) / 4 * 100)) + '%', width: Math.max(2, Math.min(100, (Number(r.max_flow_rate) - Number(r.min_flow_rate)) / 4 * 100)) + '%' }} />
            </div>
          </SwipeActionRow>
        ))}
      </div>
      <div className="sd-profile-actions" style={{ padding: 12, borderTop: '1px solid var(--border-soft)' }}>
        <Btn variant="ghost" className="block" onClick={() => app.addRoast()}><Icon name="plus" size={18} /> {tr('add_roast')}</Btn>
      </div>
      {roast && <RoastEditorModal app={app} roast={roast} onClose={() => setEditing(null)} />}
    </Card>
  );
}

function RoastEditorModal({ app, roast, onClose }) {
  const [d, setD] = useState({ name: roast.name, min_flow_rate: roast.min_flow_rate, max_flow_rate: roast.max_flow_rate });
  return (
    <Modal title={tr('roast_types')} onClose={onClose}
      footer={<>
        {!roast.protected && <Btn variant="danger" onClick={() => { app.deleteRoast(roast.name); onClose(); }}>{tr('delete')}</Btn>}
        <Btn variant="primary" className="block" onClick={() => { app.saveRoast(roast.name, d); onClose(); }}>{tr('save')}</Btn>
      </>}>
      <ApiChip>PATCH /roast-types/{roast.name}</ApiChip>
      <div style={{ marginBottom: 14 }}>
        <div className="sd-fieldlabel">{tr('name')}</div>
        <input className="sd-input mono" value={d.name} disabled={roast.protected} onChange={e => setD({ ...d, name: e.target.value })} />
      </div>
      <Row label={tr('min_flow')}><Stepper value={d.min_flow_rate} min={0} max={8} step={0.1} onChange={v => setD({ ...d, min_flow_rate: v })} /></Row>
      <Row label={tr('max_flow')}><Stepper value={d.max_flow_rate} min={0} max={8} step={0.1} onChange={v => setD({ ...d, max_flow_rate: v })} /></Row>
    </Modal>
  );
}

Object.assign(window, { ProfilesScreen, ProfileEditor, ProfilePrebrewFields, UsersCard, UserEditorModal, RoastsCard, RoastEditorModal, Accordion });
