#!/usr/bin/env python3
"""Bridge between the updater CLI and Shotdeck's file-based update prompt UI."""

from __future__ import annotations

import argparse
import hashlib
from datetime import datetime, timezone
import json
import os
import stat
import subprocess
import sys
from uuid import uuid4
from pathlib import Path


DEFAULT_CONFIG_PATH = Path("/etc/shotdeck/updater.json")
CURRENT_UPDATER_BIN = Path("/opt/shotdeck/updater-current/bin/shotdeck-updater")
LEGACY_UPDATER_BIN = Path("/opt/shotdeck/updater-venv/bin/shotdeck-updater")
HARDWARE_PROFILE = Path("/etc/shotdeck/hardware-profile.json")
LEGACY_PROFILE_ID = "rev1_2_3_5f_bbw"
REV15_PROFILE_ID = "rev15_3_5f"
DATA_ROOT = Path(os.environ.get("SHOTDECK_DATA_DIR", "/var/lib/shotdeck"))
STATUS_PATH = Path(os.environ.get("SHOTDECK_UPDATE_STATUS_FILE", str(DATA_ROOT / "update-status.json")))
RESPONSE_PATH = Path(os.environ.get("SHOTDECK_UPDATE_RESPONSE_FILE", str(DATA_ROOT / "update-response.json")))
WEB_STATE_PATH = Path(os.environ.get("SHOTDECK_UPDATE_WEB_STATE_FILE", str(DATA_ROOT / "update-web-state.json")))
# Integrity verification reads the retained runtime and recovery release. It is
# disk work, not a network probe, and can exceed 30 seconds on customer SD cards.
TRUST_CHECK_TIMEOUT_SECONDS = 180


def _installed_profile_id() -> str:
    """Resolve identity even when the independent updater runtime is broken."""
    try:
        parent_fd = os.open(HARDWARE_PROFILE.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except FileNotFoundError:
        return LEGACY_PROFILE_ID
    except OSError as exc:
        raise SystemExit(f"Cannot open protected hardware identity: {exc}") from exc
    try:
        parent = os.fstat(parent_fd)
        if not stat.S_ISDIR(parent.st_mode) or parent.st_uid != 0 or parent.st_mode & 0o022:
            raise SystemExit("Hardware identity directory must be protected and root-owned")
        try:
            fd = os.open(HARDWARE_PROFILE.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK,
                         dir_fd=parent_fd)
        except FileNotFoundError:
            return LEGACY_PROFILE_ID
        with os.fdopen(fd, "r", encoding="utf-8") as stream:
            metadata = os.fstat(stream.fileno())
            if (not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != 0
                    or metadata.st_mode & 0o022 or metadata.st_size > 16384):
                raise SystemExit("Hardware identity must be a protected root-owned regular file")
            payload = json.load(stream)
    except (OSError, ValueError) as exc:
        raise SystemExit(f"Cannot read protected hardware identity: {exc}") from exc
    finally:
        os.close(parent_fd)
    if (not isinstance(payload, dict) or type(payload.get("schema_version")) is not int
            or payload["schema_version"] != 1
            or not isinstance(payload.get("profile_id"), str)
            or payload.get("profile_id") not in {LEGACY_PROFILE_ID, REV15_PROFILE_ID}):
        raise SystemExit("Unknown installed hardware identity; updater execution refused")
    return payload["profile_id"]


def select_updater_binary() -> Path:
    trust = DATA_ROOT / 'signing/updates'
    indicators = (trust, trust.parent / 'update-enrolled.json',
                  trust.parent / 'licence/enrolled.json', trust.parent / 'licence/floor.json')
    if any(path.exists() or path.is_symlink() for path in indicators):
        def protected_json(path):
            if path.is_symlink() or path.parent.is_symlink():
                raise ValueError('Aliased signing state')
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, 'r') as stream:
                info = os.fstat(stream.fileno())
                if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022 or info.st_size > 1024 * 1024:
                    raise ValueError('Unprotected signing state')
                return json.load(stream)
        try:
            pointer = protected_json(trust / 'active.json')
            identity = pointer['generation_id']
            if len(identity) != 64 or any(c not in '0123456789abcdef' for c in identity):
                raise ValueError('Invalid signing generation')
            record = protected_json(trust / 'generations' / identity / 'generation.json')
            if hashlib.sha256(json.dumps(record, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()).hexdigest() != identity:
                raise ValueError('Changed signing generation')
            runtime = Path(record['runtime'])
            if runtime.parent != CURRENT_UPDATER_BIN.parents[2] / 'updater-runtimes' or runtime.is_symlink():
                raise ValueError('Invalid signing runtime path')
            python = runtime / 'bin/python'
            binary = runtime / 'bin/shotdeck-updater'
            if not all(p.is_file() and os.access(p, os.X_OK) for p in (python, binary)):
                raise ValueError('Missing signing runtime')
            check = ('from pathlib import Path; from shotdeck_security.updates import UpdateStore; '
                f'assert UpdateStore(Path({str(trust.parent)!r}), Path({str(CURRENT_UPDATER_BIN.parents[2])!r}), '
                f'Path({str(DATA_ROOT / "updater/manifest-security-state.json")!r})).active()')
            subprocess.run([str(python), '-I', '-c', check], check=True, capture_output=True,
                           timeout=TRUST_CHECK_TIMEOUT_SECONDS)
            return binary
        except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as exc:
            raise SystemExit('Committed signing runtime needs repair; legacy fallback refused') from exc
    if _installed_profile_id() != REV15_PROFILE_ID:
        return CURRENT_UPDATER_BIN if CURRENT_UPDATER_BIN.is_file() else LEGACY_UPDATER_BIN
    python = CURRENT_UPDATER_BIN.with_name("python")
    if not all(path.is_file() and os.access(path, os.X_OK) for path in (CURRENT_UPDATER_BIN, python)):
        raise SystemExit("REV15 requires its current hardware-aware updater; legacy fallback refused")
    check = (
        "from packaging.version import Version; "
        "from shotdeck_updater import __version__; "
        "from shotdeck_updater.hardware import HARDWARE_GUARD_VERSION, installed_profile, assert_hardware_compatible; "
        "assert Version(__version__) >= Version('0.2.3'); "
        "assert type(HARDWARE_GUARD_VERSION) is int and HARDWARE_GUARD_VERSION == 1; "
        "assert callable(installed_profile) and callable(assert_hardware_compatible)"
    )
    try:
        subprocess.run([str(python), "-I", "-c", check], check=True,
                       capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError) as exc:
        raise SystemExit("REV15 updater is unavailable or lacks hardware protection; legacy fallback refused") from exc
    return CURRENT_UPDATER_BIN


def _load_json(path: Path) -> dict[str, object] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        temp_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp_path, path)
    finally:
        try:
            temp_path.unlink()
        except FileNotFoundError:
            pass


def _update_web_state(**changes: object) -> None:
    payload = _load_json(WEB_STATE_PATH) or {}
    payload.update(changes)
    payload["updated_at"] = datetime.now(timezone.utc).isoformat()
    _write_json(WEB_STATE_PATH, payload)


def _update_feedback(state: str, version: str) -> None:
    """Also support installations performed by an older standalone updater."""
    path = WEB_STATE_PATH.with_name("update-feedback.json")
    try:
        payload = _load_json(path) or {}
        if state != "installing" and payload.get("version") not in {None, version}:
            # The CLI has released its updater lock. A different installation
            # may already have started; its feedback must remain authoritative.
            return
        if state == "installing" or payload.get("version") != version or not payload.get("id"):
            payload = {"id": uuid4().hex, "version": version,
                       "started_at": datetime.now(timezone.utc).isoformat()}
        payload["state"] = state
        if state == "installed":
            payload.setdefault("completed_at", datetime.now(timezone.utc).isoformat())
        _write_json(path, payload)
    except OSError:
        # Display feedback must not turn a completed install into a failure.
        print("Could not persist update display feedback", file=sys.stderr)


def _remove_if_exists(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        return


def clear_prompt_files() -> None:
    _remove_if_exists(STATUS_PATH)
    _remove_if_exists(RESPONSE_PATH)


def _run_updater(
    config_path: Path,
    command: str,
    *,
    expected_version: str = "",
    expected_artifact_sha256: str = "",
    expected_manifest_sha256: str = "",
) -> dict[str, object]:
    binary = select_updater_binary()
    # Match the capability probe's isolated imports when actually running.
    # Console entry points otherwise honor inherited PYTHONPATH/PYTHONHOME.
    committed = binary.parent.parent.parent == CURRENT_UPDATER_BIN.parents[2] / "updater-runtimes"
    prefix = ([str(binary.with_name("python")), "-I", "-m", "shotdeck_updater.cli"]
              if committed or _installed_profile_id() == REV15_PROFILE_ID else [str(binary)])
    command_args = [*prefix, "--config", str(config_path), command]
    if command == "apply":
        command_args.extend(
            [
                "--expected-version", expected_version,
                "--expected-artifact-sha256", expected_artifact_sha256,
                "--expected-manifest-sha256", expected_manifest_sha256,
            ]
        )
    try:
        completed = subprocess.run(
            command_args,
            check=False,
            capture_output=True,
            text=True,
            **({"timeout": TRUST_CHECK_TIMEOUT_SECONDS} if command == "check" else {}),
        )
    except subprocess.TimeoutExpired as exc:
        raise SystemExit(f"Signed update check exceeded {TRUST_CHECK_TIMEOUT_SECONDS} seconds; no install started") from exc
    if completed.returncode != 0:
        stderr = completed.stderr.strip()
        raise SystemExit(stderr or f"shotdeck-updater {command} failed with exit {completed.returncode}")
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"shotdeck-updater {command} returned invalid JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise SystemExit(f"shotdeck-updater {command} returned an unexpected JSON value")
    return payload


def command_install_available(config_path: Path, *, expected_version: str = "") -> int:
    """Use the installed verifier, binding apply to the exact signed offer.

    This also works with the immutable 0.2.5 runtime on migrated 0.2.7 devices.
    It does not change configuration, signing state or Auto-Update preferences.
    Apply retains the updater/brew locks, targeting and all integrity checks.
    Never impose a wrapper deadline while activation/rollback is in progress.
    """
    offer = _run_updater(config_path, "check")
    if not offer.get("applicable"):
        print(json.dumps(offer))
        return 0
    target = str(offer.get("manifest_version") or "")
    if expected_version and target != expected_version:
        raise SystemExit("Available update differs from the requested version; check again")
    artifact = str(offer.get("artifact_sha256") or "")
    manifest = str(offer.get("manifest_sha256") or "")
    if not target or any(len(value) != 64 or any(c not in "0123456789abcdef" for c in value)
                         for value in (artifact, manifest)):
        raise SystemExit("Updater did not return a complete signed offer")
    result = _run_updater(config_path, "apply", expected_version=target,
                          expected_artifact_sha256=artifact, expected_manifest_sha256=manifest)
    if result.get("installed_version") != target:
        raise SystemExit("Updater did not confirm the requested installed version")
    clear_prompt_files()
    _update_web_state(state="installed", busy=False, update_available=False,
                      current_version=target, target_version=target,
                      completed_at=datetime.now(timezone.utc).isoformat())
    print(json.dumps(result))
    return 0


def _status_payload_from_check(check_payload: dict[str, object]) -> dict[str, object] | None:
    if not bool(check_payload.get("applicable")):
        return None
    version = str(check_payload.get("manifest_version") or "").strip()
    channel = str(check_payload.get("channel") or "stable").strip().lower()
    artifact_sha256 = str(check_payload.get("artifact_sha256") or "").strip().lower()
    manifest_sha256 = str(check_payload.get("manifest_sha256") or "").strip().lower()
    if (
        not version
        or len(artifact_sha256) != 64
        or len(manifest_sha256) != 64
    ):
        return None
    key = f"{channel}:{version}:{artifact_sha256}:{manifest_sha256}"
    return {
        "update_available": True,
        "target_version": version,
        "channel": channel,
        "summary": f"Update {version} available. Install now?",
        "key": key,
        "artifact_sha256": artifact_sha256,
        "manifest_sha256": manifest_sha256,
    }


def command_check(config_path: Path) -> int:
    check_payload = _run_updater(config_path, "check")
    status_payload = _status_payload_from_check(check_payload)
    checked_at = datetime.now(timezone.utc).isoformat()
    if status_payload is None:
        clear_prompt_files()
        reason = str(check_payload.get("reason") or "").strip()
        up_to_date = "already runs this version" in reason.lower()
        _update_web_state(
            state="up_to_date" if up_to_date else "unavailable",
            target_version=str(check_payload.get("manifest_version") or ""),
            channel=str(check_payload.get("channel") or "stable"),
            message="Software is up to date." if up_to_date else "No update is available for this device.",
            checked_at=checked_at,
            busy=False,
            update_available=False,
            error="",
        )
        return 0
    prior_status = _load_json(STATUS_PATH)
    _write_json(STATUS_PATH, status_payload)
    status_key = str(status_payload["key"])
    if prior_status is not None and str(prior_status.get("key") or "") != status_key:
        _remove_if_exists(RESPONSE_PATH)
    _update_web_state(
        state="available",
        target_version=str(status_payload["target_version"]),
        channel=str(status_payload["channel"]),
        message=f"Version {status_payload['target_version']} is available.",
        checked_at=checked_at,
        busy=False,
        update_available=True,
        error="",
    )
    return 0


def command_process_response(config_path: Path) -> int:
    status_payload = _load_json(STATUS_PATH)
    response_payload = _load_json(RESPONSE_PATH)
    if not status_payload or not response_payload:
        return 0

    status_key = str(status_payload.get("key") or "").strip()
    response_key = str(response_payload.get("key") or "").strip()
    if not status_key or response_key != status_key:
        _remove_if_exists(RESPONSE_PATH)
        return 0

    action = str(response_payload.get("action") or "").strip().lower()
    if action == "skip":
        target_version = str(status_payload.get("target_version") or "").strip()
        clear_prompt_files()
        _update_web_state(
            state="unavailable",
            target_version=target_version,
            channel=str(status_payload.get("channel") or "stable"),
            message=f"Update {target_version} was skipped.",
            busy=False,
            update_available=False,
            error="",
        )
        return 0
    if action != "install":
        _remove_if_exists(RESPONSE_PATH)
        return 0

    _remove_if_exists(RESPONSE_PATH)
    target_version = str(status_payload.get("target_version") or "").strip()
    _update_feedback("installing", target_version)
    _update_web_state(
        state="installing",
        target_version=target_version,
        channel=str(status_payload.get("channel") or "stable"),
        message=f"Installing version {target_version}. The page may disconnect while Shotdeck restarts.",
        busy=True,
        update_available=False,
        error="",
        started_at=datetime.now(timezone.utc).isoformat(),
    )
    try:
        result = _run_updater(
            config_path,
            "apply",
            expected_version=target_version,
            expected_artifact_sha256=str(status_payload.get("artifact_sha256") or ""),
            expected_manifest_sha256=str(status_payload.get("manifest_sha256") or ""),
        )
        if result.get("installed_version") != target_version:
            raise SystemExit("Updater did not confirm the requested installed version")
    except (SystemExit, OSError):
        _update_feedback("error", target_version)
        _update_web_state(
            state="error",
            message="The update failed and Shotdeck kept the previous version.",
            busy=False,
            error="The updater service failed. Check diagnostics for details.",
            update_available=True,
        )
        raise
    _update_feedback("installed", target_version)
    _remove_if_exists(STATUS_PATH)
    _update_web_state(
        state="installed",
        current_version=target_version,
        target_version=target_version,
        message=f"Updated to version {target_version}.",
        busy=False,
        update_available=False,
        error="",
        completed_at=datetime.now(timezone.utc).isoformat(),
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG_PATH)
    parser.add_argument("command", choices=("check", "process-response", "clear", "runtime-path", "unattended", "install-now", "auto-install"))
    parser.add_argument("--expected-version", default="")
    args = parser.parse_args(argv)

    if args.command in {"install-now", "auto-install"}:
        if args.command == "install-now" and not args.expected_version:
            parser.error("install-now requires --expected-version")
        if args.command == "auto-install" and (
            os.environ.get("UPDATES_ENABLED", "yes").lower() not in {"1", "true", "yes", "on"}
            or os.environ.get("AUTO_UPDATE", "no").lower() not in {"1", "true", "yes", "on"}
        ):
            raise SystemExit("Automatic installation is disabled")
        if args.command == "auto-install":
            config = json.loads(args.config.read_text())
            # Preserve an operator's explicit check-only policy and custom
            # download-only service. Only the official former prompt setting
            # needs bridging to the user-visible Auto-Update switch.
            official = str(config.get("manifest_url", "")) in {
                f"https://mecproject.github.io/espresso-shotdeck/metadata/shotdeck-{channel}{suffix}.json"
                for channel in ("stable", "beta") for suffix in ("", "-v2", "-v3")
            }
            if config.get("policy") == "check-only" or (
                config.get("policy") == "download-only" and not official
            ):
                print(json.dumps(_run_updater(args.config, "unattended")))
                return 0
        return command_install_available(args.config, expected_version=args.expected_version)

    if args.command == "runtime-path":
        print(select_updater_binary())
        return 0
    if args.command == "unattended":
        print(json.dumps(_run_updater(args.config, "unattended")))
        return 0
    if args.command == "clear":
        clear_prompt_files()
        return 0
    if args.command == "check":
        return command_check(args.config)
    return command_process_response(args.config)


if __name__ == "__main__":
    raise SystemExit(main())
