#!/usr/bin/env python3
"""Return success when the updater has enough network connectivity to run.

The check is intentionally lightweight and dependency-free:

- read `/etc/shotdeck/updater.json`
- collect `manifest_url` and optional `next_manifest_url` for legacy devices
- resolve committed new-key feeds through the retained protected runtime
- issue a short HEAD request to each URL until one succeeds

This allows the systemd service to skip unattended runs when the device is
offline or the configured update host is unavailable.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import urllib.request
from pathlib import Path

DATA_ROOT = Path(os.environ.get("SHOTDECK_DATA_DIR", "/var/lib/shotdeck"))


def _committed_urls(config_path: Path) -> list[str] | None:
    root = DATA_ROOT / 'signing'
    indicators = (root / 'updates', root / 'update-enrolled.json',
                  root / 'licence/enrolled.json', root / 'licence/floor.json')
    if not any(path.exists() or path.is_symlink() for path in indicators):
        return None
    # System Python need not have cryptography/packaging. Use the same protected
    # selector as the update service, then let that runtime verify the complete
    # committed trees and resolve effective config without fetching or writing.
    from prompted_update_flow import select_updater_binary, TRUST_CHECK_TIMEOUT_SECONDS
    binary = select_updater_binary()
    code = ('import json,sys; from pathlib import Path; '
            'from shotdeck_updater.config import UpdaterConfig; '
            'from shotdeck_updater.client import UpdaterClient; '
            'client=UpdaterClient(UpdaterConfig.from_file(Path(sys.argv[1]))); '
            'assert client.trust_id; print(json.dumps(client.config.manifest_urls))')
    result = subprocess.run([str(binary.with_name('python')), '-I', '-c', code, str(config_path)],
                            check=True, capture_output=True, text=True, timeout=TRUST_CHECK_TIMEOUT_SECONDS)
    urls = json.loads(result.stdout)
    if not isinstance(urls, list) or len(urls) != 1 or not isinstance(urls[0], str):
        raise ValueError('Invalid committed feed resolution')
    return urls


def _candidate_urls(config_path: Path) -> list[str]:
    committed = _committed_urls(config_path)
    if committed is not None:
        return committed
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    urls: list[str] = []
    for key in ("manifest_url", "next_manifest_url"):
        value = str(payload.get(key, "")).strip()
        if value and value not in urls:
            urls.append(value)
    return urls


def _url_is_reachable(url: str, *, timeout: int = 8) -> bool:
    request = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "shotdeck-updater/0.1"})
    try:
        with urllib.request.urlopen(request, timeout=timeout):
            return True
    except Exception:
        return False


def main(argv: list[str] | None = None) -> int:
    argv = argv or sys.argv[1:]
    config_path = Path(argv[0]) if argv else Path("/etc/shotdeck/updater.json")
    if not config_path.exists():
        return 1
    try:
        urls = _candidate_urls(config_path)
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError, SystemExit):
        return 1
    for url in urls:
        if _url_is_reachable(url):
            return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
