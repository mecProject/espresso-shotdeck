// ============================================================
// Shotdeck — core UI components (theme-driven via CSS classes)
// ============================================================
const { useState, useEffect, useRef, useCallback, useMemo } = React;

// ---- Icon set (inline SVG, stroke = currentColor) ----
const ICONS = {
  display: 'M3 4h18v13H3zM8 21h8M12 17v4',
  scale: 'M5 4h14v16H5zM8 8h8v5H8zM10 16h4',
  storage: 'M5 3h10l4 4v14H5zM8 3v6h8M8 15h8v6H8z',
  help: 'M9 9a3 3 0 1 1 4 2.8c-.8.4-1 1-1 1.7M12 17h.01',
  wifi: 'M2 8.5a15 15 0 0 1 20 0M5 12a10 10 0 0 1 14 0M8.5 15.5a5 5 0 0 1 7 0M12 19h.01',
  support: 'M12 3a9 9 0 0 0-9 9v4a2 2 0 0 0 2 2h1v-6H5a7 7 0 0 1 14 0h-1v6h1a2 2 0 0 0 2-2v-4a9 9 0 0 0-9-9M9 21h6',
  back: 'M15 18l-6-6 6-6',
  chevron: 'M9 6l6 6-6 6',
  plus: 'M12 5v14M5 12h14',
  trash: 'M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13',
  close: 'M6 6l12 12M18 6L6 18',
  brew: 'M5 9h11v4a5 5 0 0 1-5 5H10a5 5 0 0 1-5-5zM16 10h2a2 2 0 0 1 0 4h-2M7 4v2M10 3v3M13 4v2',
  profiles: 'M4 6h16M4 12h16M4 18h10',
  shots: 'M4 19V5M4 19h16M8 16l3-5 3 3 4-7',
  machine: 'M6 3h12v6H6zM8 9v3a4 4 0 0 0 8 0V9M9 21h6M12 16v5',
  settings: 'M12 9a3 3 0 1 0 0 6 3 3 0 0 0 0-6M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.4-2.3 1a7 7 0 0 0-1.7-1l-.4-2.6H10.5l-.4 2.6a7 7 0 0 0-1.7 1l-2.3-1-2 3.4 2 1.5a7 7 0 0 0 0 2l-2 1.5 2 3.4 2.3-1a7 7 0 0 0 1.7 1l.4 2.6h3.4l.4-2.6a7 7 0 0 0 1.7-1l2.3 1 2-3.4-2-1.5c.06-.3.1-.66.1-1z',
  check: 'M4 12l5 5L20 6',
  star: 'M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z',
  clock: 'M12 7v5l3 2M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18',
  drop: 'M12 3s6 6.5 6 11a6 6 0 0 1-12 0c0-4.5 6-11 6-11z',
  upload: 'M12 16V4M7 9l5-5 5 5M5 20h14',
  download: 'M12 3v12M8 11l4 4 4-4M5 15v5h14v-5',
  qr: 'M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h2v2h-2zM18 14h2v2h-2zM14 18h2v2h-2zM18 18h2v2h-2z',
  power: 'M12 4v8M7 6a8 8 0 1 0 10 0',
  calendar: 'M4 6h16v15H4zM4 9h16M8 3v4M16 3v4',
};
function Icon({ name, size = 20, color = 'currentColor', fill = 'none', sw = 1.7, style }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={color}
      strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" style={style}>
      <path d={ICONS[name] || ''} />
    </svg>
  );
}

// ---- Pill ----
function Pill({ children, variant = '', dot = true }) {
  return <span className={'sd-pill ' + variant}>{dot && <span className="dot" />}{children}</span>;
}

// ---- Card with optional help ----
function Card({ title, helpKey, onHelp, children, flush, right, className = '', apiNote, headingLevel }) {
  return (
    <div className={'sd-card ' + (flush ? 'flush ' : '') + className}>
      {(title || right) && (
        <div className="sd-cardhead" style={flush ? { padding: '14px 16px 0' } : null}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {title && <span className="sd-cardtitle" role={headingLevel ? 'heading' : undefined} aria-level={headingLevel}>{title}</span>}
            {helpKey && <button className="sd-helpbtn" aria-label={title ? `${title}: ${tr('help')}` : tr('help')} onClick={() => onHelp && onHelp(helpKey)}>?</button>}
          </div>
          {right}
        </div>
      )}
      {children}
    </div>
  );
}

// ---- Button ----
function Btn({ variant = 'ghost', children, className = '', ...rest }) {
  return <button className={`sd-btn ${variant} ${className}`} {...rest}>{children}</button>;
}

// ---- Switch ----
function Switch({ on, onChange, disabled, ...rest }) {
  return (
    <button type="button" className={'sd-switch' + (on ? ' on' : '') + (disabled ? ' disabled' : '')}
      onClick={() => !disabled && onChange(!on)} role="switch" aria-checked={on}
      disabled={disabled} {...rest} />
  );
}

// ---- Field row (label + control) ----
function Row({ label, sub, children }) {
  const descriptionId = React.useId();
  const controls = React.Children.map(children, child => React.isValidElement(child)
    && (child.type === Switch || child.type === Select || ['input', 'select'].includes(child.type))
      ? React.cloneElement(child, { 'aria-label': child.props['aria-label'] || (typeof label === 'string' ? label : undefined),
          'aria-describedby': child.props['aria-describedby'] || (sub ? descriptionId : undefined) }) : child);
  return (
    <div className="sd-row">
      <div>
        <div className="sd-rowlabel">{label}</div>
        {sub && <div id={descriptionId} className="sd-rowsub">{sub}</div>}
      </div>
      <div className="sd-rowcontrol">{controls}</div>
    </div>
  );
}

// ---- Select ----
function Select({ value, onChange, options, disabled, style, ...rest }) {
  return (
    <select {...rest} className="sd-select" value={value} disabled={disabled} style={style}
      onChange={e => onChange(e.target.value)}>
      {options.map(o => <option key={o.value} value={o.value} disabled={!!o.disabled}>{o.label}</option>)}
    </select>
  );
}

// ---- Number stepper ----
function Stepper({ value, onChange, min = 0, max = 999, step = 1, suffix, width = 136, disabled = false, label, commitOnBlur = false }) {
  const [draft, setDraft] = useState(String(value ?? ''));
  const [editing, setEditing] = useState(false);
  const clamp = v => Math.max(min, Math.min(max, +v.toFixed(2)));
  const parse = v => {
    if (typeof v === 'number') return Number.isFinite(v) ? v : null;
    const text = String(v ?? '').trim().replace(',', '.');
    if (!text || /^[+-]?\.?$/.test(text)) return null;
    const n = Number(text);
    return Number.isFinite(n) ? n : null;
  };
  const displayValue = editing ? draft : String(value ?? '');
  useEffect(() => {
    if (!editing) setDraft(String(value ?? ''));
  }, [value, editing]);
  const commit = raw => {
    if (disabled) return;
    const n = parse(raw);
    if (commitOnBlur && n == null) {
      setDraft(String(value ?? '')); setEditing(false); return;
    }
    const next = clamp(n == null ? min : n);
    setDraft(String(next));
    setEditing(false);
    if (!commitOnBlur || next !== Number(value)) onChange(next);
  };
  const stepBy = delta => {
    const base = parse(editing ? draft : value);
    const next = clamp((base == null ? min : base) + delta);
    setDraft(String(next));
    setEditing(false);
    if (!commitOnBlur || next !== Number(value)) onChange(next);
  };
  return (
    <div className="sd-stepper" style={{ width }}>
      <button type="button" aria-label={label ? `${tr('decrease')} ${label}` : undefined} disabled={disabled}
        onPointerDown={e => { if (commitOnBlur) e.preventDefault(); }} onClick={() => stepBy(-step)}>−</button>
      <input aria-label={label} value={displayValue} inputMode="decimal" disabled={disabled}
        onFocus={() => { setEditing(true); setDraft(String(value ?? '')); }}
        onChange={e => {
          const text = e.target.value;
          setDraft(text);
          const n = parse(text);
          if (!commitOnBlur && n != null) onChange(clamp(n));
        }}
        onKeyDown={e => { if (commitOnBlur && e.key === 'Enter') e.currentTarget.blur(); }}
        onBlur={e => commit(e.target.value)} />
      <button type="button" aria-label={label ? `${tr('increase')} ${label}` : undefined} disabled={disabled}
        onPointerDown={e => { if (commitOnBlur) e.preventDefault(); }} onClick={() => stepBy(step)}>+</button>
    </div>
  );
}

// ---- Segmented control ----
function Segmented({ value, onChange, options, label }) {
  return (
    <div className="sd-seg" role="radiogroup" aria-label={label}>
      {options.map(o => (
        <button type="button" role="radio" aria-checked={value === o.value}
          key={o.value} className={value === o.value ? 'on' : ''} disabled={!!o.disabled}
          onClick={() => !o.disabled && onChange(o.value)}>{o.label}</button>
      ))}
    </div>
  );
}

// ---- Tag list ----
function Tag({ children, warn }) { return <span className={'sd-tag' + (warn ? ' warn' : '')}>{children}</span>; }

// ---- Swipe row with trailing delete action ----
function SwipeActionRow({ children, onClick, onDelete, disabled, itemStyle, className = '', style }) {
  const [dx, setDx] = useState(0);
  const start = useRef(null);
  const moved = useRef(false);
  const canDelete = !!onDelete && !disabled;
  const max = 76;
  const point = e => (e.touches ? e.touches[0] : e.changedTouches ? e.changedTouches[0] : e);
  const close = () => setDx(0);
  const onStart = e => {
    if (!canDelete) return;
    const p = point(e);
    start.current = { x: p.clientX, y: p.clientY };
    moved.current = false;
  };
  const onMove = e => {
    if (!start.current || !canDelete) return;
    const p = point(e);
    const x = p.clientX - start.current.x;
    const y = p.clientY - start.current.y;
    if (Math.abs(y) > Math.abs(x) && Math.abs(y) > 8) return;
    const next = Math.max(-max - 8, Math.min(0, x));
    if (next < 0) {
      moved.current = true;
      if (e.cancelable) e.preventDefault();
      setDx(next);
    }
  };
  const onEnd = () => {
    if (!canDelete) return;
    setDx(d => (d < -50 ? -max : 0));
    start.current = null;
  };
  const clickRow = e => {
    if (dx !== 0 || moved.current) {
      e.preventDefault();
      close();
      return;
    }
    if (onClick) onClick(e);
  };
  return (
    <div className={'sd-swipe-row ' + className} style={style}>
      {canDelete && (
        <button className="sd-swipe-delete" onClick={e => { e.stopPropagation(); onDelete(); close(); }} aria-label={tr('delete')} title={tr('delete')}>
          <Icon name="trash" size={20} />
        </button>
      )}
      <div className="sd-swipe-front"
        onClick={clickRow}
        onMouseDown={onStart} onMouseMove={onMove} onMouseUp={onEnd} onMouseLeave={() => start.current && onEnd()}
        onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd}
        style={{ transform: `translateX(${dx}px)`, transition: start.current ? 'none' : 'transform .2s' }}>
        <div className="sd-item" style={itemStyle}>{children}</div>
      </div>
    </div>
  );
}

// ---- API annotation chip (only shown when apiLayer on) ----
function ApiChip({ children }) {
  if (!window.__sdApi) return null;
  return <div className="sd-api-chip"><span style={{ opacity: .7 }}>API</span> {children}</div>;
}

// ---- Modal (bottom sheet) ----
function Modal({ title, onClose, children, footer, dismissible = true, className = '' }) {
  const dialog = useRef(null), latest = useRef({onClose, dismissible});
  latest.current = {onClose, dismissible};
  useEffect(() => {
    const previous = document.activeElement;
    const controls = () => Array.from(dialog.current?.querySelectorAll('button, [href], input, select, textarea, [tabindex="0"]') || [])
      .filter(el => !el.disabled && el.getClientRects().length);
    (controls()[0] || dialog.current)?.focus();
    const keydown = event => {
      const dialogs = document.querySelectorAll('[role="dialog"]');
      if (dialogs[dialogs.length - 1] !== dialog.current) return;
      if (event.key === 'Escape' && latest.current.dismissible) {
        event.preventDefault(); latest.current.onClose?.();
      }
      if (event.key !== 'Tab') return;
      const items = controls(), first = items[0], last = items[items.length - 1];
      if (!items.length) { event.preventDefault(); dialog.current?.focus(); }
      else if (event.shiftKey && (document.activeElement === first || !dialog.current.contains(document.activeElement))) {
        event.preventDefault(); last.focus();
      } else if (!event.shiftKey && (document.activeElement === last || !dialog.current.contains(document.activeElement))) {
        event.preventDefault(); first.focus();
      }
    };
    document.addEventListener('keydown', keydown);
    return () => { document.removeEventListener('keydown', keydown); if (previous?.isConnected) previous.focus({preventScroll:true}); };
  }, []);
  return (
    <div className="sd-modal-back" onClick={dismissible ? onClose : undefined}>
      <div ref={dialog} tabIndex={-1} className={`sd-modal ${className}`} role="dialog" aria-modal="true" aria-label={title} onClick={e => e.stopPropagation()}>
        <div className="sd-modalgrip" />
        <div className="sd-modalhead">
          <span className="sd-modaltitle">{title}</span>
          {dismissible && <button className="sd-iconbtn" onClick={onClose} aria-label={tr('dismiss')}><Icon name="close" size={18} /></button>}
        </div>
        <div className="sd-modalbody sd-scroll">{children}</div>
        {footer && <div className="sd-modalfoot">{footer}</div>}
      </div>
    </div>
  );
}

// ---- Empty / Loading / Error states ----
function EmptyState({ icon = 'shots', title, sub }) {
  return (
    <div className="sd-empty">
      <div className="ic"><Icon name={icon} size={40} color="var(--fg-faint)" /></div>
      <h4>{title}</h4>{sub && <p>{sub}</p>}
    </div>
  );
}
function Loading({ label }) {
  return <div className="sd-empty"><div className="sd-spinner" /><p style={{ marginTop: 14 }}>{label || tr('loading')}</p></div>;
}
function ErrorState({ onRetry }) {
  return (
    <div className="sd-empty">
      <div className="ic"><Icon name="wifi" size={40} color="var(--destructive)" /></div>
      <p style={{ marginBottom: 16 }}>{tr('error_load')}</p>
      {onRetry && <Btn variant="ghost" className="sm" onClick={onRetry}>{tr('retry')}</Btn>}
    </div>
  );
}

// ---- Help bullets ----
function HelpList({ section }) {
  const items = trh(section);
  return (
    <div>
      {items.map((t, i) => (
        <div className="sd-help-li" key={i}><span className="b"><Icon name="drop" size={16} color="var(--primary)" fill="var(--primary)" /></span><p>{t}</p></div>
      ))}
    </div>
  );
}

// ---- Pull-to-refresh ----
// Wraps a screen body; when the inner scroll area (.sd-body) is at the top and
// the user drags downward, reveals a spinner and runs onRefresh() on release.
// Touch-only (mouse keeps native scroll). Mirrors SwipeActionRow's gesture
// guard: only engages when the drag is predominantly vertical, so it never
// fights the horizontal swipe-to-delete rows nested inside the body.
function PullToRefresh({ onRefresh, children }) {
  const THRESHOLD = 64;   // px of pull needed to trigger a refresh
  const MAX = 96;         // px the indicator can travel (past threshold)
  const RESIST = 0.5;     // finger-to-travel damping for a natural rubber feel
  const wrapRef = useRef(null);
  const start = useRef(null);     // { x, y } at touchstart, or null
  const scroller = useRef(null);  // the active .sd-body element
  const engaged = useRef(false);  // true once we've claimed the gesture as a pull
  const timer = useRef(null);     // watchdog so a hung refresh can't stick forever
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  // Clear any pending watchdog if the wrapper unmounts mid-refresh.
  useEffect(() => () => clearTimeout(timer.current), []);

  const findScroller = (target) => {
    const root = wrapRef.current;
    let el = target;
    while (el && el !== root) {
      if (el.classList && el.classList.contains('sd-body')) return el;
      el = el.parentElement;
    }
    return root ? root.querySelector('.sd-body') : null;
  };

  const onStart = (e) => {
    if (refreshing) return;
    // A modal sheet is rendered inside the screen body but scrolls on its own:
    // never treat a drag inside it as a pull, or a downward swipe in the sheet
    // gets cancelled and its content cannot be scrolled back up.
    if (e.target?.closest?.('.sd-modal-back')) { start.current = null; engaged.current = false; return; }
    const sc = findScroller(e.target);
    scroller.current = sc;
    engaged.current = false;
    // Only arm the gesture when already scrolled to the very top.
    if (!sc || sc.scrollTop > 0) { start.current = null; return; }
    const t = e.touches ? e.touches[0] : e;
    start.current = { x: t.clientX, y: t.clientY };
  };

  const onMove = (e) => {
    if (!start.current || refreshing) return;
    const sc = scroller.current;
    if (sc && sc.scrollTop > 0) { start.current = null; engaged.current = false; setPull(0); return; }
    const t = e.touches ? e.touches[0] : e;
    const dy = t.clientY - start.current.y;
    const dx = t.clientX - start.current.x;
    // Ignore upward drags and gestures that read as horizontal (swipe rows).
    if (dy <= 0 || Math.abs(dx) > Math.abs(dy)) {
      if (engaged.current) { engaged.current = false; setPull(0); }
      return;
    }
    engaged.current = true;
    if (e.cancelable) e.preventDefault();   // block native overscroll while pulling
    setPull(Math.min(MAX, dy * RESIST));
  };

  const onEnd = () => {
    if (!start.current) return;
    start.current = null;
    const trigger = engaged.current && pull >= THRESHOLD;
    engaged.current = false;
    if (!trigger) { setPull(0); return; }
    setRefreshing(true);
    setPull(THRESHOLD);
    // Reset exactly once — whichever fires first: the refresh settling or the
    // watchdog. Guards against a fetch that hangs without ever rejecting (no
    // timeout exists in the api layer), which would otherwise pin the spinner.
    clearTimeout(timer.current);
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timer.current);
      setRefreshing(false);
      setPull(0);
    };
    timer.current = setTimeout(finish, 8000);
    Promise.resolve()
      .then(() => onRefresh && onRefresh())
      .catch(() => {})
      .then(finish);
  };

  const ready = pull >= THRESHOLD;
  const label = refreshing ? tr('ptr_refreshing') : ready ? tr('ptr_release') : tr('ptr_pull');
  const progress = Math.min(1, pull / THRESHOLD);

  return (
    <div className="sd-ptr" ref={wrapRef}
      onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd} onTouchCancel={onEnd}>
      <div className="sd-ptr-ind" style={{ height: pull }} aria-hidden={!pull && !refreshing}>
        <div className="sd-ptr-badge" style={{ opacity: refreshing ? 1 : progress }}>
          <span className={'sd-ptr-spin' + (refreshing ? ' spin' : '')}
            style={refreshing ? null : { transform: `rotate(${progress * 270}deg)` }} />
          <span className="sd-ptr-text">{label}</span>
        </div>
      </div>
      <div className="sd-ptr-content"
        style={{ transform: pull ? `translateY(${pull}px)` : null,
          willChange: (pull || refreshing) ? 'transform' : null,
          transition: start.current ? 'none' : 'transform .24s cubic-bezier(.2,.8,.2,1)' }}>
        {children}
      </div>
    </div>
  );
}

Object.assign(window, {
  Icon, ICONS, Pill, Card, Btn, Switch, Row, Select, Stepper, Segmented,
  Tag, SwipeActionRow, ApiChip, Modal, EmptyState, Loading, ErrorState, HelpList,
  PullToRefresh,
});
