// ---- Settings ----
function updateStatusText(update) {
  if (update.migration_state === 'finishing') return tr('update_finishing_automatically');
  if (update.migration_state === 'waiting') return tr('update_resumes_automatically');
  const target = update.target_version ? ` v${update.target_version}` : '';
  if (update.state === 'checking') return tr('checking_updates');
  if (update.state === 'up_to_date') return tr('software_up_to_date');
  if (update.state === 'available') return tr('update_available') + target;
  if (update.state === 'unavailable') return tr('no_update_available');
  if (update.state === 'queued') return tr('preparing_update') + target;
  if (update.state === 'installing') return tr('installing_version') + target;
  if (update.state === 'installed') return tr('updated_to') + target;
  if (update.state === 'disabled') return tr('updates_disabled');
  if (update.state === 'blocked') return tr('updates_unavailable');
  if (update.state === 'error') return tr('update_failed');
  return tr('update_not_checked');
}

function backupDateText(app, value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return String(value);
  return date.toLocaleString(app.lang === 'de' ? 'de-DE' : 'en-GB', {
    dateStyle: 'medium', timeStyle: 'short',
  });
}

function backupStateText(state) {
  const key = `backup_state_${String(state || 'idle').toLowerCase()}`;
  const value = tr(key);
  return value === key ? tr('backup_state_idle') : value;
}

function BackupRestoreCard({ app, visible = true, enabled = true, onSummary }) {
  const [status, setStatus] = useState({ state: 'loading' });
  const [loadError, setLoadError] = useState('');
  const [cloudOpen, setCloudOpen] = useState(false);
  const [personalDrive, setPersonalDrive] = useState({ provider: 'google_drive', connected: false, enabled: false, cadence: 'weekly', retention_count: 10 });
  const [nextcloudCredentials, setNextcloudCredentials] = useState({ server_url: '', username: '', app_password: '' });
  const [options, setOptions] = useState({
    include_photos: false,
    include_scale_binding: false,
    include_machine_learning: false,
  });
  const [busy, setBusy] = useState(false);
  const [recovery, setRecovery] = useState(null);
  const [recoverySaved, setRecoverySaved] = useState(false);
  const [restore, setRestore] = useState(() => {
    const restoreId = window.sessionStorage.getItem('shotdeck_restore_id');
    return restoreId ? { restore_id: restoreId, state: 'checking' } : null;
  });
  const [restorePin, setRestorePin] = useState('');
  const [deviceInput, setDeviceInput] = useState({ state: 'idle' });
  const restoreInput = useRef(null);
  const deviceInputCompletion = useRef('');
  const personalDriveDraftDirty = useRef(false);
  const statusRead = useRef(null);
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; };
  }, []);
  const active = ['preparing', 'encrypting', 'restoring', 'applying', 'queued'].includes(String(status.state));
  const recoveryStatus = status.recovery || {};
  const recoveryConfirmed = recoveryStatus.confirmed === true;
  const displaySize = String(app.data?.settings?.device?.display_size || '').toLowerCase();
  const nonTouchDisplay = !['3.5f', '3.5_f', '3.5-f'].includes(displaySize);

  const load = async (fresh = false) => {
    // A refresh following a mutation must start after any older background
    // read. Ordinary polls share the batch already in flight.
    if (fresh && statusRead.current) await statusRead.current;
    if (!mounted.current) return;
    if (statusRead.current) return statusRead.current;
    const request = Promise.allSettled([
      api('/api/backups/status'), api('/api/backups/personal-drive'),
    ]).then(([localResult, personalDriveResult]) => {
      if (!mounted.current) return;
      if (localResult.status === 'fulfilled') { setStatus(localResult.value); setLoadError(''); }
      else setLoadError(localResult.reason?.message || tr('settings_status_unavailable'));
      if (personalDriveResult.status === 'fulfilled') {
        setPersonalDrive(current => personalDriveDraftDirty.current ? {
          ...personalDriveResult.value,
          provider: current.provider,
          cadence: current.cadence,
          retention_count: current.retention_count,
        } : personalDriveResult.value);
      }
    }).finally(() => {
      if (statusRead.current === request) statusRead.current = null;
    });
    statusRead.current = request;
    return request;
  };

  useEffect(() => {
    let disposed = false;
    const poll = () => {
      if (!disposed && enabled && (visible || active) && document.visibilityState !== 'hidden') return load();
    };
    const onVisibility = () => { if (document.visibilityState === 'visible') poll(); };
    poll();
    const timer = window.setInterval(poll, active ? 1200 : 10000);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      disposed = true;
      window.clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisibility);
    };
  }, [active, visible, enabled]);
  useEffect(() => {
    if (personalDrive.connected || personalDrive.oauth_pending) setCloudOpen(true);
  }, [personalDrive.connected, personalDrive.oauth_pending]);
  useEffect(() => {
    onSummary?.(loadError ? tr('settings_status_unavailable') : status.state === 'loading' ? ''
      : tr('manual_backup') + ' · ' + (status.state === 'idle' && !recoveryConfirmed
        ? tr('recovery_required') : backupStateText(status.state)));
  }, [status.state, recoveryConfirmed, loadError, app.lang]);

  useEffect(() => {
    if (!['active', 'processing'].includes(String(deviceInput.state))) return undefined;
    let cancelled = false;
    const poll = async () => {
      try {
        const result = await api('/api/backups/device-input');
        if (cancelled) return;
        setDeviceInput(result);
        if (result.state === 'completed' && deviceInputCompletion.current !== result.purpose) {
          deviceInputCompletion.current = result.purpose;
          if (result.purpose === 'restore_recovery' && result.recovery_armed) {
            app.toast(tr('device_recovery_ready'));
          }
          await load(true);
        }
      } catch (error) {
        if (!cancelled) app.toast(error.message);
      }
    };
    poll();
    const timer = window.setInterval(poll, 800);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [deviceInput.state, deviceInput.purpose]);

  useEffect(() => {
    const restoreId = restore && (restore.restore_id || restore.id);
    const restoreState = String((restore && restore.state) || 'staged');
    if (!restoreId || !['checking', 'queued', 'applying', 'restoring', 'rollback'].includes(restoreState)) return undefined;
    let cancelled = false;
    const poll = async () => {
      try {
        const result = await api(`/api/backups/restore/${encodeURIComponent(restoreId)}/status`);
        if (!cancelled) setRestore(current => ({ ...(current || {}), ...result }));
        if (['complete', 'completed', 'failed', 'rolled_back'].includes(String(result.state))) {
          window.sessionStorage.removeItem('shotdeck_restore_id');
        }
      } catch (_error) {
        // The service intentionally restarts during apply. Keep polling so
        // this tab reconnects and reports the persisted result.
      }
    };
    poll();
    const timer = window.setInterval(poll, 1500);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [restore && restore.restore_id, restore && restore.state]);

  const mutate = async fn => {
    setBusy(true);
    try { await fn(); await load(true); }
    catch (error) { app.toast(error.message); }
    finally { setBusy(false); }
  };

  const showPhysicalConfirmation = async purpose => {
    try {
      await api('/api/backups/confirmation', {
        method: 'POST', body: JSON.stringify({ purpose }),
      });
      return true;
    } catch (error) {
      app.toast(error.message);
      return false;
    }
  };

  const startDeviceInput = async purpose => {
    setBusy(true);
    deviceInputCompletion.current = '';
    try {
      const result = await api('/api/backups/device-input', {
        method: 'POST', body: JSON.stringify({ purpose }),
      });
      setDeviceInput(result);
    } catch (error) { app.toast(error.message); }
    finally { setBusy(false); }
  };

  const cancelDeviceInput = async () => {
    setBusy(true);
    try {
      const result = await api('/api/backups/device-input', { method: 'DELETE' });
      setDeviceInput(result);
    } catch (error) { app.toast(error.message); }
    finally { setBusy(false); }
  };

  const setupRecovery = () => mutate(async () => {
    const result = await api('/api/backups/recovery', {
      method: 'POST', body: JSON.stringify({ action: 'initialize' }),
    });
    setRecovery(result);
    setRecoverySaved(false);
  });

  const confirmRecovery = () => mutate(async () => {
    await api('/api/backups/recovery', {
      method: 'POST', body: JSON.stringify({ action: 'confirm' }),
    });
    setRecovery(null);
    app.toast(tr('recovery_confirmed'));
  });

  const revealRecovery = async () => {
    if (!await showPhysicalConfirmation('reveal_backup_recovery')) return;
    const confirmationPin = window.prompt(tr('physical_pin_prompt'));
    if (!confirmationPin) return;
    mutate(async () => {
      const result = await api('/api/backups/recovery', {
        method: 'POST', body: JSON.stringify({ action: 'reveal', confirmation_pin: confirmationPin }),
      });
      setRecovery({ ...result, mode: 'reveal' });
      setRecoverySaved(false);
    });
  };

  const createBackup = () => mutate(async () => {
    const result = await api('/api/backups', {
      method: 'POST', body: JSON.stringify(options),
    });
    setStatus(result);
  });

  const deleteBackup = async () => {
    if (!window.confirm(tr('backup_delete_confirm'))) return;
    if (!await showPhysicalConfirmation('delete_local_backup')) return;
    const confirmationPin = window.prompt(tr('physical_pin_prompt'));
    if (!confirmationPin) return;
    mutate(async () => {
      await api('/api/backups/latest', {
        method: 'DELETE', body: JSON.stringify({ confirmation_pin: confirmationPin }),
      });
      app.toast(tr('deleted'));
    });
  };

  const stageRestore = async file => {
    if (!file) return;
    setBusy(true);
    setRestore(null);
    try {
      const headers = {
        'Content-Type': 'application/octet-stream',
        'X-Shotdeck-CSRF': '1',
        'X-Shotdeck-Backup-Name': encodeURIComponent(file.name || 'backup.sdbak'),
      };
      const response = await fetch('/api/backups/restore', { method: 'POST', headers, body: file });
      const result = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(result.error || tr('restore_stage_failed'));
      setRestore(result);
      if (result.restore_id || result.id) window.sessionStorage.setItem('shotdeck_restore_id', result.restore_id || result.id);
      await showPhysicalConfirmation('apply_restore');
      setDeviceInput({ state: 'idle' });
    } catch (error) { app.toast(error.message); }
    finally {
      setBusy(false);
      if (restoreInput.current) restoreInput.current.value = '';
    }
  };

  const applyRestore = () => mutate(async () => {
    const restoreId = restore && (restore.restore_id || restore.id);
    if (!restoreId) throw new Error(tr('restore_stage_failed'));
    const result = await api(`/api/backups/restore/${encodeURIComponent(restoreId)}/apply`, {
      method: 'POST', body: JSON.stringify({ confirmation_pin: restorePin.trim() }),
    });
    setRestore({ ...restore, ...result });
    window.sessionStorage.setItem('shotdeck_restore_id', result.restore_id || restoreId);
    setRestorePin('');
  });

  const personalDriveScope = () => ({
    include_photos: options.include_photos,
    include_scale_binding: options.include_scale_binding,
    include_machine_learning: options.include_machine_learning,
  });

  const connectPersonalDrive = () => {
    const nextcloud = personalDrive.provider === 'nextcloud';
    const authorizationWindow = nextcloud ? null : window.open('about:blank', '_blank');
    if (authorizationWindow) authorizationWindow.opener = null;
    mutate(async () => {
      let navigated = false;
      try {
        const result = await api('/api/backups/personal-drive/connect', {
          method: 'POST', body: JSON.stringify({
            provider: personalDrive.provider || 'google_drive',
            cadence: personalDrive.cadence || 'weekly',
            retention_count: Number(personalDrive.retention_count || 10),
            scope: personalDriveScope(),
            ...(nextcloud ? nextcloudCredentials : {}),
          }),
        });
        personalDriveDraftDirty.current = false;
        setPersonalDrive(result);
        if (nextcloud) setNextcloudCredentials(current => ({ ...current, app_password: '' }));
        if (authorizationWindow && result.authorization_url) authorizationWindow.location = result.authorization_url;
        else if (result.authorization_url) window.location.href = result.authorization_url;
        navigated = true;
      } finally {
        if (!navigated && authorizationWindow) authorizationWindow.close();
      }
    });
  };

  const finishPersonalDrive = () => mutate(async () => {
    const result = await api('/api/backups/personal-drive/complete', { method: 'POST', body: '{}' });
    setPersonalDrive(result);
  });

  const savePersonalDrive = (enabled = personalDrive.enabled) => mutate(async () => {
    const result = await api('/api/backups/personal-drive/settings', {
      method: 'POST', body: JSON.stringify({
        cadence: personalDrive.cadence,
        retention_count: Number(personalDrive.retention_count),
        enabled: !!enabled,
        scope: personalDriveScope(),
      }),
    });
    personalDriveDraftDirty.current = false;
    setPersonalDrive(result);
  });

  const disconnectPersonalDrive = () => {
    if (!window.confirm(tr('personal_drive_disconnect_confirm'))) return;
    mutate(async () => {
      const result = await api('/api/backups/personal-drive/disconnect', { method: 'POST', body: '{}' });
      setPersonalDrive(result);
    });
  };

  const runPersonalDrive = () => mutate(async () => {
    const result = await api('/api/backups/personal-drive/run', { method: 'POST', body: '{}' });
    setPersonalDrive(result);
  });

  const artifact = status.artifact || status.latest_artifact || {};
  const hasArtifact = !!artifact.filename;
  const rawProgress = Number(status.progress || 0);
  const progress = Math.max(0, Math.min(100, rawProgress > 0 && rawProgress <= 1 ? rawProgress * 100 : rawProgress));
  const restorePreview = (restore && restore.preview) || restore || {};
  const physicalInputActive = ['active', 'processing'].includes(String(deviceInput.state));
  const restoreDeviceInput = deviceInput.purpose === 'restore_recovery';
  return (
    <Card title={tr('backup_restore')} apiNote="/api/backups · /restore · /personal-drive"
      right={<Pill variant={status.state === 'ready' ? 'good' : active ? 'ok' : ''}>{loadError ? tr('settings_status_unavailable') : status.state === 'loading' ? tr('settings_loading') : backupStateText(status.state)}</Pill>}>
      {loadError && <p role="alert" className="sd-update-error">{loadError}</p>}
      <ApiChip>POST /backups · GET /backups/status · /latest</ApiChip>
      <div className="sd-backup-section">
        <div className="sd-backup-heading">
          <div className="sd-rowlabel">{tr('manual_backup')}</div>
          <div className="sd-rowsub">{tr('backup_desc')}</div>
        </div>
        <details className="sd-settings-details"><summary>{tr('settings_backup_options')}</summary>
        <div className="sd-backup-includes">
          <span>{tr('backup_always_includes')}</span>
          <span>{tr('backup_always_excludes')}</span>
        </div>
        <Row label={tr('backup_photos')} sub={tr('backup_photos_sub')}>
          <Switch on={options.include_photos} disabled={active || busy} onChange={value => setOptions({ ...options, include_photos: value })} />
        </Row>
        <Row label={tr('backup_scale')} sub={tr('backup_scale_sub')}>
          <Switch on={options.include_scale_binding} disabled={active || busy} onChange={value => setOptions({ ...options, include_scale_binding: value })} />
        </Row>
        <Row label={tr('backup_learning')} sub={tr('backup_learning_sub')}>
          <Switch on={options.include_machine_learning} disabled={active || busy} onChange={value => setOptions({ ...options, include_machine_learning: value })} />
        </Row>
        </details>
        {!recoveryConfirmed && (
          <div className="sd-backup-warning">
            <strong>{tr('recovery_required')}</strong>
            <span>{tr('recovery_required_desc')}</span>
            <Btn variant="primary" className="sm" disabled={busy} onClick={setupRecovery}>{tr('setup_recovery')}</Btn>
          </div>
        )}
        {recoveryConfirmed && <Btn variant="ghost" className="sm" disabled={busy || active} onClick={revealRecovery}>{tr('show_recovery_code')}</Btn>}
        {active && (
          <div className="sd-backup-progress" aria-live="polite">
            <div><span>{backupStateText(status.state)}</span><span>{progress}%</span></div>
            <progress max="100" value={progress} />
          </div>
        )}
        {status.error && <div className="sd-update-error" role="alert">{status.error}</div>}
        <div className="sd-backup-actions">
          <Btn variant="primary" className="block" disabled={busy || active || !recoveryConfirmed} onClick={createBackup}>{tr('create_backup')}</Btn>
          {hasArtifact && !active && (
            <a className="sd-btn ghost block sd-download-link" href="/api/backups/latest" download={artifact.filename || ''}>{tr('download_backup')}</a>
          )}
          {hasArtifact && !active && <Btn variant="danger" className="sm" disabled={busy} onClick={deleteBackup}>{tr('delete_local_copy')}</Btn>}
        </div>
        {artifact.created_at && <div className="sd-backup-meta">{tr('created')} · {backupDateText(app, artifact.created_at)}{artifact.size ? ` · ${(artifact.size / 1024 / 1024).toFixed(1)} MB` : ''}</div>}
      </div>

      <div className="sd-backup-section">
        <div className="sd-cloud-head">
          <div className="sd-backup-heading"><div className="sd-rowlabel">{tr('personal_drive_title')}</div><div className="sd-rowsub">{tr('personal_drive_desc')}</div></div>
          <Pill variant={personalDrive.connected && personalDrive.enabled ? 'good' : ''}>
            {personalDrive.connected ? (personalDrive.enabled ? tr('personal_drive_enabled') : tr('personal_drive_paused')) : tr('personal_drive_not_connected')}
          </Pill>
        </div>
        {personalDrive.last_error && <div className="sd-update-error">{personalDrive.last_error}</div>}
        <details className="sd-settings-details sd-settings-cloud" open={cloudOpen} onToggle={event => setCloudOpen(event.currentTarget.open)}>
          <summary>{tr(personalDrive.connected ? 'settings_cloud_preferences' : 'settings_cloud_setup')}</summary>
        <div className="sd-cloud-grid">
          <span>{tr('personal_drive_provider')}</span>
          <select className="sd-select" aria-label={tr('personal_drive_provider')} disabled={busy || personalDrive.connected || personalDrive.oauth_pending} value={personalDrive.provider || 'google_drive'} onChange={event => { personalDriveDraftDirty.current = true; setPersonalDrive({ ...personalDrive, provider: event.target.value }); }}>
            <option value="google_drive">Google Drive</option><option value="dropbox">Dropbox</option><option value="nextcloud">Nextcloud</option>
          </select>
          {!personalDrive.connected && personalDrive.provider === 'nextcloud' && <>
            <span>{tr('nextcloud_server')}</span>
            <input className="sd-input" aria-label={tr('nextcloud_server')} type="url" inputMode="url" autoCapitalize="none" autoCorrect="off" spellCheck={false}
              placeholder="https://cloud.example.com" value={nextcloudCredentials.server_url}
              onChange={event => setNextcloudCredentials({ ...nextcloudCredentials, server_url: event.target.value })} />
            <span>{tr('nextcloud_username')}</span>
            <input className="sd-input" aria-label={tr('nextcloud_username')} type="text" autoCapitalize="none" autoCorrect="off" spellCheck={false}
              value={nextcloudCredentials.username}
              onChange={event => setNextcloudCredentials({ ...nextcloudCredentials, username: event.target.value })} />
            <span>{tr('nextcloud_app_password')}</span>
            <input className="sd-input" aria-label={tr('nextcloud_app_password')} type="password" autoComplete="new-password"
              value={nextcloudCredentials.app_password}
              onChange={event => setNextcloudCredentials({ ...nextcloudCredentials, app_password: event.target.value })} />
          </>}
          <span>{tr('cadence')}</span>
          <select className="sd-select" aria-label={tr('cadence')} disabled={busy || personalDrive.oauth_pending} value={personalDrive.cadence || 'weekly'} onChange={event => { personalDriveDraftDirty.current = true; setPersonalDrive({ ...personalDrive, cadence: event.target.value }); }}>
            <option value="daily">{tr('cadence_daily')}</option><option value="weekly">{tr('cadence_weekly')}</option><option value="monthly">{tr('cadence_monthly')}</option>
          </select>
          <span>{tr('personal_drive_keep')}</span>
          <select className="sd-select" aria-label={tr('personal_drive_keep')} disabled={busy || personalDrive.oauth_pending} value={Number(personalDrive.retention_count || 10)} onChange={event => { personalDriveDraftDirty.current = true; setPersonalDrive({ ...personalDrive, retention_count: Number(event.target.value) }); }}>
            {[5, 10, 20, 50].map(count => <option key={count} value={count}>{count}</option>)}
          </select>
          <span>{tr('last_backup')}</span><strong>{backupDateText(app, personalDrive.last_success_at)}</strong>
          <span>{tr('next_backup')}</span><strong>{backupDateText(app, personalDrive.next_due_at)}</strong>
        </div>
        {!personalDrive.connected && personalDrive.provider === 'nextcloud' && <div className="sd-backup-note">{tr('nextcloud_app_password_hint')}</div>}
        {!personalDrive.connected && personalDrive.provider === 'nextcloud' && window.location.protocol !== 'https:' && <div className="sd-backup-warning" role="note">
          <strong>{tr('nextcloud_local_http_warning')}</strong>
        </div>}
        <div className="sd-backup-note">{tr('personal_drive_privacy')}</div>
        {!recoveryConfirmed && !personalDrive.connected && <div id="sd-personal-drive-recovery-required" className="sd-cloud-notice" role="note">
          <strong>{tr('personal_drive_recovery_required')}</strong>
        </div>}
        {!personalDrive.connected && !personalDrive.oauth_pending && <Btn variant="primary" className="block"
          aria-describedby={!recoveryConfirmed ? 'sd-personal-drive-recovery-required' : undefined}
          disabled={busy || !recoveryConfirmed} onClick={connectPersonalDrive}>{tr('personal_drive_connect')}</Btn>}
        {personalDrive.oauth_pending && <div className="sd-backup-actions">
          <Btn variant="primary" disabled={busy || !recoveryConfirmed} onClick={finishPersonalDrive}>{tr('personal_drive_finish')}</Btn>
          <Btn variant="ghost" disabled={busy || !recoveryConfirmed} onClick={connectPersonalDrive}>{tr('personal_drive_restart')}</Btn>
        </div>}
        {personalDrive.connected && <div className="sd-backup-actions">
          <Btn variant="ghost" disabled={busy} onClick={() => savePersonalDrive(personalDrive.enabled)}>{tr('save_settings')}</Btn>
          <Btn variant="ghost" disabled={busy || !personalDrive.enabled || personalDrive.run_requested} onClick={runPersonalDrive}>{tr('backup_now')}</Btn>
          <Btn variant="ghost" disabled={busy} onClick={() => savePersonalDrive(!personalDrive.enabled)}>{personalDrive.enabled ? tr('pause_uploads') : tr('resume_uploads')}</Btn>
          <Btn variant="danger" disabled={busy} onClick={disconnectPersonalDrive}>{tr('personal_drive_disconnect')}</Btn>
        </div>}
        </details>
      </div>

      <details className="sd-backup-section sd-settings-details sd-settings-restore">
        <summary>{tr('restore_backup')}</summary>
        <div className="sd-backup-heading">
          <div className="sd-rowsub">{tr('restore_desc')}</div>
        </div>
        <div className="sd-backup-warning">
          <strong>{tr('physical_recovery_entry')}</strong>
          <span>{tr('physical_recovery_entry_desc')}</span>
        </div>
        {nonTouchDisplay ? <>
          {!restoreDeviceInput || !physicalInputActive ? <Btn variant="ghost" className="block" disabled={busy || active || physicalInputActive}
            onClick={() => startDeviceInput('restore_recovery')}>{tr('enter_recovery_on_device')}</Btn> : null}
          {restoreDeviceInput && physicalInputActive && <div className="sd-cloud-notice" aria-live="polite">
            <strong>{tr('device_input_in_progress')}</strong>
            <span>{deviceInput.entered_characters || 0} / {deviceInput.expected_characters || 60}</span>
            <span>{tr('device_input_controls')}</span>
            <Btn variant="ghost" className="sm" disabled={busy || deviceInput.state === 'processing'} onClick={cancelDeviceInput}>{tr('cancel')}</Btn>
          </div>}
          {restoreDeviceInput && deviceInput.state === 'completed' && deviceInput.recovery_armed &&
            <div className="sd-backup-note">{tr('device_recovery_ready')}</div>}
        </> : <div className="sd-backup-note">{tr('touch_recovery_entry')}</div>}
        <input ref={restoreInput} type="file" accept=".sdbak,application/octet-stream" style={{ display: 'none' }}
          onChange={event => stageRestore(event.target.files && event.target.files[0])} />
        <Btn variant="ghost" className="block" disabled={busy || active || (restoreDeviceInput && physicalInputActive)}
          onClick={() => restoreInput.current && restoreInput.current.click()}>{tr('choose_backup_file')}</Btn>
      </details>


      {recovery && (
        <Modal title={recovery.mode === 'reveal' ? tr('show_recovery_code') : tr('save_recovery_code')} onClose={() => setRecovery(null)} footer={recovery.mode === 'reveal'
          ? <Btn variant="primary" className="block" onClick={() => setRecovery(null)}>{tr('close')}</Btn>
          : <>
            <Btn variant="ghost" className="block" onClick={() => setRecovery(null)}>{tr('cancel')}</Btn>
            <Btn variant="primary" className="block" disabled={!recoverySaved || busy} onClick={confirmRecovery}>{tr('confirm_saved')}</Btn>
          </>}>
          <p className="sd-rowsub">{tr('recovery_code_desc')}</p>
          {recovery.recovery_code
            ? <div className="sd-recovery-code" aria-label={tr('recovery_code')}>{recovery.recovery_code}</div>
            : recovery.shown_on_device
              ? <div className="sd-backup-warning">{tr('recovery_on_device')}</div>
              : <div className="sd-backup-warning">{tr('recovery_display_required')}</div>}
          {recovery.mode !== 'reveal' && (recovery.recovery_code || recovery.shown_on_device) && <label className="sd-checkline"><input type="checkbox" checked={recoverySaved} onChange={event => setRecoverySaved(event.target.checked)} /> {tr('i_saved_recovery')}</label>}
        </Modal>
      )}

      {restore && (
        <Modal title={['queued', 'applying', 'restoring', 'rollback', 'checking'].includes(String(restore.state)) ? tr('restore_in_progress') : tr('confirm_restore')}
          dismissible={!['queued', 'applying', 'restoring', 'rollback'].includes(String(restore.state))}
          onClose={() => { window.sessionStorage.removeItem('shotdeck_restore_id'); setRestore(null); }}
          footer={['queued', 'applying', 'restoring', 'rollback', 'checking'].includes(String(restore.state)) ? null : <>
            <Btn variant="ghost" className="block" onClick={() => { window.sessionStorage.removeItem('shotdeck_restore_id'); setRestore(null); }}>{['complete', 'completed', 'failed', 'rolled_back'].includes(String(restore.state)) ? tr('dismiss') : tr('cancel')}</Btn>
            {!['complete', 'completed', 'failed', 'rolled_back'].includes(String(restore.state)) && <Btn variant="danger" className="block" disabled={!restorePin.trim() || busy} onClick={applyRestore}>{tr('restore_and_restart')}</Btn>}
          </>}>
          {['queued', 'applying', 'restoring', 'rollback', 'checking'].includes(String(restore.state)) ? (
            <div className="sd-update-progress" aria-live="polite">
              <div className="sd-spinner" aria-hidden="true" />
              <div className="sd-serif">{tr(`restore_state_${restore.state}`)}</div>
              <p>{tr('restore_reconnect')}</p>
              <div className="sd-update-power-warning">{tr('restore_power_warning')}</div>
            </div>
          ) : ['complete', 'completed'].includes(String(restore.state)) ? (
            <div className="sd-update-progress" aria-live="polite"><Icon name="check" size={42} color="var(--success)" /><div className="sd-serif">{tr('restore_complete')}</div></div>
          ) : restore.state === 'failed' || restore.state === 'rolled_back' ? (
            <div className="sd-update-progress" aria-live="polite"><Icon name="close" size={38} color="var(--destructive)" /><div className="sd-serif">{tr('restore_failed')}</div><p>{restore.error || restore.message}</p></div>
          ) : <>
            <div className="sd-backup-warning"><strong>{tr('restore_replaces')}</strong><span>{tr('restore_power_warning')}</span></div>
            <div className="sd-cloud-grid">
              <span>{tr('created')}</span><strong>{backupDateText(app, restorePreview.created_at)}</strong>
              <span>{tr('profiles')}</span><strong>{(restorePreview.counts && restorePreview.counts.profiles) ?? '-'}</strong>
              <span>{tr('shots_history')}</span><strong>{(restorePreview.counts && restorePreview.counts.shots) ?? '-'}</strong>
            </div>
            {restorePreview.scale_policy && <div className="sd-backup-warning">
              <strong>{tr('scale_settings')}</strong>
              <span>{restorePreview.scale_policy.mode === 'specific'
                ? tr('scale_restore_specific') + ' ' + (restorePreview.scale_policy.target?.name || '')
                : tr('scale_any')}</span>
            </div>}
            <div className="sd-fieldlabel sd-fieldlabel-sentence">{tr('physical_pin_prompt')}</div>
            <Btn variant="ghost" className="sm" onClick={() => showPhysicalConfirmation('apply_restore')}>{tr('show_confirmation_code')}</Btn>
            <input className="sd-input" inputMode="numeric" autoComplete="one-time-code" value={restorePin}
              onChange={event => setRestorePin(event.target.value.replace(/\D/g, '').slice(0, 12))} />
          </>}
        </Modal>
      )}
    </Card>
  );
}

function ScaleSettingsCard({ app }) {
  const display = app.data.settings.display;
  const [batteryBusy, setBatteryBusy] = useState(false);
  const setBattery = async (key, value) => {
    setBatteryBusy(true);
    try { await app.setScaleBattery(key, value); }
    finally { setBatteryBusy(false); }
  };
  const [status, setStatus] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [nameDraft, setNameDraft] = useState('');
  const [renameStatus, setRenameStatus] = useState(null);
  const latest = useRef(null);
  const apply = value => {
    if (!value || typeof value.revision !== 'number') return;
    if (latest.current && value.revision < latest.current.revision) return;
    latest.current = value;
    setStatus(value);
  };
  useEffect(() => {
    let disposed = false;
    let inFlight = false;
    const load = async () => {
      if (disposed || inFlight || document.visibilityState === 'hidden') return;
      inFlight = true;
      try {
        const value = await api('/api/scale');
        if (!disposed) apply(value);
      } catch (e) { if (!disposed) setError(e.message); }
      finally { inFlight = false; }
    };
    const onVisibility = () => { if (document.visibilityState === 'visible') load(); };
    load();
    const timer = setInterval(load, 1000);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      disposed = true;
      clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisibility);
      const s = latest.current;
      if (s && s.active && s.owned) {
        api('/api/scale/setup/' + s.session_id + '/cancel', { method: 'POST', keepalive: true,
          body: JSON.stringify({ operation_id: (Date.now().toString(36) + Math.random().toString(36).slice(2)), revision: s.revision }) }).catch(() => {});
      }
    };
  }, []);
  const act = async (action, extra = {}, expectedStatus = null) => {
    const s = expectedStatus || latest.current;
    if (!s || busy) return;
    if (action === 'any' && !window.confirm(tr('scale_any_explain'))) return;
    setBusy(true); setError('');
    const path = action === 'rename' ? '/api/scale/name' : action === 'any' ? '/api/scale' : action === 'start' ? '/api/scale/setup'
      : '/api/scale/setup/' + s.session_id + '/' + action;
    try {
      apply(await api(path, { method: action === 'any' ? 'PUT' : 'POST', body: JSON.stringify({
        operation_id: (Date.now().toString(36) + Math.random().toString(36).slice(2)), revision: s.revision, identification: s.identification,
        ...(action === 'any' ? { mode: 'any' } : {}), ...extra,
      }) }));
      return true;
    } catch (e) {
      setError(e.message);
      try { apply(await api('/api/scale')); } catch (_) {}
      return false;
    } finally { setBusy(false); }
  };
  const s = status || {};
  const working = ['scanning', 'connecting', 'identifying', 'saving', 'cancelling'].includes(s.state);
  const canEdit = !busy && s.owned !== false;
  return <Card title={tr('scale_settings')}>
    <div className="sd-rowlabel">{s.mode === 'specific' ? tr('scale_only') + ' ' + (s.target?.name || '') : tr('scale_any')}</div>
    <div className="sd-rowsub" role="status">{!status ? tr('settings_loading') : s.waiting_for ? tr('scale_waiting') + ' ' + s.waiting_for : tr(s.connected ? 'connected' : 'not_connected')}</div>
    {(s.target || s.family_filter && s.family_filter !== 'auto') && <details className="sd-settings-details"><summary>{tr('settings_scale_details')}</summary>
    {s.target && <div className="sd-rowsub">{s.target.address}</div>}
    {s.family_filter && s.family_filter !== 'auto' && <div className="sd-rowsub">{tr('scale_family_filter')} {s.family_filter}</div>}
    </details>}
    <div className="sd-settings-subtitle">{tr('settings_battery')}</div>
    <div role="group" aria-label={tr('scale_battery_percent')}>
      <Row label={tr('scale_battery_percent')} sub={tr('scale_battery_percent_help')}>
        <Switch on={display.scale_battery_percent_enabled !== false}
          disabled={batteryBusy} onChange={value => setBattery('scale_battery_percent_enabled', value)} />
      </Row>
    </div>
    <div role="group" aria-label={tr('scale_low_battery_warning')}>
      <Row label={tr('scale_low_battery_warning')} sub={tr('scale_low_battery_warning_help')}>
        <Switch on={display.scale_low_battery_warning_enabled !== false}
          disabled={batteryBusy} onChange={value => setBattery('scale_low_battery_warning_enabled', value)} />
      </Row>
    </div>
    {(error || s.error) && <div role="alert" className="sd-rowsub" style={{ marginTop: 10 }}>{error || s.error}</div>}
    {!s.active && !renameStatus && <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 14 }}>
      <Btn variant="primary" disabled={!status || busy} onClick={() => act('start')}>{tr('scale_choose')}</Btn>
      {s.target && !s.settings_error && <Btn variant="ghost" disabled={busy} onClick={() => {
        setNameDraft(s.target.name); setRenameStatus(s); setError('');
      }}>{tr('scale_rename')}</Btn>}
      <Btn variant="ghost" disabled={!status || busy} aria-pressed={s.mode === 'any'} onClick={() => act('any')}>{tr('scale_use_any')}{s.mode === 'any' ? ' ✓' : ''}</Btn>
    </div>}
    {renameStatus && <form style={{ marginTop: 14 }} onSubmit={async event => {
      event.preventDefault();
      if (await act('rename', { name: nameDraft, kind: renameStatus.target.kind, address: renameStatus.target.address }, renameStatus)) setRenameStatus(null);
    }}>
      <label className="sd-rowsub" htmlFor="scale-custom-name">{tr('scale_name')}</label>
      <input id="scale-custom-name" className="sd-input" value={nameDraft} maxLength={128} required autoFocus
        disabled={busy || s.active} onInput={event => setNameDraft(event.target.value)} />
      <div className="sd-rowsub" style={{ marginTop: 6 }}>{tr('scale_name_help')}</div>
      <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
        <Btn type="submit" disabled={busy || s.active || !nameDraft.trim()}>{tr('scale_name_save')}</Btn>
        <Btn type="button" variant="ghost" disabled={busy} onClick={() => setRenameStatus(null)}>{tr('cancel')}</Btn>
      </div>
    </form>}
    {s.active && <div style={{ marginTop: 14 }}>
      <div className="sd-rowsub">{tr('scale_identify_help')}</div>
      {!s.owned && <div role="status">{tr('scale_other_client')}</div>}
      {working && <div role="status" style={{ marginTop: 10 }}>{tr('scale_state_' + s.state)}</div>}
      {s.state === 'choosing' && <div>
        {!(s.candidates || []).length && <div className="sd-rowsub">{tr('scale_empty')}</div>}
        {(s.candidates || []).map(candidate => <div className="sd-row" key={candidate.id}>
          <div><div className="sd-rowlabel">{candidate.name}</div>
            <div className="sd-rowsub">{candidate.kind} · {candidate.address}{candidate.saved ? ' · ' + tr('saved') : ''}{candidate.current ? ' · ' + tr('connected') : ''}</div></div>
          <Btn className="sm" disabled={!canEdit} onClick={() => act('select', { candidate_id: candidate.id })}>{tr('scale_select_tare')}</Btn>
        </div>)}
        <Btn variant="ghost" disabled={!canEdit} onClick={() => act('scan')}>{tr('scale_scan_again')}</Btn>
      </div>}
      {s.state === 'awaiting_confirmation' && <div style={{ marginTop: 12 }}>
        <div className="sd-rowlabel">{s.candidate?.name}</div>
        <div className="sd-rowsub">{s.candidate?.address} · {s.weight != null ? Number(s.weight).toFixed(1) + ' g' : tr('scale_no_weight')}</div>
        <p>{tr('scale_confirm_question')}</p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          <Btn disabled={!canEdit || !s.can_confirm} onClick={() => act('confirm')}>{tr('scale_save')}</Btn>
          <Btn variant="ghost" disabled={!canEdit} onClick={() => act('tare')}>{tr('scale_tare_again')}</Btn>
          <Btn variant="ghost" disabled={!canEdit} onClick={() => act('scan')}>{tr('scale_choose_another')}</Btn>
        </div>
      </div>}
      <Btn variant="ghost" style={{ marginTop: 12 }} disabled={!canEdit || s.state === 'cancelling'} onClick={() => act('cancel')}>{tr('cancel')}</Btn>
    </div>}
  </Card>;
}

// Only the selected section mounts live controls. Backup drafts survive section
// and main-tab navigation; scale setup keeps its existing cancellation on exit.
const SETTINGS_SECTIONS = [
  { id: 'display', icon: 'display', group: 'preferences' },
  { id: 'scale', icon: 'scale', group: 'preferences' },
  { id: 'wifi', icon: 'wifi', group: 'preferences' },
  { id: 'backups', icon: 'storage', group: 'system' },
  { id: 'updates', icon: 'download', group: 'system' },
  { id: 'about', icon: 'support', group: 'system' },
];
function SideButtonSettingsCard({ app }) {
  const supplied = app.data.settings.side_buttons || null;
  const [state, setState] = useState(supplied || {});
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { setState(supplied || {}); }, [supplied]);
  useEffect(() => {
    if (!state.diagnostics) return undefined;
    let cancelled = false;
    const poll = async () => {
      try {
        const next = await api('/api/side-buttons');
        if (!cancelled) { setState(next); setError(''); }
      } catch (failure) { if (!cancelled) setError(failure.message); }
    };
    const timer = window.setInterval(poll, 500);
    poll();
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [state.diagnostics]);
  if (!supplied?.available) return null;
  const preferences = state.preferences || supplied.preferences || {};
  const busy = saving || state.busy;
  const send = async (path, payload = {}, method = 'POST') => {
    if (saving) return;
    setSaving(true); setError('');
    try {
      setState(await api('/api/side-buttons' + path, { method, body: JSON.stringify(payload) }));
    } catch (failure) { setError(failure.message); }
    finally { setSaving(false); }
  };
  const change = patch => send('/settings', patch, 'PUT');
  const labelAction = action => tr('side_action_' + action);
  return <Card title={tr('side_controls')}>
    {state.buttons_available && <>
      <div className="sd-rowsub">{tr('side_controls_help')}</div>
      {['B1', 'B2', 'B3'].map(button => <Row key={button} label={tr('side_button') + ' ' + button}>
        <Select aria-label={tr('side_button') + ' ' + button} disabled={busy || state.diagnostics}
          value={(preferences.assignments || {})[button] || 'none'}
          onChange={action => change({ assignments: { [button]: action } })}
          options={(state.actions || []).map(action => ({ value: action, label: labelAction(action) }))} />
      </Row>)}
      <Row label={tr('side_lock')} sub={tr('side_lock_help')}>
        <Switch on={preferences.locked === true} disabled={busy || state.diagnostics}
          onChange={locked => change({ locked })} />
      </Row>
    </>}
    {state.led_available && <Row label={tr('side_quiet')} sub={tr('side_quiet_help')}>
      <Switch on={preferences.led_quiet === true} disabled={busy}
        onChange={led_quiet => change({ led_quiet })} />
    </Row>}
    {state.busy && <p className="sd-rowsub">{tr('side_busy')}</p>}
    {(error || state.save_error) && <p role="alert" className="sd-update-error">{error || state.save_error}</p>}
    {state.save_pending && <p role="status" className="sd-rowsub">{tr('settings_saving')}</p>}
    {state.buttons_available && <>
      <Btn variant="ghost" disabled={saving || (!state.diagnostics && busy)}
        onClick={() => send('/diagnostics', { enabled: !state.diagnostics })}>
        {tr(state.diagnostics ? 'side_test_done' : 'side_test')}
      </Btn>
      {state.diagnostics && <div role="status" aria-live="polite" style={{ marginTop: 12 }}>
        <p className="sd-rowsub">{tr('side_test_help')}</p>
        <div>{tr('side_pressed')}: {(state.pressed || []).join(', ') || tr('side_none')}</div>
        <ul>{(state.events || []).slice(-8).map((event, index) => <li key={index}>
          {event.button} · {tr('side_event_' + event.event)}
          {event.action && ' · ' + labelAction(event.action)}
        </li>)}</ul>
      </div>}
    </>}
    <Btn variant="ghost" disabled={busy || state.diagnostics} style={{ marginTop: 12 }}
      onClick={() => send('/reset')}>{tr('side_defaults')}</Btn>
  </Card>;
}

function SettingsScreen({ app, active = true }) {
  const [wide, setWide] = useState(() => window.matchMedia('(min-width: 760px)').matches);
  const [backupsVisited, setBackupsVisited] = useState(false);
  const [backupSummary, setBackupSummary] = useState('');
  const [storageSummary, setStorageSummary] = useState(null);
  const scroller = useRef(null), heading = useRef(null), overviewScroll = useRef(0), lastSection = useRef('display');
  const section = app.settingsSection || (wide ? 'display' : null);
  const showBackups = active && section === 'backups';
  useEffect(() => {
    const media = window.matchMedia('(min-width: 760px)');
    const change = () => {
      if (!media.matches && !app.settingsSection) app.setSettingsSection('display');
      setWide(media.matches);
    };
    media.addEventListener('change', change);
    return () => media.removeEventListener('change', change);
  }, [app.settingsSection]);
  useEffect(() => { if (showBackups) setBackupsVisited(true); }, [showBackups]);
  const open = id => {
    if (!section) overviewScroll.current = scroller.current?.scrollTop || 0;
    lastSection.current = id;
    app.setSettingsSection(id);
    if (scroller.current) scroller.current.scrollTop = 0;
  };
  const back = () => app.setSettingsSection(null);
  React.useLayoutEffect(() => {
    if (!active) return;
    if (section) {
      heading.current?.focus({ preventScroll: true });
    } else {
      scroller.current?.querySelector(`[data-settings-section="${lastSection.current}"]`)?.focus({ preventScroll: true });
      if (scroller.current) scroller.current.scrollTop = overviewScroll.current;
    }
  }, [section, active]);
  const s = app.data.settings;
  const disp = s.display;
  const physical = s.bbw_control_mode === 'physical_gpio6';
  const activeProfile = machineActiveProfile(app);
  const ss = s.screensaver || {};
  const device = s.device || {};
  const photoAlbum = ss.photo_album_supported === true;
  const uploadRef = useRef(null);
  const update = (s.updates && s.updates.status) || {};
  const updateAvailable = !!update.update_available;
  const updateBusy = ['checking', 'queued', 'installing'].includes(update.state);
  const checkedAt = update.checked_at ? new Date(update.checked_at) : null;
  const checkedLabel = checkedAt && !Number.isNaN(checkedAt.getTime())
    ? checkedAt.toLocaleString(app.lang === 'de' ? 'de-DE' : 'en-GB', { dateStyle: 'medium', timeStyle: 'short' })
    : '';
  const attention = sectionId => sectionId === 'updates' && updateAvailable ? tr('update_available')
    : sectionId === 'backups' && storageSummary && ['low', 'critical', 'read_only'].includes(storageSummary.status)
      ? managementText(storageSummary.status, app.lang) : '';
  const description = id => id === 'backups' && backupSummary ? backupSummary : tr('settings_' + id + '_summary');
  return <div ref={scroller} hidden={!active} className={'sd-body sd-scroll sd-settings-screen' + (section ? ' has-section' : '')}>
    <header className="sd-settings-header">
      <div className="sd-eyebrow">{tr('settings_device_preferences')}</div>
      <h1>{tr('tab_settings')}</h1>
      <p>{tr('settings_intro')}</p>
    </header>
    <div className="sd-settings-layout">
      <nav className="sd-settings-nav" aria-label={tr('tab_settings')}>
        {['preferences', 'system'].map(group => <div className="sd-settings-group" key={group}>
          <h2>{tr('settings_' + group)}</h2>
          <div className="sd-settings-links">{SETTINGS_SECTIONS.filter(item => item.group === group).map(item => <button
            type="button" key={item.id} data-settings-section={item.id}
            className={'sd-settings-link' + (section === item.id ? ' selected' : '')}
            aria-current={section === item.id ? 'page' : undefined} onClick={() => open(item.id)}>
            <span className="sd-settings-icon"><Icon name={item.icon} size={21} /></span>
            <span className="sd-settings-link-copy"><span className="sd-settings-link-title">{tr('settings_' + item.id)}</span>
              <span className="sd-settings-link-summary">{description(item.id)}</span>
              {attention(item.id) && <span className="sd-settings-attention">{attention(item.id)}</span>}
            </span><Icon name="chevron" size={16} />
          </button>)}</div>
        </div>)}
      </nav>
      <div className="sd-settings-content" hidden={!section}>
        <button type="button" className="sd-settings-back" onClick={back}><Icon name="back" size={16} />{tr('settings_back')}</button>
        <div className="sd-settings-save-status" role="status">{app.settingsSaving > 0 ? tr('settings_saving') : ''}</div>
        <h2 ref={heading} tabIndex={-1} className="sd-settings-title">{tr('settings_' + section)}</h2>
        {section === 'display' && <>
      <Card title={tr('display')} helpKey="display" onHelp={app.openHelp} apiNote="PATCH /settings (display)">
        <ApiChip>PATCH /settings · display</ApiChip>
        <div className="sd-settings-subtitle first">{tr('settings_appearance')}</div>
        <Row label={tr('theme')}>
          <Select value={disp.theme} onChange={v => app.setTheme(v)}
            options={disp.theme_options.map(o => ({ value: o.value, label: o.label }))} /></Row>
        <div className="sd-settings-subtitle">{tr('settings_device_display')}</div>
        {/* Brew screen layouts as small previews of the device display */}
        <div className="sd-row sd-preset-row"><div><div className="sd-rowlabel">{tr('brew_ui')}</div></div></div>
        <div className="sd-preset-tiles" role="radiogroup" aria-label={tr('brew_ui')}>
          {(disp.brew_ui_preset_options || []).map(o => {
            const on = (disp.brew_ui_preset || 'full') === o.value;
            return <button type="button" role="radio" aria-checked={on} key={o.value} className={'sd-preset-tile' + (on ? ' on' : '')}
              onClick={() => !on && app.setDisplay('brew_ui_preset', o.value)}>
              <span className={'sd-preset-preview ' + o.value} aria-hidden="true">
                {o.value === 'weight_focus' ? <><b>22.4</b><small>/ 36.0 g</small></>
                  : o.value === 'minimal' ? <><span className="row"><b>22.4 g</b><b>00:18</b></span><i /></>
                  : <><span className="cells"><em>36.0 / <b>22.4</b></em><em>00:18</em><em>Mia</em></span><i /></>}
              </span>
              <span className="sd-preset-name">{tr('brew_ui_' + o.value) || o.label}</span>
            </button>;
          })}
        </div>
        <Row label={tr('rotation')}>
          <Select value={String(disp.rotation)} onChange={v => app.setDisplay('rotation', +v)}
            options={[0, 90, 180, 270].map(n => ({ value: String(n), label: n + '°' }))} /></Row>

        <div style={{ padding: '14px 0 8px', borderTop: '1px solid var(--border-soft)' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
            <span className="sd-rowlabel">{tr('brightness')}</span>
            <span className="sd-readout" style={{ fontSize: 19 }}>{disp.brightness}%</span>
          </div>
          <input
            type="range"
            aria-label={tr('brightness')}
            className="sd-range"
            min={10}
            max={100}
            value={disp.brightness}
            style={{ '--fill': ((Number(disp.brightness) - 10) / 90 * 100) + '%' }}
            onPointerDown={app.beginDisplayBrightness}
            onTouchStart={app.beginDisplayBrightness}
            onChange={e => app.setDisplayBrightness(+e.target.value)}
            onPointerUp={app.flushDisplayBrightness}
            onPointerCancel={app.flushDisplayBrightness}
            onLostPointerCapture={app.flushDisplayBrightness}
            onTouchEnd={app.flushDisplayBrightness}
            onTouchCancel={app.flushDisplayBrightness}
            onKeyUp={app.flushDisplayBrightness}
            onBlur={app.flushDisplayBrightness}
          />
        </div>
        <Row label={tr('always_on')} sub={tr('always_on_sub')}><Switch on={disp.always_on} onChange={v => app.setDisplay('always_on', v)} /></Row>
        <Row label={tr('sleep_after')} sub={disp.always_on ? tr('settings_sleep_disabled') : null}>
          <Select value={String(disp.sleep_after_minutes)} onChange={v => app.setDisplay('sleep_after_minutes', +v)} disabled={disp.always_on}
            options={[1, 5, 10, 30].map(n => ({ value: String(n), label: n + ' ' + tr('minutes') }))} /></Row>
      </Card>

      <Card title={tr('screensaver')} apiNote="GET/PATCH /screensaver">
        <ApiChip>PATCH /screensaver</ApiChip>
        <div className="sd-fieldlabel">{tr('screensaver')}</div>
        <Select aria-label={tr('screensaver')} value={ss.mode || 'default'} onChange={v => app.setScreensaver('mode', v)}
          options={[
            { value: 'default', label: tr('ss_clock') },
            ...(photoAlbum ? [{ value: 'photo_album', label: tr('ss_photos') }] : []),
          ]} />
        {photoAlbum && ss.mode === 'photo_album' && (
          <div style={{ marginTop: 14 }}>
            <Row label={tr('interval')}><Select value={String(ss.photo_interval_s || 60)} onChange={v => app.setScreensaver('photo_interval_s', +v)} style={{ width: 120 }} options={(ss.intervals || [15, 30, 60, 120, 300, 600]).map(n => ({ value: String(n), label: n < 60 ? n + 's' : (n / 60) + ' ' + tr('minutes') }))} /></Row>
            <input ref={uploadRef} type="file" accept="image/*" multiple style={{ display: 'none' }} onChange={e => app.uploadScreensaverPhotos(e.target.files)} />
            <Btn variant="ghost" className="block" style={{ marginTop: 12 }} onClick={() => uploadRef.current && uploadRef.current.click()}><Icon name="upload" size={18} /> {tr('upload_photo')}</Btn>
            {(ss.photos || []).map(photo => (
              <div className="sd-item" key={photo.name} style={{ paddingLeft: 0, paddingRight: 0 }}>
                <img src={photo.url} alt="" style={{ width: 52, height: 38, objectFit: 'cover', borderRadius: 6, border: '1px solid var(--border)' }} />
                <div style={{ flex: 1 }}><span className="sd-itemname">{photo.name.replace(/^\d+-/, '')}</span></div>
              </div>
            ))}
          </div>
        )}
        {!photoAlbum && <div className="sd-rowsub" style={{ marginTop: 10 }}>{tr('unavailable')}</div>}
      </Card>

      <Card title={tr('language')}>
        <Segmented value={app.lang} onChange={v => app.setLang(v)} options={[{ value: 'en', label: 'English' }, { value: 'de', label: 'Deutsch' }]} />
        <div className="sd-rowsub" style={{ marginTop: 10 }}>{tr('language_scope')}</div>
      </Card>

        </>}
        {active && section === 'scale' && <><ScaleSettingsCard app={app} />
      <SideButtonSettingsCard app={app} />
      <Card title={tr('brew_control')} helpKey="bbw" onHelp={app.openHelp} apiNote="PATCH /settings (bbw_enabled)"
        right={activeProfile && <Pill variant={machineProfileBrewsByTime(activeProfile) ? 'good' : ''} dot>{machineBrewModeLabel(activeProfile)}</Pill>}>
        <ApiChip>PATCH /settings · bbw_enabled</ApiChip>
        {activeProfile && <div className="sd-rowsub" style={{ marginBottom: 8 }}>{activeProfile.name} · {machineBrewModeLabel(activeProfile)}</div>}
        <Row label={tr('bbw_enable')} sub={physical ? tr('bbw_physical') : null}>
          <Switch on={s.bbw_enabled} disabled={physical} onChange={v => app.setSetting('bbw_enabled', v)} />
        </Row>
      </Card>

        </>}
        {active && section === 'wifi' && <WifiScreen app={app} embedded />}
        {section === 'updates' && <>
      <Card title={tr('updates')} helpKey="updates" onHelp={app.openHelp} apiNote="GET/POST /updates"
        className={updateAvailable ? 'sd-update-card available' : 'sd-update-card'}
        right={updateAvailable ? <Pill variant="ok" dot>{tr('update_available')}</Pill> : null}>
        <ApiChip>PATCH /settings · updates</ApiChip>
        <div className="sd-update-status" aria-live="polite">
          <div className="sd-update-versions">
            <div><span>{tr('installed_version')}</span><strong>v{update.current_version || s.version}</strong></div>
            {update.target_version && update.target_version !== (update.current_version || s.version) &&
              <div><span>{tr('available_version')}</span><strong>v{update.target_version}</strong></div>}
          </div>
          <div className="sd-update-message">
            {updateBusy && <span className="sd-spinner inline" aria-hidden="true" />}
            <span>{updateStatusText(update)}</span>
          </div>
          {update.error && <div className="sd-update-error">{update.error}</div>}
          {checkedLabel && <div className="sd-micro">{tr('last_checked')} · {checkedLabel}</div>}
        </div>
        <div className="sd-update-actions">
          <Btn variant="ghost" disabled={!s.updates.updates_enabled || updateBusy} onClick={() => app.checkUpdates(true)}>{update.state === 'checking' ? tr('checking_updates') : tr('check_now')}</Btn>
          {updateAvailable && <Btn variant="ghost" onClick={app.openUpdateNotes}>{tr('update_whats_new')}</Btn>}
          {updateAvailable && <Btn variant="primary" disabled={updateBusy || s.shot_active} onClick={app.openUpdateInstall}>{tr('update_now')}</Btn>}
        </div>
        {updateAvailable && s.shot_active && <div className="sd-rowsub" style={{ marginTop: 8 }}>{tr('update_after_brew')}</div>}
        <div className="sd-settings-subtitle">{tr('settings_update_preferences')}</div>
        <Row label={tr('updates_enabled')}><Switch on={s.updates.updates_enabled} disabled={updateBusy} onChange={v => app.setUpdates('updates_enabled', v)} /></Row>
        <Row label={tr('beta_updates')} sub={tr('beta_updates_sub')}><Switch on={s.updates.beta_updates} disabled={!s.updates.updates_enabled || updateBusy} onChange={v => app.setUpdates('beta_updates', v)} /></Row>
        <Row label={tr('auto_update')}><Switch on={s.updates.auto_update} disabled={!s.updates.updates_enabled || updateBusy} onChange={v => app.setUpdates('auto_update', v)} /></Row>
      </Card>

        </>}
        {(backupsVisited || showBackups) && <div hidden={!showBackups} className="sd-settings-backups">
          <BackupRestoreCard app={app} visible={showBackups} enabled={active} onSummary={setBackupSummary} />
          <StorageCard app={app} visible={showBackups} onSummary={setStorageSummary} compact />
        </div>}
        {section === 'about' && <>
      <Card title={tr('about')}>
        <Row label={tr('version')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{s.version}</span></Row>
        {device.hostname && <Row label={tr('device_name')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.hostname}</span></Row>}
        {device.local_url && <Row label={tr('local_url')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.local_url}</span></Row>}
        {device.device_short_id && <Row label={tr('device_id')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.device_short_id}</span></Row>}
        {device.display_size && <Row label={tr('display_size')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.display_size}</span></Row>}
        {device.hardware && <Row label={tr('hardware')}><span className="sd-mono" style={{ color: 'var(--fg-dim)' }}>{device.hardware}</span></Row>}
        <div style={{ marginTop: 12 }}>
          <Btn variant="ghost" className="block sm" onClick={() => { window.location.href = '/license'; }}>{tr('lic_title')}</Btn>
          <Btn variant="ghost" className="block sm" style={{ marginTop: 8 }} onClick={app.openDiag}><Icon name="support" size={18} /> {tr('nav_diag')}</Btn>
        </div>
      </Card>
        </>}
      </div>
    </div>
  </div>;
}

function UpdateNotesModal({ app }) {
  const update = app.data.settings.updates.status || {};
  const selected = app.updateNotesModal;
  const changed = !update.update_available || update.target_version !== selected.targetVersion
    || update.channel !== selected.channel
    || (!!selected.manifest && !!update.manifest_sha256 && update.manifest_sha256 !== selected.manifest);
  useEffect(() => { if (changed) app.closeUpdateNotes(); }, [changed]);
  if (changed) return null;
  const notes = Array.isArray(update.release_notes) ? update.release_notes.filter(n => typeof n === 'string') : [];
  const loading = !update.notes_loaded && update.state === 'checking';
  return <Modal title={`${tr('update_whats_new_in')} ${selected.targetVersion}`}
    className="sd-update-notes-modal" onClose={app.closeUpdateNotes}
    footer={<Btn variant="ghost" className="block" onClick={app.closeUpdateNotes}>{tr('close')}</Btn>}>
    {notes.length > 0 ? <ul className="sd-release-notes">{notes.map((note, index) => <li key={index}>{note}</li>)}</ul>
      : <p role="status">{loading ? tr('update_notes_loading') : update.notes_loaded ? tr('update_notes_empty') : tr('update_notes_unavailable')}</p>}
    {!loading && !update.notes_loaded && <Btn variant="ghost" onClick={() => app.checkUpdates(true)}>{tr('retry')}</Btn>}
  </Modal>;
}

function UpdateInstallModal({ app }) {
  const update = (app.data.settings.updates && app.data.settings.updates.status) || {};
  const modal = app.updateModal || {};
  const target = modal.targetVersion || update.target_version || '';
  const busy = ['checking', 'queued', 'installing'].includes(update.state)
    || (modal.phase === 'progress' && update.state === 'available');
  const installed = update.state === 'installed' && update.current_version === target;
  const failed = update.state === 'error';
  const progressMessage = modal.phase === 'progress' && update.state === 'available'
    ? `${tr('preparing_update')} v${target}`
    : updateStatusText(update);

  if (modal.phase === 'confirm') {
    return (
      <Modal title={tr('confirm_update_title')} onClose={app.closeUpdateInstall} footer={<>
        <Btn variant="ghost" className="block" onClick={app.closeUpdateInstall}>{tr('cancel')}</Btn>
        <Btn variant="primary" className="block" onClick={app.installUpdate}>{tr('install_update')}</Btn>
      </>}>
        <div className="sd-update-confirm-version">v{target}</div>
        <p className="sd-update-confirm-copy">{tr('update_restart_warning')}</p>
        <div className="sd-update-power-warning">{tr('update_power_warning')}</div>
      </Modal>
    );
  }

  const footer = (installed || failed)
    ? <Btn variant="ghost" className="block" onClick={app.closeUpdateInstall}>{tr('dismiss')}</Btn>
    : null;
  return (
    <Modal title={installed ? tr('update_complete') : failed ? tr('update_failed') : tr('installing_update')}
      onClose={app.closeUpdateInstall} dismissible={!busy} footer={footer}>
      <div className="sd-update-progress" aria-live="polite">
        {busy && <div className="sd-spinner" aria-hidden="true" />}
        {installed && <Icon name="check" size={42} color="var(--success)" />}
        {failed && <Icon name="close" size={38} color="var(--destructive)" />}
        <div className="sd-serif">{installed ? `${tr('updated_to')} v${target}` : progressMessage}</div>
        {busy && <p>{tr('update_reconnect_notice')}</p>}
        {failed && update.error && <p>{update.error}</p>}
        {busy && <div className="sd-update-power-warning">{tr('update_power_warning')}</div>}
      </div>
    </Modal>
  );
}


Object.assign(window, { SettingsScreen, UpdateInstallModal, UpdateNotesModal, BackupRestoreCard, SideButtonSettingsCard });
