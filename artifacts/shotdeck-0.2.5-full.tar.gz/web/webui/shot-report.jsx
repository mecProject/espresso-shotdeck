// Offline Shot Journal PDF export. Uses saved data and bundled fonts.
const SHOT_PDF_COLORS = {
  bg: '#ffffff', card: '#ffffff', inset: '#faf8f5', border: '#d9d0c5',
  'border-soft': '#eae4dc', fg: '#251f19', 'fg-dim': '#695d50', brass: '#956027',
  success: '#286b43', 'success-soft': '#e8f3eb', 'flow-curve': '#a96923',
  'weight-curve': '#287ba0', 'ideal-curve': '#8b7861', grid: '#e4ddd3',
};

function shotRangeParams(from = '', to = '') {
  if (from && to && from > to) throw new Error('Invalid date range');
  const params = new URLSearchParams();
  for (const [key, value, nextDay] of [['start', from, false], ['end', to, true]]) {
    if (!value) continue;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error('Invalid date');
    const [y, m, d] = value.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    if (date.getFullYear() !== y || date.getMonth() !== m - 1 || date.getDate() !== d) throw new Error('Invalid date');
    // Calendar arithmetic preserves inclusive end dates across DST changes.
    if (nextDay) date.setDate(date.getDate() + 1);
    params.set(key, date.toISOString());
  }
  return params;
}

async function loadShotRange(fetchApi, from = '', to = '', all = false) {
  const params = shotRangeParams(from, to);
  const limit = all ? 200 : 50;
  params.set('limit', String(limit));
  if (all) params.set('paged', '1');
  const rows = [], ids = new Set(); let total = null;
  while (true) {
    params.set('offset', String(rows.length));
    const data = await fetchApi('/api/shots?' + params);
    if (!Array.isArray(data.shots)) throw new Error('Missing shot list');
    if (all) {
      if (!Number.isInteger(data.total) || data.total < 0) throw new Error('Missing shot count');
      if (total != null && data.total !== total) throw new Error('Shot history changed; retry export');
      total = data.total;
    }
    for (const shot of data.shots) {
      // Reject overlapping pages instead of silently including duplicate shots.
      if (ids.has(shot.id)) throw new Error('Shot history changed; retry export');
      ids.add(shot.id); rows.push(shot);
    }
    if (!all || data.shots.length < limit) {
      if (all && rows.length !== total) throw new Error('Incomplete shot history');
      return rows;
    }
    if (!Number.isInteger(data.snapshot) || data.snapshot < 0) throw new Error('Missing shot snapshot');
    params.set('snapshot', String(data.snapshot));
  }
}

function summarizeShotReport(shots) {
  const numeric = v => typeof v === 'number' && Number.isFinite(v);
  const metric = (key, positive = false) => {
    const values = shots.map(s => s[key]).filter(v => numeric(v) && (positive ? v > 0 : v >= 0));
    return { count: values.length, total: values.reduce((a, b) => a + b, 0),
      mean: values.length ? values.reduce((a, b) => a + b, 0) / values.length : null };
  };
  const groups = key => {
    const counts = new Map();
    for (const shot of shots) {
      const name = String(shot[key] || '').trim();
      counts.set(name, (counts.get(name) || 0) + 1);
    }
    return [...counts].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
  };
  const dates = shots.map(s => new Date(s.started_at)).filter(d => !Number.isNaN(d.getTime()));
  const days = new Set(dates.map(d => d.toLocaleDateString('en-CA',typeof window!=='undefined'&&window.__sdTimezone?{timeZone:window.__sdTimezone}:{}))).size;
  const timed = shots.filter(s => numeric(s.duration_s) && s.duration_s >= 0 && numeric(s.target_time_min_s)
    && numeric(s.target_time_max_s) && s.target_time_min_s >= 0 && s.target_time_max_s > 0 && s.target_time_max_s >= s.target_time_min_s);
  return { count: shots.length, days, yield: metric('final_weight_g'), duration: metric('duration_s'),
    flow: metric('average_flow_g_s', true), temperature: metric('brew_temperature_c', true),
    inWindow: timed.filter(s => s.duration_s >= s.target_time_min_s && s.duration_s <= s.target_time_max_s).length,
    timed: timed.length, profiles: groups('profile_name'), users: groups('user_name'),
    first: dates.length ? new Date(dates.reduce((n, d) => Math.min(n, Number(d)), Infinity)) : null,
    last: dates.length ? new Date(dates.reduce((n, d) => Math.max(n, Number(d)), -Infinity)) : null };
}

// Journal pages use the existing offline canvas fonts and saved shot data.
// Measurements are in logical page pixels (1000 x 1414); output is 2x A4.
const JOURNAL_TEXT = {
  en: { title:'Shot journal', overview:'Overview', log:'Shot log', details:'Shot details', photos:'Grinder setting photos', best:'Highest-rated shot per coffee', bestNote:'Selected from rated shots in this export. Equal ratings use the most recent shot.', median:'Median dose / yield', medianRatio:'Median ratio', averageTime:'Average shot time', averageRating:'Average rating', taste:'Taste', tasted:'tasted', rated:'rated', window:'in target window', balanced:'Balanced / sweet', sour:'Sour / thin', bitter:'Bitter / ashy', other:'Other tastes', notTasted:'Not tasted', notRated:'Not rated', noCoffee:'No coffee recorded', unknown:'Not recorded', chart:'Shot time vs. target window', chartNote:'Oldest first. Each marker identifies a shot; the shaded bar is its target window.', targetWindow:'Target window', profiles:'Profiles', users:'Brewed by', more:'Other', shots:'shots', days:'days with shots', created:'Created', page:'Page', of:'of', see:'See page', shot:'Shot', coffee:'Coffee / profile', grind:'Grind', doseYield:'Dose → yield', ratio:'Ratio', time:'Time', flow:'Avg. flow', flowShort:'Avg. flow', tempShort:'Setpoint', temp:'Brew setpoint', rating:'Rating', dose:'Dose', yield:'Yield', target:'Target', fast:'fast', slow:'slow', inWindow:'in target window', preparation:'Coffee & preparation', roaster:'Roaster / roast', roastDate:'Roast date', roastAge:'days after roasting', grinder:'Grinder', burrs:'Burrs', rpm:'RPM', prebrew:'Pre-brewing', mode:'Mode', machine:'Machine', photo:'Grinder photo', profile:'Profile', curve:'Extraction', curveFlow:'Flow', weight:'Weight', ideal:'Ideal flow', noCurve:'No curve data recorded', scales:'Same chart scales within each coffee / profile.', tasting:'Tasting', notes:'Notes', noNotes:'No tasting notes recorded.', profileNote:'Profile note', currentNote:'Current profile note', next:'Next shot', issue:'Issue', visual:'Visual', prep:'Preparation', continued:'continued', order:'Oldest first. ▲ slow / ▼ fast relative to the saved time window.', footer:'Temperature is the saved brew setpoint, not a measured cup temperature.', selected:'Selected dates', filters:'Filters', dates:'Dates', timezone:'Time zone', manual:'* Corrected after the shot', weightMode:'Brew by weight', timeMode:'Brew by time', noRated:'No rated shots with a recorded coffee.', counts:'Recorded values only.', numericMedians:'Separate medians, not a suggested recipe.', notesFollow:'Additional notes follow on the next page.', full:'Full journal', compact:'Overview + log', format:'PDF contents', brewDays:'Days', under:'Under-extracted', over:'Over-extracted' },
  de: { title:'Shot-Journal', overview:'Überblick', log:'Shot-Protokoll', details:'Shot-Details', photos:'Fotos der Mühleneinstellung', best:'Am besten bewerteter Shot je Kaffee', bestNote:'Aus den bewerteten Shots dieses Exports. Bei Gleichstand zählt der neueste Shot.', median:'Median Dosis / Menge', medianRatio:'Median-Verhältnis', averageTime:'Ø Shot-Zeit', averageRating:'Ø Bewertung', taste:'Geschmack', tasted:'verkostet', rated:'bewertet', window:'im Zielfenster', balanced:'Ausgewogen / süß', sour:'Sauer / dünn', bitter:'Bitter / aschig', other:'Andere Geschmäcker', notTasted:'Nicht probiert', notRated:'Unbewertet', noCoffee:'Kein Kaffee erfasst', unknown:'Nicht erfasst', chart:'Shot-Zeit im Vergleich zum Zielfenster', chartNote:'Älteste zuerst. Jedes Symbol steht für einen Shot; der Balken zeigt sein Zielfenster.', targetWindow:'Zielfenster', profiles:'Profile', users:'Gebrüht von', more:'Weitere', shots:'Shots', days:'Tage mit Shots', created:'Erstellt', page:'Seite', of:'von', see:'Siehe Seite', shot:'Shot', coffee:'Kaffee / Profil', grind:'Mahlgrad', doseYield:'Dosis → Menge', ratio:'Verh.', time:'Zeit', flow:'Ø Durchfluss', flowShort:'Ø Durchfl.', tempShort:'Solltemp.', temp:'Brüh-Sollwert', rating:'Bewertung', dose:'Dosis', yield:'Getränkemenge', target:'Ziel', fast:'schnell', slow:'langsam', inWindow:'im Zielfenster', preparation:'Kaffee & Zubereitung', roaster:'Röster / Röstung', roastDate:'Röstdatum', roastAge:'Tage nach Röstung', grinder:'Mühle', burrs:'Mahlscheiben', rpm:'U/min', prebrew:'Vorbrühen', mode:'Modus', machine:'Maschine', photo:'Mühlenfoto', profile:'Profil', curve:'Extraktion', curveFlow:'Durchfluss', weight:'Gewicht', ideal:'Idealer Durchfluss', noCurve:'Keine Kurvendaten erfasst', scales:'Gleiche Diagrammskalen je Kaffee / Profil.', tasting:'Verkostung', notes:'Notizen', noNotes:'Keine Verkostungsnotizen erfasst.', profileNote:'Profilnotiz', currentNote:'Aktuelle Profilnotiz', next:'Nächster Shot', issue:'Problem', visual:'Optik', prep:'Zubereitung', continued:'Fortsetzung', order:'Älteste zuerst. ▲ langsam / ▼ schnell bezogen auf das gespeicherte Zielfenster.', footer:'Temperatur: gespeicherter Brüh-Sollwert, keine gemessene Tassentemperatur.', selected:'Gewählter Zeitraum', filters:'Filter', dates:'Daten', timezone:'Zeitzone', manual:'* Nach dem Shot korrigiert', weightMode:'Brühen nach Gewicht', timeMode:'Brühen nach Zeit', noRated:'Keine bewerteten Shots mit erfasstem Kaffee.', counts:'Nur erfasste Werte.', numericMedians:'Separate Mediane, keine Rezeptempfehlung.', notesFollow:'Weitere Notizen folgen auf der nächsten Seite.', full:'Vollständiges Journal', compact:'Überblick + Protokoll', format:'PDF-Inhalt', brewDays:'Tage', under:'Unterextrahiert', over:'Überextrahiert' },
};
const JOURNAL_W = 1000, JOURNAL_H = 1414, JOURNAL_TOP = 118, JOURNAL_BOTTOM = 1326;
const journalNumber = value => typeof value === 'number' && Number.isFinite(value) ? value : null;
const journalPositive = value => journalNumber(value) > 0 ? value : null;
function journalMedian(values) {
  const sorted = values.filter(v => journalNumber(v) != null).sort((a,b) => a-b), n = sorted.length;
  return n ? (sorted[Math.floor((n-1)/2)] + sorted[Math.floor(n/2)]) / 2 : null;
}
function journalTaste(value) {
  return ['balanced','sweet'].includes(value) ? 0 : ['sour','thin','hollow'].includes(value) ? 1
    : ['bitter','ashy'].includes(value) ? 2 : !value || value === 'not_tasted' ? 4 : 3;
}
function journalRating(shot) {
  const value = shot.feedback ? shot.feedback.rating : shot.rating;
  return Number.isInteger(value) && value >= 1 && value <= 5 ? value : null;
}
function journalWindow(shot) {
  const min = journalNumber(shot.target_time_min_s), max = journalPositive(shot.target_time_max_s);
  return min != null && min >= 0 && max != null && max >= min ? [min,max] : null;
}
function journalFormat(lang = 'en', timezone = window.__sdTimezone) {
  const t = JOURNAL_TEXT[lang] || JOURNAL_TEXT.en, locale = lang === 'de' ? 'de-DE' : 'en-GB';
  const fmt = (n, digits = 1) => journalNumber(n) == null ? '—' : n.toLocaleString(locale,{minimumFractionDigits:digits,maximumFractionDigits:digits});
  const date = (value, options = {}) => {
    if (!value) return '—';
    const d = new Date(value); return Number.isNaN(+d) ? '—' : d.toLocaleDateString(locale,{day:'numeric',month:'short',...(timezone?{timeZone:timezone}:{}),...options});
  };
  const time = value => !value || Number.isNaN(+new Date(value)) ? '—' : new Date(value).toLocaleTimeString(locale,{hour:'2-digit',minute:'2-digit',...(timezone?{timeZone:timezone}:{})});
  // Calendar dates (e.g. roast dates) are not instants and must not shift zones.
  const calendar = value => /^\d{4}-\d{2}-\d{2}$/.test(value || '') ? date(value+'T12:00:00Z',{year:'numeric',timeZone:'UTC'}) : String(value || '—');
  const label = value => value === 'under_extraction' ? t.under : value === 'over_extraction' ? t.over
    : (typeof FB_LABELS !== 'undefined' && (FB_LABELS[lang] || FB_LABELS.en)[value]) || String(value || '').replace(/_/g,' ');
  // Grind settings are free text: preserve dial labels such as "1.2.0" or "4.2".
  const grind = value => typeof value === 'number' ? fmt(value) : String(value || '—');
  return {t,fmt,date,time,calendar,label,grind,timezone,lang};
}
function journalModels(shots, {profiles = [], smoothing = 10} = {}) {
  const sorted = shots.slice().sort((a,b) => {
    const da = Date.parse(a.started_at), db = Date.parse(b.started_at);
    return (Number.isFinite(da)?da:Infinity) - (Number.isFinite(db)?db:Infinity) || Number(a.id)-Number(b.id);
  });
  const scales = new Map();
  const models = sorted.map(shot => {
    const coffee = shot.coffee || {}, profile = shot.settings?.profile || {}, bean = coffee.bean || {};
    const dose = journalPositive(coffee.dose_g) ?? (journalPositive(shot.grinder_telemetry?.grind?.grind_weight) == null ? null : shot.grinder_telemetry.grind.grind_weight/1000);
    const final = journalNumber(shot.final_weight_g), ratio = dose && final >= 0 && final != null ? final/dose : null;
    const raw = (shot.samples || []).filter(s => ['time_s','weight_g','flow_g_s'].every(k => journalNumber(s[k]) != null) && s.time_s >= 0).slice().sort((a,b)=>a.time_s-b.time_s);
    const samples = typeof postTareSamples === 'function' ? postTareSamples(raw,shot.settings?.shot_validity) : raw;
    const flow = typeof smoothFlowSamples === 'function' ? smoothFlowSamples(samples,smoothing) : samples;
    const ideal = profile.ideal_flow_enabled ? (profile.ideal_flow_profile || []).filter(s=>journalNumber(s.time_s)!=null && s.time_s>=0 && journalNumber(s.flow_g_s)!=null).slice().sort((a,b)=>a.time_s-b.time_s) : [];
    const coffeeKey = coffee.bean_id || bean.id || (bean.name ? JSON.stringify([bean.roaster || '',bean.name]) : null);
    const group = JSON.stringify([coffeeKey,shot.profile_name || '']);
    const scale = scales.get(group) || {time:5,flow:1,weight:10};
    for (const s of [...flow,...ideal]) { scale.time=Math.max(scale.time,s.time_s);scale.flow=Math.max(scale.flow,s.flow_g_s); }
    for (const s of samples) scale.weight=Math.max(scale.weight,s.weight_g);
    scale.time=Math.max(scale.time,journalNumber(shot.duration_s)||0,journalWindow(shot)?.[1]||0);
    scale.weight=Math.max(scale.weight,final||0,journalPositive(shot.target_weight_g)||0);
    scales.set(group,scale);
    return {shot,coffee,profile,bean,dose,ratio,samples,flow,ideal,group,coffeeKey,rating:journalRating(shot),taste:journalTaste(shot.feedback?.taste ?? shot.taste),
      note:typeof shotProfileNote==='function'?shotProfileNote(shot,profiles):{text:profile.comment||'',current:false}};
  });
  for (const scale of scales.values()) {
    scale.time=Math.ceil(scale.time/5)*5; scale.flow=Math.ceil(scale.flow*1.08/4)*4; scale.weight=Math.ceil(scale.weight*1.08/20)*20;
  }
  for (const m of models) m.scale=scales.get(m.group);
  return models;
}
function journalBest(models) {
  const best = new Map();
  for (const m of models) if (m.coffeeKey && m.rating != null) {
    const current=best.get(m.coffeeKey);
    if (!current || m.rating>=current.rating) best.set(m.coffeeKey,m);
  }
  return [...best.values()];
}

function journalPainter(canvas) {
  const ctx=canvas.getContext('2d'); if(!ctx)throw Error('Canvas unavailable');
  const c=SHOT_PDF_COLORS;
  const font=(size,face='sans') => `${face==='bold'||face==='number'?'600 ':face==='italic'?'italic ':''}${size}px ${face==='serif'||face==='italic'?'Fraunces, Georgia, serif':face==='number'?'"Barlow Semi Condensed", sans-serif':'Barlow, sans-serif'}`;
  const measure=(s,size=16,face='sans')=>{ctx.font=font(size,face);return ctx.measureText(String(s)).width;};
  const text=(s,x,y,size=16,color=c.fg,face='sans',align='left')=>{ctx.font=font(size,face);ctx.fillStyle=color;ctx.textAlign=align;ctx.textBaseline='top';ctx.fillText(String(s),x,y);};
  const wrap=(s,w,size=16,face='sans')=>{
    const lines=[];
    for(const paragraph of String(s ?? '').split(/\r?\n/)) {
      let line='';
      for(const word of paragraph.split(/\s+/).filter(Boolean)) {
        if(line && measure(line+' '+word,size,face)>w){lines.push(line);line='';}
        if(measure(word,size,face)>w){for(const char of Array.from(word)){if(line && measure(line+char,size,face)>w){lines.push(line);line='';}line+=char;}}
        else line+=(line?' ':'')+word;
      }
      lines.push(line);
    }
    return lines;
  };
  const paragraph=(s,x,y,w,size=16,color=c.fg,face='sans',leading=size*1.3)=>{const lines=wrap(s,w,size,face);lines.forEach((line,i)=>text(line,x,y+i*leading,size,color,face));return lines.length*leading;};
  const line=(x,y,x2,y2,color=c.border)=>{ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x2,y2);ctx.strokeStyle=color;ctx.lineWidth=1;ctx.stroke();};
  const box=(x,y,w,h,fill=c.inset,border=c.border)=>{ctx.beginPath();ctx.roundRect(x,y,w,h,10);ctx.fillStyle=fill;ctx.fill();if(border){ctx.strokeStyle=border;ctx.lineWidth=1;ctx.stroke();}};
  return {ctx,c,measure,text,wrap,paragraph,line,box};
}
async function journalAssets() {
  if(document.fonts)await Promise.all(['16px Barlow','600 16px Barlow','30px Fraunces','italic 30px Fraunces','600 32px "Barlow Semi Condensed"'].map(f=>document.fonts.load(f)));
  const logo=new Image();
  const loaded=await new Promise(resolve=>{const timer=setTimeout(()=>resolve(false),5000);logo.onload=()=>{clearTimeout(timer);resolve(true);};logo.onerror=()=>{clearTimeout(timer);resolve(false);};logo.src='/favicon.png';});
  return loaded?logo:null;
}
function journalFeedback(m,f) {
  const feedback=m.shot.feedback || {}, parts=[];
  for(const key of ['issue','visual','prep','grind_adjustment'])if(feedback[key] && !['none','normal'].includes(feedback[key]))parts.push(f.t[{grind_adjustment:'next'}[key]||key]+': '+f.label(feedback[key]));
  if(parts.length)parts.splice(0,parts.length,parts.join(' · '));
  if(feedback.notes)parts.push(String(feedback.notes));
  if(!parts.length)parts.push(f.t.noNotes);
  if(m.note.text)parts.push((m.note.current?f.t.currentNote:f.t.profileNote)+': '+m.note.text);
  if(Object.values(m.coffee.sources||{}).includes('manual'))parts.push(f.t.manual);
  return parts.join('\n');
}
function journalPreparation(m,f) {
  const {t}=f,{coffee:c,shot:s,profile:p,bean}=m;
  const mark=(key,value)=>String(value)+(c.sources?.[key]==='manual'?' *':'');
  const roast=({LR:f.lang==='de'?'Helle Röstung':'Light roast',MR:f.lang==='de'?'Mittlere Röstung':'Medium roast',DR:f.lang==='de'?'Dunkle Röstung':'Dark roast'})[bean.roast_type||s.roast]||bean.roast_type||s.roast;
  const entries=[];
  if(bean.roaster||roast)entries.push([t.roaster,[bean.roaster,roast].filter(Boolean).join(' · ')]);
  if(c.roast_date)entries.push([t.roastDate,mark('roast_date',f.calendar(c.roast_date))]);
  if(c.grinder)entries.push([t.grinder,mark(c.grinder_id?'grinder_id':'grinder',c.grinder)]);
  if(c.burr)entries.push([t.burrs,mark('burr_id',c.burr)]);
  if(c.grinder_rpm!=null)entries.push([t.rpm,mark('grinder_rpm',f.fmt(c.grinder_rpm,0))]);
  entries.push([t.grind,mark('grind_setting',f.grind(c.grind_setting))]);
  if(typeof savedPrebrewText==='function')entries.push([t.prebrew,savedPrebrewText(p,f.lang)]);
  if(['weight','time'].includes(p.brew_control_mode))entries.push([t.mode,p.brew_control_mode==='time'?t.timeMode:t.weightMode]);
  const machine=s.settings?.machine?.machine;
  if(machine?.name||machine?.model_name)entries.push([t.machine,machine.name||machine.model_name]);
  if(m.photoIncluded)entries.push([t.photo,'@photo']);
  return entries;
}
function journalDetailLayout(m,p,f) {
  const title=p.wrap((m.bean.name||f.t.noCoffee)+(m.coffee.sources?.bean_id==='manual'?' *':''),650,27,'serif');
  const subtitle=p.wrap([`#${m.shot.id}`,f.date(m.shot.started_at),f.time(m.shot.started_at),m.shot.profile_name,m.shot.user_name].filter(Boolean).join(' · '),856,15);
  const fields=journalPreparation(m,f).map(([key,value])=>({key,lines:p.wrap(value,239,15)}));
  const body=Math.max(242,fields.reduce((h,row)=>h+Math.max(22,row.lines.length*19+5),0)+25);
  const notes=p.wrap(journalFeedback(m,f),816,16);
  const fixed=22+title.length*33+subtitle.length*20+14+86+18+body+16+40+22;
  return {m,title,subtitle,fields,body,notes,fixed,height:fixed+notes.length*21};
}
function journalLogLayout(m,p,f) {
  const window=journalWindow(m.shot), target=window?f.fmt(window[0],0)+'–'+f.fmt(window[1],0)+' s':'';
  const coffeeLines=p.wrap(m.bean.name||f.t.noCoffee,202,16,'bold');
  const profileLines=p.wrap([m.shot.profile_name,m.shot.user_name].filter(Boolean).join(' · '),202,16);
  const grindLines=p.wrap(f.grind(m.coffee.grind_setting),54,16);
  const taste=f.label(m.shot.feedback?.taste ?? m.shot.taste ?? 'not_tasted');
  const tasteLines=p.wrap(taste,120,16);
  const fdb=m.shot.feedback||{};
  const note=[fdb.grind_adjustment && fdb.grind_adjustment!=='none'?f.t.next+': '+f.label(fdb.grind_adjustment):'',fdb.notes||''].filter(Boolean).join(' · ');
  const notes=note?p.wrap(note,884,16):[];
  const fixed=Math.max((coffeeLines.length+profileLines.length)*20,grindLines.length*20,(tasteLines.length+1)*20,40)+12;
  return {m,coffeeLines,profileLines,grindLines,tasteLines,notes,target,fixed,height:fixed+notes.length*21+(notes.length?4:0)};
}
function journalPlan(models,p,f,{compact=false,filterDescription='',from='',to=''}={}) {
  const pages=[{kind:'overview',title:f.t.overview}],best=journalBest(models);
  // Extra coffee cards and chart panels are paginated; nothing silently vanishes.
  for(let i=3;i<best.length;i+=6)pages.push({kind:'best',title:f.t.best,models:best.slice(i,i+6)});
  for(let i=24;i<models.length;i+=72)pages.push({kind:'times',title:f.t.chart,models:models.slice(i,i+72)});
  const scope=[from||to?f.t.selected+': '+[from?f.calendar(from):'…',to?f.calendar(to):'…'].join(' – '):'',filterDescription?f.t.filters+': '+filterDescription:'',f.t.timezone+': '+(f.timezone||Intl.DateTimeFormat().resolvedOptions().timeZone)].filter(Boolean).join('\n');
  const scopeLines=p.wrap(scope,904,16);
  if(scopeLines.length>2)for(let i=0;i<scopeLines.length;i+=50)pages.push({kind:'scope',title:f.t.filters,lines:scopeLines.slice(i,i+50)});
  let log={kind:'log',title:f.t.log,rows:[],used:0};pages.push(log);
  for(const m of models) {
    let row=journalLogLayout(m,p,f);
    // An exceptionally long log entry continues with its shot ID and metadata.
    do {
      const capacity=JOURNAL_BOTTOM-234;
      const available=capacity-log.used;
      if(row.height>available && log.rows.length){log={kind:'log',title:f.t.log,rows:[],used:0};pages.push(log);continue;}
      const fit=Math.max(0,Math.floor((capacity-row.fixed-8)/21));
      if(row.notes.length>fit){
        if(!fit)throw Error('Shot metadata is too long to fit a journal page');
        const part={...row,notes:row.notes.slice(0,fit),height:row.fixed+fit*21+8};log.rows.push(part);log.used+=part.height;
        row={...row,notes:row.notes.slice(fit),continued:true,height:row.fixed+(row.notes.length-fit)*21+8};
        log={kind:'log',title:f.t.log,rows:[],used:0};pages.push(log);
      }else{log.rows.push(row);log.used+=row.height;break;}
    }while(true);
  }
  if(!compact) {
    let detail=null;
    for(const m of models){
      const card=journalDetailLayout(m,p,f),capacity=JOURNAL_BOTTOM-JOURNAL_TOP;
      if(card.fixed>capacity-50)throw Error('Shot metadata is too long to fit a journal page');
      const maxNotes=Math.floor((capacity-card.fixed)/21);
      const overflow=card.notes.slice(maxNotes);
      if(overflow.length){card.notes=card.notes.slice(0,maxNotes-1);card.height=card.fixed+(card.notes.length+1)*21;card.continued=true;}
      if(!detail||detail.cards.length>=2||detail.used+card.height+22>capacity){detail={kind:'details',title:f.t.details,cards:[],used:0};pages.push(detail);}
      detail.cards.push(card);detail.used+=card.height+22;
      if(overflow.length){
        // Keep the complete graph/recipe together; only extraordinary notes continue.
        const omitted=journalDetailLayout(m,p,f).notes.slice(card.notes.length);
        for(let i=0;i<omitted.length;i+=52)pages.push({kind:'notes',title:f.t.notes+' · #'+m.shot.id,m,lines:omitted.slice(i,i+52)});
        detail=null;
      }
    }
    const photos=models.filter(m=>m.photoIncluded);
    for(let i=0;i<photos.length;i+=4)pages.push({kind:'photos',title:f.t.photos,models:photos.slice(i,i+4)});
  }
  const shotPages=new Map(),photoPages=new Map(),logPages=new Map();
  pages.forEach((page,i)=>{for(const row of page.rows||[])if(!logPages.has(row.m.shot.id))logPages.set(row.m.shot.id,i);for(const card of page.cards||[])shotPages.set(card.m.shot.id,i);if(page.kind==='photos')for(const m of page.models)photoPages.set(m.shot.id,i);});
  return {pages,best,shotPages:compact?logPages:shotPages,photoPages,scopeLines};
}

function journalMarker(p,kind,x,y,r=5) {
  const colors=['#2c754c','#b18117','#923e30','#65558e','#70665d'];
  const ctx=p.ctx;ctx.beginPath();
  if(kind===1){ctx.moveTo(x,y-r);ctx.lineTo(x+r,y+r);ctx.lineTo(x-r,y+r);ctx.closePath();}
  else if(kind===2)ctx.rect(x-r,y-r,r*2,r*2);
  else if(kind===3){ctx.moveTo(x,y-r);ctx.lineTo(x+r,y);ctx.lineTo(x,y+r);ctx.lineTo(x-r,y);ctx.closePath();}
  else ctx.arc(x,y,r,0,Math.PI*2);
  ctx.fillStyle=kind===4?'#ffffff':colors[kind];ctx.fill();ctx.strokeStyle=colors[kind];ctx.lineWidth=1.5;ctx.stroke();
}
function journalTimes(p,models,f,x,y,w,h,links,shotPages) {
  p.box(x,y,w,h);
  const left=x+46,top=y+20,pw=w-68,ph=h-120;
  let max=10;for(const m of models)max=Math.max(max,journalNumber(m.shot.duration_s)||0,journalWindow(m.shot)?.[1]||0);max=Math.ceil(max/10)*10;
  const yy=value=>top+ph-value/max*ph;
  for(let n=0;n<=4;n++){const value=max*n/4;p.line(left,yy(value),left+pw,yy(value),p.c.grid);p.text(f.fmt(value,0)+' s',left-8,yy(value)-7,13,p.c['fg-dim'],'sans','right');}
  models.forEach((m,i)=>{
    const xx=left+(i+.5)*pw/models.length,win=journalWindow(m.shot),duration=journalNumber(m.shot.duration_s);
    if(win){p.ctx.fillStyle='#e3ded6';p.ctx.fillRect(xx-6,yy(win[1]),12,yy(win[0])-yy(win[1]));}
    if(duration!=null&&duration>=0)journalMarker(p,m.taste,xx,yy(duration));
    p.text('#'+m.shot.id,xx,top+ph+10+(i%2)*16,12,p.c.fg,'sans','center');
    if(shotPages.has(m.shot.id))links.push({x:xx-15,y:top,w:30,h:ph+44,page:shotPages.get(m.shot.id)});
  });
  [f.t.balanced,f.t.sour,f.t.bitter,f.t.other,f.t.notTasted].forEach((label,i)=>{const xx=x+20+(i%3)*(w-40)/3,yy=y+h-42+Math.floor(i/3)*21;journalMarker(p,i,xx+5,yy+7,4);p.text(label,xx+17,yy,14,p.c['fg-dim']);});
  p.ctx.fillStyle='#e3ded6';p.ctx.fillRect(x+20+2*(w-40)/3,y+h-21,10,12);p.text(f.t.targetWindow,x+37+2*(w-40)/3,y+h-21,14,p.c['fg-dim']);
}
function journalCurve(p,m,f,x,y,w,h) {
  p.box(x,y,w,h,p.c.inset,null);p.text(f.t.curve,x+14,y+10,15,p.c.fg,'bold');
  const legends=[[f.t.curveFlow,p.c['flow-curve'],false],[f.t.weight,p.c['weight-curve'],false],...(m.ideal.length>1?[[f.t.ideal,p.c['ideal-curve'],true]]:[])];
  let lx=x+14;
  legends.forEach(([label,color,dash])=>{p.ctx.save();p.ctx.setLineDash(dash?[4,3]:[]);p.line(lx,y+42,lx+16,y+42,color);p.ctx.restore();p.text(label,lx+22,y+34,13,p.c['fg-dim']);lx+=p.measure(label,13)+38;});
  if(!m.samples.length){p.paragraph(f.t.noCurve,x+24,y+110,w-48,16,p.c['fg-dim']);return;}
  const left=x+38,top=y+73,pw=w-76,ph=h-106,scale=m.scale;
  const xx=t=>left+t/scale.time*pw,yf=v=>top+ph-v/scale.flow*ph,yw=v=>top+ph-v/scale.weight*ph;
  const window=journalWindow(m.shot);
  if(window){p.ctx.fillStyle='#dce4dc';p.ctx.fillRect(xx(window[0]),top,xx(window[1])-xx(window[0]),ph);}
  p.text('g/s',left-10,top-18,12,p.c['flow-curve']);p.text('g',left+pw+10,top-18,12,p.c['weight-curve']);
  for(let i=0;i<=4;i++){const yv=top+ph-i*ph/4;p.line(left,yv,left+pw,yv,p.c.grid);p.text(f.fmt(scale.flow*i/4,scale.flow%4?1:0),left-8,yv-6,12,p.c['fg-dim'],'sans','right');p.text(f.fmt(scale.weight*i/4,0),left+pw+8,yv-6,12,p.c['fg-dim']);}
  const step=Math.max(5,Math.ceil(scale.time/35)*5);for(let time=0;time<=scale.time;time+=step)p.text(f.fmt(time,0)+' s',xx(time),top+ph+10,12,p.c['fg-dim'],'sans','center');
  p.ctx.save();p.ctx.beginPath();p.ctx.rect(left,top,pw,ph);p.ctx.clip();
  const curve=(rows,key,axis,color,dash=[])=>{p.ctx.beginPath();rows.forEach((r,i)=>{if(i)p.ctx.lineTo(xx(r.time_s),axis(r[key]));else p.ctx.moveTo(xx(r.time_s),axis(r[key]));});p.ctx.strokeStyle=color;p.ctx.lineWidth=2;p.ctx.lineJoin='round';p.ctx.setLineDash(dash);p.ctx.stroke();};
  curve(m.flow,'flow_g_s',yf,p.c['flow-curve']);curve(m.samples,'weight_g',yw,p.c['weight-curve']);if(m.ideal.length>1)curve(m.ideal,'flow_g_s',yf,p.c['ideal-curve'],[5,4]);p.ctx.restore();
}
function journalPageBase(p,page,index,total,f,summary,logo) {
  p.ctx.fillStyle='#fff';p.ctx.fillRect(0,0,JOURNAL_W,JOURNAL_H);
  if(logo)p.ctx.drawImage(logo,48,42,35,35);
  const bx=logo?94:48;p.text('shot',bx,41,29,p.c.brass,'italic');p.text('deck',bx+p.measure('shot',29,'italic'),41,29,p.c.fg,'serif');
  p.text(page.title,952,41,16,p.c.fg,'bold','right');
  const range=f.date(summary.first,{year:'numeric'})+' – '+f.date(summary.last,{year:'numeric'});
  p.text(range,952,66,14,p.c['fg-dim'],'sans','right');p.line(48,100,952,100);
  p.line(48,1347,952,1347);p.text('shotdeck · '+f.t.title,48,1360,14,p.c['fg-dim']);p.text(f.t.created+' '+f.date(new Date(),{year:'numeric'}),500,1360,13,p.c['fg-dim']);
  p.text(`${f.t.page} ${index+1} ${f.t.of} ${total}`,952,1360,14,p.c['fg-dim'],'sans','right');
  p.text(f.t.footer,48,1382,12,p.c['fg-dim']);
}
function journalBestCard(p,m,f,x,y,w,links,shotPages) {
  p.box(x,y,w,274,'#fff');p.ctx.fillStyle=p.c.brass;p.ctx.fillRect(x,y+18,4,48);
  const name=p.wrap(m.bean.name||f.t.noCoffee,w-32,18,'bold');
  // Full names appear in details/log; use explicit continuation on small index cards.
  name.slice(0,2).forEach((s,i)=>p.text(s+(i===1&&name.length>2?'…':''),x+16,y+16+i*22,18,p.c.fg,'bold'));
  p.text(`${f.fmt(m.dose)} → ${f.fmt(m.shot.final_weight_g)} g`,x+16,y+69,29,p.c.fg,'number');
  p.text(`1:${f.fmt(m.ratio,2)} · ${f.fmt(m.shot.duration_s)} s · ${f.fmt(m.shot.brew_temperature_c)} °C`,x+16,y+108,16,p.c.brass);
  const grinder=m.coffee.grinder||f.t.unknown;
  const detail=[f.t.grinder+': '+grinder,f.t.grind+': '+f.grind(m.coffee.grind_setting),f.t.profile+': '+(m.shot.profile_name||'—')];
  let yy=y+143;
  for(const value of detail){const lines=p.wrap(value,w-32,15);p.text(lines[0]+(lines.length>1?'…':''),x+16,yy,15);yy+=24;}
  let roastAge=null;
  if(m.coffee.roast_date && Number.isFinite(Date.parse(m.shot.started_at))){
    const day=new Intl.DateTimeFormat('en-CA',{year:'numeric',month:'2-digit',day:'2-digit',...(f.timezone?{timeZone:f.timezone}:{})}).format(new Date(m.shot.started_at));
    const age=(Date.parse(day+'T00:00:00Z')-Date.parse(m.coffee.roast_date+'T00:00:00Z'))/86400000;
    if(Number.isFinite(age)&&age>=0)roastAge=age;
  }
  if(roastAge!=null)p.text(f.fmt(roastAge,0)+' '+f.t.roastAge,x+16,y+214,14,p.c['fg-dim']);
  const page=shotPages.get(m.shot.id);p.text('★'.repeat(m.rating)+' · #'+m.shot.id,x+16,y+244,15,p.c.brass);
  if(page!=null){p.text(f.t.see+' '+(page+1),x+w-16,y+244,14,p.c['fg-dim'],'sans','right');links.push({x,y,w,h:274,page});}
}
function journalOverview(p,models,plan,f,summary,links) {
  const {t,fmt}=f;p.text(t.title,48,125,48,p.c.fg,'serif');
  p.text(`${models.length} ${t.shots} · ${summary.days} ${t.days}`,48,185,17,p.c['fg-dim']);
  const ratings=models.filter(m=>m.rating!=null),tasted=models.filter(m=>m.taste!==4),balanced=tasted.filter(m=>m.taste===0);
  const cards=[[t.median,`${fmt(journalMedian(models.map(m=>m.dose)))} → ${fmt(journalMedian(models.map(m=>journalNumber(m.shot.final_weight_g))))} g`,t.medianRatio+' 1:'+fmt(journalMedian(models.map(m=>m.ratio)),2)],
    [t.averageTime,fmt(summary.duration.mean)+' s',`${summary.inWindow} / ${summary.timed} ${t.window}`],
    [t.averageRating,fmt(ratings.length?ratings.reduce((n,m)=>n+m.rating,0)/ratings.length:null)+' / 5',`${ratings.length} / ${models.length} ${t.rated}`],
    [t.taste,tasted.length?fmt(100*balanced.length/tasted.length,0)+'%':'—',`${balanced.length} / ${tasted.length} ${t.balanced.toLocaleLowerCase(f.lang)}`]];
  cards.forEach(([label,value,note],i)=>{const x=48+i*230;p.box(x,221,214,121);p.text(label,x+15,237,15,p.c['fg-dim']);let size=31;while(p.measure(value,size,'number')>184&&size>23)size--;p.text(value,x+15,270,size,p.c.fg,'number');p.paragraph(note,x+15,309,184,13,p.c['fg-dim']);});
  p.text(t.numericMedians+' '+t.counts,48,351,14,p.c['fg-dim']);
  p.text(t.best,48,384,27,p.c.fg,'serif');p.text(t.bestNote,48,420,15,p.c['fg-dim']);
  plan.best.slice(0,3).forEach((m,i)=>journalBestCard(p,m,f,48+i*307,451,290,links,plan.shotPages));
  if(!plan.best.length)p.text(t.noRated,48,470,17,p.c['fg-dim']);
  p.text(t.chart+(models.length>24?' · 1–24 / '+models.length:''),48,750,27,p.c.fg,'serif');p.text(t.chartNote,48,788,15,p.c['fg-dim']);
  journalTimes(p,models.slice(0,24),f,48,818,904,290,links,plan.shotPages);
  const tastes=[t.balanced,t.sour,t.bitter,t.other,t.notTasted].map((label,i)=>[label,models.filter(m=>m.taste===i).length]);
  const groups=[[t.taste,tastes],[t.profiles,summary.profiles],[t.users,summary.users]];
  groups.forEach(([title,values],i)=>{const x=48+i*307;p.text(title,x,1134,18,p.c.fg,'bold');const shown=values.slice(0,values.length>5?4:5);if(values.length>5)shown.push([t.more,values.slice(4).reduce((n,[,count])=>n+count,0)]);shown.forEach(([name,count],j)=>{const lines=p.wrap(name||t.unknown,227,15);p.text(lines[0]+(lines.length>1?'…':''),x,1166+j*23,15);p.text(count,x+280,1166+j*23,15,p.c.fg,'bold','right');});});
  const scope=plan.scopeLines.length<=2?plan.scopeLines:[t.filters+': '+t.see+' '+(plan.pages.findIndex(page=>page.kind==='scope')+1)];scope.forEach((line,i)=>p.text(line,48,1290+i*18,13,p.c['fg-dim']));
}
function journalDrawLog(p,page,f,links,shotPages) {
  const {t,fmt}=f;p.text(t.log,48,121,33,p.c.fg,'serif');p.text(t.order,48,166,15,p.c['fg-dim']);
  const columns=[[t.shot,48,106],[t.coffee,154,218],[t.grind,372,62],[t.doseYield+' (g)',434,118],[t.ratio,552,65],[t.time+' (s)',617,74],[t.flowShort+'\n(g/s)',691,65],[t.tempShort+'\n(°C)',756,68],[t.taste+' / '+t.rating,824,128]];
  p.box(48,191,904,37,p.c.inset,null);columns.forEach(([label,x,w])=>p.paragraph(label,x+4,195,w-8,12,p.c['fg-dim'],'bold',14));
  let y=234;
  for(const row of page.rows){
    const {m}=row,s=m.shot,win=journalWindow(s),time=journalNumber(s.duration_s),direction=win&&time!=null?(time<win[0]?'▼ ':time>win[1]?'▲ ':''):'';
    if(page.rows.indexOf(row)%2===0){p.ctx.fillStyle=p.c.inset;p.ctx.fillRect(48,y,904,row.height);}
    p.text('#'+s.id+(row.continued?' ↪':''),52,y+6,16,p.c.brass,'bold');p.text(f.time(s.started_at),148,y+7,14,p.c['fg-dim'],'sans','right');p.text(f.date(s.started_at),52,y+27,15);
    let yy=y+6;row.coffeeLines.forEach(line=>{p.text(line,158,yy,16,p.c.fg,'bold');yy+=20;});row.profileLines.forEach(line=>{p.text(line,158,yy,16,p.c['fg-dim']);yy+=20;});
    row.grindLines.forEach((line,i)=>p.text(line,376,y+6+i*20,16));
    p.text(`${fmt(m.dose)} → ${fmt(s.final_weight_g)}`,438,y+6,16,p.c.fg,'number');p.text(m.ratio==null?'—':'1:'+fmt(m.ratio,2),556,y+6,16,p.c.fg,'number');
    p.text(direction+fmt(time),621,y+6,16,direction?p.c.brass:p.c.fg,'number');p.text(row.target,621,y+28,12,p.c['fg-dim']);p.text(fmt(s.average_flow_g_s,2),695,y+6,16,p.c.fg,'number');p.text(fmt(s.brew_temperature_c),760,y+6,16,p.c.fg,'number');
    row.tasteLines.forEach((line,i)=>p.text(line,828,y+6+i*20,16));p.text(m.rating==null?t.notRated:'★'.repeat(m.rating),828,y+8+row.tasteLines.length*20,15,m.rating==null?p.c['fg-dim']:p.c.brass);
    row.notes.forEach((line,i)=>p.text(line,58,y+row.fixed+i*21,16,p.c['fg-dim']));
    if(shotPages.has(s.id))links.push({x:48,y,w:106,h:Math.min(row.height,70),page:shotPages.get(s.id)});
    y+=row.height;p.line(48,y,952,y);
  }
}
function journalDrawDetail(p,card,f,y,links,photoPages) {
  const {m}=card,{shot:s}=m,{t,fmt}=f,x=48,w=904;
  p.box(x,y,w,card.height,'#fff');let yy=y+20;
  card.title.forEach((line,i)=>p.text(line,70,yy+i*33,27,p.c.fg,'serif'));
  p.text(m.rating==null?t.notRated:'★'.repeat(m.rating),930,yy+4,16,m.rating==null?p.c['fg-dim']:p.c.brass,'bold','right');
  yy+=card.title.length*33;card.subtitle.forEach((line,i)=>p.text(line,70,yy+i*20,15,p.c['fg-dim']));yy+=card.subtitle.length*20+14;
  p.box(70,yy,860,86,p.c.inset,null);
  const win=journalWindow(s),time=journalNumber(s.duration_s),status=!win||time==null?'':time<win[0]?'▼ '+t.fast:time>win[1]?'▲ '+t.slow:'✓ '+t.inWindow;
  const metrics=[[t.dose+(m.coffee.sources?.dose_g==='manual'?' *':''),fmt(m.dose)+' g'],[t.yield,fmt(s.final_weight_g)+' g'],[t.ratio,m.ratio==null?'—':'1:'+fmt(m.ratio,2)],[t.time,fmt(time)+' s'],[t.flow,fmt(s.average_flow_g_s,2)+' g/s'],[t.temp,fmt(s.brew_temperature_c)+' °C']];
  metrics.forEach(([label,value],i)=>{const xx=82+i*143;p.text(label,xx,yy+12,12,p.c['fg-dim']);p.text(value,xx,yy+32,25,p.c.fg,'number');if(i===1&&journalPositive(s.target_weight_g))p.text(t.target+' '+fmt(s.target_weight_g)+' g',xx,yy+64,12,p.c['fg-dim']);if(i===3)p.text(win?fmt(win[0],0)+'–'+fmt(win[1],0)+' s · '+status:status,xx,yy+64,10,p.c['fg-dim']);if(i===5&&s.brew_temperature_source==='profile')p.text(f.lang==='de'?'Profilziel (unbestätigt)':'Profile target (unconfirmed)',xx,yy+64,10,p.c['fg-dim']);});
  yy+=104;p.text(t.preparation,70,yy,15,p.c.fg,'bold');let fy=yy+25;
  for(const field of card.fields){p.text(field.key,70,fy,14,p.c['fg-dim']);field.lines.forEach((line,i)=>{if(line==='@photo'){const page=photoPages.get(s.id);p.text(t.see+' '+(page+1),204,fy+i*19,15,p.c.brass);links.push({x:200,y:fy,w:210,h:20,page});}else p.text(line,204,fy+i*19,15);});fy+=Math.max(22,field.lines.length*19+5);}
  journalCurve(p,m,f,465,yy,465,card.body-10);yy+=card.body+16;
  const noteHeight=(card.notes.length+(card.continued?1:0))*21+40;p.box(70,yy,860,noteHeight,p.c.inset,null);
  p.text(t.tasting+' · '+f.label(s.feedback?.taste??s.taste??'not_tasted'),86,yy+10,14,p.c.fg,'bold');card.notes.forEach((line,i)=>p.text(line,86,yy+32+i*21,16,p.c.fg));if(card.continued)p.text(t.notesFollow,86,yy+32+card.notes.length*21,16,p.c.brass);
}
async function journalDrawPhotos(p,page,f,links,shotPages,historyRevision) {
  let y=128;
  for(let start=0;start<page.models.length;start+=2){
    const pair=page.models.slice(start,start+2),images=[];let rowHeight=0;
    for(const m of pair){const image=await loadGrindPhoto(m.shot.coffee.photo,historyRevision);const name=p.wrap('#'+m.shot.id+' · '+(m.bean.name||f.t.noCoffee),416,18,'bold');const heading=name.length*23+50;const ratio=Math.min(416/image.width,Math.max(30,580-heading-30)/image.height);images.push({m,image,ratio,name,heading});rowHeight=Math.max(rowHeight,heading+image.height*ratio+30);}
    for(let i=0;i<images.length;i++){const {m,image,ratio,name,heading}=images[i],x=48+i*460,height=heading+image.height*ratio+30;p.box(x,y,444,height);name.forEach((line,j)=>p.text(line,x+14,y+14+j*23,18,p.c.fg,'bold'));p.text(f.t.grind+': '+f.grind(m.coffee.grind_setting)+' · #'+m.shot.id,x+14,y+18+name.length*23,15,p.c['fg-dim']);p.ctx.drawImage(image,x+(444-image.width*ratio)/2,y+heading,image.width*ratio,image.height*ratio);if(shotPages.has(m.shot.id))links.push({x,y,w:444,h:heading,page:shotPages.get(m.shot.id)});}
    y+=rowHeight+22;
  }
}

// Image pages plus real PDF link annotations, Unicode metadata and bookmarks.
// IDs and byte offsets are allocated explicitly, independent of UTF-8 lengths.
function shotPdfDocument({title='Shot journal'}={}) {
  const images=[];
  const unicode=value=>'<FEFF'+Array.from(String(value)).map(char=>{const n=char.codePointAt(0);return n<=65535?n.toString(16).padStart(4,'0'):[0xd800+((n-65536)>>10),0xdc00+((n-65536)&1023)].map(v=>v.toString(16).padStart(4,'0')).join('');}).join('')+'>';
  return {
    async addPage(canvas,{links=[],bookmark=null}={}) {
      const blob=await new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('PDF image failed')),'image/jpeg',0.94));
      images.push({bytes:new Uint8Array(await blob.arrayBuffer()),width:canvas.width,height:canvas.height,links,bookmark});canvas.width=canvas.height=1;
    },
    finish() {
      const enc=new TextEncoder(),chunks=[],offsets=[0];let length=0,next=5;
      const ids=images.map(img=>({page:next++,content:next++,image:next++,links:img.links.map(()=>next++)}));
      const bookmarks=images.flatMap((img,i)=>img.bookmark?[{title:img.bookmark,page:i,id:next++}]:[]);
      const append=data=>{const bytes=typeof data==='string'?enc.encode(data):data;chunks.push(bytes);length+=bytes.length;};
      const object=(id,data)=>{offsets[id]=length;append(id+' 0 obj\n');append(data);append('\nendobj\n');};
      append('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
      object(1,'<< /Type /Catalog /Pages 2 0 R /Outlines 4 0 R >>');object(2,`<< /Type /Pages /Count ${images.length} /Kids [${ids.map(v=>v.page+' 0 R').join(' ')}] >>`);
      object(3,`<< /Title ${unicode(title)} /Creator ${unicode('Shotdeck web UI')} /Producer ${unicode('Shotdeck')} /CreationDate (D:${new Date().toISOString().replace(/[-:T]/g,'').slice(0,14)}Z) >>`);
      object(4,bookmarks.length?`<< /Type /Outlines /First ${bookmarks[0].id} 0 R /Last ${bookmarks[bookmarks.length-1].id} 0 R /Count ${bookmarks.length} >>`:'<< /Type /Outlines /Count 0 >>');
      images.forEach((img,i)=>{
        const id=ids[i],stream='q 595.28 0 0 841.89 0 0 cm /ShotImage Do Q';
        object(id.page,`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /ShotImage ${id.image} 0 R >> >> /Contents ${id.content} 0 R${id.links.length?' /Annots ['+id.links.map(v=>v+' 0 R').join(' ')+']':''} >>`);
        object(id.content,`<< /Length ${enc.encode(stream).length} >>\nstream\n${stream}\nendstream`);
        offsets[id.image]=length;append(`${id.image} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${img.width} /Height ${img.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.bytes.length} >>\nstream\n`);append(img.bytes);append('\nendstream\nendobj\n');
        img.links.forEach((link,j)=>{if(!ids[link.page])throw Error('Invalid journal page link');const sx=595.28/JOURNAL_W,sy=841.89/JOURNAL_H;const rect=[link.x*sx,(JOURNAL_H-link.y-link.h)*sy,(link.x+link.w)*sx,(JOURNAL_H-link.y)*sy].map(v=>v.toFixed(3)).join(' ');object(id.links[j],`<< /Type /Annot /Subtype /Link /Rect [${rect}] /Border [0 0 0] /Dest [${ids[link.page].page} 0 R /Fit] >>`);});
      });
      bookmarks.forEach((b,i)=>object(b.id,`<< /Title ${unicode(b.title)} /Parent 4 0 R /Dest [${ids[b.page].page} 0 R /Fit]${i?' /Prev '+bookmarks[i-1].id+' 0 R':''}${i+1<bookmarks.length?' /Next '+bookmarks[i+1].id+' 0 R':''} >>`));
      const xref=length;append('xref\n0 '+next+'\n0000000000 65535 f \n');for(let i=1;i<next;i++){if(offsets[i]==null)throw Error('Missing PDF object');append(String(offsets[i]).padStart(10,'0')+' 00000 n \n');}append(`trailer\n<< /Size ${next} /Root 1 0 R /Info 3 0 R >>\nstartxref\n${xref}\n%%EOF\n`);
      return new Blob(chunks,{type:'application/pdf'});
    },
  };
}
async function buildShotPdfReport({rows,loadShot,profiles=[],from='',to='',lang='en',smoothing=10,onProgress=()=>{},includePhotos=true,compact=false,historyRevision=null,filterDescription='',verify=async()=>{}}) {
  if(!rows.length)throw Error('No shots to export');
  const shots=[];
  onProgress(0,rows.length,'loading');
  for(let i=0;i<rows.length;i++){const shot=await loadShot(rows[i].id);if(!shot||shot.id!==rows[i].id)throw Error('Shot is no longer available');shots.push(shot);onProgress(i+1,rows.length,'loading');}
  const f=journalFormat(lang),logo=await journalAssets(),models=journalModels(shots,{profiles,smoothing});
  for(const m of models)m.photoIncluded=!compact&&includePhotos&&!!m.coffee.photo;
  const scratch=document.createElement('canvas'),p=journalPainter(scratch),plan=journalPlan(models,p,f,{compact,filterDescription,from,to}),summary=summarizeShotReport(shots);
  const pdf=shotPdfDocument({title:f.t.title}),bookmarked=new Set();
  onProgress(0,plan.pages.length,'rendering');
  for(let i=0;i<plan.pages.length;i++){
    const page=plan.pages[i],canvas=document.createElement('canvas');canvas.width=JOURNAL_W*2;canvas.height=JOURNAL_H*2;
    const p=journalPainter(canvas);p.ctx.scale(2,2);journalPageBase(p,page,i,plan.pages.length,f,summary,logo);const links=[];
    if(page.kind==='overview')journalOverview(p,models,plan,f,summary,links);
    if(page.kind==='best'){p.text(f.t.best,48,126,29,p.c.fg,'serif');page.models.forEach((m,j)=>journalBestCard(p,m,f,48+(j%3)*307,195+Math.floor(j/3)*315,290,links,plan.shotPages));}
    if(page.kind==='times'){for(let j=0;j<page.models.length;j+=24){const y=130+Math.floor(j/24)*390;p.text(f.t.chart,48,y,24,p.c.fg,'serif');journalTimes(p,page.models.slice(j,j+24),f,48,y+38,904,325,links,plan.shotPages);}}
    if(page.kind==='log')journalDrawLog(p,page,f,links,plan.shotPages);
    if(page.kind==='details'){let y=JOURNAL_TOP;for(const card of page.cards){journalDrawDetail(p,card,f,y,links,plan.photoPages);y+=card.height+22;}}
    if(page.kind==='notes'||page.kind==='scope'){p.text(page.title,48,126,29,p.c.fg,'serif');page.lines.forEach((line,j)=>p.text(line,48,182+j*21,16));}
    if(page.kind==='photos')await journalDrawPhotos(p,page,f,links,plan.shotPages,historyRevision);
    await pdf.addPage(canvas,{links,bookmark:bookmarked.has(page.kind)?null:page.title});bookmarked.add(page.kind);
    onProgress(i+1,plan.pages.length,'rendering');
    await new Promise(resolve=>setTimeout(resolve,0));
  }
  onProgress(0,0,'verifying');await verify();scratch.width=scratch.height=1;
  return {blob:pdf.finish(),pageCount:plan.pages.length,filename:'shotdeck-journal-'+(compact?'compact-':'')+(from||'all')+'-to-'+(to||'latest')+'.pdf'};
}
async function saveShotPdfReport(options) {
  const report=await buildShotPdfReport(options),url=URL.createObjectURL(report.blob),link=document.createElement('a');link.href=url;link.download=report.filename;
  try{document.body.appendChild(link);link.click();}finally{link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
}
Object.assign(window,{shotRangeParams,loadShotRange,summarizeShotReport,buildShotPdfReport,saveShotPdfReport,journalModels,journalBest,journalPlan,journalFormat,journalPainter,shotPdfDocument});
