// ============================================================
// Shotdeck — Shots tab: sticky chart · list (swipe-delete) ·
//   analysis panel · feedback modal
// ============================================================

function fmtTime(iso) { return iso ? historyDate(iso) : ''; }

const SHOT_EXPORT_TEXT = {
  en: { contents: 'PDF contents', full: 'Full journal', compact: 'Overview + log',
    collecting: 'Collecting matching shots…', loading: 'Loading shot details…',
    rendering: 'Creating PDF pages…', verifying: 'Checking the finished PDF…' },
  de: { contents: 'PDF-Inhalt', full: 'Vollständiges Journal', compact: 'Überblick + Protokoll',
    collecting: 'Passende Shots werden gesammelt…', loading: 'Shot-Details werden geladen…',
    rendering: 'PDF-Seiten werden erstellt…', verifying: 'Das fertige PDF wird geprüft…' },
};

function fmtAvgFlow(value) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n.toFixed(2) + 'g/s' : '—';
}

// Weight-vs-target badge: signed grams off target. Green inside ±0.2 g; over
// target trends red, under target trends blue — the further off, the stronger
// the hue. Colors are theme-aware (warm-dark wants light text on a dark tint;
// light theme wants dark text on a light tint), mirroring the token pattern.
function weightDeltaBadge(shot, dark) {
  const target = Number(shot.target_weight_g);
  const final = Number(shot.final_weight_g);
  if (!Number.isFinite(target) || target <= 0 || !Number.isFinite(final)) return null;
  const delta = final - target;
  const r = Math.round(delta * 10) / 10;            // display to 0.1 g
  const sign = r > 0 ? '+' : r < 0 ? '−' : '±';
  const text = sign + Math.abs(r).toFixed(1) + 'g';
  const a = Math.abs(delta);
  // Green zone keyed off the displayed value so the colour always matches the
  // number shown (and ±0.2 g reads green despite float error like 0.2000…0284).
  const onTarget = Math.abs(r) <= 0.2;
  const hue = onTarget ? 130 : (delta > 0 ? 8 : 212); // green · red · blue
  const t = onTarget ? 0 : Math.min(1, (a - 0.2) / 1.8); // intensity, full ≈2 g off
  const sat = Math.round(55 + t * 35);
  const color = dark
    ? `hsl(${hue} ${Math.min(95, sat + 5)}% ${Math.round(72 - t * 6)}%)`
    : `hsl(${hue} ${sat}% ${Math.round(34 - t * 8)}%)`;
  const bg = dark
    ? `hsl(${hue} ${sat}% ${Math.round(14 + t * 4)}%)`
    : `hsl(${hue} ${Math.max(40, sat - 15)}% ${Math.round(92 - t * 4)}%)`;
  const border = dark
    ? `hsl(${hue} ${sat}% ${Math.round(30 + t * 8)}%)`
    : `hsl(${hue} ${sat}% ${Math.round(72 - t * 8)}%)`;
  return { text, color, bg, border };
}

function ShotsScreen({ app }) {
  const [sel, setSel] = useState(app.openShotId || null);
  const [smooth, setSmooth] = useState('10');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [dateBefore,setDateBefore]=useState('');
  const [dateShortcut,setDateShortcut]=useState('all');
  const t=key=>managementText(key,app.lang);
  window.__sdTimezone=app.data.history_timezone || window.__sdTimezone || 'UTC';
  const [selecting,setSelecting]=useState(()=>{const open=!!window.__sdManageShots;window.__sdManageShots=false;return open;});
  const [selection,setSelection]=useState({all:false,ids:[]});
  const [deleteReview,setDeleteReview]=useState(null),[previewBusy,setPreviewBusy]=useState(false),[selectionNotice,setSelectionNotice]=useState('');
  const previewGeneration=useRef(0);
  const [recordedFilters,setRecordedFilters]=useState({});
  useEffect(()=>{let cancelled=false;api('/api/shots/filter-options').then(value=>{if(!cancelled)setRecordedFilters(value);}).catch(()=>{});return()=>{cancelled=true;};},[]);

  const [filters,setFilters]=useState({grinder:'',min_rating:'',sort:'newest',taste:'',user_id:'',roast:'',profile_name:'',max_rating:'',rating_state:'',has_photo:''});
  const [page,setPage]=useState(null),[reloadList,setReloadList]=useState(0),[includePhotos,setIncludePhotos]=useState(true);
  const criteria={from:dateFrom,to:dateTo,before:dateBefore,...filters,bean_id:app.shotBeanFilter};
  const filterKey=JSON.stringify(criteria);
  const membershipKey=JSON.stringify({...criteria,sort:undefined});
  const selectedCount=selection.all?Math.max(0,(page?.total||0)-selection.ids.length):selection.ids.length;
  const toggleSelected=id=>{setSelection(old=>({...old,ids:old.ids.includes(id)?old.ids.filter(x=>x!==id):[...old.ids,id]}));};
  useEffect(()=>{++previewGeneration.current;setSelection(old=>{if(old.all||old.ids.length)setSelectionNotice(t('selectionChanged'));return {all:false,ids:[]};});setDeleteReview(null);},[membershipKey,app.data.history_revision]);
  useEffect(()=>{++previewGeneration.current;},[selection]);
  const reviewSelection=async()=>{
    const generation=++previewGeneration.current;setPreviewBusy(true);setSelectionNotice('');
    const body={revision:page.revision,snapshot:page.snapshot,...(selection.all?{filters:criteria,exclude_ids:selection.ids}:{ids:selection.ids})};
    try{const result=await api('/api/shots/delete-preview',{method:'POST',body:JSON.stringify(body)});if(generation===previewGeneration.current)setDeleteReview({...result,description:Object.entries(criteria).filter(([k,v])=>v&&k!=='sort').map(([k,v])=>({from:tr('date_from'),to:tr('date_to'),before:t('before'),bean_id:tr('bean'),grinder:tr('grinder_name'),min_rating:tr('min_rating'),max_rating:t('maxRating'),rating_state:t('ratingState'),has_photo:t('photoState'),taste:tr('fb_taste'),user_id:tr('brewing_for'),roast:tr('roast'),profile_name:tr('profile_label')}[k]+': '+(k==='grinder'?grinderOptions.find(o=>o.value===v)?.label||v:v))).join(' · ')});}catch(e){setSelectionNotice(e.message);}finally{setPreviewBusy(false);}
  };
  const historyToken=JSON.stringify([app.historyRefresh,app.data.history_revision,(app.data.shots||[]).map(s=>[s.id,s.review_revision,s.has_feedback,s.gbs_status])]);
  const listGeneration=useRef(0);
  const setFilter=(key,value)=>{setListLoading(true);setFilters(f=>({...f,[key]:value}));};
  const [listLoading, setListLoading] = useState(true);
  const [listError, setListError] = useState(false);
  const [reportExporting, setReportExporting] = useState(false);
  const [reportProgress, setReportProgress] = useState(null);
  const [reportCompact, setReportCompact] = useState(false);
  const reportText = SHOT_EXPORT_TEXT[app.lang] || SHOT_EXPORT_TEXT.en;
  const reportBusy = useRef(false);
  const loadedRange = useRef(null);
  const invalidRange = !!(dateFrom && dateTo && dateFrom > dateTo);
  const [analyzed, setAnalyzed] = useState(false);
  const [shots, setShots] = useState(app.data.shots || []);
  const [detail, setDetail] = useState(null);
  const [analysisState, setAnalysisState] = useState(null);
  const [analysisRequest, setAnalysisRequest] = useState(0);
  const [exporting, setExporting] = useState(false);
  const exportBusy = useRef(false);
  const scrollBody = useRef(null);
  const graph = useRef(null);
  const requestedGraph = useRef(null);
  const scrollToGraph = () => {
    const body = scrollBody.current;
    const target = graph.current;
    if (!body || !target) return;
    const top = body.scrollTop + target.getBoundingClientRect().top - body.getBoundingClientRect().top - 8;
    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    body.scrollTo({ top: Math.max(0, top), behavior: reducedMotion ? 'instant' : 'smooth' });
  };
  useEffect(() => {
    if (detail?.id !== requestedGraph.current) return;
    requestedGraph.current = null;
    // Wait for the selected shot's panels to finish changing the page height.
    const frame = window.requestAnimationFrame(scrollToGraph);
    return () => window.cancelAnimationFrame(frame);
  }, [detail]);
  const analysis = analysisState?.shotId === sel && analysisState.status === 'ready' ? analysisState.result : null;
  const analysisLoading = analysisState?.shotId === sel && analysisState.status === 'loading';

  useEffect(() => { if (app.openShotId) { setSel(app.openShotId); setAnalyzed(true); app.openShotId = null; } }, [app.openShotId]);

  // (re)load the shot list when the date filter changes
  useEffect(() => {
    let cancelled = false;
    ++listGeneration.current;
    if (invalidRange) { setShots([]); setListLoading(false); return; }
    const range = filterKey;
    if (loadedRange.current !== range) setListLoading(true);
    app.loadShotPage(criteria).then(result => {
      if (!cancelled) { setShots(result.shots); setPage(result); setListError(false); setListLoading(false); loadedRange.current = range;
        if (sel != null && !result.shots.some(s=>s.id===sel)) { setSel(null); setDetail(null); setAnalyzed(false); }
      }
    }).catch(() => { if (!cancelled) { setShots([]); setListError(true); setListLoading(false); } });
    return () => { cancelled = true; };
  }, [filterKey, historyToken, reloadList]);
  const loadMore=async()=>{const generation=listGeneration.current;setListLoading(true);try {const next=await app.loadShotPage({...criteria,offset:shots.length,snapshot:page.snapshot,revision:page.revision});if(generation===listGeneration.current){setShots(rows=>[...rows,...next.shots]);setListError(false);}}catch{if(generation===listGeneration.current)setListError(true);}finally{if(generation===listGeneration.current)setListLoading(false);}};

  // load the full shot (samples + settings.profile) when a row is selected
  useEffect(() => {
    if (sel == null) { setDetail(null); setAnalysisState(null); return; }
    let cancelled = false;
    let timer;
    const started = Date.now();
    // Keep the selected chart and open panels visible during history refreshes.
    setDetail(current => current?.id === sel ? current : null);
    setAnalysisState(null);
    const load = () => app.loadShotDetail(sel).then(d => {
      if (cancelled) return;
      if (!d || d.id !== sel) return;
      setDetail(d);
      setShots(rows => rows.map(row => row.id === d.id ? { ...row, gbs_status: d.gbs_status } : row));
      // Receipt collection completes after reporting; refresh only recent
      // shots, with a fixed bound, so selecting a shot never starts an export.
      const recent = Date.now() - new Date(d.ended_at || d.started_at).getTime() < 120000;
      const pending = d.grinder_telemetry?.collection?.status === 'pending'
        || (!d.grinder_telemetry && !!d.gbs_status);
      if (recent && pending && Date.now() - started < 60000) timer = setTimeout(load, 2000);
    }).catch(() => {});
    load();
    return () => { cancelled = true; clearTimeout(timer); };
  }, [sel, historyToken]);

  // fetch analysis when Analyze is pressed for the selected shot
  useEffect(() => {
    if (!analyzed || sel == null) { return; }
    let cancelled = false;
    setAnalysisState({ shotId: sel, status: 'loading' });
    app.loadAnalysis(sel).then(a => {
      if (!cancelled) setAnalysisState({ shotId: sel, status: a ? 'ready' : 'error', result: a });
    }).catch(() => { if (!cancelled) setAnalysisState({ shotId: sel, status: 'error' }); });
    return () => { cancelled = true; };
  }, [analyzed, sel, analysisRequest, historyToken]);

  const selShot = shots.find(s => s.id === sel) || null;
  const profForShot = detail && detail.settings ? detail.settings.profile : null;
  const ideal = profForShot && profForShot.ideal_flow_enabled ? profForShot.ideal_flow_profile : null;
  const dark = !/light/.test(app.theme || '');
  const detailReady = detail && detail.id === sel;
  const saveScreenshot = async () => {
    if (!detailReady || exportBusy.current || analysisLoading || (analyzed && !analysis)) return;
    exportBusy.current = true; setExporting(true);
    try {
      await saveShotScreenshot({ shot: detail, analysis, smoothing: Number(smooth), lang: app.lang,
        note: shotProfileNote(detail, app.data.profiles || []), includePhotos });
      app.toast(tr('screenshot_saved'));
    } catch { app.toast(tr('screenshot_failed')); }
    finally { exportBusy.current = false; setExporting(false); }
  };
  const saveButton = <Btn variant="ghost" className="sm sd-shot-save" onClick={saveScreenshot}
    disabled={!detailReady || exporting || analysisLoading || (analyzed && !analysis)}
    title={tr('save_screenshot')} aria-label={tr('save_screenshot')} aria-busy={exporting}>
    <Icon name="download" size={14} /><span className="sd-shot-save-label">{tr(exporting ? 'saving_screenshot' : 'save_screenshot')}</span>
  </Btn>;

  const exportReport = async () => {
    if (reportBusy.current || invalidRange || listLoading || listError || !shots.length) return;
    const allHistory = !Object.entries(criteria).some(([key, value]) => key !== 'sort' && value);
    if (!window.confirm(tr(allHistory ? 'report_confirm_all' : 'report_confirm').replace('{count}', page.total))) return;
    reportBusy.current = true; setReportExporting(true); setReportProgress({ phase: 'collecting' });
    try {
      const {rows,revision} = await app.loadFilteredShots(criteria);
      if (!rows.length) { setReportProgress({ phase: 'empty' }); return; }
      await saveShotPdfReport({ rows, loadShot: id=>app.loadShotDetail(id,revision), includePhotos, historyRevision:revision, filterDescription: Object.entries(criteria).filter(([k,v])=>v && !['from','to','sort'].includes(k)).map(([k,v])=>({grinder:tr('grinder_name'),max_rating:t('maxRating'),rating_state:t('ratingState'),has_photo:t('photoState'),before:t('before')}[k]||tr({bean_id:'bean',min_rating:'min_rating',taste:'fb_taste',user_id:'brewing_for',roast:'roast',profile_name:'profile_label',sort:'sort',max_rating:'storage_max_rating',rating_state:'storage_rating',has_photo:'storage_photo',before:'storage_before'}[k]))+': '+(k==='bean_id'?(app.data.beans||[]).find(b=>b.id===v)?.name||tr('unassigned'):k==='grinder'?grinderOptions.find(o=>o.value===v)?.label||v:k==='user_id'?[...(app.data.users?.items||[]),...(recordedFilters.users||[])].find(u=>u.id===v)?.name||v:k==='taste'?fbLabel(v):k==='sort'?tr(v==='rating'?'best_rated':'newest'):v)).join(' · '), verify:()=>app.loadShotPage({...criteria,revision}), profiles: app.data.profiles || [],
        from: dateFrom, to: dateTo, lang: app.lang, smoothing: Number(smooth), compact: reportCompact,
        onProgress: (done, total, phase = 'loading') => setReportProgress({ done, total, phase }) });
      setReportProgress({ phase: 'complete', done: 1, total: 1 });
    } catch { setReportProgress({ phase: 'error' }); }
    finally { reportBusy.current = false; setReportExporting(false); }
  };
  // Catalogue grinders by identity, plus names recorded on older shots.
  const grinderOptions = (() => {
    const options = [], seen = new Set();
    for (const g of app.data.grinders || []) { options.push({ value: 'id:' + g.id, label: g.name }); seen.add('id:' + g.id); }
    for (const o of recordedFilters.grinders || []) if (!seen.has(o.value)) { options.push(o); seen.add(o.value); }
    return [{ value: 'unassigned', label: tr('no_grinder') }, ...options];
  })();
  const changeDate = (key, value) => {
    const dates={from:dateFrom,to:dateTo,before:dateBefore,[key]:value};
    if(key==='before'&&value)dates.to='';
    if(key==='to')dates.before='';
    if(dates.from!==dateFrom||dates.to!==dateTo||dates.before!==dateBefore){setListLoading(true);setListError(false);}
    setDateFrom(dates.from);setDateTo(dates.to);setDateBefore(dates.before);
    setDateShortcut(Object.values(dates).some(Boolean)?'custom':'all');
  };
  const changeDateShortcut = value => {
    setDateShortcut(value);
    if(value==='custom')return;
    const dates=quickShotDates(value,window.__sdTimezone);
    if(dates.from!==dateFrom||dates.to!==dateTo||dates.before!==dateBefore){setListLoading(true);setListError(false);}
    setDateFrom(dates.from);setDateTo(dates.to);setDateBefore(dates.before);
  };
  const moreFilterCount = ['taste', 'user_id', 'roast', 'profile_name', 'max_rating', 'rating_state', 'has_photo']
    .filter(key => filters[key]).length;
  const reportStatus = reportProgress && (reportText[reportProgress.phase]
    || tr({ complete: 'report_saved', error: 'report_failed', empty: 'report_empty' }[reportProgress.phase]));

  return (
    <div className="sd-body sd-scroll sd-shots-screen" ref={scrollBody} style={{ paddingTop: 12 }}>
      {/* Filters: one panel above the list and the selected shot. */}
      <Card className="sd-shot-filter-card">
        <div className="sd-cardhead" style={{ marginBottom: 12 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span className="sd-cardtitle">{tr('shots_history')}</span>
            <button className="sd-helpbtn" onClick={() => app.openHelp('shots')}>?</button>
          </div>
          <div className="sd-coffee-actions" style={{ margin: 0 }}><Btn variant="ghost" className="sm" disabled={reportExporting||previewBusy} onClick={()=>{setSelecting(v=>!v);setSelection({all:false,ids:[]});}}>{t(selecting?'cancel':'select')}</Btn></div>
        </div>
        <div className="sd-coffee-fields sd-shot-filter-main">
          <CoffeeField label={t('dates')}><select className="sd-input" value={dateShortcut} disabled={reportExporting} onChange={e=>changeDateShortcut(e.target.value)}><option value="all">{t('allDates')}</option><option value="custom">{t('custom')}</option>{['today','last7','last30','older30','older90'].map(k=><option key={k} value={k}>{t(k)}</option>)}</select></CoffeeField>
          <CoffeeField label={tr('bean')}><select className="sd-input" value={app.shotBeanFilter} disabled={reportExporting} onChange={e=>app.setShotBeanFilter(e.target.value)}><option value="">{tr('all_beans')}</option><option value="unassigned">{tr('unassigned')}</option>{(app.data.beans||[]).map(b=><option key={b.id} value={b.id}>{beanLabel(b)}</option>)}</select></CoffeeField>
          <CoffeeField label={tr('grinder_name')}><select className="sd-input" value={filters.grinder} disabled={reportExporting} onChange={e=>setFilter('grinder',e.target.value)}><option value="">{tr('all_grinders')}</option>{grinderOptions.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select></CoffeeField>
          <CoffeeField label={tr('min_rating')}><select className="sd-input" value={filters.min_rating} disabled={reportExporting} onChange={e=>setFilter('min_rating',e.target.value)}><option value="">{tr('all_ratings')}</option>{[1,2,3,4,5].map(n=><option key={n} value={n}>{n} ★+</option>)}</select></CoffeeField>
          <CoffeeField label={tr('sort')}><Select value={filters.sort} onChange={v=>setFilter('sort',v)} disabled={reportExporting} options={[{value:'newest',label:tr('newest')},{value:'rating',label:tr('best_rated')}]}/></CoffeeField>
        </div>
        <div className="sd-shot-custom-dates" hidden={dateShortcut !== 'custom'}>
          <div className="sd-shot-range">
            <CoffeeField label={tr('date_from')}><input type="date" className="sd-input" value={dateFrom}
              max={dateTo || undefined} disabled={reportExporting} onChange={e => changeDate('from', e.target.value)} /></CoffeeField>
            <CoffeeField label={tr('date_to')}><input type="date" className="sd-input" value={dateTo}
              min={dateFrom || undefined} disabled={reportExporting} onChange={e => changeDate('to', e.target.value)} /></CoffeeField>
            <CoffeeField label={t('before')}><input type="date" className="sd-input" value={dateBefore}
              disabled={reportExporting} onChange={e => changeDate('before', e.target.value)} /></CoffeeField>
          </div>
        </div>
        <p className="sd-rowsub sd-shot-timezone">{t('timezone')} {window.__sdTimezone}</p>
        <details className="sd-shot-more"><summary>{tr('more_filters')}{moreFilterCount > 0 && <span className="sd-filter-count">{moreFilterCount}</span>}</summary><div className="sd-coffee-fields">{[['taste','fb_taste',[...new Set([...FB_OPTIONS.taste,...(recordedFilters.taste||[])])]],['user_id','brewing_for',[...(app.data.users?.items||[]),...(recordedFilters.users||[])].map(u=>u.id)],['roast','roast',[...(app.data.roast_types||[]).map(r=>r.name),...(recordedFilters.roast||[])]],['profile_name','profile_label',[...(app.data.profiles||[]).map(p=>p.name),...(recordedFilters.profile_name||[])]]].map(([key,label,values])=><CoffeeField key={key} label={tr(label)}><select className="sd-input" value={filters[key]} disabled={reportExporting} onChange={e=>setFilter(key,e.target.value)}><option value="">{tr('all_values')}</option>{[...new Set(values)].map(v=><option key={v} value={v}>{key==='taste'?fbLabel(v):key==='user_id'?[...(app.data.users?.items||[]),...(recordedFilters.users||[])].find(u=>u.id===v)?.name||v:v}</option>)}</select></CoffeeField>)}{[['max_rating','maxRating',['1','2','3','4','5']],['rating_state','ratingState',['unrated','rated']],['has_photo','photoState',['yes','no']]].map(([key,label,values])=><CoffeeField key={key} label={t(label)}><select className="sd-input" value={filters[key]} disabled={reportExporting} onChange={e=>setFilter(key,e.target.value)}><option value="">{t('any')}</option>{values.map(v=><option key={v} value={v}>{key==='max_rating'?v+' ★':t(v)}</option>)}</select></CoffeeField>)}</div></details>
        <div className="sd-shot-export">
          <CoffeeField label={reportText.contents}><select className="sd-input sd-shot-pdf-format" value={reportCompact ? 'compact' : 'full'}
            disabled={reportExporting} onChange={e => setReportCompact(e.target.value === 'compact')}>
            <option value="full">{reportText.full}</option><option value="compact">{reportText.compact}</option>
          </select></CoffeeField>
          <label className="sd-coffee-check"><input type="checkbox" checked={includePhotos} disabled={reportExporting}
            onChange={e => setIncludePhotos(e.target.checked)} />{tr('include_photos')}</label>
          <Btn variant="primary" className="sd-shot-pdf" onClick={exportReport} aria-busy={reportExporting}
            disabled={reportExporting || invalidRange || listLoading || listError || !shots.length}>
            <Icon name="download" size={18} />{tr(reportExporting ? 'report_exporting' : 'export_pdf')}
          </Btn>
        </div>
        {reportProgress && <div className={'sd-shot-export-status ' + reportProgress.phase} role="status" aria-live="polite" aria-atomic="true">
          <div className="sd-shot-export-status-copy">
            <span>{reportStatus}{reportExporting && reportProgress.total > 0 && <span className="sd-shot-export-count">{reportProgress.done} / {reportProgress.total}</span>}</span>
            {!reportExporting && <button type="button" className="sd-iconbtn" aria-label={tr('dismiss')} onClick={() => setReportProgress(null)}>×</button>}
          </div>
          {(reportExporting || reportProgress.phase === 'complete') && <progress aria-label={reportStatus}
            max={reportProgress.total || 1} value={reportProgress.total ? reportProgress.done : undefined} />}
        </div>}
        {invalidRange && <p role="alert" className="sd-itemsub">{tr('report_invalid_range')}</p>}
        {listError && <p role="alert" className="sd-itemsub">{tr('history_changed')} <Btn onClick={()=>setReloadList(n=>n+1)}>{tr('reload_history')}</Btn></p>}
      </Card>

      <div className="sd-shots-detail">
      {/* Selected shot: the chart is a display window, like the device screen. */}
      <div style={{ position: 'relative', zIndex: 5, marginBottom: 14 }}>
        <Card flush className="sd-shot-history-card">
          <div style={{ padding: '14px 16px 0' }}>
            <div className="sd-cardhead" style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
                <span className="sd-cardtitle">{selShot ? `${Number(selShot.final_weight_g).toFixed(1)} g in ${Number(selShot.duration_s).toFixed(1)} s` : tr('select_shot')}</span>
              </div>
              {saveButton}
            </div>
          </div>
          {/* chart */}
          <div ref={graph} className="sd-shot-graph sd-glass">
            <div className="sd-glass-legend"><span><i />{tr('flow')}</span><span><i className="w" />{tr('weight')}</span>{ideal && <span><i className="ideal" />{tr('ideal_flow')}</span>}</div>
            {detail ? (
              <ResponsiveShotChart height={240} samples={detail.samples} finalWeight={detail.final_weight_g} ideal={ideal} band={shotFlowBand(app, detail)} themeKey={app.theme} smoothing={Number(smooth)} shotValidity={detail.settings?.shot_validity} />
            ) : (
              <div style={{ height: 240, display: 'grid', placeItems: 'center' }}><span className="sd-micro" style={{ color: 'var(--glass-dim)' }}>{tr('select_shot')}</span></div>
            )}
          </div>
          <div className="sd-shot-chart-foot">
            {/* Primary action sits with the chart it acts on */}
            <Btn variant={sel ? 'primary' : 'ghost'} className="block" disabled={!detailReady || analysisLoading}
              onClick={() => { setAnalysisState({ shotId: sel, status: 'loading' }); setAnalyzed(true); setAnalysisRequest(n => n + 1); }}>{tr(analysisLoading ? 'analyzing_shot' : 'analyze')}</Btn>
            <div style={{ width: 104, flexShrink: 0 }}>
              <div className="sd-fieldlabel">{tr('smooth_short')}</div>
              <Select value={smooth} onChange={setSmooth} style={{ width: '100%' }}
                options={[1, 3, 5, 10, 20].map(n => ({ value: String(n), label: n === 1 ? tr('off') : n + '×' }))} />
            </div>
          </div>
        </Card>
      </div>

      {detailReady && analyzed && analysis && <AnalysisPanel analysis={analysis} app={app} onClose={() => setAnalyzed(false)} />}
      {detailReady && analyzed && analysisState?.status === 'error' && <p role="alert" className="sd-itemsub">{tr('shot_analysis_failed')}</p>}

      {detail && <CoffeeShotDetails key={detail.id} shot={detail} app={app}/>}
      {detail?.grinder_telemetry && Object.keys(detail.grinder_telemetry).length > 0 && <GrinderShotDetails key={detail.id} shot={detail} />}
      </div>

      <div className="sd-shots-list">

      {selecting&&<Card title={t('manage')}><p role="status">{selectedCount} {t('selected')} · {page?.total||0} {t('matches')}</p><div className="sd-coffee-actions">
        <Btn variant="ghost" disabled={listLoading||listError||previewBusy} onClick={()=>setSelection({all:false,ids:shots.map(s=>s.id)})}>{t('loaded')} ({shots.length})</Btn>
        <Btn variant="ghost" disabled={listLoading||listError||previewBusy} onClick={()=>setSelection({all:true,ids:[]})}>{t('matching')} ({page?.total||0})</Btn>
        <Btn variant="ghost" onClick={()=>setSelection({all:false,ids:[]})}>{t('clear')}</Btn>
        <Btn disabled={!selectedCount||listLoading||listError||previewBusy||app.data.settings.shot_active} onClick={reviewSelection}>{t('review')} ({selectedCount})</Btn>
      </div></Card>}
      {selectionNotice&&<p role="status">{selectionNotice}</p>}
      {deleteReview&&<ShotDeleteReview key={deleteReview.token} app={app} review={deleteReview} onClose={()=>setDeleteReview(null)} onDeleted={op=>{setDeleteReview(null);setSelection({all:false,ids:[]});setSel(null);setDetail(null);setAnalysisState(null);setReloadList(n=>n+1);app.toast(op.deleted+' '+t('deleted'));}}/>}
      {/* Shot list */}
      <div className="sd-eyebrow" style={{ margin: '4px 4px 8px' }}>{shots.length}{page?.total!=null?' / '+page.total:''} {tr('tab_shots')}</div>
      {!listLoading && !listError && !invalidRange && !shots.length && <EmptyState icon="shots"
        title={tr(dateFrom || dateTo ? 'report_empty' : 'no_shots')} sub={tr('no_shots_sub')} />}
      {shots.map(s => (
        <div key={s.id} className={selecting?'sd-shot-selection':''}>
        {selecting&&<input type="checkbox" aria-label={'#'+s.id+' · '+historyDate(s.started_at,app.lang)} checked={selection.all?!selection.ids.includes(s.id):selection.ids.includes(s.id)} disabled={previewBusy} onChange={()=>toggleSelected(s.id)}/>}
        <div><ShotRow selectionMode={selecting} shot={s} selected={s.id === sel} dark={dark}
          gbsEnabled={!!app.data.settings?.gbs?.settings?.enabled}
          onSelect={() => {
            if(selecting){toggleSelected(s.id);return;}
            requestedGraph.current = s.id;
            if (s.id !== sel) { setSel(s.id); setDetail(null); setAnalysisState(null); }
            else if (detail?.id === s.id) {
              requestedGraph.current = null;
              window.requestAnimationFrame(scrollToGraph);
            }
            setAnalyzed(false);
          }}
          onDelete={async () => {
            const previousShots = shots;
            const previousDetail = detail;
            const previousAnalysis = analysisState;
            const previousAnalyzed = analyzed;
            setShots(rows => rows.filter(row => row.id !== s.id));
            if (sel === s.id) {
              setSel(null);
              setDetail(null);
              setAnalysisState(null);
              setAnalyzed(false);
            }
            const result = await app.deleteShot(s.id);
            if (result && result.ok) return;
            setShots(previousShots);
            if (sel === s.id) {
              setSel(s.id);
              setDetail(previousDetail);
              setAnalysisState(previousAnalysis);
              setAnalyzed(previousAnalyzed);
            }
          }}
          onFeedback={() => app.openFeedback(s.id)} /></div></div>
      ))}
      {page && shots.length < page.total && <Btn className="block" disabled={listLoading||listError||reportExporting} onClick={loadMore}>{tr(listLoading?'loading':'load_more')}</Btn>}
      </div>
    </div>
  );
}

function ShotGbsBadge({ status, enabled }) {
  const labels = { successful: 'shot_gbs_successful', failed: 'shot_gbs_failed', unconfirmed: 'shot_gbs_unconfirmed' };
  if (!enabled || !labels[status]) return null;
  return <span className={'sd-pill sd-shot-gbs ' + (status === 'successful' ? 'good' : status)}
    data-gbs-status={status} title={tr(labels[status])} aria-label={tr(labels[status])}>
    <span className="dot" aria-hidden="true" />GBS
  </span>;
}

function GrinderShotDetails({ shot }) {
  const data = shot.grinder_telemetry;
  const fmt = (v, unit, digits = 2) => typeof v === 'number' && Number.isFinite(v) ? v.toFixed(digits) + ' ' + unit : '—';
  const rawUnit = (v, unit, divisor = 1000) => typeof v === 'number' ? fmt(v / divisor, unit) : '—';
  const row = (label, value) => <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, padding: '6px 0', borderBottom: '1px solid var(--border-soft)' }}>
    <dt className="sd-itemsub" style={{ flex: 1 }}>{label}</dt><dd className="sd-mono" style={{ margin: 0, textAlign: 'right', fontSize: 12, overflowWrap: 'anywhere', maxWidth: '60%' }}>{value}</dd>
  </div>;
  const report = data?.reporting || {};
  const grind = data?.grind || {};
  const recipe = data?.recipe || {};
  const brew = data?.brew_event || {};
  const before = data?.before?.recipe_gbs?.coursenessDeciMym;
  const after = data?.after?.recipe_gbs?.coursenessDeciMym;
  const beforeKnown = typeof before === 'number' && Number.isFinite(before);
  const afterKnown = typeof after === 'number' && Number.isFinite(after);
  const targetChanged = beforeKnown && afterKnown ? before !== after : null;
  const states = {result_served: 'grinder_report_served', delivery_incomplete: 'grinder_report_incomplete',
    captured: 'grinder_report_captured', rejected: 'grinder_report_rejected'};
  const receipt = data?.receipt || 'unconfirmed';
  const collecting = data?.collection?.status === 'pending' && Date.now() - new Date(data.collection.updated_at).getTime() < 120000;
  const validity = shot.settings?.shot_validity;
  return <ShotDetailsPanel title={tr('grinder_shot_title')} className="sd-grinder-shot-details">
    <div className="sd-itemsub" style={{ marginBottom: 10 }}>#{shot.id} · {shot.profile_name}</div>
    {!data ? <div className="sd-itemsub">{tr('grinder_no_capture')}</div> : <>
      <div className="sd-grinder-status" style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: 12, marginBottom: 10 }}>
        <div><div className="sd-fieldlabel">{tr('grinder_shot_report')}</div><Pill variant={report.outcome === 'result_served' ? 'good' : ''}>
          {tr(states[report.outcome] || 'grinder_report_captured')}</Pill></div>
        <div><div className="sd-fieldlabel">{tr('grinder_shot_receipt')}</div><Pill variant={receipt === 'recorded_valid' ? 'good' : ''}>
          {tr(receipt === 'recorded_valid' ? 'grinder_receipt_valid' : receipt === 'recorded_invalid' ? 'grinder_receipt_invalid' : 'grinder_receipt_unknown')}</Pill></div>
      </div>
      {collecting && <p className="sd-itemsub">{tr('grinder_collecting')}</p>}
      {(data.collection?.error || data.collection?.baseline_error) && <p className="sd-itemsub">{tr('grinder_export_unavailable')}</p>}
      {report.reason && <p className="sd-itemsub" style={{ overflowWrap: 'anywhere' }}>{report.reason}</p>}
      <dl style={{ margin: '8px 0 12px' }}>
        {row(tr('grinder_reported_brew'), fmt(report.duration_s, 's', 3) + ' / ' + fmt(report.weight_g, 'g'))}
        {data.brew_event && row(tr('grinder_received_brew'), rawUnit(brew.brew_duration, 's') + ' / ' + rawUnit(brew.brew_mass, 'g'))}
        {row(tr('grinder_brew_target'), rawUnit(recipe.recipe_brew_time, 's') + ' / ' + rawUnit(recipe.recipe_brew_weight, 'g'))}
        {typeof report.duration_s === 'number' && typeof recipe.recipe_brew_time === 'number' && row(tr('grinder_time_error'),
          (report.duration_s - recipe.recipe_brew_time / 1000 > 0 ? '+' : '') + fmt(report.duration_s - recipe.recipe_brew_time / 1000, 's'))}
      </dl>
      <details>
        <summary style={{ cursor: 'pointer', color: 'var(--primary)', fontSize: 13, padding: '4px 0' }}>{tr('grinder_dose_adjustment')}</summary>
        <dl style={{ margin: '8px 0' }}>
          {row(tr('grinder_linked_dose'), grind.grind_id != null ? '#' + grind.grind_id : '—')}
          {row(tr('grinder_dose_time'), fmtTime(grind.grind_date_time) || '—')}
          {row(tr('grinder_dose_weight'), rawUnit(grind.grind_weight, 'g') + ' / ' + rawUnit(recipe.recipe_amount, 'g'))}
          {row(tr('grinder_grind_duration'), rawUnit(grind.grind_duration, 's'))}
          {row(tr('grinder_trigger'), grind.trigger || '—')}
          {row(tr('grinder_dose_success'), grind.grind_successfull == null ? '—' : tr(grind.grind_successfull === 1 ? 'grinder_yes' : 'grinder_no'))}
          {row(tr('grinder_recipe_slot'), grind.recipe_index ?? '—')}
          {row(tr('grinder_gbs_enabled'), grind.recipe_gbs_enabled == null ? '—' : tr(grind.recipe_gbs_enabled === 1 ? 'grinder_yes' : 'grinder_no'))}
          {row(tr('grinder_gbs_mode'), data.after?.recipe_gbs?.gbsMode || data.before?.recipe_gbs?.gbsMode || '—')}
          {row(tr('grinder_initial_dd'), fmt(recipe.recipe_coarseness, 'µm', 1))}
          {row(tr('grinder_target_before'), rawUnit(before, 'µm', 10))}
          {row(tr('grinder_target_after'), rawUnit(after, 'µm', 10))}
          {row(tr('grinder_target_change'), targetChanged == null ? tr('grinder_not_comparable') : tr(targetChanged ? 'grinder_target_changed' : 'grinder_target_unchanged'))}
          {row(tr('grinder_effective_dd'), fmt(data.after?.settings?.['Gbs.State.EffectiveGrindSizePrediction']?.grindSizeUm, 'µm'))}
          {row(tr('grinder_raw_dd'), grind.grind_ddd ?? '—')}
          {row(tr('grinder_scale_capture'), validity ? tr(validity.valid_for_learning === true ? 'grinder_capture_valid' : 'grinder_capture_check') : '—')}
        </dl>
        <p className="sd-itemsub">{tr('grinder_motion_unconfirmed')}</p>
        {data.after?.captured_at && <p className="sd-micro">{tr('grinder_snapshot_time')} {fmtTime(data.after.captured_at)}</p>}
        {!!data.alerts?.length && <div className="sd-itemsub">{tr('grinder_new_alerts')}: {data.alerts.map(a => a.type || a.alert_type_id).join(', ')}</div>}
        <GrinderTechnicalDetails data={data} />
      </details>
    </>}
  </ShotDetailsPanel>;
}

// Closed telemetry details do not serialize the full grinder export or mount
// a large text node; unrelated status updates also reuse the existing text.
function GrinderTechnicalDetails({ data }) {
  const [open, setOpen] = useState(false);
  const text = useMemo(() => open ? JSON.stringify(data, null, 2) : '', [open, data]);
  return <details style={{ marginTop: 12 }} onToggle={event => setOpen(event.currentTarget.open)}>
    <summary className="sd-itemsub" style={{ cursor: 'pointer' }}>{tr('grinder_technical_details')}</summary>
    {open && <pre style={{ fontSize: 11, whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', background: 'var(--inset)', borderRadius: 'var(--r-md)', padding: 12, maxHeight: 300, overflow: 'auto' }}>{text}</pre>}
  </details>;
}

function ShotRow({ selectionMode=false, shot, selected, dark, gbsEnabled, onSelect, onDelete, onFeedback }) {
  const [dx, setDx] = useState(0);
  const start = useRef(null);
  const onStart = e => { if(selectionMode)return; start.current = (e.touches ? e.touches[0].clientX : e.clientX); };
  const onMove = e => {
    if (start.current == null) return;
    const x = (e.touches ? e.touches[0].clientX : e.clientX);
    setDx(Math.max(-84, Math.min(0, x - start.current)));
  };
  const onEnd = () => { setDx(d => (d < -50 ? -76 : 0)); start.current = null; };
  // Green time pill = pull landed inside the profile's own target window.
  // Fall back to the conventional 25–32 s if a shot has no stored targets.
  const tMin = shot.target_time_min_s > 0 ? shot.target_time_min_s : 25;
  const tMax = shot.target_time_max_s > 0 ? shot.target_time_max_s : 32;
  const inWindow = shot.duration_s >= tMin && shot.duration_s <= tMax;
  const wBadge = weightDeltaBadge(shot, dark);
  return (
    <div className="sd-shot-row" data-shot-id={shot.id} style={{ position: 'relative', marginBottom: 8 }}>
      {/* delete bg */}
      <button disabled={selectionMode} aria-label={tr('delete')} onClick={onDelete} style={{
        position: 'absolute', right: 0, top: 0, bottom: 0, width: 76, border: 'none',
        background: 'var(--danger-surface)', color: 'var(--danger-text)', borderRadius: 'var(--r-md)',
        display: 'grid', placeItems: 'center', cursor: 'pointer',
      }}><Icon name="trash" size={20} /></button>
      <div onClick={() => dx === 0 && onSelect()}
        onMouseDown={onStart} onMouseMove={onMove} onMouseUp={onEnd} onMouseLeave={() => start.current && onEnd()}
        onTouchStart={onStart} onTouchMove={onMove} onTouchEnd={onEnd}
        style={{
          transform: `translateX(${dx}px)`, transition: start.current ? 'none' : 'transform .2s',
          background: selected ? 'var(--card-2)' : 'var(--card)', border: '1px solid ' + (selected ? 'var(--fg-faint)' : 'var(--border-soft)'), boxShadow: selected ? 'inset 3px 0 0 var(--primary)' : 'var(--sh-sm)',
          borderRadius: 'var(--r-md)', padding: '12px 14px', cursor: 'pointer', position: 'relative',

        }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="sd-shot-identity" style={{ display: 'flex', alignItems: 'center', gap: 8, minHeight: 24 }}>
              <span className="sd-itemname" style={{ flex: '0 1 auto', minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{shot.user_name}</span>
              <span className="sd-itemsub" style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>· {shot.profile_name}</span>
              <ShotGbsBadge status={shot.gbs_status} enabled={gbsEnabled} />
            </div>
            <div className="sd-shot-metrics" style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6, minHeight: 28 }}>
              <span className="sd-readout" style={{ flexShrink: 0, color: 'var(--fg)', fontSize: 17 }}>{shot.final_weight_g} g</span>
              {wBadge && (
                <span className="sd-mono" title={tr('target') + ' ' + shot.target_weight_g + 'g'}
                  style={{
                    flex: 'none', display: 'inline-flex', alignItems: 'center', height: 28, padding: '0 10px',
                    borderRadius: 'var(--r-pill)', fontSize: 11, fontWeight: 600, letterSpacing: '.02em',
                    color: wBadge.color, background: wBadge.bg, border: '1px solid ' + wBadge.border,
                    whiteSpace: 'nowrap',
                  }}>{wBadge.text}</span>
              )}
              <span style={{ marginLeft: 'auto', display: 'inline-flex', flexShrink: 0 }}>
                <Pill variant={inWindow ? 'good' : ''} dot>{shot.duration_s.toFixed(1)}s</Pill>
              </span>
            </div>
            <div className="sd-itemsub" style={{ marginTop: 6, display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 6 }}>
              {(shot.coffee?.bean || shot.coffee?.grind_setting || shot.rating || shot.coffee?.photo) && <span className="sd-coffee-row" style={{width:'100%'}}>{shot.coffee?.bean?.name || tr('unassigned')}{shot.coffee?.grind_setting?' · '+shot.coffee.grind_setting:''}{shot.rating?' · '+shot.rating+' ★':''}{shot.coffee?.photo?' · '+tr('grinder_photo'):''}</span>}
              <span>{fmtTime(shot.started_at)} · {shot.roast} · {tr('avg_flow')} {fmtAvgFlow(shot.average_flow_g_s)}</span>
              {typeof shot.brew_temperature_c === 'number' && Number.isFinite(shot.brew_temperature_c) &&
                <span className="sd-shot-temperature" title={tr(shot.brew_temperature_source === 'profile' ? 'shot_profile_temperature' : 'shot_brew_temperature')}>
                  · {shot.brew_temperature_c.toFixed(1)} °C{shot.brew_temperature_source === 'profile' ? ' (' + tr('shot_temperature_profile') + ')' : ''}
                </span>}
              {/* The action link is the single feedback affordance; its label
                  already says whether feedback exists. */}
              <button onClick={e => { e.stopPropagation(); onFeedback(); }} style={{ marginLeft: 'auto', flexShrink: 0, background: 'none', border: 'none', color: 'var(--primary)', fontWeight: 600, fontSize: 12, cursor: 'pointer' }}>
                {shot.has_feedback ? tr('edit_feedback') : tr('feedback')}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function AnalysisPanel({ analysis, app, onClose }) {
  const evidence = analysis.evidence || [];
  const recommendations = analysis.recommendations || [];
  const prebrewing = analysis.prebrewing || {};
  return (
    <div style={{ marginTop: 14, marginBottom: 12, padding: 14, background: 'var(--card-2)', borderRadius: 'var(--r-md)', border: '1px solid var(--border-soft)', animation: 'sd-rise .2s ease' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <span className="sd-serif" style={{ fontStyle: 'italic', fontSize: 18, color: 'var(--fg)' }}>{analysis.label || analysis.primary_issue}</span>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Pill variant="ok" dot>{Math.round((analysis.confidence || 0) * 100)}% {tr('confidence')}</Pill>
          <button className="sd-iconbtn" onClick={onClose} title={tr('dismiss')}><Icon name="close" size={16} /></button>
        </div>
      </div>
      <p style={{ margin: '0 0 12px', fontSize: 13, lineHeight: 1.5, color: 'var(--fg-dim)' }}>{analysis.summary}</p>
      <div style={{ marginBottom: 10 }}>
        <Tag>{tr('prebrew_detected')}: {prebrewing.detected ? '●' : '○'} {tr('prebrew')} {prebrewing.match ? '✓' : '✕'}</Tag>
      </div>
      <div className="sd-micro" style={{ marginBottom: 6 }}>{tr('evidence')}</div>
      <div className="sd-tags" style={{ marginBottom: 12 }}>{evidence.map((e, i) => <Tag key={i}>{e}</Tag>)}</div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'baseline' }}>
        <span className="sd-micro" style={{ color: 'var(--primary)' }}>{tr('recommend')}:</span>
        <span style={{ fontSize: 13, color: 'var(--fg)' }}>{recommendations.join(' · ')}</span>
      </div>
    </div>
  );
}

// ---- Feedback modal ----
const FB_DEFAULTS = { issue: 'none', taste: 'not_tasted', visual: 'normal', prep: 'normal', grind_adjustment: 'none', rating: null, notes: '' };

function FeedbackModal({ app }) {
  const shotId = app.feedbackShot;
  const [f, setF] = useState(null);
  const [existing,setExisting]=useState(false),[shot,setShot]=useState(null),[context,setContext]=useState({}),[error,setError]=useState(''),[conflict,setConflict]=useState(false),[reload,setReload]=useState(0),[busy,setBusy]=useState(false),[tasteDirty,setTasteDirty]=useState(false),[photo,setPhoto]=useState(null),[removePhoto,setRemovePhoto]=useState(false),[addingBean,setAddingBean]=useState(false),[photoReading,setPhotoReading]=useState(false);
  useEffect(()=>{let cancelled=false;setF(null);setError('');setConflict(false);setTasteDirty(false);setPhoto(null);setRemovePhoto(false);
    app.loadShotDetail(shotId).then(d=>{if(cancelled)return;if(!d)throw new Error(tr('report_load_failed'));setShot(d);setContext(coffeeDraft(d.coffee));setExisting(!!d.feedback);setF({...FB_DEFAULTS,...(d.feedback||{})});}).catch(e=>{if(!cancelled)setError(e.message);});return()=>{cancelled=true;};
  },[shotId,reload]);
  const save=async removeTaste=>{setBusy(true);setError('');try {const body={revision:shot.review_revision};if(removeTaste)body.feedback=null;else {body.context=context;if(existing||tasteDirty)body.feedback={...f,user_name:app.data.users?.active?.name||''};if(photo)body.photo_data_url=photo;if(removePhoto)body.remove_photo=true;}await app.saveReview(shotId,body);}catch(e){setError(e.status===409?tr('review_conflict'):e.message);setConflict(e.status===409);}finally{setBusy(false);}};
  if(!f)return <Modal title={tr('fb_title')} onClose={app.closeFeedback}>{error?<><p role="alert">{error}</p><Btn onClick={()=>setReload(n=>n+1)}>{tr('retry')}</Btn></>:<EmptyState icon="shots" title={tr('loading')}/>}</Modal>;
  const set=(k,v)=>{setTasteDirty(true);setF(s=>({...s,[k]:v}));};
  const sel = (key, label) => (
    <div style={{ marginBottom: 14 }}>
      <div className="sd-fieldlabel">{label}</div>
      <Select value={f[key]} onChange={v => set(key, v)} options={FB_OPTIONS[key].map(o => ({ value: o, label: fbLabel(o) }))} />
    </div>
  );
  return (
    <Modal title={tr('fb_title')} onClose={() => !busy && app.closeFeedback()} dismissible={!busy}
      footer={<>
        {existing && <Btn variant="danger" disabled={busy||conflict||photoReading} onClick={() => save(true)}>{tr('delete_taste')}</Btn>}
        <Btn variant="primary" className="block" disabled={busy||conflict||photoReading} onClick={() => save(false)}>{tr('save')}</Btn>
      </>}>
      {error&&<p role="alert">{error}</p>}{conflict&&<Btn onClick={()=>setReload(n=>n+1)}>{tr('reload_review')}</Btn>}
      <h3>{tr('preparation')}</h3><PreparationFields value={context} onChange={setContext} beans={app.data.beans} grinders={app.data.grinders} recorded={shot.coffee} history disabled={busy}/>
      {addingBean?<BeanEditor app={app} onCancel={()=>setAddingBean(false)} onSaved={b=>{setContext(c=>({...c,bean_id:b.id}));setAddingBean(false);}}/>:<Btn variant="ghost" onClick={()=>setAddingBean(true)}>{tr('add_bean')}</Btn>}
      <GrindPhotoInput onLoading={setPhotoReading} photo={shot.coffee?.photo} dataUrl={photo} remove={removePhoto} disabled={busy} onChange={(value,remove)=>{setPhoto(value);setRemovePhoto(remove);}}/>
      <h3>{tr('feedback')}</h3>
      {sel('issue', tr('fb_issue'))}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {sel('taste', tr('fb_taste'))}
        {sel('visual', tr('fb_visual'))}
      </div>
      {sel('prep', tr('fb_prep'))}
      <div style={{ marginBottom: 14 }}>
        <div className="sd-fieldlabel">{tr('fb_grind')}</div>
        <Segmented value={f.grind_adjustment} onChange={v => set('grind_adjustment', v)}
          options={[{ value: 'finer_next', label: tr('fb_finer') }, { value: 'none', label: tr('fb_same') }, { value: 'coarser_next', label: tr('fb_coarser') }]} />
      </div>
      <div style={{ marginBottom: 14 }}>
        <div className="sd-fieldlabel">{tr('fb_rating')}</div>
        <div style={{ display: 'flex', gap: 8 }}>
          {[1, 2, 3, 4, 5].map(n => (
            <button key={n} aria-label={n+' / 5'} aria-pressed={f.rating===n} onClick={() => set('rating', f.rating===n?null:n)} style={{ flex: 1, minHeight: 46, background: 'var(--input)', border: '1px solid var(--input-border)', borderRadius: 'var(--r-sm)', cursor: 'pointer', display: 'grid', placeItems: 'center' }}>
              <Icon name="star" size={22} color={n <= f.rating ? 'var(--primary)' : 'var(--fg-faint)'} fill={n <= f.rating ? 'var(--primary)' : 'none'} />
            </button>
          ))}
        </div>
      </div>
      <div>
        <div className="sd-fieldlabel">{tr('fb_notes')} · ≤1000</div>
        <textarea className="sd-input" maxLength={1000} value={f.notes} onChange={e => set('notes', e.target.value)}
          style={{ height: 80, padding: 12, resize: 'none', fontFamily: 'var(--sans)' }} />
      </div>
    </Modal>
  );
}

Object.assign(window, { ShotsScreen, ShotRow, AnalysisPanel, FeedbackModal, fmtTime, fmtAvgFlow });
