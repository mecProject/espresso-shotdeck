"""Atomic update-trust generations and retained compatible recovery policy.

Replacement keys/feeds enter only through a digest pinned in authenticated B
software. The active pointer contains the floor and staged observation, so a
power cut cannot activate a new signer without its recovery policy. The old
manifest-security file remains monotonic and is never reset.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import re
import stat
from urllib.parse import urlsplit

from .storage import MigrationError, atomic, boot_id, canonical, digest, directory, guard, read, read_json, remove, version, write_json

MARKER = '.shotdeck-signing-migration-v1'


def tree_digest(root, *, runtime=False):
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise MigrationError('Pinned tree must be an ordinary directory')
    result = hashlib.sha256()
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if '.shotdeck-release.json' == path.name or (runtime and ('__pycache__' in relative.parts or path.suffix == '.pyc')):
            continue
        info = path.lstat()
        if info.st_uid != os.geteuid() or (not stat.S_ISLNK(info.st_mode) and info.st_mode & 0o022):
            raise MigrationError('Pinned tree must be owned by the operator and protected from writes')
        if stat.S_ISDIR(info.st_mode):
            result.update(f'dir:{relative.as_posix()}\n'.encode())
        elif stat.S_ISREG(info.st_mode):
            result.update(f'file:{relative.as_posix()}\n'.encode())
            with path.open('rb') as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    result.update(block)
        elif runtime and stat.S_ISLNK(info.st_mode):
            target = path.resolve(strict=True)
            if not target.is_relative_to(root.resolve()) and not (
                    relative.parent == Path('bin') and re.fullmatch(r'python(?:3(?:\.\d+)?)?', path.name)
                    and target.is_relative_to(Path('/usr').resolve()) and target.stat().st_uid == 0
                    and not target.stat().st_mode & 0o022):
                raise MigrationError('Runtime contains an external non-Python link')
            result.update(f'link:{relative.as_posix()}:{os.readlink(path)}\n'.encode())
        else:
            raise MigrationError('Pinned tree contains an unsupported filesystem object')
    return result.hexdigest()


def validate_policy(value):
    fields = {'schema_version', 'generation', 'public_key_pem', 'fingerprint', 'feeds',
              'minimum_app_version', 'minimum_updater_version', 'recovery_version'}
    if (not isinstance(value, dict) or set(value) != fields or type(value['schema_version']) is not int
            or value['schema_version'] != 1 or type(value['generation']) is not int or value['generation'] < 1
            or not isinstance(value['feeds'], dict) or set(value['feeds']) != {'stable', 'beta'}):
        raise MigrationError('Invalid pinned update migration policy')
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        raw = value['public_key_pem'].encode('ascii')
        key = serialization.load_pem_public_key(raw)
        if not isinstance(key, Ed25519PublicKey) or key.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo) != raw:
            raise ValueError()
    except (AttributeError, UnicodeError, ValueError, TypeError) as exc:
        raise MigrationError('Expected exactly one canonical Ed25519 update public key') from exc
    if value['fingerprint'] != digest(raw):
        raise MigrationError('Update public fingerprint differs from the pinned policy')
    for channel, url in value['feeds'].items():
        if not isinstance(url, str):
            raise MigrationError('Invalid update lane')
        parsed = urlsplit(url)
        if (parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password
                or parsed.query or parsed.fragment or not parsed.path.endswith(f'/shotdeck-{channel}-v3.json')):
            raise MigrationError('Migration requires explicit HTTPS v3 stable/beta lanes')
    if version(value['recovery_version']) != version(value['minimum_app_version']):
        raise MigrationError('Initial migration floor must retain the exact compatibility release')
    if version(value['minimum_updater_version']) < version('0.2.4'):
        raise MigrationError('Migration policy requires updater 0.2.4 or newer')
    return value


class UpdateStore:
    def __init__(self, root, install_root, security_state, *, checkpoint=lambda step: None, boot=boot_id):
        self.root, self.install_root, self.security_state = Path(root), Path(install_root), Path(security_state)
        self.folder = self.root / 'updates'
        self.active_file = self.folder / 'active.json'
        self.journal = self.folder / 'pending.json'
        self.enrolled = self.root / 'update-enrolled.json'
        self.intent = self.root / 'update-initial-intent.json'
        self.checkpoint, self.boot = checkpoint, boot

    def active(self, *, verify_trees=True):
        try:
            pointer = read_json(self.active_file)
        except FileNotFoundError:
            indicators = (self.folder, self.enrolled, self.root / 'licence/enrolled.json', self.root / 'licence/floor.json')
            if any(path.exists() or path.is_symlink() for path in indicators):
                raise MigrationError('Update trust state is incomplete; legacy fallback refused')
            return None
        if (set(pointer) != {'schema_version', 'generation_id'} or type(pointer['schema_version']) is not int
                or pointer['schema_version'] != 1 or not isinstance(pointer['generation_id'], str)
                or not re.fullmatch('[0-9a-f]{64}', pointer['generation_id'])):
            raise MigrationError('Invalid active update generation')
        record = read_json(self.folder / 'generations' / pointer['generation_id'] / 'generation.json')
        if digest(canonical(record)) != pointer['generation_id']:
            raise MigrationError('Active update generation was changed')
        expected = {'schema_version', 'policy', 'runtime', 'runtime_sha256', 'highest_seen_version', 'recovery_tree_sha256'}
        if set(record) != expected or type(record['schema_version']) is not int or record['schema_version'] != 1:
            raise MigrationError('Invalid complete update generation')
        validate_policy(record['policy'])
        if self.enrolled.exists():
            floor = read_json(self.enrolled)
            if (set(floor) != {'schema_version', 'minimum_generation'} or type(floor['schema_version']) is not int
                    or floor['schema_version'] != 1 or type(floor['minimum_generation']) is not int
                    or not 1 <= floor['minimum_generation'] <= record['policy']['generation']):
                raise MigrationError('Active update authority is below a corrupt or higher committed generation floor')
        if read(self.folder / 'generations' / pointer['generation_id'] / 'update-public.pem', 16384) != record['policy']['public_key_pem'].encode('ascii'):
            raise MigrationError('Active update verifier differs from its policy')
        version(record['highest_seen_version'])
        runtime = Path(record['runtime'])
        allowed = self.install_root / 'updater-runtimes'
        if (runtime.parent != allowed or allowed.is_symlink() or runtime.name in {'.', '..'}
                or not re.fullmatch('[A-Za-z0-9._-]+', runtime.name)):
            raise MigrationError('Runtime is outside the retained versioned runtime directory')
        if verify_trees:
            if not all((runtime / 'bin' / name).is_file() and os.access(runtime / 'bin' / name, os.X_OK)
                    for name in ('python', 'shotdeck-updater')):
                raise MigrationError('Committed updater launcher is not executable; legacy fallback refused')
            if tree_digest(runtime, runtime=True) != record['runtime_sha256']:
                raise MigrationError('Active updater runtime is missing or changed; legacy fallback refused')
            self.assert_recovery(record)
        return record

    def assert_recovery(self, active):
        policy = active['policy']
        recovery = self.install_root / 'releases' / policy['recovery_version']
        if (read(recovery / MARKER, 16) != b'1\n' or not os.access(recovery / 'shotdeck', os.X_OK)
                or tree_digest(recovery) != active['recovery_tree_sha256']):
            raise MigrationError('Retained compatibility recovery release is missing or changed')
        return recovery

    def stage_and_activate(self, policy, expected_policy_sha256, runtime, *, probe_runtime, check_feed, current_version, recovery_sha256):
        """Caller holds updater and brew locks; this guard excludes licence/deploy writers.

        Feed validation is injected by the real updater adapter and uses an
        isolated state root. Neither a failed probe nor an interrupted prepare
        changes the active key/configuration/high-water file.
        """
        validate_policy(policy)
        if not isinstance(recovery_sha256, str) or not re.fullmatch('[0-9a-f]{64}', recovery_sha256):
            raise MigrationError('An independently approved recovery tree digest is required')
        if not isinstance(expected_policy_sha256, str) or digest(canonical(policy)) != expected_policy_sha256:
            raise MigrationError('Replacement update policy is not pinned by this compatibility app')
        with guard(self.root):
            # A pending licence transaction owns the approved active generation.
            if (self.root / 'licence/pending.json').exists():
                raise MigrationError('Finish the pending licence transaction before changing updater trust')
            previous = self.active() if self.active_file.exists() else None
            if previous is None and (self.enrolled.exists() or (self.root / 'licence/enrolled.json').exists() or (self.root / 'licence/floor.json').exists()):
                raise MigrationError('Committed update authority is missing; restore protected state instead of re-enrolling')
            if self.intent.exists() and read_json(self.intent) != {'schema_version': 1, 'policy_sha256': expected_policy_sha256}:
                raise MigrationError('Initial update preparation belongs to a different policy')
            if self.journal.exists():
                pending = read_json(self.journal)
                if (set(pending) != {'schema_version', 'generation_id', 'previous_id', 'policy_sha256'}
                        or type(pending['schema_version']) is not int or pending['schema_version'] != 1
                        or pending['policy_sha256'] != expected_policy_sha256
                        or (not self.active_file.exists() and pending['previous_id'] is not None)):
                    raise MigrationError('Cannot resume a changed or corrupted update trust journal')
            if self.folder.exists() and previous is None and not self.journal.exists() and not self.intent.exists():
                raise MigrationError('Incomplete update trust state requires recovery')
            if previous and policy['generation'] <= previous['policy']['generation']:
                if policy == previous['policy']:
                    if self.journal.exists():
                        if pending['generation_id'] != digest(canonical(previous)):
                            raise MigrationError('Pending update journal conflicts with active policy')
                        remove(self.journal)
                    write_json(self.enrolled, {'schema_version': 1, 'minimum_generation': policy['generation']})
                    if self.intent.exists():remove(self.intent)
                    return previous
                raise MigrationError('Update trust generations must increase')
            if previous and version(policy['minimum_app_version']) < version(previous['policy']['minimum_app_version']):
                raise MigrationError('Compatible application floors must never decrease')
            if version(current_version) < version(policy['minimum_app_version']):
                raise MigrationError('Install the compatibility release before changing trust')
            runtime = Path(runtime)
            if (runtime.parent != self.install_root / 'updater-runtimes' or runtime.is_symlink()
                    or runtime.parent.is_symlink() or runtime.name in {'.', '..'}):
                raise MigrationError('An immutable versioned runtime is required')
            probe_runtime(runtime, policy['minimum_updater_version'])
            highest = str(current_version)
            if self.security_state.exists():
                observed = read_json(self.security_state).get('highest_seen_version')
                if not isinstance(observed, str):
                    raise MigrationError('Invalid existing manifest high-water state')
                highest = str(max(version(highest), version(observed)))
            if previous:
                highest = str(max(version(highest), version(previous['highest_seen_version'])))
            # Must return a verified manifest version; no check() on live state.
            checked = check_feed(policy)
            if version(checked) < version(highest):
                raise MigrationError('New signed feed is below legitimate highest-seen history')
            record = dict(schema_version=1, policy=policy, runtime=str(runtime),
                runtime_sha256=tree_digest(runtime, runtime=True), highest_seen_version=str(max(version(highest), version(checked))),
                recovery_tree_sha256=recovery_sha256)
            self.assert_recovery(record)
            identifier = digest(canonical(record))
            if previous is None and not self.intent.exists():
                write_json(self.intent, {'schema_version': 1, 'policy_sha256': expected_policy_sha256},
                    lambda step: self.checkpoint('initial_intent_' + step))
            generation = directory(self.folder / 'generations' / identifier)
            write_json(generation / 'generation.json', record, lambda step: self.checkpoint('generation_' + step))
            atomic(generation / 'update-public.pem', policy['public_key_pem'].encode('ascii'),
                lambda step: self.checkpoint('update_key_' + step))
            write_json(self.journal, {'schema_version': 1, 'generation_id': identifier,
                'previous_id': digest(canonical(previous)) if previous else None, 'policy_sha256': expected_policy_sha256},
                lambda step: self.checkpoint('update_journal_' + step))
            self.checkpoint('update_prepared')
            # One replacement commits key, feeds, runtime, high-water observation
            # and app/recovery floors together. Never write the old shared PEM.
            write_json(self.active_file, {'schema_version': 1, 'generation_id': identifier},
                lambda step: self.checkpoint('update_' + step))
            self.checkpoint('update_activated')
            self.active()
            write_json(self.enrolled, {'schema_version': 1, 'minimum_generation': policy['generation']},
                lambda step: self.checkpoint('update_enrolled_' + step))
            if self.intent.exists():remove(self.intent)
            remove(self.journal)
            return record

    def recover_precommit(self):
        """Uncommitted preparation never becomes authority merely on restart."""
        if not self.journal.exists():
            return self.active()
        with guard(self.root):
            pending = read_json(self.journal)
            if (set(pending) != {'schema_version', 'generation_id', 'previous_id', 'policy_sha256'}
                    or pending.get('schema_version') != 1):
                raise MigrationError('Invalid update trust journal')
            if self.active_file.exists():
                active = self.active()
                active_id = digest(canonical(active))
                if active_id not in {pending['generation_id'], pending['previous_id']}:
                    raise MigrationError('Update trust journal conflicts with active authority')
                if active_id == pending['generation_id']:
                    remove(self.journal)
                return active
            if pending['previous_id'] is not None:
                raise MigrationError('Previous update authority was lost')
            # Initial precommit: old config remains complete. Keep the journal
            # to distinguish this state from deletion of committed authority.
            return None

    def record_install(self, installed_version, tree_sha256, manifest_sha256, key_id):
        active = self.active()
        if not active:
            return
        if key_id != active['policy']['fingerprint'][:16] or version(installed_version) <= version(active['policy']['minimum_app_version']):
            return
        write_json(self.folder / 'installed.json', dict(schema_version=1, generation_id=digest(canonical(active)),
            version=installed_version, tree_sha256=tree_sha256, manifest_sha256=manifest_sha256,
            install_boot=self.boot(), booted='', recovery_boot=''))

    def confirm_boot(self, installed_version, installed_tree, *, validate_licence):
        with guard(self.root):
            active = self.active()
            event = read_json(self.folder / 'installed.json')
            if (event.get('generation_id') != digest(canonical(active)) or event.get('version') != installed_version
                    or event.get('tree_sha256') != installed_tree or event.get('install_boot') == self.boot()):
                raise MigrationError('A higher-version U1 installation and new offline boot must be observed')
            validate_licence()
            event['booted'] = self.boot()
            write_json(self.folder / 'installed.json', event)
            return event

    def confirm_recovery(self, installed_version, installed_tree, *, validate_licence, physical_evidence):
        with guard(self.root):
            active = self.active()
            event = read_json(self.folder / 'installed.json')
            if (event.get('generation_id') != digest(canonical(active)) or not event.get('booted')
                    or self.boot() in {event['install_boot'], event['booted']}
                    or installed_version != active['policy']['recovery_version']
                    or installed_tree != active['recovery_tree_sha256']):
                raise MigrationError('Cold-boot the retained compatible recovery app before confirming U1')
            validate_licence()
            if (not isinstance(physical_evidence, dict) or set(physical_evidence) != {'operator', 'brew', 'stop', 'offline', 'recovery'}
                    or not isinstance(physical_evidence['operator'], str) or not physical_evidence['operator'].strip()
                    or any(physical_evidence[k] is not True for k in ('brew', 'stop', 'offline', 'recovery'))):
                raise MigrationError('Explicit operator observations of Brew, Stop, offline use and recovery are required')
            event.update(recovery_boot=self.boot(), physical_evidence=physical_evidence)
            write_json(self.folder / 'verified.json', event)
            return event

    def require_verified(self):
        active = self.active()
        if not active:
            raise MigrationError('U1 is not active')
        if not self.folder.joinpath('verified.json').exists():
            return self._require_automatic_verified(active)
        event = read_json(self.folder / 'verified.json')
        if (event.get('generation_id') != digest(canonical(active)) or type(event.get('schema_version')) is not int
                or event.get('schema_version') != 1 or not event.get('recovery_boot') or not event.get('booted')
                or len({event.get('install_boot'), event.get('booted'), event.get('recovery_boot')}) != 3
                or version(event.get('version')) <= version(active['policy']['minimum_app_version'])
                or not isinstance(event.get('physical_evidence'), dict)
                or any(event['physical_evidence'].get(k) is not True for k in ('brew', 'stop', 'offline', 'recovery'))):
            raise MigrationError('U1 update, offline boot and compatible recovery are not yet verified')
        return active

    def record_automatic_verification(self, qualification, observations, *, validate_licence):
        """Separate from attended pilot evidence; no physical observations invented.

        Caller observed both exact native apps healthy after distinct OS boots.
        The U1 qualification carries the independently completed physical gates.
        """
        with guard(self.root):
            active = self.active()
            self._check_automatic_verified(active, qualification, observations)
            if observations['recovery_boot'] != self.boot():
                raise MigrationError('Automatic recovery must be observed on this boot')
            validate_licence()
            write_json(self.folder / 'automatic-qualification.json', qualification)
            write_json(self.folder / 'automatic-verified.json', observations)
        return active

    def _check_automatic_verified(self, active, qualification, event):
        from .automatic import validate_plan
        plan = validate_plan(qualification, active['policy']['public_key_pem'].encode('ascii'))
        fields = {'schema_version', 'generation_id', 'qualification_sha256', 'install_boot',
            'target_boot', 'recovery_boot', 'target_tree_sha256', 'recovery_tree_sha256'}
        if (not isinstance(event, dict) or set(event) != fields
                or type(event['schema_version']) is not int or event['schema_version'] != 1
                or event['generation_id'] != digest(canonical(active))
                or event['qualification_sha256'] != digest(canonical(qualification))
                or plan['update_policy'] != active['policy']
                or event['target_tree_sha256'] != plan['target']['tree_sha256']
                or event['recovery_tree_sha256'] != active['recovery_tree_sha256']
                or plan['compatibility']['tree_sha256'] != active['recovery_tree_sha256']
                or any(not isinstance(event[k], str) or not re.fullmatch(r'[0-9a-f-]{36}', event[k])
                       for k in ('install_boot', 'target_boot', 'recovery_boot'))
                or len({event['install_boot'], event['target_boot'], event['recovery_boot']}) != 3):
            raise MigrationError('Automatic U1 boot and recovery proof is incomplete')

    def _require_automatic_verified(self, active):
        self._check_automatic_verified(active, read_json(self.folder / 'automatic-qualification.json'),
            read_json(self.folder / 'automatic-verified.json'))
        return active
