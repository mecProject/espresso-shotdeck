"""Durable automatic migration coordinator; all hardware operations are adapters.

The journal precedes each effect. Adapters reconcile the exact actual files on
retry, and never infer successful boot from a restart request. Reboot requests
are bounded per transition, so failed firmware/network/health cannot loop boots.
"""
from __future__ import annotations

from .storage import MigrationError, canonical, digest, read_json, write_json

PHASES = ('activate', 'install_target', 'target_boot', 'rollback', 'recovery_boot',
    'install_licence', 'licence_boot', 'commit_licence', 'committed_boot',
    'finish_licence', 'restore_target', 'final_boot', 'complete')


class AutomaticFlow:
    def __init__(self, folder, qualification, plan, port):
        self.folder, self.qualification, self.plan, self.port = folder, qualification, plan, port
        self.path = folder / 'transaction.json'

    def start(self):
        if self.path.exists():
            return self._load()
        self.port.assert_baseline()
        value = dict(schema_version=1, qualification_sha256=digest(canonical(self.qualification)),
            phase='activate', boots={}, reboot_attempts=0)
        write_json(self.folder / 'qualification.json', self.qualification)
        write_json(self.path, value)
        return value

    def _load(self):
        value = read_json(self.path)
        if (set(value) != {'schema_version', 'qualification_sha256', 'phase', 'boots', 'reboot_attempts'}
                or type(value['schema_version']) is not int or value['schema_version'] != 1
                or value['qualification_sha256'] != digest(canonical(self.qualification))
                or value['phase'] not in PHASES or not isinstance(value['boots'], dict)
                or type(value['reboot_attempts']) is not int or not 0 <= value['reboot_attempts'] <= 3):
            raise MigrationError('Automatic migration journal needs operator reconciliation')
        # Only transition names may identify observations, all measured boot IDs.
        import uuid
        try:
            for key, boot in value['boots'].items():
                if key not in PHASES or str(uuid.UUID(boot)) != boot:
                    raise ValueError()
        except (ValueError, TypeError, AttributeError) as exc:
            raise MigrationError('Invalid automatic boot observation') from exc
        return value

    def _advance(self, value, phase):
        value.update(phase=phase, reboot_attempts=0)
        write_json(self.path, value)

    def _intent_boot(self, value, *, refresh=False):
        if refresh or value['phase'] not in value['boots']:
            value['boots'][value['phase']] = self.port.boot()
            write_json(self.path, value)
        return value['boots'][value['phase']]

    def _reboot(self, value):
        if value['reboot_attempts'] >= 3:
            raise MigrationError('Automatic restart limit reached; working installation retained')
        value['reboot_attempts'] += 1
        write_json(self.path, value)
        self.port.reboot_when_idle()
        return 'restarting'

    def tick(self):
        value = self._load()
        phase = value['phase']
        if phase == 'complete':
            return 'complete'
        self.port.assert_safe()
        if phase == 'activate':
            self.port.activate()
            self._advance(value, 'install_target')
        elif phase == 'install_target':
            self._intent_boot(value, refresh=not self.port.target_installed())
            self.port.install_target()
            self._advance(value, 'target_boot')
        elif phase == 'target_boot':
            if self.port.boot() == value['boots']['install_target']:
                return self._reboot(value)
            self.port.validate_target()
            value['boots']['target_boot'] = self.port.boot()
            self._advance(value, 'rollback')
        elif phase == 'rollback':
            self._intent_boot(value, refresh=not self.port.baseline_installed())
            self.port.restore_baseline()
            self._advance(value, 'recovery_boot')
        elif phase == 'recovery_boot':
            if self.port.boot() in {value['boots']['rollback'], value['boots']['target_boot'], value['boots']['install_target']}:
                return self._reboot(value)
            self.port.validate_baseline()
            value['boots']['recovery_boot'] = self.port.boot()
            # Repeating this after a cut is idempotent; proof includes the same
            # exact signed plan and genuine observations.
            self.port.verify_update(value['boots'])
            self._advance(value, 'install_licence')
        elif phase == 'install_licence':
            self.port.install_licence()
            self._advance(value, 'licence_boot')
        elif phase == 'licence_boot':
            journal = self.port.licence_journal()
            if self.port.boot() == journal['install_boot']:
                return self._reboot(value)
            self.port.validate_baseline()
            self._advance(value, 'commit_licence')
        elif phase == 'commit_licence':
            self.port.commit_licence()
            self._advance(value, 'committed_boot')
        elif phase == 'committed_boot':
            journal = self.port.licence_journal()
            if self.port.boot() in {journal['install_boot'], journal['commit_boot']}:
                return self._reboot(value)
            self.port.validate_baseline()
            self._advance(value, 'finish_licence')
        elif phase == 'finish_licence':
            self.port.finish_licence()
            self._advance(value, 'restore_target')
        elif phase == 'restore_target':
            self._intent_boot(value, refresh=not self.port.target_installed())
            self.port.install_target()
            self._advance(value, 'final_boot')
        elif phase == 'final_boot':
            if self.port.boot() == value['boots']['restore_target']:
                return self._reboot(value)
            self.port.validate_target()
            self.port.assert_complete()
            self._advance(value, 'complete')
        return value['phase']
