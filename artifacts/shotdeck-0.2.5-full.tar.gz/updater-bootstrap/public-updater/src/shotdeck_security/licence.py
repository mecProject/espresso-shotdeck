"""Resumable licence replacement; key/identity/term validation stays in the app.

No method issues a licence. A separately approved receipt pins the original,
replacement and every entitlement field. The floor is written only after a new
boot has validated the exact durable replacement. A second recovery boot closes
the transaction. All writers use the same persistent guard.
"""
from __future__ import annotations

import json
from pathlib import Path
import re

from .storage import MigrationError, atomic, boot_id, canonical, digest, directory, guard, read, read_json, remove, write_json


def terms_digest(payload):
    return digest(canonical({k: v for k, v in payload.items() if k not in {'signature', 'issued_at'}}))


class LicenceStore:
    def __init__(self, root, active, *, checkpoint=lambda stage: None, boot=boot_id, key_generations=None):
        self.root, self.active = Path(root), Path(active)
        self.folder = self.root / 'licence'
        self.pending = self.folder / 'pending.json'
        self.floor_file = self.folder / 'floor.json'
        self.checkpoint, self.boot = checkpoint, boot
        self.key_generations = key_generations or {}
        self.automatic_qualification = None

    def _check_generation(self, payload, generation):
        if self.key_generations.get(payload['signature']['key_id']) != generation:
            raise MigrationError('Replacement key is not pinned to the approved licence generation')

    def floor(self):
        try:
            value = read_json(self.floor_file)
        except FileNotFoundError:
            # Once enrolled, loss of the floor cannot re-enable historical keys.
            if (self.folder / 'enrolled.json').exists():
                raise MigrationError('Committed licence floor is missing; service recovery required')
            return 0
        if (set(value) != {'schema_version', 'minimum_generation', 'key_id', 'receipt_sha256', 'licence_sha256', 'boot_id'}
                or type(value['schema_version']) is not int or value['schema_version'] != 1
                or type(value['minimum_generation']) is not int or value['minimum_generation'] < 1
                or not all(isinstance(value[k], str) and value[k] for k in ('key_id', 'receipt_sha256', 'licence_sha256', 'boot_id'))
                or not re.fullmatch('[0-9a-f]{16}', value['key_id'])
                or any(not re.fullmatch('[0-9a-f]{64}', value[k]) for k in ('receipt_sha256', 'licence_sha256'))
                or (self.key_generations and self.key_generations.get(value['key_id']) != value['minimum_generation'])):
            raise MigrationError('Invalid committed licence floor')
        return value['minimum_generation']

    def assert_ordinary_writer(self, replacement_sha256=None):
        self.floor()
        if self.pending.exists() or self.pending.is_symlink():
            journal = self._journal()
            if (journal['phase'] in {'installing', 'pending_reboot', 'committed'}
                    and replacement_sha256 == journal['new_sha256']):
                # Recovery may repair ONLY the identical approved candidate.
                # It cannot substitute a different renewal or historical file
                # behind the pending boot/commit transaction.
                return
            raise MigrationError('Licence migration awaits completion; other licence writers must defer')
        from .automatic import assert_automatic_access
        assert_automatic_access(self.root, self.automatic_qualification)

    def assert_app_writer(self):
        self.floor()
        if self.pending.exists() or self.pending.is_symlink():
            journal = self._journal()
            if (journal['phase'] != 'committed' or self.floor() < journal['generation']
                    or digest(read(self.active, 256 * 1024, protected=False)) != journal['new_sha256']):
                raise MigrationError('Finish the pending licence boot transaction before changing applications')

    def note_repair(self):
        if not self.pending.exists():
            return
        journal = self._journal()
        if journal['phase'] == 'committed':
            journal['commit_boot'] = self.boot()
        else:
            journal['install_boot'] = self.boot()
        # Persist BEFORE repairing the file: even a failed repair cannot let
        # this same boot stand in for a successful boot of the replacement.
        write_json(self.pending, journal)

    def _journal(self):
        value = read_json(self.pending)
        fields = {'schema_version', 'id', 'phase', 'generation', 'key_id', 'old_sha256', 'new_sha256',
                  'terms_sha256', 'receipt_sha256', 'install_boot', 'commit_boot'}
        if (set(value) != fields or type(value['schema_version']) is not int or value['schema_version'] != 1
                or not re.fullmatch('[0-9a-f]{64}', str(value['id']))
                or type(value['generation']) is not int or value['generation'] < 1
                or value['phase'] not in {'prepared', 'installing', 'pending_reboot', 'committed'}
                or not all(isinstance(value[k], str) for k in fields - {'schema_version', 'generation'})
                or any(not re.fullmatch('[0-9a-f]{64}', value[k]) for k in ('old_sha256', 'new_sha256', 'terms_sha256', 'receipt_sha256'))):
            raise MigrationError('Invalid licence migration journal')
        if ((value['phase'] != 'prepared' and not value['install_boot'])
                or (value['phase'] == 'committed' and not value['commit_boot'])
                or not re.fullmatch('[0-9a-f]{16}', value['key_id'])
                or (self.key_generations and self.key_generations.get(value['key_id']) != value['generation'])):
            raise MigrationError('Licence journal lost its approved key or boot identity')
        return value

    def stage(self, raw, receipt, *, validate, require_update_verified, validate_recovery):
        """Stage only. Operator approval is a supplied receipt, never inferred."""
        required = {'schema_version', 'original_sha256', 'replacement_sha256', 'terms_sha256', 'generation', 'key_id', 'approved_by'}
        if (set(receipt) != required or type(receipt['schema_version']) is not int or receipt['schema_version'] != 1
                or type(receipt['generation']) is not int or receipt['generation'] < 1
                or not isinstance(receipt['approved_by'], str) or not receipt['approved_by'].strip()
                or not isinstance(receipt['key_id'], str) or not receipt['key_id']):
            raise MigrationError('An explicit approved replacement receipt is required')
        with guard(self.root):
            self.assert_ordinary_writer()
            require_update_verified()
            original = read(self.active, 256 * 1024, protected=False)
            old = validate(original)
            new = validate(raw)
            self._check_generation(new, receipt['generation'])
            if (digest(original) != receipt['original_sha256'] or digest(raw) != receipt['replacement_sha256']
                    or terms_digest(old) != receipt['terms_sha256'] or terms_digest(new) != receipt['terms_sha256']
                    or new['signature']['key_id'] != receipt['key_id'] or receipt['generation'] <= self.floor()):
                raise MigrationError('Replacement does not match the approved original, terms, generation and digest')
            validate_recovery(raw)
            identifier = digest(canonical(receipt))
            saved = directory(self.folder / identifier)
            atomic(saved / 'original.dat', original, lambda step: self.checkpoint('original_' + step))
            atomic(saved / 'replacement.dat', raw, lambda step: self.checkpoint('candidate_' + step))
            write_json(saved / 'receipt.json', receipt, lambda step: self.checkpoint('receipt_' + step))
            journal = dict(schema_version=1, id=identifier, phase='prepared', generation=receipt['generation'],
                key_id=receipt['key_id'], old_sha256=digest(original), new_sha256=digest(raw),
                terms_sha256=receipt['terms_sha256'], receipt_sha256=identifier, install_boot='', commit_boot='')
            write_json(self.pending, journal, lambda step: self.checkpoint('prepared_journal_' + step))
            self.checkpoint('licence_prepared')
            return journal

    def install(self, *, validate, require_update_verified, validate_recovery):
        with guard(self.root):
            journal = self._journal()
            if journal['phase'] == 'committed':
                return journal
            require_update_verified()
            raw = read(self.folder / journal['id'] / 'replacement.dat', 256 * 1024)
            payload = validate(raw)
            self._check_generation(payload, journal['generation'])
            if digest(raw) != journal['new_sha256'] or terms_digest(payload) != journal['terms_sha256']:
                raise MigrationError('Staged licence changed')
            validate_recovery(raw)
            current = digest(read(self.active, 256 * 1024, protected=False))
            if current not in {journal['old_sha256'], journal['new_sha256']}:
                raise MigrationError('Another writer changed the active licence; reconcile before resuming')
            if journal['phase'] == 'prepared' or (current != journal['new_sha256'] and journal['install_boot'] != self.boot()):
                journal.update(phase='installing', install_boot=self.boot())
                write_json(self.pending, journal, lambda step: self.checkpoint('install_journal_' + step))
            if current != journal['new_sha256']:
                atomic(self.active, raw, lambda step: self.checkpoint('licence_' + step))
            if journal['phase'] != 'pending_reboot':
                journal['phase'] = 'pending_reboot'
                write_json(self.pending, journal)
            self.checkpoint('licence_pending_reboot')
            return journal

    def commit(self, *, validate, require_update_verified, validate_recovery):
        with guard(self.root):
            journal = self._journal()
            if journal['phase'] not in {'pending_reboot', 'committed'}:
                raise MigrationError('Install the staged licence before confirming its boot')
            require_update_verified()
            raw = read(self.active, 256 * 1024, protected=False)
            payload = validate(raw)
            self._check_generation(payload, journal['generation'])
            current_boot = self.boot()
            if current_boot == journal['install_boot']:
                raise MigrationError('A new boot is required before licence commitment')
            if (digest(raw) != journal['new_sha256'] or terms_digest(payload) != journal['terms_sha256']
                    or payload['signature']['key_id'] != journal['key_id']):
                raise MigrationError('Active replacement no longer matches the approved receipt')
            validate_recovery(raw)
            floor = self.floor()
            if floor > journal['generation']:
                raise MigrationError('Refusing to reduce the committed licence generation')
            value = dict(schema_version=1, minimum_generation=journal['generation'], key_id=journal['key_id'],
                receipt_sha256=journal['receipt_sha256'], licence_sha256=journal['new_sha256'], boot_id=current_boot)
            write_json(self.floor_file, value, lambda step: self.checkpoint('floor_' + step))
            # Written AFTER the floor: absence during first commitment cannot
            # strand the valid replacement; floor presence itself enforces it.
            write_json(self.folder / 'enrolled.json', {'schema_version': 1})
            if journal['phase'] != 'committed':
                journal.update(phase='committed', commit_boot=current_boot)
                write_json(self.pending, journal)
            self.checkpoint('licence_committed')
            return journal

    def finish_recovery_boot(self, *, validate, require_recovery_evidence):
        with guard(self.root):
            journal = self._journal()
            if journal['phase'] != 'committed' or self.boot() in {journal['install_boot'], journal['commit_boot']}:
                raise MigrationError('A second, compatible recovery boot is required')
            raw = read(self.active, 256 * 1024, protected=False)
            validate(raw)
            if digest(raw) != journal['new_sha256'] or self.floor() != journal['generation']:
                raise MigrationError('Committed licence changed before recovery confirmation')
            require_recovery_evidence()
            write_json(self.folder / journal['id'] / 'completed.json', {**journal, 'recovery_boot': self.boot()})
            remove(self.pending)
            return {'complete': True, 'generation': journal['generation']}
