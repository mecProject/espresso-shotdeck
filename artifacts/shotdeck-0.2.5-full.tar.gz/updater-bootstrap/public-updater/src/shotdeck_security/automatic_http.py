"""Bounded HTTPS exchange. Credentials never cross redirects or enter logs."""
import urllib.request

from .automatic import EXCHANGE_BASE, MAX_MESSAGE_BYTES, bounded_json
from .storage import MigrationError, canonical


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise MigrationError('Migration exchange redirects are refused')


def exchange(url, payload, credential=None):
    if url != EXCHANGE_BASE:
        raise MigrationError('Unapproved licence exchange endpoint')
    raw = canonical(payload)
    if len(raw) > MAX_MESSAGE_BYTES:
        raise MigrationError('Migration request exceeds its size bound')
    headers = {'Content-Type': 'application/json', 'User-Agent': 'shotdeck-migration/1'}
    if credential:
        headers['Authorization'] = 'Bearer ' + credential
    request = urllib.request.Request(url + '/index.php', data=raw, headers=headers, method='POST')
    with urllib.request.build_opener(NoRedirect()).open(request, timeout=20) as response:
        return bounded_json(response.read(MAX_MESSAGE_BYTES + 1))
