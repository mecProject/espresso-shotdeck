"""Persistent signing migration primitives shared by the app and updater."""

MIGRATION_PROTOCOL = 1
