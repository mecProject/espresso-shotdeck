"""Signed qualification and encrypted delivery for automatic legacy migration.

Neither an old licence signature nor the hosting service grants an entitlement.
Issuance needs the operator's independent inventory/cohort policy and L1 signer.
The primitives follow PyCA's X25519/HKDF, AEAD and Ed25519 interfaces:
https://cryptography.io/en/stable/hazmat/primitives/asymmetric/x25519/
https://cryptography.io/en/stable/hazmat/primitives/aead/
"""
from __future__ import annotations

import base64
from datetime import datetime
import hashlib
import json
import os
import re

from .storage import MigrationError, canonical, digest, unique, version

MAX_MESSAGE_BYTES = 512 * 1024
RELEASE_BASE = 'https://mecproject.github.io/espresso-shotdeck'
EXCHANGE_BASE = 'https://support.espresso-shotdeck.com/migration'
DOMAIN = b'shotdeck-automatic-migration/v1/'
HEX64 = re.compile(r'[0-9a-f]{64}')
REQUEST_ID = re.compile(r'[0-9a-f]{32}')


def bounded_json(raw):
    if not isinstance(raw, bytes) or not 0 < len(raw) <= MAX_MESSAGE_BYTES:
        raise MigrationError('Migration message exceeds its bounds')
    try:
        value = json.loads(raw, object_pairs_hook=unique)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise MigrationError('Invalid migration JSON') from exc
    if not isinstance(value, dict):
        raise MigrationError('Migration message must be an object')
    return value


def b64(raw):
    return base64.b64encode(raw).decode('ascii')


def unb64(value, *, length=None, limit=MAX_MESSAGE_BYTES):
    try:
        if not isinstance(value, str) or len(value) > (limit + 2) // 3 * 4:
            raise ValueError()
        raw = base64.b64decode(value.encode('ascii'), validate=True)
        if len(raw) > limit or (length is not None and len(raw) != length) or b64(raw) != value:
            raise ValueError()
        return raw
    except (ValueError, UnicodeError) as exc:
        raise MigrationError('Invalid bounded base64 field') from exc


def public_pem(key):
    from cryptography.hazmat.primitives import serialization
    return key.public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)


def signing_message(payload, purpose):
    if purpose not in {'qualification', 'licence-approval'}:
        raise MigrationError('Unknown migration signing purpose')
    return DOMAIN + purpose.encode('ascii') + b'\0' + canonical(payload)


def sign_document(payload, private_key, purpose):
    if not isinstance(payload, dict) or 'signature' in payload:
        raise MigrationError('Expected an unsigned migration document')
    pem = public_pem(private_key.public_key())
    return {**payload, 'signature': {'algorithm': 'ed25519', 'key_id': digest(pem)[:16],
        'value': b64(private_key.sign(signing_message(payload, purpose)))}}


def verify_document(document, public_key_pem, purpose):
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    if not isinstance(document, dict) or len(canonical(document)) > MAX_MESSAGE_BYTES:
        raise MigrationError('Invalid signed migration document')
    signature = document.get('signature')
    if (not isinstance(signature, dict) or set(signature) != {'algorithm', 'key_id', 'value'}
            or signature['algorithm'] != 'ed25519' or signature['key_id'] != digest(public_key_pem)[:16]):
        raise MigrationError('Migration signature does not match the pinned role key')
    payload = {key: value for key, value in document.items() if key != 'signature'}
    try:
        key = serialization.load_pem_public_key(public_key_pem)
        if not isinstance(key, Ed25519PublicKey) or public_pem(key) != public_key_pem:
            raise ValueError()
        key.verify(unb64(signature['value'], length=64), signing_message(payload, purpose))
    except (ValueError, TypeError, InvalidSignature) as exc:
        raise MigrationError('Migration signature verification failed') from exc
    return payload


def validate_plan(document, update_public_key, *, channel=None):
    """The compiled U1 pin authorizes this exact bench-qualified production path."""
    from .updates import validate_policy
    plan = verify_document(document, update_public_key, 'qualification')
    fields = {'schema_version', 'migration_id', 'channel', 'hardware_group', 'compatibility',
        'target', 'update_policy', 'qualification', 'exchange_url', 'transport_public_key', 'issued_at'}
    if (set(plan) != fields or type(plan['schema_version']) is not int or plan['schema_version'] != 1
            or not isinstance(plan['migration_id'], str) or not re.fullmatch(r'[a-z0-9][a-z0-9._-]{0,63}', plan['migration_id'])
            or plan['channel'] not in {'stable', 'beta'} or (channel is not None and plan['channel'] != channel)
            or plan['hardware_group'] != 'rev1_2_3_5f_bbw'):
        raise MigrationError('Invalid automatic migration cohort')
    try:
        issued = datetime.fromisoformat(plan['issued_at'].replace('Z', '+00:00'))
        if issued.tzinfo is None:
            raise ValueError()
    except (AttributeError, ValueError, TypeError) as exc:
        raise MigrationError('Qualification needs an explicit issuance time') from exc
    compatibility, target = plan['compatibility'], plan['target']
    if (not isinstance(compatibility, dict) or set(compatibility) != {'version', 'tree_sha256', 'source_commit'}
            or not isinstance(target, dict) or set(target) != {'version', 'tree_sha256', 'manifest_sha256', 'artifact_sha256', 'manifest_url'}):
        raise MigrationError('Qualification must bind exact compatibility and target artifacts')
    for value in (compatibility['tree_sha256'], target['tree_sha256'], target['manifest_sha256'], target['artifact_sha256']):
        if not isinstance(value, str) or not HEX64.fullmatch(value):
            raise MigrationError('Invalid qualification digest')
    if (not isinstance(compatibility['source_commit'], str) or not re.fullmatch(r'[0-9a-f]{40}', compatibility['source_commit'])
            or version(target['version']) <= version(compatibility['version'])):
        raise MigrationError('Qualification requires a real higher-version replacement-key target')
    expected_manifest = f"{RELEASE_BASE}/metadata/releases/shotdeck-{target['version']}-{plan['channel']}.json"
    if target['manifest_url'] != expected_manifest:
        raise MigrationError('Target must use its immutable official channel manifest')
    policy = validate_policy(plan['update_policy'])
    if (policy['public_key_pem'].encode('ascii') != update_public_key or policy['generation'] != 1
            or policy['minimum_app_version'] != compatibility['version']
            or policy['recovery_version'] != compatibility['version']
            or version(policy['minimum_updater_version']) < version('0.2.5')
            or policy['feeds'] != {name: f'{RELEASE_BASE}/metadata/shotdeck-{name}-v3.json' for name in ('stable', 'beta')}):
        raise MigrationError('Qualification changed the compiled key or official recovery policy')
    qualification = plan['qualification']
    checks = {'cold_boot', 'offline_licence', 'brew', 'stop', 'rollback', 'licence_recovery'}
    if (not isinstance(qualification, dict) or set(qualification) != checks | {'approved_by', 'evidence_sha256'}
            or not isinstance(qualification['approved_by'], str) or not qualification['approved_by'].strip()
            or not isinstance(qualification['evidence_sha256'], str) or not HEX64.fullmatch(qualification['evidence_sha256'])
            or any(qualification[name] is not True for name in checks)):
        raise MigrationError('Exact-candidate physical release qualification is required')
    if plan['exchange_url'] != EXCHANGE_BASE:
        raise MigrationError('Automatic delivery must use the pinned private exchange')
    unb64(plan['transport_public_key'], length=32)
    return plan


def transport_context(request_id, device_id, reply_public_key, migration_id):
    if (not isinstance(request_id, str) or not REQUEST_ID.fullmatch(request_id)
            or not isinstance(device_id, str) or not re.fullmatch(r'[0-9a-f]{12}', device_id)
            or not isinstance(migration_id, str) or not re.fullmatch(r'[a-z0-9][a-z0-9._-]{0,63}', migration_id)):
        raise MigrationError('Invalid migration request identity')
    unb64(reply_public_key, length=32)
    return {'protocol': 'shotdeck-automatic-migration-v1', 'request_id': request_id,
        'device_id': device_id, 'reply_public_key': reply_public_key, 'migration_id': migration_id}


def seal(plaintext, recipient_public_key, context):
    """Fresh ephemeral X25519 and nonce per message; bind all routing metadata."""
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    if not isinstance(plaintext, bytes) or not 0 < len(plaintext) <= (MAX_MESSAGE_BYTES - 1024) * 3 // 4:
        raise MigrationError('Invalid migration plaintext size')
    ephemeral = X25519PrivateKey.generate()
    try:
        shared = ephemeral.exchange(X25519PublicKey.from_public_bytes(recipient_public_key))
    except ValueError as exc:
        raise MigrationError('Invalid migration encryption recipient') from exc
    aad = DOMAIN + b'transport\0' + canonical(context)
    key = HKDF(algorithm=hashes.SHA256(), length=32, salt=hashlib.sha256(aad).digest(), info=DOMAIN + b'encryption').derive(shared)
    nonce = os.urandom(12)
    return {'schema_version': 1,
        'ephemeral_public_key': b64(ephemeral.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)),
        'nonce': b64(nonce), 'ciphertext': b64(AESGCM(key).encrypt(nonce, plaintext, aad))}


def unseal(envelope, recipient_private_key, context):
    from cryptography.exceptions import InvalidTag
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PublicKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    if (not isinstance(envelope, dict) or set(envelope) != {'schema_version', 'ephemeral_public_key', 'nonce', 'ciphertext'}
            or type(envelope['schema_version']) is not int or envelope['schema_version'] != 1):
        raise MigrationError('Invalid migration encryption envelope')
    try:
        shared = recipient_private_key.exchange(X25519PublicKey.from_public_bytes(unb64(envelope['ephemeral_public_key'], length=32)))
        aad = DOMAIN + b'transport\0' + canonical(context)
        key = HKDF(algorithm=hashes.SHA256(), length=32, salt=hashlib.sha256(aad).digest(), info=DOMAIN + b'encryption').derive(shared)
        ciphertext = unb64(envelope['ciphertext'])
        if len(ciphertext) < 17:
            raise ValueError()
        return AESGCM(key).decrypt(unb64(envelope['nonce'], length=12), ciphertext, aad)
    except (ValueError, TypeError, InvalidTag) as exc:
        raise MigrationError('Migration message authentication failed') from exc


def validate_approval(document, licence_public_key, *, context, original_sha256, terms_sha256):
    approval = verify_document(document, licence_public_key, 'licence-approval')
    if (set(approval) != {'schema_version', 'context', 'original_sha256', 'replacement', 'receipt'}
            or type(approval['schema_version']) is not int or approval['schema_version'] != 1
            or approval['context'] != context or approval['original_sha256'] != original_sha256):
        raise MigrationError('Licence approval belongs to a different device request')
    raw = unb64(approval['replacement'], limit=256 * 1024)
    receipt = approval['receipt']
    fields = {'schema_version', 'approved_by', 'original_sha256', 'replacement_sha256', 'terms_sha256', 'generation', 'key_id'}
    if (not isinstance(receipt, dict) or set(receipt) != fields or type(receipt['schema_version']) is not int or receipt['schema_version'] != 1
            or type(receipt['generation']) is not int or receipt['generation'] != 1
            or not isinstance(receipt['approved_by'], str) or not receipt['approved_by'].strip()
            or receipt['original_sha256'] != original_sha256 or receipt['replacement_sha256'] != digest(raw)
            or receipt['terms_sha256'] != terms_sha256 or receipt['key_id'] != digest(licence_public_key)[:16]):
        raise MigrationError('Licence approval changed its authorized original, terms or signer')
    from .licence import terms_digest
    payload = bounded_json(raw)
    if terms_digest(payload) != terms_sha256:
        raise MigrationError('Replacement entitlement terms differ')
    return raw, receipt


def assert_automatic_access(root, qualification=None):
    """Exclude ordinary updater writers while the automatic journal owns them."""
    from .storage import read_json
    path = root / 'automatic/transaction.json'
    if not path.exists():
        if qualification is not None:
            raise MigrationError('Automatic update has no durable transaction')
        return
    state = read_json(path)
    if state.get('phase') == 'complete':
        return
    if (qualification is None or state.get('qualification_sha256') != digest(canonical(qualification))
            or read_json(root / 'automatic/qualification.json') != qualification):
        raise MigrationError('Update maintenance is in progress; retry after automatic migration')
