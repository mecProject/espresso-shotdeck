"""Bounded state reads, durable replacement and one nonblocking writer guard."""
from __future__ import annotations

from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile

DEFAULT_ROOT = Path('/var/lib/shotdeck/signing')
MAX_STATE_BYTES = 1024 * 1024


class MigrationError(ValueError):
    pass


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise MigrationError('Duplicate migration-state property')
        result[key] = value
    return result


def read(path, limit=MAX_STATE_BYTES, *, protected=True):
    path = Path(path)
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | getattr(os, 'O_NOFOLLOW', 0))
    try:
        metadata = os.fstat(fd)
        if (not stat.S_ISREG(metadata.st_mode) or metadata.st_size > limit
                or (protected and (metadata.st_uid != os.geteuid() or metadata.st_mode & 0o022))):
            raise MigrationError('Migration input must be a bounded regular file')
        with os.fdopen(fd, 'rb', closefd=False) as source:
            data = source.read(limit + 1)
        if len(data) > limit:
            raise MigrationError('Migration input exceeds its size limit')
        return data
    finally:
        os.close(fd)


def read_json(path):
    try:
        value = json.loads(read(path), object_pairs_hook=unique)
        if not isinstance(value, dict):
            raise MigrationError('Migration state must be an object')
        return value
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise MigrationError('Migration state is corrupt') from exc


def fsync_dir(path):
    fd = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def directory(path):
    path = Path(path)
    if path.is_symlink():
        raise MigrationError('Migration directory must not be a symlink')
    if not path.exists():
        directory(path.parent)
        path.mkdir(mode=0o700)
        fsync_dir(path.parent)
    info = path.stat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022:
        raise MigrationError('Migration directory must be owned by the operator and protected from writes')
    return path


def atomic(path, data, checkpoint=lambda stage: None):
    """A fault after replacement leaves the complete new value, never a prefix."""
    path = Path(path)
    directory(path.parent)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent, prefix='.' + path.name + '.', delete=False) as output:
            temporary = Path(output.name)
            os.fchmod(output.fileno(), 0o600)
            output.write(data)
            output.flush()
            checkpoint('file_written')
            os.fsync(output.fileno())
            checkpoint('file_synced')
        if path.is_symlink():
            raise MigrationError('Migration destination must not be a symlink')
        os.replace(temporary, path)
        checkpoint('replaced')
        fsync_dir(path.parent)
        checkpoint('directory_synced')
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def write_json(path, value, checkpoint=lambda stage: None):
    atomic(path, canonical(value) + b'\n', checkpoint)


def remove(path):
    path = Path(path)
    path.unlink(missing_ok=True)
    fsync_dir(path.parent)


@contextmanager
def guard(root, *, maintenance=False):
    root = directory(root)
    descriptor = os.open(root / 'writer.lock', os.O_RDWR | os.O_CREAT | os.O_NONBLOCK
        | getattr(os, 'O_CLOEXEC', 0) | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != os.geteuid() or metadata.st_mode & 0o022:
            raise MigrationError('Invalid migration lock')
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise MigrationError('Signing migration writer is busy; retry when idle') from exc
        if not maintenance and (root / 'maintenance.json').exists():
            raise MigrationError('A deployment is pending; signing migration is deferred')
        yield
    finally:
        os.close(descriptor)


def boot_id():
    value = read(Path('/proc/sys/kernel/random/boot_id'), 128).decode().strip()
    if not value or len(value) > 64:
        raise MigrationError('Cannot establish a boot identity')
    return value


def version(value):
    from packaging.version import InvalidVersion, Version
    if not isinstance(value, str) or not value:
        raise MigrationError('Invalid migration version')
    try:
        return Version(value)
    except InvalidVersion as exc:
        raise MigrationError('Invalid migration version') from exc
