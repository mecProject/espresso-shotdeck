"""Physical compatibility guard, independent of replaceable application code."""

import json
import os
from pathlib import Path
import stat

from .errors import InstallError


PROFILE_FILE = Path("/etc/shotdeck/hardware-profile.json")
DESCRIPTOR = ".shotdeck-hardware-support.json"
LEGACY_ID = "rev1_2_3_5f_bbw"
REV15_ID = "rev15_3_5f"
HARDWARE_GUARD_VERSION = 1


def installed_profile(path: Path | None = None) -> tuple[str, int]:
    path = PROFILE_FILE if path is None else Path(path)
    try:
        parent_fd = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    except FileNotFoundError:
        return LEGACY_ID, 1
    except OSError as exc:
        raise InstallError(f"Cannot open hardware identity directory: {exc}") from exc
    try:
        parent = os.fstat(parent_fd)
        if not stat.S_ISDIR(parent.st_mode) or parent.st_uid != 0 or parent.st_mode & 0o022:
            raise InstallError("Hardware identity directory must be protected and root-owned")
        try:
            fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent_fd)
        except FileNotFoundError:
            return LEGACY_ID, 1
        with os.fdopen(fd, "r", encoding="utf-8") as stream:
            metadata = os.fstat(stream.fileno())
            if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != 0 or metadata.st_mode & 0o022:
                raise InstallError("Hardware identity must be a protected root-owned regular file")
            if metadata.st_size > 16384:
                raise InstallError("Hardware identity is too large")
            payload = json.load(stream)
    except (OSError, ValueError) as exc:
        raise InstallError(f"Cannot read installed hardware identity: {exc}") from exc
    finally:
        os.close(parent_fd)
    if (not isinstance(payload, dict) or type(payload.get("schema_version")) is not int
            or payload["schema_version"] != 1
            or payload.get("profile_id") not in {LEGACY_ID, REV15_ID}):
        raise InstallError("Unknown installed hardware identity; activation refused")
    return payload["profile_id"], payload["schema_version"]


def assert_hardware_compatible(release_dir: Path, *, profile_path: Path | None = None) -> None:
    profile_id, schema = installed_profile(profile_path)
    descriptor = Path(release_dir) / DESCRIPTOR
    if not descriptor.exists() and profile_id == LEGACY_ID:
        # Verified historic releases remain valid legacy recovery candidates.
        return
    try:
        if descriptor.is_symlink():
            raise InstallError("Hardware support descriptor must be inside the release tree")
        payload = json.loads(descriptor.read_text(encoding="utf-8"))
        if not isinstance(payload, dict) or payload.get("schema_version") != 1:
            raise ValueError("unsupported descriptor schema")
        support = payload["profiles"][profile_id]
        if not isinstance(support, dict) or not support["schema_min"] <= schema <= support["schema_max"]:
            raise ValueError("unsupported profile schema")
        if profile_id == REV15_ID and (
            support.get("watchdog") != "tps3430-window-v1"
            or support.get("license_backend") != "atecc608c-board-v1"
            or support.get("hardware_guard_version") != HARDWARE_GUARD_VERSION
        ):
            raise ValueError("missing REV15 watchdog, licensing or compatibility contract")
    except (OSError, ValueError, TypeError, KeyError) as exc:
        raise InstallError(f"Release does not support installed hardware {profile_id}: {exc}") from exc


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Check a release against persistent board identity")
    parser.add_argument("release", type=Path)
    args = parser.parse_args()
    try:
        assert_hardware_compatible(args.release)
    except InstallError as exc:
        parser.exit(1, f"{exc}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
