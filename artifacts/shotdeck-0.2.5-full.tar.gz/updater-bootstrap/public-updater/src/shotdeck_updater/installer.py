"""Install, activate, health-check, and roll back release artifacts."""

from __future__ import annotations

import shutil
import os
import json
import re
import stat
from functools import wraps
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from shotdeck_manifest import PatchArtifactRef, ReleaseManifest

from .config import UpdaterConfig
from .errors import HealthCheckError, InstallError, PatchError
from .hardware import REV15_ID, assert_hardware_compatible, installed_profile
from .patching import apply_patch_archive, patch_is_eligible
from .storage import (
    atomic_symlink_swap,
    directory_tree_sha256,
    ensure_directory,
    prune_releases,
    read_json,
    safe_extract_tarball,
    write_json_atomic,
)
from .system import CommandRunner, ServiceController, SystemctlServiceController, run_hooks
from shotdeck_security.storage import MigrationError, guard, version as trust_version
from shotdeck_security.licence import LicenceStore
from shotdeck_security.updates import UpdateStore, MARKER


RELEASE_METADATA_NAME = ".shotdeck-release.json"


def signing_writer(method):
    @wraps(method)
    def invoke(self, *args, **kwargs):
        try:
            with guard(self.config.migration_root):
                from shotdeck_security.automatic import assert_automatic_access
                assert_automatic_access(self.config.migration_root, self.automatic_qualification)
                LicenceStore(self.config.migration_root, self.config.install_root / 'hardware.dat').assert_app_writer()
                return method(self, *args, **kwargs)
        except MigrationError as exc:
            raise InstallError(str(exc)) from exc
    return invoke


@dataclass(slots=True)
class InstalledRelease:
    version: str
    path: Path
    tree_sha256: str


@dataclass(slots=True)
class InstallOutcome:
    version: str
    release_path: Path
    artifact_kind: str
    rolled_back: bool = False


class ReleaseInstaller:
    def _signing_policy(self):
        try:
            return UpdateStore(self.config.migration_root, self.config.install_root,
                self.config.manifest_security_state_file).active()
        except (OSError, MigrationError) as exc:
            raise InstallError(f'Cannot validate committed signing recovery policy: {exc}') from exc

    def _assert_signing_compatible(self, path: Path, release_version: str):
        active = self._signing_policy()
        if active and (trust_version(release_version) < trust_version(active['policy']['minimum_app_version'])
                or not (path / MARKER).is_file() or (path / MARKER).read_bytes() != b'1\n'):
            raise InstallError('Application is below the committed signing compatibility floor')

    def __init__(
        self,
        config: UpdaterConfig,
        *,
        service_controller: ServiceController | None = None,
        runner: CommandRunner | None = None,
        logger=None,
        automatic_qualification=None,
    ) -> None:
        self.config = config
        self.runner = runner or CommandRunner()
        self.service_controller = service_controller or SystemctlServiceController(
            config.service_name,
            runner=self.runner,
        )
        self.logger = logger
        self.automatic_qualification = automatic_qualification

    def _log(self, level: str, message: str, *args: object) -> None:
        if self.logger is not None:
            getattr(self.logger, level)(message, *args)

    def _metadata_path(self, release_dir: Path) -> Path:
        return release_dir / RELEASE_METADATA_NAME

    def current_release(self) -> InstalledRelease | None:
        if not self.config.current_link.exists():
            return None
        target = self.config.current_link.resolve()
        return self._release_from_dir(target)

    def previous_release(self) -> InstalledRelease | None:
        if not self.config.previous_link.exists():
            return None
        target = self.config.previous_link.resolve()
        return self._release_from_dir(target)

    def _release_from_dir(self, release_dir: Path) -> InstalledRelease | None:
        if installed_profile()[0] == REV15_ID:
            return self._read_rev15_release_metadata(release_dir)
        metadata_path = self._metadata_path(release_dir)
        if metadata_path.exists():
            payload = read_json(metadata_path)
            return InstalledRelease(
                version=str(payload["version"]),
                path=release_dir,
                tree_sha256=str(payload["tree_sha256"]),
            )
        if release_dir.is_dir():
            tree_sha256 = directory_tree_sha256(release_dir, ignore_names={RELEASE_METADATA_NAME})
            return InstalledRelease(version=release_dir.name, path=release_dir, tree_sha256=tree_sha256)
        return None

    def _write_release_metadata(
        self,
        release_dir: Path,
        *,
        version: str,
        tree_sha256: str,
        artifact_kind: str,
        source_version: str | None,
    ) -> None:
        write_json_atomic(
            self._metadata_path(release_dir),
            {
                "version": version,
                "tree_sha256": tree_sha256,
                "artifact_kind": artifact_kind,
                "source_version": source_version,
                "installed_at": datetime.now(timezone.utc).isoformat(),
            },
        )

    def _read_rev15_release_metadata(self, release_dir: Path) -> InstalledRelease:
        metadata_path = self._metadata_path(release_dir)
        try:
            fd = os.open(metadata_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, "r", encoding="utf-8") as stream:
                metadata = os.fstat(stream.fileno())
                if not stat.S_ISREG(metadata.st_mode) or metadata.st_size > 16384:
                    raise ValueError("metadata must be a bounded regular file")
                payload = json.load(stream)
            if (not isinstance(payload, dict) or not isinstance(payload.get("version"), str)
                    or not payload["version"]
                    or payload.get("artifact_kind") not in {"full", "patch"}
                    or not isinstance(payload.get("tree_sha256"), str)
                    or re.fullmatch(r"[0-9a-f]{64}", payload["tree_sha256"]) is None):
                raise ValueError("metadata does not identify a verified release")
            return InstalledRelease(payload["version"], release_dir, payload["tree_sha256"])
        except (OSError, ValueError, TypeError) as exc:
            raise InstallError(f"REV15 requires verified release metadata at {release_dir}: {exc}") from exc

    def _assert_rev15_release_integrity(self, release: InstalledRelease | None, *, role: str) -> None:
        """Rehash a retained, verified release; never infer REV15 trust from files."""
        if installed_profile()[0] != REV15_ID:
            return
        if release is None:
            raise InstallError(f"REV15 requires a verified {role} release")
        retained = self._read_rev15_release_metadata(release.path)
        try:
            if retained.version != release.version or retained.tree_sha256 != release.tree_sha256:
                raise ValueError("retained release metadata changed during update")
            actual = directory_tree_sha256(release.path, ignore_names={RELEASE_METADATA_NAME})
            if actual != retained.tree_sha256:
                raise ValueError("release tree checksum differs from retained metadata")
        except (OSError, ValueError, TypeError) as exc:
            raise InstallError(f"REV15 {role} release integrity check failed: {exc}") from exc

    def _assert_rev15_activation_integrity(
        self, candidate_dir: Path, previous_release: InstalledRelease | None,
    ) -> None:
        if installed_profile()[0] != REV15_ID:
            return
        self._assert_rev15_release_integrity(previous_release, role="current recovery")
        try:
            current_path = self.config.current_link.resolve(strict=True)
        except OSError as exc:
            raise InstallError("REV15 requires an available current recovery target") from exc
        if current_path != previous_release.path.resolve():
            raise InstallError("REV15 current recovery target changed before activation")
        self._assert_rev15_release_integrity(self._release_from_dir(candidate_dir), role="candidate")

    def _finalize_release(self, staging_dir: Path, version: str, tree_sha256: str) -> Path:
        release_dir = self.config.releases_dir / f"{version}-{tree_sha256[:12]}"
        ensure_directory(self.config.releases_dir)
        if release_dir.exists():
            existing_sha = directory_tree_sha256(
                release_dir,
                ignore_names={RELEASE_METADATA_NAME},
            )
            if existing_sha != tree_sha256:
                raise InstallError(f"Immutable release directory collision: {release_dir}")
            shutil.rmtree(staging_dir, ignore_errors=True)
            return release_dir
        staging_dir.replace(release_dir)
        return release_dir

    def _prepare_full_release(self, manifest: ReleaseManifest, artifact_path: Path) -> tuple[Path, str]:
        staging_dir = self.config.work_dir / f"{manifest.version}.full.{uuid4().hex}"
        ensure_directory(self.config.work_dir)
        safe_extract_tarball(artifact_path, staging_dir)
        tree_sha = directory_tree_sha256(staging_dir)
        expected = manifest.full_artifact.install_tree_sha256
        if expected and tree_sha != expected:
            raise InstallError(
                f"Full artifact tree checksum mismatch: expected {expected}, got {tree_sha}"
            )
        return staging_dir, tree_sha

    def _prepare_patch_release(
        self,
        current_release: InstalledRelease,
        patch_artifact: PatchArtifactRef,
        artifact_path: Path,
    ) -> tuple[Path, str]:
        eligible, reason = patch_is_eligible(
            current_release.version,
            current_release.tree_sha256,
            patch_artifact,
        )
        if not eligible:
            raise PatchError(reason)
        staging_dir = self.config.work_dir / f"{patch_artifact.to_version}.patch.{uuid4().hex}"
        ensure_directory(self.config.work_dir)
        tree_sha = apply_patch_archive(
            patch_archive=artifact_path,
            base_release_dir=current_release.path,
            staging_dir=staging_dir,
            patch_artifact=patch_artifact,
        )
        return staging_dir, tree_sha

    def _assert_wifi_compatible(self, release_dir: Path) -> None:
        """Older applications can reactivate Wi-Fi or reinstall an unsafe watchdog."""
        assert_hardware_compatible(release_dir)
        self._assert_scale_compatible(release_dir)
        if (release_dir / ".shotdeck-wifi-radio-v1").is_file():
            return
        preference = Path(os.environ.get(
            "SHOTDECK_WIFI_SETTINGS_FILE",
            str(Path(os.environ.get("SHOTDECK_DATA_DIR", "/var/lib/shotdeck")) / "wifi-settings.json"),
        ))
        try:
            payload = json.loads(preference.read_text(encoding="utf-8"))
            if not isinstance(payload, dict) or payload.get("schema") != 1 or type(payload.get("enabled")) is not bool:
                raise ValueError("Invalid Wi-Fi preference")
        except FileNotFoundError:
            return
        except (OSError, ValueError) as exc:
            raise InstallError("Repair Wi-Fi settings before installing an older release.") from exc
        if payload["enabled"] is False:
            raise InstallError("This older release cannot preserve Wi-Fi off. Turn Wi-Fi on before downgrading.")

    def _assert_scale_compatible(self, release_dir: Path) -> None:
        if ((release_dir / ".shotdeck-scale-policy-v1").is_file()
                or (release_dir / "service/shotdeck-scale-policy-v1").is_file()):
            return
        preference = Path(os.environ.get("SHOTDECK_SCALE_SETTINGS_FILE", str(
            Path(os.environ.get("SHOTDECK_DATA_DIR", "/var/lib/shotdeck")) / "scale-settings.json")))
        try:
            if preference.stat().st_size > 4096:
                raise ValueError("Scale settings are too large")
            payload = json.loads(preference.read_text(encoding="utf-8"))
            if (not isinstance(payload, dict) or set(payload) != {"version", "mode", "target"}
                    or type(payload.get("version")) is not int or payload["version"] != 1
                    or payload.get("mode") not in ("any", "specific")):
                raise ValueError("Invalid scale settings")
            if payload["mode"] == "any" and payload.get("target") is not None:
                raise ValueError("Invalid automatic scale settings")
        except FileNotFoundError:
            return
        except (OSError, ValueError) as exc:
            raise InstallError("Repair scale settings before installing an older release.") from exc
        if payload["mode"] == "specific":
            raise InstallError("This older release cannot connect exclusively to the saved scale. Select any compatible scale before downgrading.")

    def _activate_release(
        self,
        new_release_dir: Path,
        *,
        previous_release: InstalledRelease | None,
        health_timeout_seconds: int,
        expected_version: str,
    ) -> None:
        # All refusal-only preconditions run before entering this method. From
        # the first stop attempt onward the service may have changed state,
        # even if that attempt raises, so failures require recovery.
        self.service_controller.stop()
        run_hooks(self.runner, self.config.hooks.pre_install)
        if previous_release is not None:
            atomic_symlink_swap(self.config.previous_link, previous_release.path)
        atomic_symlink_swap(self.config.current_link, new_release_dir)
        self._log("info", "Starting service %s", self.config.service_name)
        self.service_controller.start()
        if self.config.hooks.health_check:
            run_hooks(self.runner, self.config.hooks.health_check, timeout_seconds=health_timeout_seconds)
        # Hooks may add product-specific checks, but they must never replace
        # the updater's version-aware service readiness contract.
        self.service_controller.health_check(health_timeout_seconds, expected_version)
        run_hooks(self.runner, self.config.hooks.post_install)

    def _rollback_to_previous(
        self,
        previous_release: InstalledRelease | None,
        *,
        health_timeout_seconds: int,
    ) -> None:
        if previous_release is None:
            raise HealthCheckError("No previous release is available for rollback")
        self._assert_signing_compatible(previous_release.path, previous_release.version)
        self._assert_wifi_compatible(previous_release.path)
        self._assert_rev15_release_integrity(previous_release, role="rollback")
        self._log("warning", "Rolling back to %s", previous_release.version)
        self.service_controller.stop()
        atomic_symlink_swap(self.config.current_link, previous_release.path)
        self.service_controller.start()
        self.service_controller.health_check(health_timeout_seconds, previous_release.version)
        run_hooks(self.runner, self.config.hooks.rollback)

    @signing_writer
    def apply_release(
        self,
        *,
        manifest: ReleaseManifest,
        artifact_path: Path,
        patch_artifact: PatchArtifactRef | None = None,
    ) -> InstallOutcome:
        ensure_directory(self.config.install_root)
        ensure_directory(self.config.releases_dir)
        ensure_directory(self.config.state_dir)
        ensure_directory(self.config.work_dir)

        previous_release = self.current_release()
        if patch_artifact:
            if previous_release is None:
                raise PatchError("Cannot apply a patch without an installed base release")
            self._log("info", "Preparing patch update from %s to %s", previous_release.version, manifest.version)
            staging_dir, tree_sha = self._prepare_patch_release(previous_release, patch_artifact, artifact_path)
            artifact_kind = "patch"
            source_version = previous_release.version
        else:
            self._log("info", "Preparing full update to %s", manifest.version)
            staging_dir, tree_sha = self._prepare_full_release(manifest, artifact_path)
            artifact_kind = "full"
            source_version = None

        release_dir = self._finalize_release(staging_dir, manifest.version, tree_sha)
        self._write_release_metadata(
            release_dir,
            version=manifest.version,
            tree_sha256=tree_sha,
            artifact_kind=artifact_kind,
            source_version=source_version,
        )

        # Reject incompatible candidates AND recovery targets before stopping a
        # healthy application. A failed compatibility check must never trigger
        # an otherwise unnecessary restart/rollback of the current service.
        assert_hardware_compatible(release_dir)
        if previous_release is not None:
            assert_hardware_compatible(previous_release.path)
        # Do this outside the activation/rollback handler: a damaged recovery
        # target must reject the candidate without disrupting the running app.
        self._assert_rev15_activation_integrity(release_dir, previous_release)
        self._assert_wifi_compatible(release_dir)
        self._assert_signing_compatible(release_dir, manifest.version)
        if previous_release is not None:
            self._assert_signing_compatible(previous_release.path, previous_release.version)
        assert_idle = getattr(self.service_controller, "assert_brew_idle", None)
        if callable(assert_idle):
            assert_idle()
        self._log("info", "Stopping service %s", self.config.service_name)

        try:
            self._activate_release(
                release_dir,
                previous_release=previous_release,
                health_timeout_seconds=manifest.rollback.health_check_timeout_seconds,
                expected_version=manifest.version,
            )
        except Exception:
            self._rollback_to_previous(
                previous_release,
                health_timeout_seconds=manifest.rollback.health_check_timeout_seconds,
            )
            raise

        keep_paths = {release_dir}
        if previous_release:
            keep_paths.add(previous_release.path)
        signing_policy = self._signing_policy()
        if signing_policy:
            keep_paths.add(self.config.releases_dir / signing_policy['policy']['recovery_version'])
        prune_releases(
            self.config.releases_dir,
            keep_paths=keep_paths,
            retained_releases=max(self.config.retained_releases, manifest.rollback.keep_versions),
        )
        write_json_atomic(
            self.config.state_file,
            {
                "current_version": manifest.version,
                "current_release_path": str(release_dir),
                "previous_version": previous_release.version if previous_release else None,
                "previous_release_path": str(previous_release.path) if previous_release else None,
                "artifact_kind": artifact_kind,
                "updated_at": datetime.now(timezone.utc).isoformat(),
            },
        )
        return InstallOutcome(version=manifest.version, release_path=release_dir, artifact_kind=artifact_kind)

    @signing_writer
    def rollback(self, *, health_timeout_seconds: int = 20) -> InstallOutcome:
        current_release = self.current_release()
        previous_release = self.previous_release()
        if previous_release is None:
            raise InstallError("No previous release is available for rollback")
        self._assert_signing_compatible(previous_release.path, previous_release.version)
        self._assert_wifi_compatible(previous_release.path)
        self._assert_rev15_release_integrity(previous_release, role="rollback")
        self._log("warning", "Manual rollback from %s to %s", current_release.version if current_release else "unknown", previous_release.version)
        assert_idle = getattr(self.service_controller, "assert_brew_idle", None)
        if callable(assert_idle):
            assert_idle()
        self.service_controller.stop()
        if current_release is not None:
            atomic_symlink_swap(self.config.previous_link, current_release.path)
        atomic_symlink_swap(self.config.current_link, previous_release.path)
        self.service_controller.start()
        if self.config.hooks.health_check:
            run_hooks(self.runner, self.config.hooks.health_check, timeout_seconds=health_timeout_seconds)
        self.service_controller.health_check(health_timeout_seconds, previous_release.version)
        run_hooks(self.runner, self.config.hooks.rollback)
        write_json_atomic(
            self.config.state_file,
            {
                "current_version": previous_release.version,
                "current_release_path": str(previous_release.path),
                "previous_version": current_release.version if current_release else None,
                "previous_release_path": str(current_release.path) if current_release else None,
                "artifact_kind": "rollback",
                "updated_at": datetime.now(timezone.utc).isoformat(),
            },
        )
        return InstallOutcome(
            version=previous_release.version,
            release_path=previous_release.path,
            artifact_kind="rollback",
            rolled_back=True,
        )
