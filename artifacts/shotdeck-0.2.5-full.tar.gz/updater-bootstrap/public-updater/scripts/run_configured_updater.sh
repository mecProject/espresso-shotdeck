#!/usr/bin/env bash
set -euo pipefail

CONFIG_PATH="${1:-/etc/shotdeck/updater.json}"
COMMAND_MODE="${2:-scheduled}"
UPDATES_ENABLED_VALUE="${UPDATES_ENABLED:-yes}"
UPDATES_ENABLED_NORMALIZED="$(printf '%s' "$UPDATES_ENABLED_VALUE" | tr '[:upper:]' '[:lower:]')"
AUTO_UPDATE_VALUE="${AUTO_UPDATE:-no}"
AUTO_UPDATE_NORMALIZED="$(printf '%s' "$AUTO_UPDATE_VALUE" | tr '[:upper:]' '[:lower:]')"
SCRIPT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROMPT_FLOW="$SCRIPT_ROOT/prompted_update_flow.py"

clear_prompt_files() {
    /usr/bin/python3 "$PROMPT_FLOW" \
        --config "$CONFIG_PATH" clear
}

run_prompted_check() {
    exec /usr/bin/python3 "$PROMPT_FLOW" \
        --config "$CONFIG_PATH" check
}

run_prompted_response() {
    exec /usr/bin/python3 "$PROMPT_FLOW" \
        --config "$CONFIG_PATH" process-response
}

case "$UPDATES_ENABLED_NORMALIZED" in
    1|true|yes|on)
        ;;
    0|false|no|off)
        clear_prompt_files
        exit 0
        ;;
    *)
        echo "[WARN] Unrecognized UPDATES_ENABLED=$UPDATES_ENABLED_VALUE; defaulting to enabled" >&2
        ;;
esac

if [[ "$COMMAND_MODE" == "process-response" ]]; then
    run_prompted_response
fi

case "$AUTO_UPDATE_NORMALIZED" in
    1|true|yes|on)
        /usr/bin/python3 "$PROMPT_FLOW" runtime-path >/dev/null
        clear_prompt_files
        exec /usr/bin/python3 "$PROMPT_FLOW" --config "$CONFIG_PATH" unattended
        ;;
    0|false|no|off)
        run_prompted_check
        ;;
    *)
        echo "[WARN] Unrecognized AUTO_UPDATE=$AUTO_UPDATE_VALUE; defaulting to prompted mode" >&2
        run_prompted_check
        ;;
esac
