#!/usr/bin/env python3
"""Publish an optional, conflict-checked LAN alias through the existing Avahi daemon.

The OS hostname and its normal mDNS records are never modified here. Installed by
provisioning or an application update. No proxy or second mDNS stack is used.
"""
from __future__ import annotations

import ipaddress
import json
import re
import subprocess
import time
from pathlib import Path

ALIAS = "shotdeck.local"
NO_REVERSE = 16  # AvahiPublishFlags; AddAddress still probes unique A/AAAA records.
STATUS_PATH = Path("/run/shotdeck-web-alias/status.json")


def lan_addresses(interfaces):
    """Only up Ethernet/WLAN interfaces, with usable, non-tentative LAN addresses."""
    result = set()
    for iface in interfaces:
        if not re.match(r"^(eth|en|wl)[a-zA-Z0-9_.-]*$", iface.get("ifname", "")):
            continue
        if "UP" not in iface.get("flags", []) or iface.get("link_type") != "ether":
            continue
        for addr in iface.get("addr_info", []):
            flags = set(addr.get("flags", []))
            if addr.get("scope") != "global" or flags.intersection({"tentative", "dadfailed", "deprecated"}):
                continue
            if any(addr.get(key, False) for key in ("tentative", "dadfailed", "deprecated")):
                continue
            try:
                ip = ipaddress.ip_address(addr["local"])
                index = int(iface["ifindex"])
            except (KeyError, ValueError):
                continue
            if index > 0 and not (ip.is_loopback or ip.is_multicast or ip.is_unspecified or ip.is_link_local):
                result.add((index, str(ip)))
    return tuple(sorted(result))


class Publisher:
    """One entry group: a collision withdraws the whole alias, never the hostname."""
    def __init__(self, group):
        self.group = group
        self.addresses = ()
        self.hostname = ""
        self.state = "waiting-network"
        self.retry_at = 0.0

    def reset(self):
        self.group.Reset()
        self.addresses = ()

    def tick(self, server_state, hostname, addresses, now):
        if server_state != 2 or not addresses or hostname.lower().rstrip(".") == ALIAS:
            self.reset()
            self.hostname = hostname
            self.state = "waiting-network" if server_state != 2 or not addresses else "hostname-conflict"
            return self.state
        changed = addresses != self.addresses or hostname != self.hostname
        if not changed:
            if self.state == "conflict" and now < self.retry_at:
                return self.state
            state = int(self.group.GetState())
            if state == 2:
                self.state = "established"
                return self.state
            if state == 3:
                if self.state != "conflict":
                    self.retry_at = now + 120
                self.state = "conflict"
                if now < self.retry_at:
                    return self.state
            elif state == 4:
                raise RuntimeError("Avahi alias entry group failed")
            elif state == 1:
                self.state = "probing"
                return self.state
        self.reset()
        self.hostname = hostname
        self.addresses = addresses
        try:
            for index, address in addresses:
                self.group.AddAddress(index, -1, NO_REVERSE, ALIAS, address)
            self.group.Commit()
        except Exception as exc:
            # A local publisher can already own the name before probing starts.
            if getattr(exc, "get_dbus_name", lambda: "")() != "org.freedesktop.Avahi.CollisionError":
                raise
            self.reset()
            self.addresses = addresses
            self.state = "conflict"
            self.retry_at = now + 120
            return self.state
        self.state = "probing"
        return self.state


def main():
    import dbus  # System package on the Pi; pure controller is testable on the host.

    bus = dbus.SystemBus()
    server = dbus.Interface(bus.get_object("org.freedesktop.Avahi", "/"), "org.freedesktop.Avahi.Server")
    group = dbus.Interface(bus.get_object("org.freedesktop.Avahi", server.EntryGroupNew()), "org.freedesktop.Avahi.EntryGroup")
    publisher = Publisher(group)
    last_state = None
    try:
        while True:
            result = subprocess.run(["ip", "-j", "address", "show"], check=True, capture_output=True, text=True, timeout=5)
            hostname = str(server.GetHostNameFqdn())
            addresses = lan_addresses(json.loads(result.stdout))
            state = publisher.tick(int(server.GetState()), hostname, addresses, time.monotonic())
            status = {"alias": ALIAS, "unique_url": "http://" + hostname,
                      "state": state, "addresses": addresses, "observed_at": int(time.time())}
            temporary = STATUS_PATH.with_suffix(".tmp")
            temporary.write_text(json.dumps(status) + "\n", encoding="utf-8")
            temporary.replace(STATUS_PATH)
            if state != last_state:
                print(f"{ALIAS}: {state}; unique address: http://{hostname}", flush=True)
                last_state = state
            time.sleep(15)
    finally:
        try:
            group.Free()
        except Exception:
            pass  # D-Bus/Avahi may have restarted; systemd reconnects this process.


if __name__ == "__main__":
    main()
