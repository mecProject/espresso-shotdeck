# Third-party notices

Shotdeck distributions include the following third-party components and
assets. Copyright remains with their respective owners.

| Component | Copyright / author | Licence |
| --- | --- | --- |
| Preact | Jason Miller and contributors | MIT (`PREACT-MIT.txt`) |
| Inter font | Rasmus Andersson and contributors | SIL Open Font License 1.1 (`OFL-1.1.txt`) |
| Fraunces font | The Fraunces Project Authors | SIL Open Font License 1.1 (`OFL-1.1.txt`) |
| JetBrains Mono font | JetBrains and contributors | SIL Open Font License 1.1 (`OFL-1.1.txt`) |
| Barlow and Barlow Semi Condensed fonts | The Barlow Project Authors (https://github.com/jpt/barlow) | SIL Open Font License 1.1 (`OFL-1.1.txt`) |

The compiled Python distribution can also contain third-party Python packages.
Their own licence metadata and notice files are retained by the standalone
builder. This notice supplements, and does not replace, those files.
