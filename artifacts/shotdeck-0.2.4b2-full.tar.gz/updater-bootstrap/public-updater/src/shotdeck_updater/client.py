"""High-level update workflow used by CLI commands and systemd timers."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, replace
from pathlib import Path
from packaging.version import Version

from shotdeck_manifest import (
    AllowlistDocument,
    ApplicabilityDecision,
    DeviceContext,
    PatchArtifactRef,
    ReleaseManifest,
    canonical_json_bytes,
    evaluate_targeting,
    verify_manifest_payload,
)

from .config import UpdaterConfig
from .download import download_to_path, fetch_bytes, fetch_json
from .errors import ConfigError, DownloadError
from .identity import collect_identity
from .installer import InstallOutcome, ReleaseInstaller
from .patching import patch_is_eligible
from .storage import ensure_directory, read_json, sha256_file, write_json_atomic
from .system import CommandRunner
from . import __version__ as updater_version
from shotdeck_security.storage import MigrationError, canonical as trust_canonical, digest as trust_digest
from shotdeck_security.updates import UpdateStore


@dataclass(slots=True)
class CheckResult:
    manifest: ReleaseManifest
    allowlist: AllowlistDocument | None
    decision: ApplicabilityDecision
    selected_patch: PatchArtifactRef | None
    manifest_sha256: str = ""

    @property
    def selected_artifact_filename(self) -> str:
        if self.selected_patch:
            return self.selected_patch.filename
        return self.manifest.full_artifact.filename

    @property
    def selected_artifact_url(self) -> str:
        if self.selected_patch:
            return self.selected_patch.url
        return self.manifest.full_artifact.url

    @property
    def selected_artifact_sha256(self) -> str:
        if self.selected_patch:
            return self.selected_patch.sha256
        return self.manifest.full_artifact.sha256

    @property
    def selected_artifact_size(self) -> int:
        if self.selected_patch:
            return self.selected_patch.size
        return self.manifest.full_artifact.size

    def to_dict(self) -> dict[str, object]:
        manifest_sha256 = self.manifest_sha256 or hashlib.sha256(
            canonical_json_bytes(self.manifest.to_dict())
        ).hexdigest()
        payload = {
            "applicable": self.decision.applicable,
            "reason": self.decision.reason,
            "manifest_version": self.manifest.version,
            "channel": self.manifest.channel,
            "artifact_kind": "patch" if self.selected_patch else "full",
            "artifact_filename": self.selected_artifact_filename if self.decision.applicable else None,
            "artifact_sha256": self.selected_artifact_sha256 if self.decision.applicable else None,
            "artifact_size": self.selected_artifact_size if self.decision.applicable else None,
            "manifest_sha256": manifest_sha256,
        }
        if self.decision.staged_rollout_bucket is not None:
            payload["staged_rollout_bucket"] = self.decision.staged_rollout_bucket
        return payload


class UpdaterClient:
    def __init__(
        self,
        config: UpdaterConfig,
        *,
        installer: ReleaseInstaller | None = None,
        runner: CommandRunner | None = None,
        logger=None,
    ) -> None:
        self.trust = UpdateStore(config.migration_root, config.install_root, config.manifest_security_state_file)
        try:
            active = self.trust.active()
        except (OSError, MigrationError) as exc:
            raise ConfigError(f'Cannot resolve persistent update trust: {exc}') from exc
        self.trust_id = trust_digest(trust_canonical(active)) if active else None
        if active:
            policy = active['policy']
            if Version(updater_version) < Version(policy['minimum_updater_version']):
                raise ConfigError('Updater is below the committed migration runtime floor')
            config = replace(config, manifest_url=policy['feeds'][config.channel], next_manifest_url='',
                public_key_path=self.trust.folder / 'generations' / self.trust_id / 'update-public.pem',
                allow_recovery_downgrade=False)
        self.config = config
        self.runner = runner or CommandRunner()
        self.installer = installer or ReleaseInstaller(config, runner=self.runner, logger=logger)
        self.logger = logger
        self._last_manifest_sha256 = ""

    def _log(self, level: str, message: str, *args: object) -> None:
        if self.logger is not None:
            getattr(self.logger, level)(message, *args)

    def _load_manifest(self) -> ReleaseManifest:
        last_error: DownloadError | None = None
        for index, manifest_url in enumerate(self.config.manifest_urls):
            try:
                manifest_payload = fetch_json(manifest_url, timeout=self.config.request_timeout_seconds)
                verify_manifest_payload(manifest_payload, self.config.public_key_path.read_bytes())
                manifest_sha256 = hashlib.sha256(
                    canonical_json_bytes(manifest_payload)
                ).hexdigest()
                manifest = ReleaseManifest.from_dict(manifest_payload)
                if self.trust_id and manifest.channel != self.config.channel:
                    raise ConfigError('New-key manifest channel differs from the selected channel')
                if (
                    Version(updater_version) < Version(manifest.min_updater_version)
                    and index + 1 < len(self.config.manifest_urls)
                ):
                    self._log(
                        "warning",
                        "Manifest at %s requires updater %s; trying compatibility fallback",
                        manifest_url,
                        manifest.min_updater_version,
                    )
                    continue
                self._enforce_manifest_anti_rollback(manifest)
                self._last_manifest_sha256 = manifest_sha256
                if index > 0:
                    self._log(
                        "warning",
                        "Primary manifest URL %s failed earlier; using fallback manifest URL %s",
                        self.config.manifest_url,
                        manifest_url,
                    )
                return manifest
            except DownloadError as exc:
                last_error = exc
                if index + 1 < len(self.config.manifest_urls):
                    self._log(
                        "warning",
                        "Failed to fetch manifest from %s; trying fallback manifest URL",
                        manifest_url,
                    )
                    continue
                raise
        if last_error is not None:
            raise last_error
        raise DownloadError("No manifest URLs are configured")

    def _enforce_manifest_anti_rollback(self, manifest: ReleaseManifest) -> None:
        state_path = self.config.manifest_security_state_file
        highest_seen = ""
        if state_path.exists():
            try:
                highest_seen = str(read_json(state_path).get("highest_seen_version") or "")
                if highest_seen:
                    Version(highest_seen)
            except Exception as exc:
                raise ConfigError("Manifest anti-rollback state is invalid") from exc
        if self.trust_id:
            active = self.trust.active()
            if trust_digest(trust_canonical(active)) != self.trust_id:
                raise ConfigError('Update trust changed during this operation; check again')
            highest_seen = str(max(Version(highest_seen or '0'), Version(active['highest_seen_version'])))
        if highest_seen and Version(manifest.version) < Version(highest_seen):
            if not self.config.allow_recovery_downgrade:
                raise ConfigError(
                    f"Signed manifest version {manifest.version} is below highest-seen {highest_seen}"
                )
            self._log(
                "warning",
                "Explicit recovery downgrade permits manifest %s below highest-seen %s",
                manifest.version,
                highest_seen,
            )
            return
        if not highest_seen or Version(manifest.version) > Version(highest_seen):
            write_json_atomic(
                state_path,
                {
                    "highest_seen_version": manifest.version,
                    "manifest_key_id": manifest.signature.key_id if manifest.signature else "",
                },
            )

    def _load_allowlist(self, manifest: ReleaseManifest) -> AllowlistDocument | None:
        allowlist_ref = manifest.rollout.allowlist
        if allowlist_ref is None:
            return None
        raw_bytes = fetch_bytes(allowlist_ref.url, timeout=self.config.request_timeout_seconds)
        actual_sha = hashlib.sha256(raw_bytes).hexdigest()
        if len(raw_bytes) != allowlist_ref.size:
            raise DownloadError(
                f"Allowlist size mismatch: expected {allowlist_ref.size}, got {len(raw_bytes)}"
            )
        if actual_sha != allowlist_ref.sha256:
            raise DownloadError(
                f"Allowlist checksum mismatch: expected {allowlist_ref.sha256}, got {actual_sha}"
            )
        return AllowlistDocument.from_dict(json.loads(raw_bytes.decode("utf-8")))

    def _build_context(self, allowlist: AllowlistDocument | None) -> DeviceContext:
        identity = collect_identity(self.config.identity_policy)
        current_release = self.installer.current_release()
        current_version = current_release.version if current_release else "0"
        allowlist_entry = allowlist.find_device(identity.device_fingerprint) if allowlist else None
        return DeviceContext(
            product=self.config.product,
            fingerprint=identity.device_fingerprint,
            short_id=identity.device_short_id,
            hardware_group=identity.hardware_group,
            channel=self.config.channel,
            current_version=current_version,
            updater_version=updater_version,
            allowlist_entry=allowlist_entry,
        )

    def _select_patch(
        self,
        manifest: ReleaseManifest,
        current_version: str,
        current_tree_sha256: str | None,
    ) -> PatchArtifactRef | None:
        if not current_tree_sha256:
            return None
        for patch in manifest.patch_artifacts:
            eligible, _ = patch_is_eligible(current_version, current_tree_sha256, patch)
            if eligible:
                return patch
        return None

    def check(self) -> CheckResult:
        if not self.config.public_key_path.exists():
            raise ConfigError(f"Verification key not found: {self.config.public_key_path}")
        manifest = self._load_manifest()
        allowlist = self._load_allowlist(manifest)
        context = self._build_context(allowlist)
        decision = evaluate_targeting(manifest, context)
        current_release = self.installer.current_release()
        selected_patch = None
        if decision.applicable and current_release:
            selected_patch = self._select_patch(manifest, current_release.version, current_release.tree_sha256)
        return CheckResult(
            manifest=manifest,
            allowlist=allowlist,
            decision=decision,
            selected_patch=selected_patch,
            manifest_sha256=self._last_manifest_sha256,
        )

    def download(self, check_result: CheckResult) -> Path:
        if not check_result.decision.applicable:
            raise DownloadError(f"Refusing to download a non-applicable update: {check_result.decision.reason}")
        ensure_directory(self.config.cache_dir)
        destination = self.config.cache_dir / check_result.selected_artifact_filename
        return download_to_path(
            check_result.selected_artifact_url,
            destination,
            expected_sha256=check_result.selected_artifact_sha256,
            expected_size=check_result.selected_artifact_size,
            timeout=self.config.request_timeout_seconds,
        )

    def apply(self, check_result: CheckResult, artifact_path: Path | None = None) -> InstallOutcome:
        if not check_result.decision.applicable:
            raise DownloadError(f"Refusing to apply a non-applicable update: {check_result.decision.reason}")
        if self.trust_id and trust_digest(trust_canonical(self.trust.active())) != self.trust_id:
            raise ConfigError('Update trust changed since approval; check again')
        artifact_path = artifact_path or self.download(check_result)
        outcome = self.installer.apply_release(
            manifest=check_result.manifest,
            artifact_path=artifact_path,
            patch_artifact=check_result.selected_patch,
        )
        if self.trust_id:
            installed = self.installer.current_release()
            self.trust.record_install(outcome.version, installed.tree_sha256, check_result.manifest_sha256,
                check_result.manifest.signature.key_id)
        return outcome

    def rollback(self) -> InstallOutcome:
        return self.installer.rollback()

    def unattended(self) -> dict[str, object]:
        result = self.check()
        if self.config.policy == "check-only":
            return {"mode": "check-only", **result.to_dict()}
        if not result.decision.applicable:
            return {"mode": self.config.policy, **result.to_dict()}
        artifact_path = self.download(result)
        if self.config.policy == "download-only":
            return {
                "mode": "download-only",
                "downloaded_artifact": str(artifact_path),
                **result.to_dict(),
            }
        outcome = self.apply(result, artifact_path)
        return {
            "mode": "auto-apply",
            "installed_version": outcome.version,
            "release_path": str(outcome.release_path),
            "artifact_kind": outcome.artifact_kind,
            **result.to_dict(),
        }
