// ============================================================
// Shotdeck — feedback taxonomy (brief §4b).
// The real app fetches shots/analysis/feedback from /api.
// ============================================================

// Feedback taxonomy values MUST match the server-side options in lib/bbw_touch.py.
const FB_OPTIONS = {
  issue: ['none', 'under_extraction', 'over_extraction', 'channeling', 'weak_crema', 'choking', 'inconsistent', 'other'],
  taste: ['not_tasted', 'balanced', 'sour', 'bitter', 'sour_and_bitter', 'thin', 'hollow', 'ashy', 'sweet'],
  visual: ['normal', 'pale_stream', 'early_blonding', 'spraying', 'one_sided_flow', 'dark_drips', 'thin_crema', 'large_bubbles', 'no_stream'],
  prep: ['normal', 'wdt_missing', 'clumps', 'tamp_tilted', 'tamp_light', 'tamp_hard', 'rim_grounds', 'dose_low', 'dose_high'],
  grind_adjustment: ['none', 'finer_next', 'coarser_next'],
};

const FB_LABELS = {
  en: {
    none: 'No issue', under_extraction: 'Under', over_extraction: 'Over',
    channeling: 'Channeling', weak_crema: 'Weak crema', choking: 'Choking', inconsistent: 'Inconsistent', other: 'Other',
    not_tasted: 'Not tasted', balanced: 'Balanced', sour: 'Sour', bitter: 'Bitter', sour_and_bitter: 'Sour+bitter',
    thin: 'Thin', hollow: 'Hollow', ashy: 'Ashy', sweet: 'Sweet',
    normal: 'Normal', pale_stream: 'Pale stream', early_blonding: 'Blonding', spraying: 'Spraying',
    one_sided_flow: 'One-sided', dark_drips: 'Dark drips', thin_crema: 'Thin crema', large_bubbles: 'Large bubbles', no_stream: 'No stream',
    wdt_missing: 'No WDT', clumps: 'Clumps', tamp_tilted: 'Tilted tamp', tamp_light: 'Light tamp', tamp_hard: 'Hard tamp',
    rim_grounds: 'Rim grounds', dose_low: 'Dose low', dose_high: 'Dose high',
    finer_next: 'Finer', coarser_next: 'Coarser',
  },
  de: {
    none: 'Kein Problem', under_extraction: 'Unter', over_extraction: 'Über',
    channeling: 'Channeling', weak_crema: 'Schwache Crema', choking: 'Verstopft', inconsistent: 'Inkonsistent', other: 'Andere',
    not_tasted: 'Nicht probiert', balanced: 'Ausgewogen', sour: 'Sauer', bitter: 'Bitter', sour_and_bitter: 'Sauer+bitter',
    thin: 'Dünn', hollow: 'Hohl', ashy: 'Aschig', sweet: 'Süß',
    normal: 'Normal', pale_stream: 'Blasser Strahl', early_blonding: 'Blonding', spraying: 'Spritzt',
    one_sided_flow: 'Einseitig', dark_drips: 'Dunkle Tropfen', thin_crema: 'Dünne Crema', large_bubbles: 'Große Blasen', no_stream: 'Kein Strahl',
    wdt_missing: 'Kein WDT', clumps: 'Klumpen', tamp_tilted: 'Schiefer Tamp', tamp_light: 'Leichter Tamp', tamp_hard: 'Harter Tamp',
    rim_grounds: 'Rand-Reste', dose_low: 'Dosis niedrig', dose_high: 'Dosis hoch',
    finer_next: 'Feiner', coarser_next: 'Gröber',
  },
};
function fbLabel(v) {
  const lang = window.__sdLang || 'en';
  return (FB_LABELS[lang] && FB_LABELS[lang][v]) || FB_LABELS.en[v] || v;
}

// Default seed curve used when a profile first enables ideal flow and has no
// stored points yet. The user can drag these in the editor afterwards.
const IDEAL_ESPR = [
  { time_s: 0, flow_g_s: 0, gradient_g_s2: 0 },
  { time_s: 6, flow_g_s: 0.6, gradient_g_s2: 0.1 },
  { time_s: 10, flow_g_s: 1.9, gradient_g_s2: 0.32 },
  { time_s: 20, flow_g_s: 2.1, gradient_g_s2: 0.02 },
  { time_s: 28, flow_g_s: 1.6, gradient_g_s2: -0.06 },
];

Object.assign(window, {
  FB_OPTIONS, FB_LABELS, fbLabel, IDEAL_ESPR,
});
