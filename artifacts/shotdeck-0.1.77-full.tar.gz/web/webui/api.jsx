// ============================================================
// Shotdeck — API client (PLAIN JS, no JSX).
//
// A thin fetch wrapper for the device's /api endpoints. JSON in/out,
// throws on !res.ok using the server's {error} field.
//
// Pairing is NOT handled here: the injected __SHOTDECK_PAIRING_SCRIPT__
// already wraps window.fetch and handles 401 {code:"unpaired"} (PIN modal
// + retry). This helper just surfaces other errors to the caller.
// ============================================================

const api = async (path, opts = {}) => {
  const headers = {
    'Content-Type': 'application/json',
    // Mutating backup/restore routes require this same-origin-only marker in
    // addition to the signed pairing cookie. It is deliberately not a secret;
    // its purpose is to prevent cross-site form submissions.
    'X-Shotdeck-CSRF': '1',
    ...(opts.headers || {}),
  };
  const res = await fetch(path, {
    ...opts,
    headers,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const error = new Error(data.error || 'Request failed');
    error.status = res.status;
    error.code = data.code || null;
    error.details = data;
    throw error;
  }
  return data;
};

Object.assign(window, { api });
