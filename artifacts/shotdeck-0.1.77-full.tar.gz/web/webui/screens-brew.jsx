// ============================================================
// Shotdeck — Brew tab (home dashboard) + LIVE brewing hero
// ============================================================

function activeProfile(app) { return app.data.profiles.find(p => p.selected && !p.archived) || app.data.profiles.find(p => !p.archived) || app.data.profiles[0]; }
function profileBrewMode(p) { return String((p && p.brew_control_mode) || 'weight').toLowerCase() === 'time' ? 'time' : 'weight'; }
function profileBrewsByTime(p) { return profileBrewMode(p) === 'time'; }
function profileTargetText(p) {
  if (!p) return '-';
  if (profileBrewsByTime(p)) return `${Number(p.target_stop_time_s || p.target_time_max_s || 30).toFixed(0)}s`;
  return `${Number(p.target_weight_g || 0).toFixed(1)}g`;
}
function profileBrewModeLabel(p) {
  return profileBrewsByTime(p) ? tr('brew_by_time') : tr('brew_by_weight');
}
function profileTimingText(p) {
  if (!p) return '-';
  if (profileBrewsByTime(p)) return profileTargetText(p);
  return `${profileTargetText(p)} · ${p.target_time_min_s}-${p.target_time_max_s}s`;
}
// A successful cloud login can still describe an unplugged machine.
function lmOnline(app) { const s = app.data.lm; return !!(s && s.configured && s.login_successful && s.enabled && s.snapshot && s.snapshot.available && s.snapshot.connected === true); }
function lmEnabled(app) { const s = app.data.lm; return !!(s && s.configured && s.enabled); }
function lmMachineOn(app) {
  const snap = app.data.lm && app.data.lm.snapshot;
  const status = snap && snap.status ? snap.status : {};
  const mode = String(status.mode || status.status || '').toLowerCase();
  if (!mode) return !!(snap && (snap.connected || snap.available));
  return mode.indexOf('standby') === -1 && mode.indexOf('off') === -1;
}
function boilerReady(boiler) {
  if (!boiler) return false;
  const status = String(boiler.status || '').toLowerCase();
  if (status.indexOf('ready') !== -1 || status.indexOf('reached') !== -1) return true;
  if (boiler.warmup_estimate && Number(boiler.warmup_estimate.progress || 0) >= 1) return true;
  if (boiler.current_temperature_c == null || boiler.target_temperature_c == null) return false;
  return Number(boiler.current_temperature_c) >= Number(boiler.target_temperature_c) - 1;
}
function boolish(value) {
  return value === true || value === 1 || String(value).toLowerCase() === 'true';
}
function steamBoilerUsesLevel(boiler) {
  const raw = (boiler && boiler.raw) || {};
  return !!boiler && (boolish(raw.target_level_supported) || boiler.target_level != null || boiler.current_level != null);
}
function steamLevelLabel(value) {
  if (value == null || value === '' || value === '-') return '-';
  const text = String(value).trim().replace(/^level/i, '').replace(/^l/i, '');
  return 'L' + (text || value);
}
function steamBoilerLabel(boiler) {
  if (!boiler) return '-';
  if (steamBoilerUsesLevel(boiler)) {
    const current = boiler.current_level ?? boiler.target_level ?? '-';
    const target = boiler.target_level;
    return { value: steamLevelLabel(current), unit: target != null ? '/' + steamLevelLabel(target) : '' };
  }
  const current = boiler.current_temperature_c ?? boiler.target_temperature_c ?? '-';
  const target = boiler.target_temperature_c;
  return { value: String(current), unit: target != null ? '/' + target + '°' : '°' };
}
function brewPrebrewModeText(value) {
  const raw = String(value || '').replace(/[_-]/g, ' ').toLowerCase();
  if (!raw) return '-';
  if (raw.indexOf('disabled') !== -1) return tr('pb_disabled');
  if (raw.indexOf('prebrewing') !== -1 || raw.indexOf('pre brewing') !== -1) return tr('pb_on');
  if (raw.indexOf('preinfusion') !== -1 || raw.indexOf('pre infusion') !== -1) return tr('preinfusion');
  return String(value);
}
function brewPrebrewTimes(pre) {
  if (!pre) return { on: null, off: null };
  if (pre.seconds_on != null || pre.seconds_off != null) return { on: pre.seconds_on, off: pre.seconds_off };
  const entries = pre.times && (pre.times.pre_brewing || pre.times.preBrewing || pre.times.PreBrewing);
  const first = Array.isArray(entries) ? entries[0] : entries;
  const seconds = first && first.seconds ? first.seconds : {};
  return { on: seconds.In ?? seconds.in ?? null, off: seconds.Out ?? seconds.out ?? null };
}
function brewPrebrewTimeText(value) {
  if (value == null || value === '') return '-';
  const n = Number(value);
  if (!Number.isFinite(n)) return String(value);
  return n.toFixed(1).replace(/\.0$/, '') + 's';
}
function brewPrebrewTimesText(times) {
  return `${tr('on')} ${brewPrebrewTimeText(times.on)} / ${tr('off')} ${brewPrebrewTimeText(times.off)}`;
}
function profilePrebrewText(profile, machinePrebrew, prebrewSettings) {
  const preference = (profile && profile.prebrew_preference) || {};
  // A profile may retain its old LM timings while pre-brewing is switched
  // off, so the explicit profile preference must take precedence over the
  // dormant prebrew_mode value.
  if (preference.enabled !== true) return tr('prebrew_off');
  const owner = prebrewSettings && prebrewSettings.owner || 'lamarzocco';
  if (owner === 'shotdeck') {
    const local = profile.shotdeck_prebrew || {};
    if (!local.enabled) return `Shotdeck · ${tr('off')}`;
    const guard = prebrewSettings.native_guard || {};
    if (guard.state === 'active') return tr('lm_override');
    if (guard.state === 'unknown' && !guard.manually_confirmed) return tr('local_prebrew_paused');
    return `Shotdeck · ${brewPrebrewTimeText(local.pump_s)} / ${brewPrebrewTimeText(local.pause_s)}`;
  }
  if (profile.prebrew_mode === 'prebrewing') {
    return brewPrebrewTimesText({ on: profile.prebrew_seconds_on, off: profile.prebrew_seconds_off });
  }
  if (profile.prebrew_mode === 'disabled') return tr('pb_disabled');
  if (machinePrebrew && machinePrebrew.supported !== false) {
    if (String(machinePrebrew.mode || '').toLowerCase().indexOf('disabled') !== -1) return tr('pb_disabled');
    const times = brewPrebrewTimes(machinePrebrew);
    if (times.on != null || times.off != null) return brewPrebrewTimesText(times);
    return brewPrebrewModeText(machinePrebrew.mode);
  }
  return tr('pb_no_change');
}
function brewProfileUsesUnavailableShotdeckPrebrew(profile) {
  const preference = (profile && profile.prebrew_preference) || {};
  const local = (profile && profile.shotdeck_prebrew) || {};
  return preference.enabled === true
    && preference.controller === 'shotdeck'
    && local.supported !== true;
}
function brewAvailability(app, profile = activeProfile(app)) {
  if (app.data.settings.shot_active) return { ok: false, reason: tr('shot_in_progress') };
  if (!app.data.profiles || !app.data.profiles.some(p => !p.archived)) return { ok: false, reason: tr('no_profiles') };
  if (brewProfileUsesUnavailableShotdeckPrebrew(profile)) {
    return { ok: false, reason: tr('shotdeck_prebrew_unavailable_short') };
  }
  if (!lmEnabled(app)) return { ok: true, reason: tr('ready_to_brew') };
  if (!lmOnline(app)) return { ok: false, reason: tr('lm_unavailable') };
  if (!lmMachineOn(app)) return { ok: false, reason: tr('machine_off') };
  if (!boilerReady(app.data.lm.snapshot.coffee_boiler)) return { ok: false, reason: tr('boiler_warming') };
  return { ok: true, reason: tr('ready_to_brew') };
}

// ---- Brew / Home dashboard ----
function BrewScreen({ app }) {
  const [quickEdit, setQuickEdit] = useState(null);
  const p = activeProfile(app);
  const lm = app.data.lm.snapshot;
  const online = lmOnline(app);
  const users = app.data.users;
  const shotActive = app.data.settings.shot_active;
  const canBrew = brewAvailability(app);
  const steam = online ? steamBoilerLabel(lm.steam_boiler) : null;
  const prebrewText = profilePrebrewText(p, online ? lm.prebrewing : null, app.data.settings.prebrew);
  const openQuickEdit = field => {
    if (!shotActive) setQuickEdit({ field, profile: JSON.parse(JSON.stringify(p)) });
  };
  const summary = (field, label, value, unit, compact = false) => (
    <button type="button" className="sd-sumcell sd-sumedit" data-field={field} disabled={shotActive}
      onClick={() => openQuickEdit(field)} aria-label={tr('quick_edit_title').replace('{setting}', label)}>
      <div className="sd-sumk">{label}<Icon name="chevron" size={12} /></div>
      <div className="sd-sumv" style={compact ? { fontSize: 15 } : undefined}>{value}{unit && <span className="u">{unit}</span>}</div>
    </button>
  );

  return (
    <>
    <div className="sd-body sd-scroll">
      {/* Active profile hero */}
      <Card helpKey="summary" onHelp={app.openHelp}>
        <ApiChip>GET /status · PATCH /profiles/{'{i}'}</ApiChip>
        {/* Hero: the profile name speaks for itself; the field label below
            carries the wording once. */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
          <span className="sd-dot" style={{ background: p.color, width: 16, height: 16 }} />
          <div className="sd-serif" style={{ fontSize: 30, fontStyle: 'italic', lineHeight: 1.05 }}>{p.name}</div>
          <Pill variant={profileBrewsByTime(p) ? 'good' : ''} dot>{profileBrewModeLabel(p)}</Pill>
        </div>

        {/* Active barista */}
        <div style={{ marginBottom: 14 }}>
          <div className="sd-fieldlabel">{tr('brewing_for')}</div>
          <Select value={users.active.id}
            disabled={shotActive}
            onChange={id => app.setActiveUser(id)}
            options={users.items.filter(u => !u.archived).map(u => ({ value: u.id, label: u.name }))} />
          {shotActive && <div className="sd-rowsub" style={{ marginTop: 6 }}>{tr('locked_shot')}</div>}
        </div>

        <div style={{ marginBottom: 14 }}>
          <div className="sd-fieldlabel">{tr('profile_label')}</div>
          <Select value={String(p.index)}
            disabled={shotActive}
            onChange={idx => app.selectProfile(Number(idx))}
            options={app.data.profiles.filter(pr => !pr.archived).map(pr => ({
              value: String(pr.index), label: pr.name + ' · ' + pr.roast,
              disabled: brewProfileUsesUnavailableShotdeckPrebrew(pr),
            }))} />
        </div>

        <BrewPreparation app={app} profile={p}/>

        {/* Summary grid — 3-up so the whole card fits above the fold */}
        <div className="sd-sumgrid three">
          {summary('target', profileBrewsByTime(p) ? tr('target_time') : tr('target'), profileBrewsByTime(p) ? Number(p.target_stop_time_s || p.target_time_max_s || 30).toFixed(0) : p.target_weight_g.toFixed(1), profileBrewsByTime(p) ? 's' : 'g')}
          {!profileBrewsByTime(p) && summary('time', tr('time'), `${p.target_time_min_s}–${p.target_time_max_s}`, 's')}
          {profileBrewsByTime(p) && <div className="sd-sumcell"><div className="sd-sumk">{tr('brew_mode')}</div><div className="sd-sumv" style={{ fontSize: 15 }}>{tr('brew_by_time')}</div></div>}
          {summary('roast', tr('roast'), p.roast)}
          {summary('prebrew', tr('prebrew'), prebrewText, '', true)}
          {online && <>
            {summary('coffee', tr('coffee'), lm.coffee_boiler?.current_temperature_c ?? '-', `/${lm.coffee_boiler?.target_temperature_c ?? '-'}°`)}
            {summary('steam', tr('steam'), steam.value, steam.unit)}
          </>}
        </div>
      </Card>

      {/* Start brew */}
      <Card>
        <ApiChip>POST /brew/start · GET /status poll</ApiChip>
        <div style={{ textAlign: 'center', padding: '4px 0 2px' }}>
          <div className="sd-micro" style={{ marginBottom: 4 }}>{canBrew.reason}</div>
          <div className="sd-rowsub" style={{ marginBottom: 16 }}>{tr('place_cup')}</div>
          <Btn variant="primary" className="block" style={{ minHeight: 64, fontSize: 17 }}
            disabled={!canBrew.ok}
            onClick={() => app.brew.confirm(p.index)}>
            <Icon name="brew" size={24} /> {tr('start_brew')}
          </Btn>
        </div>
      </Card>

      {/* Last shot mini */}
      <LastShotCard app={app} />
    </div>
    {quickEdit && <BrewQuickEditor app={app} field={quickEdit.field} profile={quickEdit.profile} onClose={() => setQuickEdit(null)} />}
    </>
  );
}

function BrewQuickEditor({ app, field, profile, onClose }) {
  const [draft, setDraft] = useState({
    ...profile,
    prebrew_preference: { enabled: true, controller: 'lamarzocco', ...profile.prebrew_preference },
    shotdeck_prebrew: { enabled: false, pump_s: 2, pause_s: 3, ...profile.shotdeck_prebrew },
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const inFlight = useRef(false);
  const set = (key, value) => setDraft(current => ({ ...current, [key]: value }));
  const byTime = profileBrewsByTime(draft);
  const sameProfile = activeProfile(app)?.index === profile.index;
  const locked = !!app.data.settings.shot_active || !sameProfile;
  const snapshot = app.data.lm.snapshot || {};
  const boiler = (field === 'coffee' ? snapshot.coffee_boiler : snapshot.steam_boiler) || {};
  const level = field === 'steam' && steamBoilerUsesLevel(boiler);
  const temperatureKey = field === 'coffee' ? 'coffee_target_temperature_c' : level ? 'steam_target_level' : 'steam_target_temperature_c';
  const custom = !!draft.temperature_targets_enabled && draft[temperatureKey] != null;
  const min = boiler.raw?.target_temperature_min ?? (field === 'coffee' ? 80 : 100);
  const max = boiler.raw?.target_temperature_max ?? (field === 'coffee' ? 100 : 140);
  const defaultValue = level
    ? Number(String(boiler.target_level ?? 2).replace(/^(level|l)/i, ''))
    : boiler.target_temperature_c ?? (field === 'coffee' ? 93 : 123);
  const unavailable = (field === 'coffee' || field === 'steam')
    && (!lmOnline(app) || boiler.supported !== true || (level ? boiler.target_level == null : !Number.isFinite(boiler.target_temperature_c)));
  const prebrewUnavailable = field === 'prebrew' && draft.prebrew_preference.enabled
    && draft.prebrew_preference.controller === 'shotdeck' && draft.shotdeck_prebrew.supported !== true;
  const title = { target: byTime ? tr('target_time') : tr('target'), time: tr('time'), roast: tr('roast'),
    prebrew: tr('prebrew'), coffee: tr('coffee'), steam: tr('steam') }[field];
  const temperatureFields = enabled => {
    const fields = { [temperatureKey]: enabled ? draft[temperatureKey] ?? defaultValue : null };
    if (field === 'steam') fields[level ? 'steam_target_temperature_c' : 'steam_target_level'] = null;
    if (enabled && !draft.temperature_targets_enabled) {
      // Enabling one target must not activate another dormant machine setting.
      for (const key of ['coffee_target_temperature_c', 'steam_target_temperature_c', 'steam_target_level']) {
        if (!(key in fields)) fields[key] = null;
      }
    }
    const next = { ...draft, ...fields };
    const other = field === 'coffee' ? [next.steam_target_temperature_c, next.steam_target_level] : [next.coffee_target_temperature_c];
    fields.temperature_targets_enabled = enabled || (draft.temperature_targets_enabled && other.some(value => value != null));
    return fields;
  };
  const fieldsToSave = () => {
    if (field === 'target') return byTime
      ? { target_stop_time_s: Math.round(draft.target_stop_time_s ?? draft.target_time_max_s ?? 30) }
      : { target_weight_g: draft.target_weight_g };
    if (field === 'time') return { target_time_min_s: Math.round(draft.target_time_min_s), target_time_max_s: Math.round(draft.target_time_max_s) };
    if (field === 'roast') return { roast: draft.roast };
    if (field === 'coffee' || field === 'steam') return temperatureFields(custom);
    return {
      prebrew_preference: draft.prebrew_preference,
      prebrew_mode: draft.prebrew_mode === 'prebrewing' ? 'prebrewing' : 'no_change',
      prebrew_seconds_on: draft.prebrew_seconds_on, prebrew_seconds_off: draft.prebrew_seconds_off,
      shotdeck_prebrew: { enabled: draft.prebrew_preference.enabled && draft.prebrew_preference.controller === 'shotdeck',
        pump_s: draft.shotdeck_prebrew.pump_s, pause_s: draft.shotdeck_prebrew.pause_s },
    };
  };
  const save = async () => {
    if (inFlight.current || locked || unavailable || prebrewUnavailable) return;
    inFlight.current = true; setSaving(true); setError('');
    try { await app.saveProfileFields(profile.index, fieldsToSave()); onClose(); }
    catch (failure) { setError(failure.message || tr('quick_save_failed')); }
    finally { inFlight.current = false; setSaving(false); }
  };
  useEffect(() => {
    const close = event => { if (event.key === 'Escape' && !inFlight.current) onClose(); };
    document.addEventListener('keydown', close);
    return () => document.removeEventListener('keydown', close);
  }, []);
  return <Modal title={tr('quick_edit_title').replace('{setting}', title)} onClose={onClose} dismissible={!saving}
    footer={<><Btn variant="ghost" disabled={saving} onClick={onClose}>{tr('cancel')}</Btn>
      <Btn variant="primary" className="block" disabled={saving || locked || unavailable || prebrewUnavailable} onClick={save}>
        {saving ? tr('quick_saving') : tr('save')}</Btn></>}>
    <div className="sd-quick-profile"><span className="sd-dot" style={{ background: profile.color }} />
      <strong>{profile.name}</strong><span>{tr('quick_profile_hint')}</span></div>
    {locked && <p role="alert" className="sd-quick-error">{sameProfile ? tr('locked_shot') : tr('quick_profile_changed')}</p>}
    {unavailable && <p role="alert" className="sd-quick-error">{tr('lm_unavailable')}</p>}
    <fieldset className="sd-quick-fields" disabled={saving || locked || unavailable}>
      {field === 'target' && <Row label={byTime ? tr('target_time') : tr('weight_g')}>
        <Stepper width={170} value={byTime ? draft.target_stop_time_s ?? draft.target_time_max_s ?? 30 : draft.target_weight_g}
          onChange={value => set(byTime ? 'target_stop_time_s' : 'target_weight_g', value)} min={byTime ? 1 : 0} max={byTime ? 999 : 100} /></Row>}
      {field === 'time' && <>
        <Row label={tr('time_min')}><Stepper value={draft.target_time_min_s} min={0} max={999}
          onChange={value => set('target_time_min_s', Math.min(Math.round(value), draft.target_time_max_s))} /></Row>
        <Row label={tr('time_max')}><Stepper value={draft.target_time_max_s} min={0} max={999}
          onChange={value => set('target_time_max_s', Math.max(Math.round(value), draft.target_time_min_s))} /></Row>
      </>}
      {field === 'roast' && <><div className="sd-fieldlabel">{tr('roast')}</div>
        <Select value={draft.roast} onChange={value => set('roast', value)} options={app.data.roast_types.map(roast => ({ value: roast.name, label: roast.name }))} /></>}
      {field === 'prebrew' && <ProfilePrebrewFields draft={draft} onChange={setDraft} />}
      {(field === 'coffee' || field === 'steam') && <>
        <Row label={tr('quick_custom_target')} sub={tr('lm_profile_prebrew_help')}>
          <Switch on={custom} onChange={enabled => setDraft(current => ({ ...current, ...temperatureFields(enabled) }))} />
        </Row>
        {custom ? (level ? <><div className="sd-fieldlabel">{tr('steam_level')}</div>
          <Segmented value={String(draft.steam_target_level)} onChange={value => set('steam_target_level', Number(value))}
            options={[0, 1, 2, 3].map(value => ({ value: String(value), label: value === 0 ? tr('off') : 'L' + value }))} /></>
          : <Row label={field === 'coffee' ? tr('coffee_c') : tr('steam_c')}>
            <Stepper value={draft[temperatureKey]} onChange={value => set(temperatureKey, value)} min={min} max={max} step={0.5} /></Row>)
          : <p className="sd-rowsub">{tr('pb_no_change')}</p>}
      </>}
    </fieldset>
    {error && <p role="alert" className="sd-quick-error">{error}</p>}
  </Modal>;
}

function LastShotCard({ app }) {
  const shot = app.data.shots[0] || null;
  const [detail, setDetail] = useState(null);
  useEffect(() => {
    if (!shot) { setDetail(null); return; }
    let cancelled = false;
    setDetail(null);
    app.loadShotDetail(shot.id)
      .then(d => { if (!cancelled) setDetail(d); })
      .catch(() => { if (!cancelled) setDetail(null); });
    return () => { cancelled = true; };
  }, [shot ? shot.id : null]);

  if (!shot) return null;
  const inWindow = shot.duration_s >= 25 && shot.duration_s <= 32;
  return (
    <Card title={tr('view_shot')} className="" right={<Pill variant={inWindow ? 'good' : ''} dot>{shot.duration_s.toFixed(1)}s</Pill>}>
      <ApiChip>GET /shots?limit=1</ApiChip>
      <div onClick={() => app.openShot(shot.id)} style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 14 }}>
        <div style={{ flex: 'none', width: 120, height: 56, background: 'var(--inset)', borderRadius: 'var(--r-sm)', overflow: 'hidden' }}>
          {detail && <LiveBrewChart width={120} height={56} samples={detail.samples} duration={shot.duration_s} ideal={null} themeKey={app.theme} />}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span className="sd-itemname">{shot.profile_name}</span>
            <span className="sd-mono" style={{ color: 'var(--primary)', fontSize: 15 }}>{shot.final_weight_g}g</span>
          </div>
          <div className="sd-itemsub">{shot.user_name} · {shot.roast}{shot.has_feedback ? ' · ' + tr('feedback') : ''}</div>
        </div>
        <Icon name="chevron" size={18} color="var(--fg-faint)" />
      </div>
    </Card>
  );
}

// ============================================================
// LIVE BREWING VIEW — the hero. Full-screen takeover.
// ============================================================
function LiveBrewView({ app }) {
  const b = app.brew.state;
  const p = app.data.profiles.find(pr => pr.index === b.profileIdx) || activeProfile(app);
  const live = app.data.live || {};
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(id);
  }, []);
  const elapsed = Math.max(0, (now - (b.startedAt || now)) / 1000);
  const liveElapsedRaw = Number(live.elapsed_s);
  const liveElapsed = Number.isFinite(liveElapsedRaw) && liveElapsedRaw > 0 ? Math.max(liveElapsedRaw, elapsed) : elapsed;
  const liveWeight = Number.isFinite(Number(live.weight_g)) ? Number(live.weight_g) : null;
  const liveFlow = Number.isFinite(Number(live.flow_g_s)) ? Number(live.flow_g_s) : null;
  const liveWeightText = liveWeight == null ? '-' : liveWeight.toFixed(1);
  const liveFlowText = liveFlow == null ? '-' : liveFlow.toFixed(1);
  const lastShot = app.data.shots && app.data.shots[0];
  const brew = app.data.settings.brew || {};
  const phase = String(brew.phase || 'extracting');
  const phaseLabel = phase === 'prebrew_pump' ? tr('phase_pump_on')
    : phase === 'prebrew_soak' ? tr('phase_soak') : tr('extracting');
  const phaseRemaining = Number(brew.phase_remaining_s || 0);

  return (
    <div style={{
      position: 'absolute', inset: 0, zIndex: 40, background: 'var(--bg)',
      display: 'flex', flexDirection: 'column', padding: '46px 22px 30px',
      animation: 'sd-rise .25s ease',
    }}>
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span className="sd-dot" style={{ background: p.color, width: 12, height: 12 }} />
          <span className="sd-serif" style={{ fontStyle: 'italic', fontSize: 20 }}>{p.name}</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Pill variant={profileBrewsByTime(p) ? 'good' : ''} dot>{profileBrewModeLabel(p)}</Pill>
          <Pill variant="ok" dot>{phaseLabel}{phaseRemaining > 0 ? ` · ${phaseRemaining.toFixed(1)}s` : ''}</Pill>
        </div>
      </div>

      <div style={{ textAlign: 'center', marginTop: 36 }}>
        <div className="sd-micro">{tr('elapsed')}</div>
        <div className="sd-serif" style={{ fontSize: 92, fontWeight: 300, lineHeight: .95, fontVariantNumeric: 'tabular-nums' }}>
          {liveElapsed.toFixed(0)}<span style={{ fontSize: 34, color: 'var(--fg-faint)' }}>s</span>
        </div>
        <div className="sd-mono" style={{ color: 'var(--fg-faint)', marginTop: 8 }}>{tr('target')} {profileTimingText(p)}</div>
      </div>

      <div style={{ flex: 1, background: 'var(--inset)', borderRadius: 'var(--r-md)', marginTop: 28, padding: 18, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 18 }}>
        <div className="sd-micro">{tr('waiting_for_shot')}</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          <div className="sd-sumcell" style={{ minHeight: 96 }}>
            <div className="sd-sumk">{tr('weight')}</div>
            <div className="sd-sumv" style={{ fontSize: 36, fontVariantNumeric: 'tabular-nums' }}>
              {liveWeightText}<span className="u">{liveWeight == null ? '' : 'g'}</span>
            </div>
          </div>
          <div className="sd-sumcell" style={{ minHeight: 96 }}>
            <div className="sd-sumk">{tr('flow')}</div>
            <div className="sd-sumv" style={{ fontSize: 36, fontVariantNumeric: 'tabular-nums' }}>
              {liveFlowText}<span className="u">{liveFlow == null ? '' : 'g/s'}</span>
            </div>
          </div>
        </div>
        <div className="sd-rowsub">{tr('live_stream_followup')}</div>
        {lastShot && (
          <div className="sd-row" style={{ marginTop: 8 }}>
            <div className="sd-rowlabel">{tr('view_shot')}<div className="sd-rowsub">{lastShot.profile_name} · {lastShot.final_weight_g}g · {lastShot.duration_s.toFixed(1)}s</div></div>
            <Btn className="sm" onClick={() => app.openShot(lastShot.id)}>{tr('open')}</Btn>
          </div>
        )}
      </div>

      <Btn variant="danger" className="block" style={{ marginTop: 22 }} onClick={() => app.brew.stop()}>{tr('stop_brew')}</Btn>
    </div>
  );
}

function BrewConfirmModal({ app }) {
  const selectedIdx = app.brewConfirm.profileIdx;
  const p = app.data.profiles.find(pr => pr.index === selectedIdx) || activeProfile(app);
  const canBrew = brewAvailability(app, p);
  const online = lmOnline(app);
  const lm = app.data.lm.snapshot;
  const prebrewText = profilePrebrewText(p, online ? lm.prebrewing : null, app.data.settings.prebrew);
  return (
    <Modal title={tr('confirm_start')} onClose={app.brew.closeConfirm}
      footer={<>
        <Btn variant="ghost" onClick={app.brew.closeConfirm}>{tr('cancel')}</Btn>
        <Btn variant="primary" className="block" disabled={!canBrew.ok} onClick={() => app.brew.start(p.index)}>{tr('start_now')}</Btn>
      </>}>
      <ApiChip>POST /brew/start</ApiChip>
      <div className="sd-rowsub" style={{ marginBottom: 14 }}>{tr('confirm_start_desc')}</div>
      <div style={{ marginBottom: 14 }}>
        <div className="sd-fieldlabel">{tr('profile_label')}</div>
        <Select value={String(p.index)}
          onChange={idx => app.brew.setConfirmProfile(Number(idx))}
          options={app.data.profiles.filter(pr => !pr.archived).map(pr => ({
            value: String(pr.index), label: pr.name + ' · ' + pr.roast,
            disabled: brewProfileUsesUnavailableShotdeckPrebrew(pr),
          }))} />
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
        <span className="sd-dot" style={{ background: p.color, width: 12, height: 12 }} />
        <span className="sd-serif" style={{ fontStyle: 'italic', fontSize: 20 }}>{p.name}</span>
        <Pill variant={profileBrewsByTime(p) ? 'good' : ''} dot>{profileBrewModeLabel(p)}</Pill>
        <Pill variant={canBrew.ok ? 'good' : ''} dot>{canBrew.reason}</Pill>
      </div>
      <div className="sd-sumgrid">
        <div className="sd-sumcell"><div className="sd-sumk">{profileBrewsByTime(p) ? tr('target_time') : tr('target')}</div><div className="sd-sumv">{profileBrewsByTime(p) ? Number(p.target_stop_time_s || p.target_time_max_s || 30).toFixed(0) : p.target_weight_g.toFixed(1)}<span className="u">{profileBrewsByTime(p) ? 's' : 'g'}</span></div></div>
        {!profileBrewsByTime(p) && <div className="sd-sumcell"><div className="sd-sumk">{tr('time')}</div><div className="sd-sumv">{p.target_time_min_s}-{p.target_time_max_s}<span className="u">s</span></div></div>}
        {profileBrewsByTime(p) && <div className="sd-sumcell"><div className="sd-sumk">{tr('brew_mode')}</div><div className="sd-sumv" style={{ fontSize: 15 }}>{tr('brew_by_time')}</div></div>}
        <div className="sd-sumcell"><div className="sd-sumk">{tr('roast')}</div><div className="sd-sumv">{p.roast}</div></div>
        <div className="sd-sumcell"><div className="sd-sumk">{tr('prebrew')}</div><div className="sd-sumv" style={{ fontSize: 15 }}>{prebrewText}</div></div>
      </div>
    </Modal>
  );
}

Object.assign(window, { BrewScreen, LiveBrewView, BrewConfirmModal, activeProfile, profileBrewMode, profileBrewsByTime, profileTargetText, profileBrewModeLabel, profileTimingText, lmOnline, steamBoilerUsesLevel, steamLevelLabel, steamBoilerLabel, brewPrebrewModeText, brewPrebrewTimes, brewPrebrewTimeText, brewPrebrewTimesText, profilePrebrewText });
