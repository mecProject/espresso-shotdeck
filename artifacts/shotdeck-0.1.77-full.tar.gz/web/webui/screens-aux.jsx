// ============================================================
// Shotdeck — Help modal · Diagnostics modal
// ============================================================

// ---- Help modal ----
function HelpModal({ app }) {
  return (
    <Modal title={tr('help')} onClose={() => app.openHelp(null)}>
      <ApiChip>(client) H dictionary · {app.lang.toUpperCase()}</ApiChip>
      <HelpList section={app.helpSection} />
    </Modal>
  );
}

// ---- Diagnostics modal (real POST + polled status) ----
function DiagnosticsModal({ app }) {
  const [status, setStatus] = useState('idle'); // idle|building|uploading|sent|saved|failed|error
  const [code, setCode] = useState('');
  const [errMsg, setErrMsg] = useState('');
  const timer = useRef(null);
  const tries = useRef(0);
  const stopPoll = () => { if (timer.current) { clearInterval(timer.current); timer.current = null; } };
  useEffect(() => () => stopPoll(), []);

  const finish = (st) => { stopPoll(); setStatus(st); };
  const tick = async () => {
    tries.current += 1;
    try {
      const d = await api('/api/support/diagnostics/status');
      const st = d.status || 'building';
      if (st === 'sent') { setCode(d.support_code || d.bundle_id || ''); finish('sent'); return; }
      if (st === 'saved') { finish('saved'); return; }
      if (st === 'failed') { setErrMsg(d.error || d.upload_error || ''); finish('failed'); return; }
      setStatus(st); // building | uploading
      if (tries.current >= 90) { setErrMsg(''); finish('saved'); }
    } catch (e) {
      setErrMsg(e.message || ''); finish('error');
    }
  };
  const send = () => {
    stopPoll();
    tries.current = 0;
    setCode(''); setErrMsg('');
    setStatus('building');
    api('/api/support/diagnostics', { method: 'POST', body: '{}' })
      .then(() => { tick(); timer.current = setInterval(tick, 1000); })
      .catch(e => { setErrMsg(e.message || ''); setStatus('error'); });
  };
  const close = () => { stopPoll(); app.closeDiag(); };

  const labelFor = { building: tr('diag_preparing'), uploading: tr('diag_uploading') };
  const terminal = status === 'sent' || status === 'saved' || status === 'failed' || status === 'error';
  const footer =
    status === 'idle' ? <Btn variant="primary" className="block" onClick={send}>{tr('diag_send')}</Btn> :
      terminal ? <Btn variant="ghost" className="block" onClick={close}>{tr('dismiss')}</Btn> : null;

  return (
    <Modal title={tr('diag_title')} onClose={close} footer={footer}>
      <ApiChip>POST /support/diagnostics · GET …/status</ApiChip>
      <p style={{ fontSize: 13, lineHeight: 1.5, color: 'var(--fg-dim)', margin: '0 0 18px' }}>{tr('diag_desc')}</p>
      {(status === 'building' || status === 'uploading') && <div style={{ textAlign: 'center', padding: '12px 0' }}><div className="sd-spinner" /><div className="sd-micro" style={{ marginTop: 14 }}>{labelFor[status]}</div></div>}
      {status === 'sent' && (
        <div style={{ textAlign: 'center', padding: '8px 0' }}>
          <Icon name="check" size={40} color="var(--success)" />
          <div className="sd-serif" style={{ fontStyle: 'italic', fontSize: 22, margin: '10px 0 4px' }}>{tr('diag_sent')}</div>
          <div className="sd-micro">{tr('diag_code')}</div>
          <div className="sd-mono" style={{ fontSize: 26, letterSpacing: '.18em', color: 'var(--primary)', marginTop: 6 }}>{code}</div>
        </div>
      )}
      {status === 'saved' && (
        <div style={{ textAlign: 'center', padding: '8px 0' }}>
          <Icon name="check" size={40} color="var(--success)" />
          <div className="sd-serif" style={{ fontStyle: 'italic', fontSize: 22, margin: '10px 0 4px' }}>{tr('diag_sent')}</div>
          <a className="sd-btn ghost sm" style={{ marginTop: 14, display: 'inline-flex', alignItems: 'center', gap: 6 }} href="/api/support/diagnostics/latest"><Icon name="upload" size={16} style={{ transform: 'rotate(180deg)' }} /> {tr('diag_download')}</a>
        </div>
      )}
      {(status === 'failed' || status === 'error') && (
        <div style={{ textAlign: 'center', padding: '8px 0' }}>
          <Icon name="close" size={36} color="var(--destructive)" />
          {errMsg && <div className="sd-micro" style={{ margin: '10px 0', color: 'var(--fg-dim)' }}>{errMsg}</div>}
          {status === 'failed' && <a className="sd-btn ghost sm" style={{ marginTop: 8, display: 'inline-flex', alignItems: 'center', gap: 6 }} href="/api/support/diagnostics/latest"><Icon name="upload" size={16} style={{ transform: 'rotate(180deg)' }} /> {tr('diag_download')}</a>}
        </div>
      )}
    </Modal>
  );
}

Object.assign(window, { HelpModal, DiagnosticsModal });
