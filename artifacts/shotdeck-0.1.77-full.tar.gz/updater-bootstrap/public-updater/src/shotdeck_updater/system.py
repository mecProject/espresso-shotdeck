"""Command execution and service control wrappers."""

from __future__ import annotations

import subprocess
import time
import json
import ssl
import urllib.request
from dataclasses import dataclass
from typing import Protocol, Sequence

from .errors import HealthCheckError, InstallError


def _read_local_health(timeout: float) -> dict[str, object]:
    last_error: Exception | None = None
    for url, context in (
        ("http://127.0.0.1/healthz", None),
        ("https://127.0.0.1/healthz", ssl._create_unverified_context()),
    ):
        try:
            with urllib.request.urlopen(url, timeout=timeout, context=context) as response:
                return json.loads(response.read(64 * 1024).decode("utf-8"))
        except Exception as exc:
            last_error = exc
    assert last_error is not None
    raise last_error


@dataclass(slots=True)
class CommandResult:
    command: tuple[str, ...]
    returncode: int
    stdout: str
    stderr: str


class CommandRunner:
    def run(
        self,
        command: Sequence[str],
        *,
        timeout: int | None = None,
        check: bool = True,
    ) -> CommandResult:
        completed = subprocess.run(
            list(command),
            timeout=timeout,
            check=False,
            capture_output=True,
            text=True,
        )
        result = CommandResult(
            command=tuple(command),
            returncode=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )
        if check and completed.returncode != 0:
            raise InstallError(
                f"Command {' '.join(command)!r} failed with exit {completed.returncode}: {completed.stderr.strip()}"
            )
        return result


class ServiceController(Protocol):
    def stop(self) -> None:
        ...

    def start(self) -> None:
        ...

    def health_check(self, timeout_seconds: int, expected_version: str | None = None) -> None:
        ...

    def assert_brew_idle(self) -> None:
        ...


class SystemctlServiceController:
    def __init__(self, service_name: str, runner: CommandRunner | None = None) -> None:
        self.service_name = service_name
        self.runner = runner or CommandRunner()

    def stop(self) -> None:
        self.runner.run(("systemctl", "stop", self.service_name))

    def start(self) -> None:
        self.runner.run(("systemctl", "start", self.service_name))

    def assert_brew_idle(self) -> None:
        try:
            payload = _read_local_health(2)
        except Exception as exc:
            raise InstallError("Could not verify Shotdeck brew state before service stop") from exc
        if payload.get("status") != "ready" or payload.get("control_ready") is not True:
            raise InstallError("Shotdeck is not ready for a safe software activation")
        if payload.get("brew_active") is not False:
            raise InstallError("An active brew prevents software activation")

    def health_check(self, timeout_seconds: int, expected_version: str | None = None) -> None:
        deadline = time.monotonic() + timeout_seconds
        consecutive_active = 0
        while time.monotonic() < deadline:
            result = self.runner.run(
                ("systemctl", "is-active", self.service_name),
                check=False,
            )
            if result.returncode == 0 and result.stdout.strip() == "active":
                try:
                    payload = _read_local_health(1)
                    healthy = (
                        payload.get("status") == "ready"
                        and payload.get("control_ready") is True
                        and (
                            expected_version is None
                            or str(payload.get("version") or "") == expected_version
                        )
                    )
                except Exception:
                    healthy = False
                consecutive_active = consecutive_active + 1 if healthy else 0
                if consecutive_active >= 3:
                    return
            else:
                consecutive_active = 0
            time.sleep(1)
        raise HealthCheckError(f"Service {self.service_name} did not become healthy within {timeout_seconds}s")


def run_hooks(
    runner: CommandRunner,
    commands: list[list[str]],
    *,
    timeout_seconds: int | None = None,
) -> None:
    for command in commands:
        runner.run(command, timeout=timeout_seconds)
