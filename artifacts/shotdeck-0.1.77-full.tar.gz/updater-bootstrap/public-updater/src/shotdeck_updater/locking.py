"""Advisory file locking for unattended updater runs."""

from __future__ import annotations

import fcntl
import os
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from .errors import LockUnavailableError


@contextmanager
def exclusive_lock(path: Path) -> Iterator[None]:
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        # Open an existing lock without O_CREAT. Linux's
        # fs.protected_regular=2 can reject O_CREAT for a file in /run/lock
        # that was left behind under another UID, even when no write is
        # needed. flock(2) supports an exclusive lock on a read-only fd.
        descriptor = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
    except FileNotFoundError:
        try:
            descriptor = os.open(
                path,
                os.O_RDONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC,
                0o664,
            )
        except FileExistsError:
            # Another process won the creation race. Reopen without O_CREAT.
            descriptor = os.open(path, os.O_RDONLY | os.O_CLOEXEC)
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise LockUnavailableError(f"Another updater instance is already running ({path})") from exc
        try:
            yield
        finally:
            fcntl.flock(descriptor, fcntl.LOCK_UN)
    finally:
        os.close(descriptor)
