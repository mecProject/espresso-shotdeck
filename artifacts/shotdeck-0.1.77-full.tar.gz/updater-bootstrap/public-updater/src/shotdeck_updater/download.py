"""Network and checksum-safe downloading for manifests, allowlists, and artifacts."""

from __future__ import annotations

import json
import os
import urllib.request
from pathlib import Path

from . import __version__
from .errors import DownloadError
from .storage import ensure_directory, sha256_file

USER_AGENT = f"shotdeck-updater/{__version__}"
MAX_METADATA_BYTES = 10 * 1024 * 1024
MAX_ARTIFACT_BYTES = 2 * 1024 * 1024 * 1024


def fetch_bytes(url: str, *, timeout: int = 60, max_bytes: int = MAX_METADATA_BYTES) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > max_bytes:
                raise DownloadError(f"Response from {url} exceeds the {max_bytes}-byte limit")
            data = response.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise DownloadError(f"Response from {url} exceeds the {max_bytes}-byte limit")
            return data
    except Exception as exc:
        raise DownloadError(f"Failed to fetch {url}: {exc}") from exc


def fetch_json(url: str, *, timeout: int = 60) -> dict[str, object]:
    try:
        return json.loads(fetch_bytes(url, timeout=timeout).decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise DownloadError(f"Remote JSON at {url} is invalid: {exc}") from exc


def download_to_path(
    url: str,
    destination: Path,
    *,
    expected_sha256: str,
    expected_size: int | None = None,
    timeout: int = 60,
) -> Path:
    ensure_directory(destination.parent)
    if destination.exists() and sha256_file(destination) == expected_sha256:
        if expected_size is None or destination.stat().st_size == expected_size:
            return destination
    temp_path = destination.with_suffix(destination.suffix + ".part")
    if temp_path.exists():
        temp_path.unlink()

    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    byte_limit = expected_size if expected_size is not None else MAX_ARTIFACT_BYTES
    downloaded_size = 0
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response, temp_path.open("wb") as handle:
            content_length = response.headers.get("Content-Length")
            if content_length and int(content_length) > byte_limit:
                raise DownloadError(
                    f"Artifact from {url} exceeds expected size {byte_limit}"
                )
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                downloaded_size += len(chunk)
                if downloaded_size > byte_limit:
                    raise DownloadError(
                        f"Artifact from {url} exceeds expected size {byte_limit}"
                    )
                handle.write(chunk)
            handle.flush()
            os.fsync(handle.fileno())
    except Exception as exc:
        if temp_path.exists():
            temp_path.unlink(missing_ok=True)
        raise DownloadError(f"Failed to download {url}: {exc}") from exc

    if expected_size is not None and downloaded_size != expected_size:
        temp_path.unlink(missing_ok=True)
        raise DownloadError(
            f"Downloaded artifact size mismatch for {url}: expected {expected_size}, got {downloaded_size}"
        )
    actual_sha256 = sha256_file(temp_path)
    if actual_sha256 != expected_sha256:
        temp_path.unlink(missing_ok=True)
        raise DownloadError(
            f"Downloaded artifact checksum mismatch for {url}: expected {expected_sha256}, got {actual_sha256}"
        )
    os.replace(temp_path, destination)
    return destination
