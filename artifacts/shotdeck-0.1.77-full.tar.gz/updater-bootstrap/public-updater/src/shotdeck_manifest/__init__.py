"""Manifest models, signatures, and targeting rules for Shotdeck updates."""

from .errors import ManifestError, ManifestSignatureError, ManifestValidationError
from .legacy_v01 import legacy_v01_unsigned_payload, verify_legacy_v01_manifest_payload
from .models import (
    AllowlistDocument,
    AllowlistEntry,
    AllowlistRef,
    ArtifactRef,
    ManifestSignature,
    PatchArtifactRef,
    ReleaseManifest,
    RolloutRules,
    RollbackInfo,
)
from .signing import canonical_json_bytes, sign_manifest, verify_manifest, verify_manifest_payload
from .targeting import ApplicabilityDecision, DeviceContext, evaluate_targeting

__all__ = [
    "AllowlistDocument",
    "AllowlistEntry",
    "AllowlistRef",
    "ApplicabilityDecision",
    "ArtifactRef",
    "DeviceContext",
    "ManifestError",
    "ManifestSignature",
    "ManifestSignatureError",
    "ManifestValidationError",
    "PatchArtifactRef",
    "ReleaseManifest",
    "RollbackInfo",
    "RolloutRules",
    "canonical_json_bytes",
    "evaluate_targeting",
    "legacy_v01_unsigned_payload",
    "sign_manifest",
    "verify_legacy_v01_manifest_payload",
    "verify_manifest",
    "verify_manifest_payload",
]
