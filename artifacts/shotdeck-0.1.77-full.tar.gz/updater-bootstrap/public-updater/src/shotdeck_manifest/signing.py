"""Canonical JSON signing and verification for release manifests."""

from __future__ import annotations

import base64
import json
from pathlib import Path
from typing import Any, Mapping

from .errors import ManifestSignatureError, ManifestValidationError
from .models import ManifestSignature, ReleaseManifest


def canonical_json_bytes(payload: Mapping[str, Any]) -> bytes:
    """Serialize a JSON object deterministically for signing."""
    return json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    ).encode("utf-8")


def _import_crypto() -> tuple[Any, Any, Any]:
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric.ed25519 import (
            Ed25519PrivateKey,
            Ed25519PublicKey,
        )
    except ModuleNotFoundError as exc:
        raise ManifestSignatureError(
            "cryptography is required for manifest signing and verification"
        ) from exc
    return serialization, Ed25519PrivateKey, Ed25519PublicKey


def derive_key_id(public_key_pem: bytes) -> str:
    import hashlib

    digest = hashlib.sha256(public_key_pem).hexdigest()
    return digest[:16]


def sign_manifest(
    manifest: ReleaseManifest,
    private_key_pem: bytes,
    key_id: str | None = None,
) -> ReleaseManifest:
    serialization, Ed25519PrivateKey, _ = _import_crypto()
    private_key = serialization.load_pem_private_key(private_key_pem, password=None)
    if not isinstance(private_key, Ed25519PrivateKey):
        raise ManifestSignatureError("Expected an Ed25519 private key")
    public_key_pem = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    signature = private_key.sign(canonical_json_bytes(manifest.unsigned_dict()))
    manifest.signature = ManifestSignature(
        algorithm="ed25519",
        key_id=key_id or derive_key_id(public_key_pem),
        value=base64.b64encode(signature).decode("ascii"),
    )
    return manifest


def verify_manifest(manifest: ReleaseManifest, public_key_pem: bytes) -> None:
    verify_manifest_payload(manifest.to_dict(), public_key_pem)


def verify_manifest_payload(payload: Mapping[str, Any], public_key_pem: bytes) -> None:
    """Verify the exact JSON mapping received from the update host.

    Verification must happen before converting to a typed model.  Otherwise an
    older/newer client can silently discard an additive field and then verify a
    different canonical object.  This exact bug stranded updater 0.1.0 when
    the signed ``provenance`` field was introduced.
    """
    if not isinstance(payload, Mapping):
        raise ManifestValidationError("Manifest payload must be an object")
    signature_payload = payload.get("signature")
    if not isinstance(signature_payload, Mapping):
        raise ManifestSignatureError("Manifest is missing a signature")
    signature_model = ManifestSignature.from_dict(dict(signature_payload))
    serialization, _, Ed25519PublicKey = _import_crypto()
    public_key = serialization.load_pem_public_key(public_key_pem)
    if not isinstance(public_key, Ed25519PublicKey):
        raise ManifestSignatureError("Expected an Ed25519 public key")
    expected_key_id = derive_key_id(
        public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
    )
    if signature_model.key_id != expected_key_id:
        raise ManifestSignatureError(
            f"Manifest key_id {signature_model.key_id!r} does not match verification key"
        )
    try:
        signature = base64.b64decode(signature_model.value.encode("ascii"), validate=True)
    except ValueError as exc:
        raise ManifestValidationError("Manifest signature is not valid base64") from exc
    unsigned_payload = dict(payload)
    unsigned_payload.pop("signature", None)
    try:
        public_key.verify(signature, canonical_json_bytes(unsigned_payload))
    except Exception as exc:
        raise ManifestSignatureError("Manifest signature verification failed") from exc


def read_private_key(path: Path) -> bytes:
    return path.read_bytes()


def read_public_key(path: Path) -> bytes:
    return path.read_bytes()
