"""Frozen updater-0.1 manifest round-trip used by the permanent bridge gate.

Updater 0.1 verifies a manifest only after parsing it into its typed model and
serializing it again.  This module intentionally copies that exact 0.1 schema
so future additions to the current model cannot accidentally produce a bridge
that the installed legacy fleet cannot verify.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from packaging.specifiers import InvalidSpecifier, SpecifierSet
from packaging.version import InvalidVersion, Version

from .errors import ManifestValidationError
from .models import ManifestSignature
from .signing import verify_manifest_payload


def _mapping(value: Any, field_name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ManifestValidationError(f"{field_name} must be an object")
    return value


def _text(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ManifestValidationError(f"{field_name} must be a non-empty string")
    return value.strip()


def _version(value: Any, field_name: str) -> str:
    text = _text(value, field_name)
    try:
        Version(text)
    except InvalidVersion as exc:
        raise ManifestValidationError(f"{field_name} must be a valid PEP 440 version") from exc
    return text


def _integer(value: Any, field_name: str) -> int:
    if not isinstance(value, int):
        raise ManifestValidationError(f"{field_name} must be an integer")
    return value


def _sha256(value: Any, field_name: str) -> str:
    text = _text(value, field_name).lower()
    if len(text) != 64 or any(character not in "0123456789abcdef" for character in text):
        raise ManifestValidationError(f"{field_name} must be a SHA-256 digest")
    return text


def _array(value: Any, field_name: str) -> list[Any]:
    if not isinstance(value, list):
        raise ManifestValidationError(f"{field_name} must be an array")
    return value


def _slug_array(value: Any, field_name: str) -> list[str]:
    if value is None:
        return []
    return sorted({_text(item, field_name).lower() for item in _array(value, field_name)})


def _artifact(value: Any, *, patch: bool = False) -> dict[str, Any]:
    payload = _mapping(value, "artifact")
    size = _integer(payload.get("size", 0), "artifact.size")
    if size < 0:
        raise ManifestValidationError("artifact.size must be zero or greater")
    filename = _text(payload.get("filename", ""), "artifact.filename")
    if "/" in filename or filename in {".", ".."}:
        raise ManifestValidationError("artifact.filename must be a basename")
    result: dict[str, Any] = {
        "url": _text(payload.get("url", ""), "artifact.url"),
        "sha256": _sha256(payload.get("sha256", ""), "artifact.sha256"),
        "size": size,
        "filename": filename,
    }
    install_tree = payload.get("install_tree_sha256")
    if install_tree is not None:
        result["install_tree_sha256"] = _sha256(
            install_tree,
            "artifact.install_tree_sha256",
        )
    if patch:
        strategy = _text(payload.get("strategy", "tar-overlay"), "patch.strategy")
        if strategy != "tar-overlay":
            raise ManifestValidationError("Only tar-overlay patch strategy is supported")
        removed_paths: list[str] = []
        for path in _array(payload.get("removed_paths", []), "patch.removed_paths"):
            normalized = _text(path, "patch.removed_paths")
            if normalized.startswith("/") or ".." in normalized.split("/"):
                raise ManifestValidationError("patch.removed_paths contains an unsafe path")
            removed_paths.append(normalized)
        result.update(
            {
                "from_version": _version(payload.get("from_version", ""), "patch.from_version"),
                "to_version": _version(payload.get("to_version", ""), "patch.to_version"),
                "base_tree_sha256": _sha256(
                    payload.get("base_tree_sha256", ""),
                    "patch.base_tree_sha256",
                ),
                "target_tree_sha256": _sha256(
                    payload.get("target_tree_sha256", ""),
                    "patch.target_tree_sha256",
                ),
                "strategy": strategy,
                "removed_paths": sorted(set(removed_paths)),
            }
        )
    return result


def _allowlist(value: Any) -> dict[str, Any]:
    payload = _mapping(value, "rollout.allowlist")
    size = _integer(payload.get("size", 0), "rollout.allowlist.size")
    if size < 0:
        raise ManifestValidationError("rollout.allowlist.size must be zero or greater")
    return {
        "url": _text(payload.get("url", ""), "rollout.allowlist.url"),
        "sha256": _sha256(payload.get("sha256", ""), "rollout.allowlist.sha256"),
        "size": size,
    }


def _rollout(value: Any) -> dict[str, Any]:
    payload = {} if value is None else _mapping(value, "rollout")
    result: dict[str, Any] = {
        "channels": _slug_array(payload.get("channels", []), "rollout.channels"),
        "hardware_groups": _slug_array(
            payload.get("hardware_groups", []),
            "rollout.hardware_groups",
        ),
        "device_fingerprints": sorted(
            {
                _sha256(item, "rollout.device_fingerprints")
                for item in _array(
                    payload.get("device_fingerprints", []),
                    "rollout.device_fingerprints",
                )
            }
        ),
        "allowlist_tags": _slug_array(
            payload.get("allowlist_tags", []),
            "rollout.allowlist_tags",
        ),
        "allow_downgrade": bool(payload.get("allow_downgrade", False)),
    }
    current_version = payload.get("current_version")
    if current_version is not None:
        current_version = _text(current_version, "rollout.current_version")
        try:
            SpecifierSet(current_version)
        except InvalidSpecifier as exc:
            raise ManifestValidationError(
                "rollout.current_version must be a valid specifier set"
            ) from exc
        result["current_version"] = current_version
    staged = payload.get("staged_rollout_percentage")
    if staged is not None:
        staged = _integer(staged, "rollout.staged_rollout_percentage")
        if not 0 < staged <= 100:
            raise ManifestValidationError(
                "rollout.staged_rollout_percentage must be between 1 and 100"
            )
        result["staged_rollout_percentage"] = staged
    allowlist = payload.get("allowlist")
    if allowlist:
        result["allowlist"] = _allowlist(allowlist)
    return result


def _rollback(value: Any) -> dict[str, Any]:
    payload = {} if value is None else _mapping(value, "rollback")
    keep_versions = _integer(payload.get("keep_versions", 2), "rollback.keep_versions")
    timeout = _integer(
        payload.get("health_check_timeout_seconds", 20),
        "rollback.health_check_timeout_seconds",
    )
    if keep_versions < 1 or timeout < 1:
        raise ManifestValidationError("rollback retention and timeout must be positive")
    return {
        "keep_versions": keep_versions,
        "allow_manual_rollback": bool(payload.get("allow_manual_rollback", True)),
        "health_check_timeout_seconds": timeout,
    }


def legacy_v01_unsigned_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Parse and serialize exactly the fields known to updater 0.1."""
    payload = _mapping(payload, "manifest")
    patches = [
        _artifact(item, patch=True)
        for item in _array(payload.get("patch_artifacts", []), "patch_artifacts")
    ]
    version = _version(payload.get("version", ""), "version")
    for patch in patches:
        if patch["to_version"] != version:
            raise ManifestValidationError("Every patch must target the manifest version")
    schema_version = _text(payload.get("schema_version", ""), "schema_version")
    if schema_version != "1.0":
        raise ManifestValidationError("Updater 0.1 supports only schema_version 1.0")
    return {
        "schema_version": schema_version,
        "product": _text(payload.get("product", ""), "product").lower(),
        "channel": _text(payload.get("channel", ""), "channel").lower(),
        "version": version,
        "released_at": _text(payload.get("released_at", ""), "released_at"),
        "min_updater_version": _version(
            payload.get("min_updater_version", ""),
            "min_updater_version",
        ),
        "full_artifact": _artifact(payload.get("full_artifact", {})),
        "patch_artifacts": patches,
        "rollout": _rollout(payload.get("rollout")),
        "rollback": _rollback(payload.get("rollback")),
        "notes": [
            _text(item, "notes")
            for item in _array(payload.get("notes", []), "notes")
        ],
    }


def verify_legacy_v01_manifest_payload(
    payload: Mapping[str, Any],
    public_key_pem: bytes,
) -> None:
    """Verify using updater 0.1's parse-then-canonicalize behavior."""
    signature_payload = _mapping(payload.get("signature"), "signature")
    signature = ManifestSignature.from_dict(dict(signature_payload))
    round_tripped = legacy_v01_unsigned_payload(payload)
    round_tripped["signature"] = signature.to_dict()
    verify_manifest_payload(round_tripped, public_key_pem)
