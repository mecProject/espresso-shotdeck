#!/usr/bin/env python3
"""Bridge between the updater CLI and Shotdeck's file-based update prompt UI."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
import os
import subprocess
import sys
from pathlib import Path


DEFAULT_CONFIG_PATH = Path("/etc/shotdeck/updater.json")
CURRENT_UPDATER_BIN = Path("/opt/shotdeck/updater-current/bin/shotdeck-updater")
LEGACY_UPDATER_BIN = Path("/opt/shotdeck/updater-venv/bin/shotdeck-updater")
UPDATER_BIN = CURRENT_UPDATER_BIN if CURRENT_UPDATER_BIN.is_file() else LEGACY_UPDATER_BIN
DATA_ROOT = Path(os.environ.get("SHOTDECK_DATA_DIR", "/var/lib/shotdeck"))
STATUS_PATH = Path(os.environ.get("SHOTDECK_UPDATE_STATUS_FILE", str(DATA_ROOT / "update-status.json")))
RESPONSE_PATH = Path(os.environ.get("SHOTDECK_UPDATE_RESPONSE_FILE", str(DATA_ROOT / "update-response.json")))
WEB_STATE_PATH = Path(os.environ.get("SHOTDECK_UPDATE_WEB_STATE_FILE", str(DATA_ROOT / "update-web-state.json")))


def _load_json(path: Path) -> dict[str, object] | None:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None
    except json.JSONDecodeError:
        return None
    return payload if isinstance(payload, dict) else None


def _write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        temp_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(temp_path, path)
    finally:
        try:
            temp_path.unlink()
        except FileNotFoundError:
            pass


def _update_web_state(**changes: object) -> None:
    payload = _load_json(WEB_STATE_PATH) or {}
    payload.update(changes)
    payload["updated_at"] = datetime.now(timezone.utc).isoformat()
    _write_json(WEB_STATE_PATH, payload)


def _remove_if_exists(path: Path) -> None:
    try:
        path.unlink()
    except FileNotFoundError:
        return


def clear_prompt_files() -> None:
    _remove_if_exists(STATUS_PATH)
    _remove_if_exists(RESPONSE_PATH)


def _run_updater(
    config_path: Path,
    command: str,
    *,
    expected_version: str = "",
    expected_artifact_sha256: str = "",
    expected_manifest_sha256: str = "",
) -> dict[str, object]:
    command_args = [str(UPDATER_BIN), "--config", str(config_path), command]
    if command == "apply":
        command_args.extend(
            [
                "--expected-version", expected_version,
                "--expected-artifact-sha256", expected_artifact_sha256,
                "--expected-manifest-sha256", expected_manifest_sha256,
            ]
        )
    completed = subprocess.run(
        command_args,
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        stderr = completed.stderr.strip()
        raise SystemExit(stderr or f"shotdeck-updater {command} failed with exit {completed.returncode}")
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"shotdeck-updater {command} returned invalid JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise SystemExit(f"shotdeck-updater {command} returned an unexpected JSON value")
    return payload


def _status_payload_from_check(check_payload: dict[str, object]) -> dict[str, object] | None:
    if not bool(check_payload.get("applicable")):
        return None
    version = str(check_payload.get("manifest_version") or "").strip()
    channel = str(check_payload.get("channel") or "stable").strip().lower()
    artifact_sha256 = str(check_payload.get("artifact_sha256") or "").strip().lower()
    manifest_sha256 = str(check_payload.get("manifest_sha256") or "").strip().lower()
    if (
        not version
        or len(artifact_sha256) != 64
        or len(manifest_sha256) != 64
    ):
        return None
    key = f"{channel}:{version}:{artifact_sha256}:{manifest_sha256}"
    return {
        "update_available": True,
        "target_version": version,
        "channel": channel,
        "summary": f"Update {version} available. Install now?",
        "key": key,
        "artifact_sha256": artifact_sha256,
        "manifest_sha256": manifest_sha256,
    }


def command_check(config_path: Path) -> int:
    check_payload = _run_updater(config_path, "check")
    status_payload = _status_payload_from_check(check_payload)
    checked_at = datetime.now(timezone.utc).isoformat()
    if status_payload is None:
        clear_prompt_files()
        reason = str(check_payload.get("reason") or "").strip()
        up_to_date = "already runs this version" in reason.lower()
        _update_web_state(
            state="up_to_date" if up_to_date else "unavailable",
            target_version=str(check_payload.get("manifest_version") or ""),
            channel=str(check_payload.get("channel") or "stable"),
            message="Software is up to date." if up_to_date else "No update is available for this device.",
            checked_at=checked_at,
            busy=False,
            update_available=False,
            error="",
        )
        return 0
    prior_status = _load_json(STATUS_PATH)
    _write_json(STATUS_PATH, status_payload)
    status_key = str(status_payload["key"])
    if prior_status is not None and str(prior_status.get("key") or "") != status_key:
        _remove_if_exists(RESPONSE_PATH)
    _update_web_state(
        state="available",
        target_version=str(status_payload["target_version"]),
        channel=str(status_payload["channel"]),
        message=f"Version {status_payload['target_version']} is available.",
        checked_at=checked_at,
        busy=False,
        update_available=True,
        error="",
    )
    return 0


def command_process_response(config_path: Path) -> int:
    status_payload = _load_json(STATUS_PATH)
    response_payload = _load_json(RESPONSE_PATH)
    if not status_payload or not response_payload:
        return 0

    status_key = str(status_payload.get("key") or "").strip()
    response_key = str(response_payload.get("key") or "").strip()
    if not status_key or response_key != status_key:
        _remove_if_exists(RESPONSE_PATH)
        return 0

    action = str(response_payload.get("action") or "").strip().lower()
    if action == "skip":
        target_version = str(status_payload.get("target_version") or "").strip()
        clear_prompt_files()
        _update_web_state(
            state="unavailable",
            target_version=target_version,
            channel=str(status_payload.get("channel") or "stable"),
            message=f"Update {target_version} was skipped.",
            busy=False,
            update_available=False,
            error="",
        )
        return 0
    if action != "install":
        _remove_if_exists(RESPONSE_PATH)
        return 0

    _remove_if_exists(RESPONSE_PATH)
    target_version = str(status_payload.get("target_version") or "").strip()
    _update_web_state(
        state="installing",
        target_version=target_version,
        channel=str(status_payload.get("channel") or "stable"),
        message=f"Installing version {target_version}. The page may disconnect while Shotdeck restarts.",
        busy=True,
        update_available=False,
        error="",
        started_at=datetime.now(timezone.utc).isoformat(),
    )
    try:
        _run_updater(
            config_path,
            "apply",
            expected_version=target_version,
            expected_artifact_sha256=str(status_payload.get("artifact_sha256") or ""),
            expected_manifest_sha256=str(status_payload.get("manifest_sha256") or ""),
        )
    except SystemExit:
        _update_web_state(
            state="error",
            message="The update failed and Shotdeck kept the previous version.",
            busy=False,
            error="The updater service failed. Check diagnostics for details.",
            update_available=True,
        )
        raise
    _remove_if_exists(STATUS_PATH)
    _update_web_state(
        state="installed",
        current_version=target_version,
        target_version=target_version,
        message=f"Updated to version {target_version}.",
        busy=False,
        update_available=False,
        error="",
        completed_at=datetime.now(timezone.utc).isoformat(),
    )
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG_PATH)
    parser.add_argument("command", choices=("check", "process-response", "clear"))
    args = parser.parse_args(argv)

    if args.command == "clear":
        clear_prompt_files()
        return 0
    if args.command == "check":
        return command_check(args.config)
    return command_process_response(args.config)


if __name__ == "__main__":
    raise SystemExit(main())
