#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_ROOT="/opt/shotdeck"
CONFIG_ROOT="/etc/shotdeck"
RUNTIMES_ROOT="$INSTALL_ROOT/updater-runtimes"
CURRENT_RUNTIME_LINK="$INSTALL_ROOT/updater-current"
DATA_ROOT="/var/lib/shotdeck"
UPDATER_STATE_ROOT="$DATA_ROOT/updater"
PUBLIC_KEY_SRC="${1:-}"
WORKER_UNITS=(
    shotdeck-update-control.slice
    shotdeck-update-coordinator.slice
    shotdeck-update-check.slice
    shotdeck-update-queue.service
    shotdeck-update-queue.path
    shotdeck-update-queue.timer
    shotdeck-update-check@.service
    shotdeck-update-apply@.service
    shotdeck-update-wake@.service
    shotdeck-update-retry.timer
    shotdeck-update-control.service
    shotdeck-update-control.path
)
ENABLED_WORKER_UNITS=(shotdeck-update-queue.path shotdeck-update-queue.timer shotdeck-update-control.path)
RECOVERY_UNITS=(shotdeck-recovery-boot.service shotdeck-recovery-failure.service
    shotdeck-recovery-watchdog.service shotdeck-recovery-watchdog.timer
    shotdeck-recovery.socket shotdeck-recovery.service shotdeck-recovery-gateway.socket
    shotdeck-recovery-gateway.service shotdeck-recovery-portal.slice shotdeck-recovery-screen.service
    shotdeck-recovery-screen.slice shotdeck-recovery-network-restore.service
    shotdeck-recovery-maintenance.service shotdeck-recovery-maintenance.timer
    shotdeck-recovery-status.service shotdeck-recovery-status.timer shotdeck-recovery-access-boot.service
    shotdeck-recovery-operation@.service shotdeck-recovery-read@.service
    shotdeck.service.d/50-shotdeck-recovery.conf)
SEED_UNITS=(shotdeck-recovery-seed-install.service shotdeck-recovery-seed-install.timer)

info()  { echo "[INFO]  $*"; }
warn()  { echo "[WARN]  $*" >&2; }
die()   { echo "[ERROR] $*" >&2; exit 1; }

[[ ! -e "$DATA_ROOT/signing/updates" && ! -L "$DATA_ROOT/signing/updates" ]] \
    || die "Signing migration owns updater trust; use generation-aware recovery instead of the legacy installer."

install_if_needed() {
    local mode="$1"
    local src="$2"
    local dest="$3"

    if [[ -e "$dest" ]] && cmp -s "$src" "$dest"; then
        chmod "$mode" "$dest"
        return 0
    fi

    install -m "$mode" "$src" "$dest"
}

create_lock_file_if_missing() {
    local path="$1"
    [[ -e "$path" ]] && return 0
    # noclobber makes this an atomic create-only operation. If another process
    # wins the race, the now-existing file is exactly what we need.
    if ! (umask 0002; set -o noclobber; : >"$path") 2>/dev/null; then
        [[ -e "$path" ]] || die "Could not create updater lock file at $path."
    fi
}

newer_runtime_is_healthy() {
    local runtime="$1"
    local bundled_version="$2"
    local rev15_required="$3"
    [[ -x "$runtime/bin/python" && -x "$runtime/bin/shotdeck-updater" ]] || return 1
    # A failed probe means repair is needed, not that the candidate installer
    # should abort. Only a newer, working runtime may prevent replacement.
    "$runtime/bin/python" -I - "$bundled_version" "$rev15_required" <<'PYCODE' >/dev/null 2>&1 || return 1
import sys
from importlib.metadata import version
from packaging.version import Version
from shotdeck_updater import __version__
if Version(__version__) <= Version(sys.argv[1]):
    raise SystemExit(1)
if Version(version("cryptography")) < Version("42.0.0") or Version(version("packaging")) < Version("23.2"):
    raise SystemExit(1)
if sys.argv[2] == "1":
    from shotdeck_updater.hardware import HARDWARE_GUARD_VERSION, installed_profile, assert_hardware_compatible
    if (type(HARDWARE_GUARD_VERSION) is not int or HARDWARE_GUARD_VERSION != 1
            or Version(__version__) < Version("0.2.3")
            or not callable(installed_profile) or not callable(assert_hardware_compatible)):
        raise SystemExit(1)
PYCODE
    PYTHONPATH= PYTHONNOUSERSITE=1 "$runtime/bin/shotdeck-updater" --help >/dev/null 2>&1
}

# Let the regression test load the idempotent file helper without executing
# this privileged installer. Normal execution and ordinary shell sourcing are
# unchanged.
if [[ "${SHOTDECK_INSTALL_UPDATER_SOURCE_ONLY:-0}" == "1" && "${BASH_SOURCE[0]}" != "$0" ]]; then
    return 0
fi

[[ $EUID -eq 0 ]] || die "Run this installer as root."
command -v python3 >/dev/null || die "python3 is required."
[[ -n "$PUBLIC_KEY_SRC" ]] || die "Path to the production updater public key is required."
[[ -f "$PUBLIC_KEY_SRC" ]] || die "Updater public key not found at $PUBLIC_KEY_SRC."

# Resolve physical identity with this independent updater before any mutation.
# REV15 must retain a runtime that can enforce its persistent startup guard.
REV15_REQUIRED="$(PYTHONPATH="$REPO_ROOT/src" python3 - <<'PYCODE'
from shotdeck_updater.hardware import installed_profile, REV15_ID, HARDWARE_GUARD_VERSION
from shotdeck_updater import __version__
profile, _ = installed_profile()
if profile == REV15_ID:
    if HARDWARE_GUARD_VERSION != 1 or tuple(map(int, __version__.split('.'))) < (0, 2, 3):
        raise SystemExit("REV15 requires the protected hardware-aware updater")
    print("1")
else:
    print("0")
PYCODE
)"

info "Installing system dependencies…"
required_packages=(
    python3 python3-venv python3-setuptools python3-wheel
    python3-cryptography python3-packaging
)
missing_packages=()
for package in "${required_packages[@]}"; do
    dpkg -s "$package" >/dev/null 2>&1 || missing_packages+=("$package")
done

if (( ${#missing_packages[@]} == 0 )); then
    info "System dependencies already installed; skipping apt-get."
else
    available_kb="$(df -Pk /var | awk 'NR==2 {print $4}')"
    if [[ -n "$available_kb" ]] && (( available_kb < 131072 )); then
        warn "Low free space under /var before apt; cleaning package caches."
        apt-get clean || true
        rm -rf /var/lib/apt/lists/* || true
        available_kb="$(df -Pk /var | awk 'NR==2 {print $4}')"
    fi
    if [[ -n "$available_kb" ]] && (( available_kb < 131072 )); then
        die "Not enough free space under /var for apt operations (${available_kb} KB available)."
    fi
    apt-get update -q
    apt-get install -y "${missing_packages[@]}"
fi

info "Preparing directories…"
mkdir -p "$INSTALL_ROOT" "$RUNTIMES_ROOT" "$CONFIG_ROOT" /var/log/shotdeck "$DATA_ROOT" "$DATA_ROOT/web" "$UPDATER_STATE_ROOT"
mkdir -p "$INSTALL_ROOT/public-updater-installer/scripts"

UPDATER_VERSION="$(PYTHONPATH="$REPO_ROOT/src" python3 -c 'from shotdeck_updater import __version__; print(__version__)')"
[[ "$UPDATER_VERSION" =~ ^[0-9]+([.][0-9]+)*$ ]] \
    || die "Bundled updater version is invalid: $UPDATER_VERSION"
SOURCE_DIGEST="$(python3 - "$REPO_ROOT" <<'PY'
import hashlib
import sys
from pathlib import Path

root = Path(sys.argv[1])
digest = hashlib.sha256()
for path in sorted(root.rglob("*")):
    if not path.is_file() or path.is_symlink():
        continue
    relative_path = path.relative_to(root)
    if (
        any(part in {"__pycache__", ".pytest_cache", "build"} for part in relative_path.parts)
        or path.suffix == ".pyc"
        or path.name == ".DS_Store"
    ):
        continue
    relative = relative_path.as_posix().encode("utf-8")
    data = path.read_bytes()
    digest.update(len(relative).to_bytes(4, "big"))
    digest.update(relative)
    digest.update(len(data).to_bytes(8, "big"))
    digest.update(data)
print(digest.hexdigest())
PY
)"
RUNTIME_PATH="$RUNTIMES_ROOT/$UPDATER_VERSION-${SOURCE_DIGEST:0:12}"
RUNTIME_LINK_TEMP="$INSTALL_ROOT/.updater-current.$$"
RUNTIME_INCOMPLETE=0
RUNTIME_LINK_SWITCHED=0
PREVIOUS_RUNTIME_TARGET=""
cleanup_staging() {
    if [[ "$RUNTIME_INCOMPLETE" == "1" ]]; then
        rm -rf "$RUNTIME_PATH"
    fi
    if [[ "$RUNTIME_LINK_SWITCHED" == "1" ]]; then
        rm -f "$RUNTIME_LINK_TEMP"
        if [[ -n "$PREVIOUS_RUNTIME_TARGET" ]]; then
            ln -s "$PREVIOUS_RUNTIME_TARGET" "$RUNTIME_LINK_TEMP"
            mv -Tf "$RUNTIME_LINK_TEMP" "$CURRENT_RUNTIME_LINK"
        else
            rm -f "$CURRENT_RUNTIME_LINK"
        fi
    fi
    rm -f "$RUNTIME_LINK_TEMP"
}
trap cleanup_staging EXIT HUP INT TERM

runtime_is_valid() {
    local runtime="$1"
    [[ -x "$runtime/bin/python" && -x "$runtime/bin/shotdeck-updater" ]] || return 1
    "$runtime/bin/python" -c \
        "from importlib.metadata import version; from packaging.version import Version; from shotdeck_updater import __version__; assert __version__ == '$UPDATER_VERSION'; assert Version(version('cryptography')) >= Version('42.0.0'); assert Version(version('packaging')) >= Version('23.2')" \
        >/dev/null 2>&1 || return 1
    if [[ "$REV15_REQUIRED" == "1" ]]; then
        "$runtime/bin/python" -c 'from shotdeck_updater.hardware import HARDWARE_GUARD_VERSION; assert HARDWARE_GUARD_VERSION == 1' \
            >/dev/null 2>&1 || return 1
    fi
    "$runtime/bin/shotdeck-updater" --help >/dev/null 2>&1
}

# Serialize runtime construction and every mutable updater/config/unit
# operation with scheduled checks. The versioned path is inactive until the
# final symlink swap, but the lock also prevents concurrent provisioners.
install -d -m 0775 /run/lock
UPDATER_LOCK_PATH=/run/lock/shotdeck-updater.lock
create_lock_file_if_missing "$UPDATER_LOCK_PATH"
# Opening an existing lock without O_CREAT avoids Trixie's protected_regular
# rejection if an old diagnostic created it under another UID.
exec 9<"$UPDATER_LOCK_PATH"
flock 9
# Capture rollback state only after serialization. Otherwise a second
# installer could advance updater-current while this process waits, and a
# later smoke-test failure could roll back past that successful installation.
PREVIOUS_RUNTIME_TARGET="$(readlink "$CURRENT_RUNTIME_LINK" 2>/dev/null || true)"

# An application/recovery bundle must not roll the independent updater back.
# Check after acquiring the lock so concurrent installers cannot race selection.
if newer_runtime_is_healthy "$CURRENT_RUNTIME_LINK" "$UPDATER_VERSION" "$REV15_REQUIRED"; then
    info "Preserving the newer installed updater and its support files."
    exit 0
fi

if runtime_is_valid "$RUNTIME_PATH"; then
    info "Verified updater runtime already exists at $RUNTIME_PATH."
else
    info "Building inactive updater runtime $UPDATER_VERSION without network package downloads…"
    active_target="$(readlink -f "$CURRENT_RUNTIME_LINK" 2>/dev/null || true)"
    [[ "$active_target" != "$RUNTIME_PATH" ]] \
        || die "Refusing to rebuild the active updater runtime in place: $RUNTIME_PATH"
    rm -rf "$RUNTIME_PATH"
    RUNTIME_INCOMPLETE=1
    # Build at the final content-addressed path so venv metadata and console
    # script shebangs never refer to a renamed directory.
    python3 -m venv --system-site-packages "$RUNTIME_PATH"
    "$RUNTIME_PATH/bin/python" -m pip install \
        --no-deps --no-build-isolation "$REPO_ROOT"
    runtime_is_valid "$RUNTIME_PATH" \
        || die "Candidate updater runtime failed its import/CLI smoke test."
    RUNTIME_INCOMPLETE=0
fi

info "Installing update verification key…"
install_if_needed 0644 "$PUBLIC_KEY_SRC" "$CONFIG_ROOT/update-signing-key.pem"

if [[ ! -f "$CONFIG_ROOT/updater.json" ]]; then
    info "Installing example updater config…"
    install -m 0644 "$REPO_ROOT/examples/config/updater.example.json" "$CONFIG_ROOT/updater.json"
fi

info "Installing systemd units…"
# Full-app-owned selector/account/seed enrollment must precede the app drop-in.
# C sockets remain stopped until authenticated seed enrollment completes.
systemd-sysusers "$REPO_ROOT/systemd/shotdeck-recovery.sysusers"
install_if_needed 0755 "$REPO_ROOT/scripts/shotdeck_seed_gate.py" "$INSTALL_ROOT/public-updater-installer/scripts/shotdeck_seed_gate.py"
for seed_unit in "${SEED_UNITS[@]}"; do
    install_if_needed 0644 "$REPO_ROOT/systemd/$seed_unit" "/etc/systemd/system/$seed_unit"
done
install -m 0644 "$REPO_ROOT/systemd/shotdeck.service" /etc/systemd/system/shotdeck.service
install -m 0644 "$REPO_ROOT/systemd/shotdeck-updater.service" /etc/systemd/system/shotdeck-updater.service
install -m 0644 "$REPO_ROOT/systemd/shotdeck-updater-boot.timer" /etc/systemd/system/shotdeck-updater-boot.timer
install -m 0644 "$REPO_ROOT/systemd/shotdeck-updater.timer" /etc/systemd/system/shotdeck-updater.timer
install -m 0644 "$REPO_ROOT/systemd/shotdeck-update-response.service" /etc/systemd/system/shotdeck-update-response.service
install -m 0644 "$REPO_ROOT/systemd/shotdeck-update-response.path" /etc/systemd/system/shotdeck-update-response.path
install_if_needed 0755 "$REPO_ROOT/scripts/check_update_connectivity.py" "$INSTALL_ROOT/public-updater-installer/scripts/check_update_connectivity.py"
install_if_needed 0755 "$REPO_ROOT/scripts/prompted_update_flow.py" "$INSTALL_ROOT/public-updater-installer/scripts/prompted_update_flow.py"
install_if_needed 0755 "$REPO_ROOT/scripts/run_configured_updater.sh" "$INSTALL_ROOT/public-updater-installer/scripts/run_configured_updater.sh"
# Fixed dispatch gate and independent update worker units. The gate routes the
# timer and response units; without an enabled worker it uses the launchers above.
install_if_needed 0755 "$REPO_ROOT/scripts/shotdeck_update_gate.py" "$INSTALL_ROOT/public-updater-installer/scripts/shotdeck_update_gate.py"
install_if_needed 0755 "$REPO_ROOT/scripts/shotdeck_recovery_gate.py" "$INSTALL_ROOT/public-updater-installer/scripts/shotdeck_recovery_gate.py"
install -d -m 0755 /etc/systemd/system/shotdeck.service.d
for recovery_unit in "${RECOVERY_UNITS[@]}"; do
    install_if_needed 0644 "$REPO_ROOT/systemd/$recovery_unit" "/etc/systemd/system/$recovery_unit"
done
for worker_unit in "${WORKER_UNITS[@]}"; do
    install_if_needed 0644 "$REPO_ROOT/systemd/$worker_unit" "/etc/systemd/system/$worker_unit"
done
systemctl daemon-reload
systemctl enable shotdeck.service

ln -s "$RUNTIME_PATH" "$RUNTIME_LINK_TEMP"
mv -Tf "$RUNTIME_LINK_TEMP" "$CURRENT_RUNTIME_LINK"
RUNTIME_LINK_SWITCHED=1
runtime_is_valid "$CURRENT_RUNTIME_LINK" \
    || die "Activated updater runtime failed its final smoke test."
RUNTIME_LINK_SWITCHED=0
if [[ "${SHOTDECK_DEFER_START:-0}" == "1" ]]; then
    systemctl enable shotdeck-updater-boot.timer shotdeck-updater.timer shotdeck-update-response.path \
        "${ENABLED_WORKER_UNITS[@]}" shotdeck-recovery-watchdog.timer shotdeck-recovery-seed-install.timer
else
    systemctl enable --now shotdeck-updater-boot.timer shotdeck-updater.timer shotdeck-update-response.path \
        "${ENABLED_WORKER_UNITS[@]}" shotdeck-recovery-watchdog.timer shotdeck-recovery-seed-install.timer
fi
trap - EXIT HUP INT TERM
cleanup_staging

# Install, probe and enable the independent update worker generation. Failure
# leaves the retained launchers in use; the application bootstrap retries.
GATE="$INSTALL_ROOT/public-updater-installer/scripts/shotdeck_update_gate.py"
# A fresh installation is not yet signing-migrated, so the gate normally keeps
# the retained path (status 78) until a qualified, migrated state is reached.
worker_status=0
if /usr/bin/python3 -I "$GATE" install-generation --source "$REPO_ROOT/src/shotdeck_recovery"; then
    /usr/bin/python3 -I "$GATE" activate || worker_status=$?
else
    worker_status=1
fi
case "$worker_status" in
    0) info "Independent update worker enabled." ;;
    78) info "Independent update worker installed; this device is not qualified for it yet, so the retained update path remains in use." ;;
    *) warn "Independent update worker not enabled; the retained update path remains in use." ;;
esac

echo ""
echo "Shotdeck updater installed."
echo "Runtime: $RUNTIME_PATH"
echo "Edit $CONFIG_ROOT/updater.json and then run:"
echo "  sudo systemctl start shotdeck-updater.service"
