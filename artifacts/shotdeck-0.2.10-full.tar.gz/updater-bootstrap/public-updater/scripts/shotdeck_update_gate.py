#!/usr/bin/env python3
"""Fixed dispatch gate for Shotdeck update work (Release A).

This small launcher lives outside the replaceable worker generation and uses
only the standard library, so it keeps working when that generation is broken.
It owns one root-protected, versioned mode record:

* ``worker``    – requests go to the durable queue and per-job executors;
* ``suspended`` – no new admission; queued evidence is preserved;
* ``legacy``    – the retained, reviewed launcher handles updates directly.

The gate checks the mode at service admission and before every executor
launch. It never signals or stops an executor, never imposes an activation
deadline and switches to ``legacy`` only after execution ownership is released
and no uncertain activation remains. Repeated worker crashes latch suspension;
elapsed time never clears that latch. This contains faults; it is not
protection from an arbitrary process already running as root.

A missing mode record means the worker was never enabled: use the retained
launcher, exactly as before this gate existed.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
import errno
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time

STATE_ROOT = Path("/var/lib/shotdeck/updater")
DISPATCH_ROOT = STATE_ROOT / "dispatch"
JOBS_ROOT = STATE_ROOT / "jobs"
SUPPORT_RECEIPT = STATE_ROOT / "support-generation.json"
INSTALL_ROOT = Path("/opt/shotdeck")
SCRIPTS_ROOT = INSTALL_ROOT / "public-updater-installer/scripts"
DATA_ROOT = Path("/var/lib/shotdeck")
SYSTEMD_ROOT = Path("/etc/systemd/system")
CONFIG_PATH = Path("/etc/shotdeck/updater.json")
CGROUP_ROOT = Path("/sys/fs/cgroup")
PROC_ROOT = Path("/proc")
DEVICE_MODEL = Path("/proc/device-tree/model")
OS_RELEASE = Path("/etc/os-release")
# Root-owned, expiring local override for producing qualification evidence on
# an owner-designated workshop unit. It waives only the qualified-profile list;
# memory/PSI, migration, rollback and routing requirements always apply.
WORKSHOP_OVERRIDE = Path("/etc/shotdeck/update-worker-workshop.json")
MAX_OVERRIDE_DAYS = 30
# First app release whose migrated bootstrap honours the support revision
# guard (0.2.8, source ccd9df57). A device that can roll back to an older app
# could have the gate-routed units overwritten by that app's bootstrap.
MIN_ROLLBACK_GUARDED_VERSION = (0, 2, 8)
# Device profiles whose record passes scripts/check_update_worker_qualification.py
# for the listed worker revision. Tests keep
# every entry backed by a passing record.
RELEASE_A_QUALIFIED_PROFILES: tuple[dict, ...] = (
    {"board": "Raspberry Pi Zero 2 W Rev 1.0", "os_codename": "trixie", "worker_revision": 3},
)
# Owner decision, 15 November 2026: enable Pi 4 and Pi 5 without separate
# hardware qualification. Keep this distinct from measured qualification.
# Runtime resource, migration and rollback checks below remain mandatory.
RELEASE_A_OWNER_ACCEPTED_PROFILES: tuple[dict, ...] = (
    {"board_family": "Raspberry Pi 4 Model B", "os_codename": "trixie", "worker_revision": 3},
    {"board_family": "Raspberry Pi 5 Model B", "os_codename": "trixie", "worker_revision": 3},
)
# Support revision 8 adds a different service lifecycle. Release A's immutable
# measurements and owner decision remain historical evidence; they do not
# qualify this candidate. Only an expiring workshop override may run it until
# a new record is selected and the corresponding profiles are enabled.
QUALIFICATION_STAGE = "workshop_pending"
QUALIFIED_PROFILES: tuple[dict, ...] = ()
OWNER_ACCEPTED_PROFILES: tuple[dict, ...] = ()
REQUIRED_UNITS = (
    "shotdeck-update-queue.path",
    "shotdeck-update-queue.service",
    "shotdeck-update-check@.service",
    "shotdeck-update-apply@.service",
    "shotdeck-update-control.path",
    "shotdeck-update-control.service",
    "shotdeck-update-control.slice",
    "shotdeck-update-coordinator.slice",
    "shotdeck-update-check.slice",
    "shotdeck-update-wake@.service",
    "shotdeck-update-retry.timer",
)
MODES = ("worker", "suspended", "legacy")
FAULT_REASONS = frozenset({"worker_crash", "corrupt_queue", "generation_invalid", "probe_failed", "corrupt_mode"})
FAILURE_BUDGET = 3
CONTROL_ACTIONS = ("suspend", "resume", "legacy", "acknowledge")
CONTROL_SOURCES = ("touch", "web", "operator")
EXIT_REFUSED = 75
EXIT_GENERATION_INVALID = 76
EXIT_NOT_QUALIFIED = 78
EXIT_CORRUPT_QUEUE = 3
# Exits of the gate itself (before handing over to the worker): already
# accounted, never a worker crash.
GATE_EXITS = frozenset({64, EXIT_REFUSED, EXIT_GENERATION_INVALID, EXIT_NOT_QUALIFIED})
# Automatic legacy choices that activation may undo once the device is ready.
AUTOMATIC_REASONS = frozenset({"probe_failed", "unqualified", "legacy_selected"})
MAX_GENERATION_FILES = 40
MAX_GENERATION_FILE_BYTES = 256 * 1024
MAX_GENERATION_BYTES = 1024 * 1024
KEEP_REVISION_HISTORY = 16
KEEP_HELD = 16

_JOB_ID = re.compile(r"^[0-9a-f]{32}$")
_GENERATION_NAME = re.compile(r"^(\d{1,6})-([0-9a-f]{12})$")
_MODULE_FILE = re.compile(r"^[a-z_][a-z0-9_]{0,63}\.py$")
_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)


class GateError(RuntimeError):
    pass


# -- paths derived from (test-overridable) roots ------------------------------
def mode_file() -> Path:
    return DISPATCH_ROOT / "mode.json"


def capability_file() -> Path:
    return DISPATCH_ROOT / "capability.json"


def releases_root() -> Path:
    return INSTALL_ROOT / "support-releases"


def current_link() -> Path:
    return INSTALL_ROOT / "support-current"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def log(message: str) -> None:
    print(f"shotdeck-update-gate: {message}", file=sys.stderr)


# -- protected file primitives ----------------------------------------------
def _fsync_dir(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _protected_dir(path: Path, mode: int = 0o700) -> Path:
    if path.is_symlink():
        raise GateError(f"{path} must not be a symlink")
    if not path.exists():
        if not path.parent.exists():
            _protected_dir(path.parent, mode)
        try:
            path.mkdir(mode=mode)
            _fsync_dir(path.parent)
        except FileExistsError:
            pass
    info = os.lstat(path)
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022:
        raise GateError(f"{path} must be a protected directory")
    return path


def _read(path: Path, limit: int = 65536) -> bytes:
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | _NOFOLLOW)
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022
                or info.st_size > limit):
            raise GateError(f"{path.name} is not a protected bounded file")
        data = os.read(fd, limit + 1)
        if len(data) > limit:
            raise GateError(f"{path.name} exceeds its size limit")
        return data
    except OSError as exc:
        if exc.errno == errno.ELOOP:
            raise GateError(f"{path.name} must not be a symlink") from exc
        raise
    finally:
        os.close(fd)


def _read_json(path: Path, limit: int = 65536) -> dict:
    try:
        value = json.loads(_read(path, limit))
    except (UnicodeError, ValueError) as exc:
        raise GateError(f"{path.name} is corrupt") from exc
    if not isinstance(value, dict):
        raise GateError(f"{path.name} must be an object")
    return value


def _write_json(path: Path, value: dict, mode: int = 0o600) -> None:
    _protected_dir(path.parent)
    if path.is_symlink():
        raise GateError(f"{path.name} must not be a symlink")
    temporary = path.with_name(f".{path.name}.{os.getpid()}.{time.monotonic_ns()}.tmp")
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | _NOFOLLOW, mode)
    try:
        os.fchmod(fd, mode)
        os.write(fd, json.dumps(value, sort_keys=True, separators=(",", ":")).encode() + b"\n")
        os.fsync(fd)
    finally:
        os.close(fd)
    try:
        os.replace(temporary, path)
        _fsync_dir(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


@contextmanager
def _lock(path: Path, timeout: float = 60.0):
    _protected_dir(path.parent)
    try:
        fd = os.open(path, os.O_RDONLY | _NOFOLLOW)
    except FileNotFoundError:
        fd = os.open(path, os.O_RDONLY | os.O_CREAT | _NOFOLLOW, 0o600)
    try:
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise GateError(f"{path.name} remained locked")
                time.sleep(0.05)
        yield
    finally:
        os.close(fd)


def _lock_held(path: Path) -> bool:
    """True when another process holds ``path`` (an executor's lifetime lock)."""
    try:
        fd = os.open(path, os.O_RDONLY | _NOFOLLOW)
    except OSError:
        return False
    try:
        fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
    except BlockingIOError:
        return True
    finally:
        os.close(fd)
    return False


def _move_aside(source: Path, folder: Path, prefix: str) -> None:
    _protected_dir(folder)
    stamp = now().replace(":", "").replace("+", "Z")
    name = source.name if re.fullmatch(r"[A-Za-z0-9._-]{1,96}", source.name) else "entry"
    target = folder / f"{prefix}{stamp}-{os.getpid()}-{name}"
    if os.path.lexists(target):
        target = folder / f"{prefix}{stamp}-{os.getpid()}-{time.monotonic_ns()}"
    os.rename(source, target)
    _fsync_dir(folder)
    _fsync_dir(source.parent)
    entries = sorted(os.listdir(folder))
    for stale in entries[:-KEEP_HELD] if len(entries) > KEEP_HELD else []:
        path = folder / stale
        if path.is_dir() and not path.is_symlink():
            shutil.rmtree(path, ignore_errors=True)
        else:
            path.unlink(missing_ok=True)


# -- mode record -------------------------------------------------------------
def default_mode() -> dict:
    return {"schema_version": 1, "mode": "legacy", "reason": "not_enabled", "source": "default",
            "changed_at": "", "latched": False, "failures": 0, "pending": "",
            "latched_generation": "", "last_control": None}


def read_mode() -> dict:
    try:
        record = _read_json(mode_file(), 16384)
    except FileNotFoundError:
        return default_mode()
    except (GateError, OSError):
        # Fail closed: an unreadable record must not resume or bypass anything.
        return {**default_mode(), "mode": "suspended", "reason": "corrupt_mode", "latched": True}
    if record.get("schema_version") != 1 or record.get("mode") not in MODES:
        return {**default_mode(), "mode": "suspended", "reason": "corrupt_mode", "latched": True}
    return {**default_mode(), **record}


def mode_recorded() -> bool:
    return mode_file().exists() or mode_file().is_symlink()


def write_mode(record: dict, *, mode: str | None = None, reason: str | None = None,
               source: str | None = None, **changes) -> dict:
    updated = {**default_mode(), **record, **changes}
    if mode is not None and mode != record.get("mode"):
        updated["mode"] = mode
        updated["changed_at"] = now()
    if reason is not None:
        updated["reason"] = reason
    if source is not None:
        updated["source"] = source
    _write_json(mode_file(), updated)
    return updated


# -- generations -------------------------------------------------------------
def _digest_files(files: list[tuple[str, bytes]]) -> str:
    digest = hashlib.sha256()
    for name, data in sorted(files):
        digest.update(name.encode() + b"\0" + len(data).to_bytes(8, "big") + data)
    return digest.hexdigest()


def _generation_files(package: Path, *, protected: bool) -> list[tuple[str, bytes]]:
    if package.is_symlink() or not package.is_dir():
        raise GateError("Worker package must be an ordinary directory")
    files: list[tuple[str, bytes]] = []
    total = 0
    for entry in sorted(os.listdir(package)):
        path = package / entry
        if entry == "__pycache__" and not protected:
            continue
        info = os.lstat(path)
        if not stat.S_ISREG(info.st_mode) or not _MODULE_FILE.fullmatch(entry):
            raise GateError(f"Unexpected entry in worker package: {entry}")
        if info.st_size > MAX_GENERATION_FILE_BYTES:
            raise GateError(f"Worker module is too large: {entry}")
        data = _read(path, MAX_GENERATION_FILE_BYTES) if protected else path.read_bytes()
        total += len(data)
        files.append((entry, data))
    if not files or len(files) > MAX_GENERATION_FILES or total > MAX_GENERATION_BYTES:
        raise GateError("Worker package exceeds its inventory limits")
    if "__init__.py" not in dict(files):
        raise GateError("Worker package has no __init__.py")
    return files


def _declared(files: list[tuple[str, bytes]], name: str) -> int:
    source = dict(files)["__init__.py"].decode("utf-8", "replace")
    match = re.search(rf"^{name}\s*=\s*(\d+)\s*$", source, re.MULTILINE)
    if not match:
        raise GateError(f"Worker package does not declare {name}")
    return int(match.group(1))


def signed_support_enrolled() -> bool:
    return any(os.path.lexists(STATE_ROOT / "support" / name)
               for name in ("enrolled.json", "accepted.json", "high-water.json", "pending.json"))


def selected_generation() -> dict | None:
    """Verify the selected generation before anything launches it."""
    if signed_support_enrolled():
        result = subprocess.run(["/usr/bin/python3", "-I", "-B", str(SCRIPTS_ROOT / "shotdeck_seed_gate.py"),
                                 "worker-info"], capture_output=True, timeout=180, check=False)
        try:
            value = json.loads(result.stdout)
            if result.returncode or len(result.stdout) > 16384 or value.get("release_c") is not True:
                raise ValueError()
            value["path"] = Path(value["path"])
            if (value["path"].parent != releases_root() or not re.fullmatch(r"c[1-9][0-9]*-[0-9a-f]{12}", value["path"].name)
                    or type(value["revision"]) is not int or type(value["protocol"]) is not int
                    or not re.fullmatch(r"[0-9a-f]{64}", value["digest"])):
                raise ValueError()
            return value
        except (ValueError, KeyError, TypeError) as exc:
            raise GateError("Signed recovery helper selection needs repair") from exc
    link = current_link()
    if not link.is_symlink():
        return None
    target = Path(os.readlink(link))
    if not target.is_absolute():
        target = link.parent / target
    match = _GENERATION_NAME.fullmatch(target.name)
    if target.parent != releases_root() or not match or target.is_symlink() or not target.is_dir():
        raise GateError("Selected worker generation is outside the support release directory")
    _protected_dir(target)
    cache = target / "shotdeck_recovery" / "__pycache__"
    if cache.exists() or cache.is_symlink():
        # Bytecode is never part of a verified generation: a cached .pyc with a
        # matching timestamp would be loaded instead of the verified source.
        if cache.is_dir() and not cache.is_symlink():
            shutil.rmtree(cache)
        else:
            cache.unlink()
    record = _read_json(target / "GENERATION.json")
    files = _generation_files(target / "shotdeck_recovery", protected=True)
    digest = _digest_files(files)
    if (record.get("schema_version") != 1 or record.get("digest") != digest
            or record.get("files") != sorted(name for name, _ in files)
            or record.get("revision") != _declared(files, "SUPPORT_REVISION")
            or str(record.get("revision")) != match.group(1) or not digest.startswith(match.group(2))):
        raise GateError("Selected worker generation does not match its recorded inventory")
    return {"path": target, "revision": record["revision"], "protocol": record["protocol"], "digest": digest}


def run_generation(generation: dict, module: str, args: list[str], *, capture: bool = False,
                   timeout: float | None = None) -> subprocess.CompletedProcess:
    if generation.get("release_c") is True:
        return subprocess.run(["/usr/bin/python3", "-I", "-B", str(SCRIPTS_ROOT / "shotdeck_seed_gate.py"),
                               "worker-run", module, *args], check=False, timeout=timeout,
                              capture_output=capture, text=capture)
    code = ("import sys; sys.path.insert(0, sys.argv[1]); del sys.argv[1]; "
            f"from shotdeck_recovery.{module} import main; raise SystemExit(main(sys.argv[1:]))")
    # -I: no environment, user site or script directory; -B: never write
    # bytecode into the verified generation.
    command = [sys.executable, "-I", "-B", "-c", code, str(generation["path"]), *args]
    return subprocess.run(command, check=False, timeout=timeout,
                          capture_output=capture, text=capture)


def probe(generation: dict) -> dict | None:
    try:
        completed = run_generation(generation, "probe", [], capture=True, timeout=60)
    except (OSError, subprocess.SubprocessError) as exc:
        log(f"worker probe could not run: {exc}")
        return None
    if completed.returncode != 0:
        log(f"worker probe failed: {(completed.stderr or '').strip()[-400:]}")
        return None
    try:
        value = json.loads(completed.stdout)
    except ValueError:
        return None
    if (not isinstance(value, dict) or value.get("protocol") != generation["protocol"]
            or value.get("revision") != generation["revision"] or "jobs-v1" not in value.get("capabilities", [])):
        log("worker probe reported an incompatible generation")
        return None
    return value


def _replace_link(target_name: str) -> None:
    link = current_link()
    temporary = link.with_name(f".{link.name}.{os.getpid()}.{time.monotonic_ns()}")
    temporary.symlink_to(Path("support-releases") / target_name)
    os.replace(temporary, link)
    _fsync_dir(link.parent)


def _read_support_receipt() -> dict:
    try:
        receipt = _read_json(SUPPORT_RECEIPT)
    except FileNotFoundError:
        return {"schema_version": 1, "high_water_revision": 0, "revisions": {}, "selected": None, "previous": None}
    if (receipt.get("schema_version") != 1 or type(receipt.get("high_water_revision")) is not int
            or not isinstance(receipt.get("revisions"), dict)):
        raise GateError("Worker generation receipt is corrupt")
    return receipt


def install_generation(source: Path) -> int:
    if signed_support_enrolled():
        log("Signed recovery helper enrollment owns support selection; bundled worker replacement skipped")
        return 0
    files = _generation_files(source, protected=False)
    revision = _declared(files, "SUPPORT_REVISION")
    protocol = _declared(files, "PROTOCOL_VERSION")
    digest = _digest_files(files)
    _protected_dir(STATE_ROOT)
    _protected_dir(releases_root(), 0o755)
    with _lock(STATE_ROOT / ".support.lock"):
        receipt = _read_support_receipt()
        try:
            selected = selected_generation()
        except GateError as exc:
            log(f"selected worker generation is invalid and will be replaced: {exc}")
            selected = None
        revisions = dict(receipt["revisions"])
        high = receipt["high_water_revision"]
        if selected is not None:
            # Power loss between the pointer switch and this receipt.
            high = max(high, selected["revision"])
            revisions.setdefault(str(selected["revision"]), selected["digest"])
        if revision < high:
            log(f"keeping update worker revision {high}; refusing older bundled revision {revision}")
            return 0
        if revisions.get(str(revision), digest) != digest:
            log(f"update worker revision {revision} changed without a new revision; refused")
            return 2
        if selected is not None and selected["digest"] == digest:
            if receipt["high_water_revision"] != high or receipt["revisions"] != revisions:
                _write_json(SUPPORT_RECEIPT, {**receipt, "high_water_revision": high, "revisions": revisions})
            return 0
        name = f"{revision}-{digest[:12]}"
        final = releases_root() / name
        if final.exists() or final.is_symlink():
            try:
                if final.is_symlink():
                    raise GateError("generation path is a link")
                existing = _digest_files(_generation_files(final / "shotdeck_recovery", protected=True))
                if existing != digest:
                    raise GateError("generation content differs")
            except (GateError, OSError):
                _move_aside(final, releases_root(), ".discard-")
        if not final.exists():
            stage = releases_root() / f".stage-{os.getpid()}-{time.monotonic_ns()}"
            package = stage / "shotdeck_recovery"
            os.mkdir(stage, 0o755)
            os.mkdir(package, 0o755)
            try:
                for module, data in files:
                    fd = os.open(package / module, os.O_WRONLY | os.O_CREAT | os.O_EXCL | _NOFOLLOW, 0o644)
                    try:
                        os.fchmod(fd, 0o644)
                        os.write(fd, data)
                        os.fsync(fd)
                    finally:
                        os.close(fd)
                _fsync_dir(package)
                _write_json(stage / "GENERATION.json", {
                    "schema_version": 1, "revision": revision, "protocol": protocol, "digest": digest,
                    "files": sorted(module for module, _ in files), "installed_at": now()}, mode=0o644)
                os.chmod(stage, 0o755)
                _fsync_dir(stage)
                os.rename(stage, final)
                _fsync_dir(releases_root())
            except BaseException:
                shutil.rmtree(stage, ignore_errors=True)
                raise
        candidate = {"path": final, "revision": revision, "protocol": protocol, "digest": digest}
        if probe(candidate) is None:
            shutil.rmtree(final, ignore_errors=True)
            log(f"update worker revision {revision} failed its probe; previous selection kept")
            return 1
        _replace_link(name)
        revisions[str(revision)] = digest
        recent = sorted(revisions, key=int)[-KEEP_REVISION_HISTORY:]
        previous = ({"revision": selected["revision"], "digest": selected["digest"], "name": selected["path"].name}
                    if selected else receipt.get("previous"))
        _write_json(SUPPORT_RECEIPT, {
            "schema_version": 1, "high_water_revision": max(high, revision),
            "revisions": {key: revisions[key] for key in recent},
            "selected": {"revision": revision, "digest": digest, "name": name},
            "previous": previous, "updated_at": now()})
        keep = {name, previous["name"] if previous else ""}
        for entry in os.listdir(releases_root()):
            path = releases_root() / entry
            if entry in keep:
                continue
            if _GENERATION_NAME.fullmatch(entry) or entry.startswith((".stage-", ".discard-")):
                if path.is_dir() and not path.is_symlink():
                    shutil.rmtree(path, ignore_errors=True)
                else:
                    path.unlink(missing_ok=True)
        log(f"selected update worker revision {revision} ({digest[:12]})")
        return 0


# -- execution ownership -----------------------------------------------------
def _systemd_active_executors() -> bool | None:
    try:
        completed = subprocess.run(
            ("systemctl", "list-units", "--no-legend", "--plain", "--all",
             "shotdeck-update-apply@*", "shotdeck-update-check@*"),
            check=False, capture_output=True, text=True, timeout=20)
    except (OSError, subprocess.SubprocessError):
        return None
    if completed.returncode != 0:
        return None
    for line in completed.stdout.splitlines():
        fields = line.split()
        if len(fields) >= 3 and fields[2] in {"active", "activating", "deactivating", "reloading"}:
            return True
    return False


def execution_busy() -> bool:
    if recovery_work_pending():
        return True
    run = JOBS_ROOT / "run"
    if run.is_dir():
        for name in os.listdir(run):
            if name.endswith(".lock") and _lock_held(run / name):
                return True
    active = _systemd_active_executors()
    return True if active is None else active


def recovery_work_pending() -> bool:
    """Stdlib-only barrier, including crashes before maintenance lock creation."""
    if any(os.path.lexists(STATE_ROOT / name / "pending.json") for name in ("seed", "support")):
        return True
    root = DATA_ROOT / "recovery-access"
    if os.path.lexists(root / "access-latch.json"):
        return True
    try:
        files = list((root / "jobs").glob("*.json"))
        if len(files) > 128:
            return True
        for path in files:
            value = _read_json(path)
            record = value["record"]
            checksum = hashlib.sha256(json.dumps(record, sort_keys=True, separators=(",", ":"),
                                                 ensure_ascii=True, allow_nan=False).encode()).hexdigest()
            if (set(value) != {"record", "sha256"} or checksum != value["sha256"]
                    or record.get("schema_version") != 1 or record.get("job_id") != path.stem
                    or record.get("state") not in {"succeeded", "failed"}
                    or record.get("state") == "failed" and record.get("mutation_started") is not False):
                return True
    except (OSError, GateError, ValueError, KeyError, TypeError):
        return True
    return False


def _acknowledged(job_id: str) -> bool:
    try:
        return _read_json(DISPATCH_ROOT / "acknowledged" / f"{job_id}.json", 4096).get("job_id") == job_id
    except (FileNotFoundError, GateError, OSError):
        return False


# -- transaction record contract ------------------------------------------------
#
# An independent copy of the worker's job contract (shotdeck_recovery.protocol
# and queue). The gate must judge the worker's records when the selected worker
# generation is damaged, so it never imports it. Tests keep both
# classifications identical; valid JSON alone is never enough.
JOB_PROTOCOL = 1
JOB_ACTIONS = ("check", "install", "scheduled")
JOB_SOURCES = ("touch", "web", "timer", "legacy-response", "operator")
JOB_CHANNELS = ("stable", "beta")
JOB_ACTIVE_STATES = frozenset({"queued", "checking", "waiting-for-idle", "downloading", "verifying",
                               "installing", "health-checking", "rolling-back"})
JOB_TERMINAL_STATES = frozenset({"succeeded", "failed", "interrupted", "coalesced", "recovery-required"})
JOB_OUTCOMES = ("available", "up_to_date", "unavailable", "installed", "skipped",
                "blocked", "not_started", "failed", "unknown", "coalesced")
JOB_ERROR_CODES = frozenset({
    "updates_disabled", "auto_update_disabled", "read_only", "offer_changed",
    "offer_unavailable", "offer_incomplete", "brew_active", "app_not_ready",
    "maintenance_active", "licence_pending", "runtime_unavailable",
    "check_failed", "check_timeout", "check_interrupted", "apply_failed",
    "result_mismatch", "bad_output", "executor_interrupted", "outcome_unknown",
    "admission_timeout", "another_update_active", "unknown_apply_pending",
    "worker_suspended", "dispatch_failed", "expired", "internal_error",
    "apply_interrupted", "records_unreadable",
})
JOB_MUTATING_ACTIONS = frozenset({"install", "scheduled"})
JOB_REQUEST_FIELDS = frozenset({"schema_version", "job_id", "action", "source", "created_at", "offer"})
JOB_STATE_FIELDS = frozenset({
    "schema_version", "job_id", "action", "source", "created_at", "offer", "state", "attempt",
    "dispatch", "executor", "apply_offer", "apply_invoked_at", "wait_reason", "error_code", "message",
    "coalesced_into", "phase_timings",
})
JOB_RECEIPT_FIELDS = frozenset({
    "schema_version", "job_id", "action", "source", "created_at", "offer", "state", "outcome",
    "error_code", "message", "detail", "result", "observations", "coalesced_into", "completed_at",
    "phase_timings",
})
_JOB_TIMESTAMP = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?\+00:00$")
_JOB_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_JOB_VERSION = re.compile(r"^[0-9A-Za-z][0-9A-Za-z.+-]{0,63}$")
_JOB_UNIT = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}@([0-9a-f]{32})\.service$")
_JOB_FILE = re.compile(r"^[0-9a-f]{32}\.json$")


class RecordInvalid(Exception):
    """A worker transaction record is untrustworthy."""


def _unique_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise RecordInvalid("duplicate property")
        result[key] = value
    return result


def _record(path: Path, limit: int = 65536) -> dict | None:
    """One protected job record, or ``None`` when absent. Never follows links."""
    if not os.path.lexists(path):
        return None
    try:
        value = json.loads(_read(path, limit), object_pairs_hook=_unique_pairs)
    except FileNotFoundError:
        return None
    except (GateError, OSError, UnicodeError, ValueError, RecursionError) as exc:
        raise RecordInvalid(f"{path.name}: {exc}") from exc
    if not isinstance(value, dict):
        raise RecordInvalid(f"{path.name} is not an object")
    return value


def _is_timestamp(value) -> bool:
    return isinstance(value, str) and bool(_JOB_TIMESTAMP.fullmatch(value))


def _offer(value) -> dict | None:
    if value is None:
        return None
    if (not isinstance(value, dict) or set(value) != {"channel", "version", "artifact_sha256", "manifest_sha256"}
            or value["channel"] not in JOB_CHANNELS
            or not isinstance(value["version"], str) or not _JOB_VERSION.fullmatch(value["version"])
            or not all(isinstance(value[key], str) and _JOB_SHA256.fullmatch(value[key])
                       for key in ("artifact_sha256", "manifest_sha256"))):
        raise RecordInvalid("invalid offer")
    return value


def _check_request(value: dict, job_id: str) -> dict:
    if (set(value) != JOB_REQUEST_FIELDS or type(value["schema_version"]) is not int
            or value["schema_version"] != JOB_PROTOCOL or value["job_id"] != job_id
            or value["action"] not in JOB_ACTIONS or value["source"] not in JOB_SOURCES
            or not _is_timestamp(value["created_at"])):
        raise RecordInvalid("invalid request")
    offer = _offer(value["offer"]) if value["action"] == "install" else value["offer"]
    if (value["action"] == "install") != (offer is not None):
        raise RecordInvalid("request offer does not match its action")
    if value["action"] == "scheduled" and value["source"] != "timer":
        raise RecordInvalid("scheduled request not from the timer")
    return value


def _check_common(value: dict, job_id: str) -> None:
    if (type(value["schema_version"]) is not int or value["schema_version"] != JOB_PROTOCOL
            or value["job_id"] != job_id or value["action"] not in JOB_ACTIONS
            or value["source"] not in JOB_SOURCES or not _is_timestamp(value["created_at"])
            or (value["error_code"] != "" and value["error_code"] not in JOB_ERROR_CODES)
            or not isinstance(value["message"], str) or not isinstance(value["phase_timings"], dict)):
        raise RecordInvalid("invalid record identity or fields")
    coalesced = value["coalesced_into"]
    if coalesced is not None and (not isinstance(coalesced, str) or not _JOB_ID.fullmatch(coalesced)
                                  or coalesced == job_id):
        raise RecordInvalid("invalid primary job")
    if (value["state"] == "coalesced") != (coalesced is not None):
        raise RecordInvalid("inconsistent coalescing")


def _check_state(value: dict, job_id: str) -> dict:
    if not JOB_STATE_FIELDS <= set(value):
        raise RecordInvalid("state lacks required fields")
    _check_common(value, job_id)
    if value["state"] not in JOB_ACTIVE_STATES | JOB_TERMINAL_STATES:
        raise RecordInvalid("unknown phase")
    if type(value["attempt"]) is not int or value["attempt"] < 0:
        raise RecordInvalid("invalid attempt")
    offer = _offer(value["offer"])
    if (value["action"] == "install") != (offer is not None):
        raise RecordInvalid("state offer does not match its action")
    apply_offer = _offer(value["apply_offer"])
    if apply_offer is not None and (value["action"] not in JOB_MUTATING_ACTIONS
                                    or (value["action"] == "install" and apply_offer != offer)):
        raise RecordInvalid("activation of an unapproved offer")
    if value["apply_invoked_at"] is not None and (not _is_timestamp(value["apply_invoked_at"])
                                                  or apply_offer is None):
        raise RecordInvalid("activation without its offer")
    dispatch = value["dispatch"]
    if dispatch is not None:
        unit = dispatch.get("unit") if isinstance(dispatch, dict) else None
        match = _JOB_UNIT.fullmatch(unit) if isinstance(unit, str) else None
        if (match is None or match.group(1) != job_id or not _is_timestamp(dispatch.get("intent_at"))
                or type(dispatch.get("attempt")) is not int):
            raise RecordInvalid("invalid dispatch record")
    executor = value["executor"]
    if executor is not None and (not isinstance(executor, dict) or not _is_timestamp(executor.get("started_at"))):
        raise RecordInvalid("invalid executor record")
    if not isinstance(value["wait_reason"], str):
        raise RecordInvalid("invalid wait reason")
    return value


def _check_receipt(value: dict, job_id: str) -> dict:
    if set(value) != JOB_RECEIPT_FIELDS:
        raise RecordInvalid("receipt has an unexpected shape")
    _check_common(value, job_id)
    if value["state"] not in JOB_TERMINAL_STATES or value["outcome"] not in JOB_OUTCOMES:
        raise RecordInvalid("invalid result")
    offer = _offer(value["offer"])
    if (not isinstance(value["detail"], str) or not isinstance(value["observations"], dict)
            or not (value["result"] is None or isinstance(value["result"], dict))
            or not _is_timestamp(value["completed_at"])):
        raise RecordInvalid("invalid receipt fields")
    if (value["outcome"] == "coalesced") != (value["state"] == "coalesced"):
        raise RecordInvalid("inconsistent coalescing")
    if value["outcome"] in {"installed", "unknown"} and value["action"] not in JOB_MUTATING_ACTIONS:
        raise RecordInvalid("activation outcome for a non-installation")
    if value["outcome"] == "installed" and (value["state"] != "succeeded" or offer is None):
        raise RecordInvalid("installation receipt without success or offer")
    return value


def _check_job(request: dict | None, state: dict | None, receipt: dict | None) -> None:
    def identity(value):
        return value["action"], value["source"], value["created_at"]
    if request is not None and state is not None and (
            identity(request) != identity(state) or request["offer"] != state["offer"]):
        raise RecordInvalid("state differs from its request")
    if request is not None and receipt is not None and identity(request) != identity(receipt):
        raise RecordInvalid("receipt differs from its request")
    if state is not None and receipt is not None:
        if identity(state) != identity(receipt) or receipt["offer"] != (state["apply_offer"] or state["offer"]):
            raise RecordInvalid("receipt differs from its state")
        if state["state"] in JOB_TERMINAL_STATES and (
                state["state"] != receipt["state"] or state["coalesced_into"] != receipt["coalesced_into"]):
            raise RecordInvalid("state and receipt disagree")
    if state is not None and state["state"] in JOB_TERMINAL_STATES and receipt is None:
        raise RecordInvalid("terminal state without a receipt")
    if state is not None and request is None and not (state["state"] in JOB_TERMINAL_STATES and receipt is not None):
        raise RecordInvalid("unfinished job without its request")


def _job_files(folder: Path) -> set[str]:
    try:
        names = os.listdir(folder)
    except (FileNotFoundError, NotADirectoryError):
        return set()
    return {name[:-5] for name in names if _JOB_FILE.fullmatch(name)}


def job_concern(job_id: str) -> str:
    """Why a job must be reviewed before any installation or fallback, or ``""``.

    ``untrustworthy``: a record breaks the job contract (the worker blocks
    installations on the same rules). ``unknown_outcome``: a valid receipt says
    the activation result is unknown. ``unreconciled_intent``: durable
    activation intent without a receipt yet (in flight, or not yet reconciled).
    """
    name = f"{job_id}.json"
    try:
        raw_request = _record(JOBS_ROOT / "claimed" / name, 4096)
        request = _check_request(raw_request, job_id) if raw_request is not None else None
        raw_state = _record(JOBS_ROOT / "state" / name)
        state = _check_state(raw_state, job_id) if raw_state is not None else None
        raw_receipt = _record(JOBS_ROOT / "receipts" / name)
        receipt = _check_receipt(raw_receipt, job_id) if raw_receipt is not None else None
        _check_job(request, state, receipt)
    except (RecordInvalid, KeyError, TypeError, AttributeError):
        return "untrustworthy"
    if receipt is not None:
        return "unknown_outcome" if receipt["outcome"] == "unknown" else ""
    return "unreconciled_intent" if state is not None and state["apply_invoked_at"] else ""


def uncertain_jobs() -> list[str]:
    """Jobs that block installation and fallback until a user reviews them.

    A superset of the worker's mutation barrier (the same untrustworthy and
    unknown-outcome rules, plus unreconciled activation intent): nothing the
    worker refuses to install over can be bypassed through the previous updater.
    """
    jobs = _job_files(JOBS_ROOT / "state") | _job_files(JOBS_ROOT / "receipts") | _job_files(JOBS_ROOT / "claimed")
    return sorted(job_id for job_id in jobs if not _acknowledged(job_id) and job_concern(job_id))


def capability_valid(generation: dict | None = None) -> bool:
    try:
        generation = generation or selected_generation()
        record = _read_json(capability_file())
    except (FileNotFoundError, GateError, OSError):
        return False
    return bool(generation) and record.get("schema_version") == 1 and record.get("generation") == generation["digest"]


def _settle_pending(record: dict) -> dict:
    if record.get("mode") == "suspended" and record.get("pending") == "legacy":
        if not execution_busy() and not uncertain_jobs():
            return write_mode(record, mode="legacy", reason="legacy_selected", pending="")
    return record


def _hold_incoming() -> None:
    incoming = JOBS_ROOT / "incoming"
    if not incoming.is_dir():
        return
    for name in sorted(os.listdir(incoming)):
        _move_aside(incoming / name, JOBS_ROOT / "held", "")


def _count_failure(reason: str, generation: dict | None) -> None:
    with _lock(DISPATCH_ROOT / ".lock"):
        record = read_mode()
        failures = int(record.get("failures") or 0) + 1
        if failures >= FAILURE_BUDGET and record.get("mode") == "worker":
            log(f"latching update worker suspension after {failures} failures ({reason})")
            write_mode(record, mode="suspended", reason=reason, source="gate", latched=True,
                       failures=failures, latched_generation=(generation or {}).get("digest", ""))
        else:
            write_mode(record, failures=failures)


def _clear_failures() -> None:
    record = read_mode()
    if int(record.get("failures") or 0):
        with _lock(DISPATCH_ROOT / ".lock"):
            write_mode(read_mode(), failures=0)


def _small_text(path: Path, limit: int = 4096) -> str:
    try:
        with open(path, encoding="utf-8", errors="replace") as stream:
            return stream.read(limit)
    except OSError:
        return ""


def device_profile() -> dict:
    codename = ""
    for line in _small_text(OS_RELEASE).splitlines():
        key, _, value = line.partition("=")
        if key == "VERSION_CODENAME":
            codename = value.strip().strip('"')
    controllers = _small_text(CGROUP_ROOT / "cgroup.controllers").split()
    return {
        "board": _small_text(DEVICE_MODEL, 256).strip("\x00\n "),
        "os_codename": codename,
        "memory_controller": "memory" in controllers,
        "psi": (PROC_ROOT / "pressure/memory").exists() and (PROC_ROOT / "pressure/io").exists(),
    }


# Canonical PEP 440 release spellings (``0.2.10``, ``0.2.10b1``, ``0.2.10rc1``,
# ``0.2.10.post1``, ``0.2.10.dev1``, ``0.2.10a1.dev2``); anything else is unknown.
_RELEASE_VERSION = re.compile(r"(\d+)\.(\d+)\.(\d+)((?:a|b|rc)\d+)?(\.post\d+)?(\.dev\d+)?")


def _version_key(text: str):
    match = _RELEASE_VERSION.fullmatch(text.strip())
    if not match:
        return None
    # Pre-releases and development releases sort before their release; a
    # post-release does not.
    return tuple(int(part) for part in match.groups()[:3]), 0 if match.group(4) or match.group(6) else 1


def _routed_through_gate(unit: str, argument: str) -> bool:
    for line in _small_text(SYSTEMD_ROOT / unit, 65536).splitlines():
        if line.startswith("ExecStart=") and line.rstrip().endswith(f"shotdeck_update_gate.py {argument}"):
            return True
    return False


def workshop_override(profile: dict) -> dict | None:
    try:
        info = os.lstat(WORKSHOP_OVERRIDE)
    except FileNotFoundError:
        return None
    if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022:
        log("workshop override ignored: not a protected regular file")
        return None
    try:
        value = _read_json(WORKSHOP_OVERRIDE, 4096)
        expires = datetime.fromisoformat(value["expires_at"])
    except (GateError, OSError, KeyError, TypeError, ValueError):
        log("workshop override ignored: unreadable")
        return None
    current = datetime.now(timezone.utc)
    if (value.get("schema_version") != 1 or not str(value.get("reason") or "").strip()
            or expires.tzinfo is None or not current < expires <= current + timedelta(days=MAX_OVERRIDE_DAYS)
            or value.get("board") != profile["board"] or value.get("os_codename") != profile["os_codename"]):
        log("workshop override ignored: expired, too long or for another device profile")
        return None
    return value


def qualification(generation: dict | None) -> tuple[bool, list[str], str]:
    """Release A may run only where its rollback path and resources are qualified."""
    profile = device_profile()
    reasons: list[str] = []
    if not profile["memory_controller"]:
        reasons.append("memory cgroup controller is not enabled")
    if not profile["psi"]:
        reasons.append("pressure stall information is not enabled")
    if not (DATA_ROOT / "signing/updates/active.json").is_file():
        reasons.append("signing migration is not complete")
    previous = INSTALL_ROOT / "previous" / ".shotdeck-version"
    if os.path.lexists(INSTALL_ROOT / "previous"):
        version = _small_text(previous, 128).strip()
        key = _version_key(version)
        if key is None or key < (MIN_ROLLBACK_GUARDED_VERSION, 1):
            reasons.append(f"rollback target {version or 'unknown'} predates the support revision guard")
    for unit, argument in (("shotdeck-updater.service", "scheduled"),
                           ("shotdeck-update-response.service", "response")):
        if not _routed_through_gate(unit, argument):
            reasons.append(f"{unit} does not route through the dispatch gate")
    revision = (generation or {}).get("revision")
    if (generation or {}).get("release_c") is True:
        basis = "qualified_release_c" if generation.get("qualified") is True else ""
        if not basis:
            reasons.append("Release C access, support and resource qualification is not enabled")
    elif any(entry.get("board") == profile["board"] and entry.get("os_codename") == profile["os_codename"]
           and entry.get("worker_revision") == revision for entry in QUALIFIED_PROFILES):
        basis = "qualified_profile"
    elif any(re.fullmatch(re.escape(entry["board_family"]) + r" Rev \d+\.\d+", profile["board"])
             and entry["os_codename"] == profile["os_codename"]
             and entry["worker_revision"] == revision for entry in OWNER_ACCEPTED_PROFILES):
        basis = "owner_accepted_profile"
    elif workshop_override(profile) is not None:
        basis = "workshop_override"
    else:
        basis = ""
        reasons.append(f"device profile {profile['board']!r} / {profile['os_codename']!r} is not qualified "
                       f"for worker revision {revision}")
    return not reasons, reasons, basis


def _deactivate(record: dict, reason: str, generation: dict | None) -> None:
    """Return to the retained path, or to pending legacy while work is uncertain."""
    capability_file().unlink(missing_ok=True)
    if not mode_recorded():
        write_mode(record, mode="legacy", reason=reason, source="activation")
    elif record["mode"] == "worker":
        if execution_busy() or uncertain_jobs():
            write_mode(record, mode="suspended", reason=reason, source="activation", latched=True,
                       pending="legacy", latched_generation=(generation or {}).get("digest", ""))
        else:
            write_mode(record, mode="legacy", reason=reason, source="activation")


def _exec_generation(generation: dict, module: str, args: list[str]) -> int:
    """Hand this process over to the verified worker: no idle gate parent.

    Failure accounting happens in ``stopped`` (ExecStopPost), from the exit
    status systemd reports.
    """
    if generation.get("release_c") is True:
        os.execv("/usr/bin/python3", ["/usr/bin/python3", "-I", "-B", str(SCRIPTS_ROOT / "shotdeck_seed_gate.py"),
                                    "worker-run", module, *args])
    code = ("import sys; sys.path.insert(0, sys.argv[1]); del sys.argv[1]; "
            f"from shotdeck_recovery.{module} import main; raise SystemExit(main(sys.argv[1:]))")
    sys.stdout.flush()
    sys.stderr.flush()
    os.execv(sys.executable, [sys.executable, "-I", "-B", "-c", code, str(generation["path"]), *args])
    return 1  # pragma: no cover - execv does not return


def wake_dir() -> Path:
    return JOBS_ROOT / "wake"


def command_wake(job_id: str) -> int:
    """Leave a level-triggered wake marker for the queue path unit.

    Executors call this from ExecStopPost, and PID 1 runs it through
    ``OnFailure=`` when an executor's whole cgroup was killed. A marker that
    appears while the coordinator runs keeps the watched directory non-empty,
    so systemd starts the coordinator again after it exits; a plain start
    request would merge into the running activation and be lost.
    """
    if not _JOB_ID.fullmatch(job_id):
        log("invalid update job identifier")
        return 64
    folder = _protected_dir(wake_dir())
    fd = os.open(folder / job_id, os.O_WRONLY | os.O_CREAT | _NOFOLLOW, 0o600)
    os.close(fd)
    return 0


def _consume_wakes() -> None:
    """Clear markers before work starts; later ones re-trigger the path unit."""
    folder = wake_dir()
    if folder.is_symlink() or not folder.is_dir():
        return
    for name in os.listdir(folder):
        try:
            (folder / name).unlink()
        except FileNotFoundError:
            pass


WATCHED_PATH_UNITS = ("shotdeck-update-queue.path", "shotdeck-update-control.path")


def _heal_path_units() -> None:
    """Re-arm a path unit that systemd failed (trigger or start limit hit).

    A failed path unit stops watching for requests until reboot. The boot and
    hourly timers still run the coordinator, which restores the watch here.
    """
    for unit in WATCHED_PATH_UNITS:
        try:
            state = subprocess.run(("systemctl", "is-failed", unit), check=False, capture_output=True,
                                   text=True, timeout=10).stdout.strip()
            if state == "failed":
                log(f"{unit} had failed; re-arming it")
                subprocess.run(("systemctl", "reset-failed", unit), check=False, capture_output=True, timeout=10)
                subprocess.run(("systemctl", "start", "--no-block", unit), check=False, capture_output=True,
                               timeout=10)
        except (OSError, subprocess.SubprocessError) as exc:
            log(f"could not check {unit}: {exc}")


def command_coordinator() -> int:
    # Always first and in every mode: an unconsumed marker would make the
    # path unit re-trigger until systemd's trigger limit disables it.
    _consume_wakes()
    _heal_path_units()
    with _lock(DISPATCH_ROOT / ".lock"):
        record = _settle_pending(read_mode())
    if record["mode"] != "worker":
        _hold_incoming()
        log(f"update worker is {record['mode']}; no queue work admitted")
        return 0
    try:
        generation = selected_generation()
    except (GateError, OSError) as exc:
        log(f"update worker generation is invalid: {exc}")
        generation = None
    if generation is None:
        _count_failure("generation_invalid", None)
        return EXIT_GENERATION_INVALID
    qualified, reasons, _ = qualification(generation)
    if not qualified:
        log("update worker disabled on this device: " + "; ".join(reasons))
        with _lock(DISPATCH_ROOT / ".lock"):
            _deactivate(read_mode(), "unqualified", generation)
        _hold_incoming()
        return 0
    return _exec_generation(generation, "worker", [])


def command_execute(job_id: str) -> int:
    if not _JOB_ID.fullmatch(job_id):
        log("invalid update job identifier")
        return 64
    if recovery_work_pending():
        log("Recovery work or interrupted helper maintenance blocks updater execution")
        return EXIT_REFUSED
    record = read_mode()
    if record["mode"] != "worker":
        log(f"update worker is {record['mode']}; executor admission refused")
        return EXIT_REFUSED
    try:
        generation = selected_generation()
    except (GateError, OSError) as exc:
        log(f"update worker generation is invalid: {exc}")
        generation = None
    if generation is None:
        _count_failure("generation_invalid", None)
        return EXIT_GENERATION_INVALID
    qualified, reasons, _ = qualification(generation)
    if not qualified:
        log("executor admission refused: " + "; ".join(reasons))
        return EXIT_NOT_QUALIFIED
    return _exec_generation(generation, "executor", [job_id])


def command_stopped(kind: str, job_id: str | None = None) -> int:
    """ExecStopPost: failure accounting for the worker, and executor wake-up.

    systemd passes the main process result in EXIT_CODE/EXIT_STATUS. Exits of
    the gate itself are already accounted. A kill of the unit's whole cgroup
    can also kill this process; executors then rely on ``OnFailure=`` and the
    coordinator on its bounded ``Restart=on-failure``.
    """
    if kind == "execute":
        if not job_id or command_wake(job_id) != 0:
            return 64
    code, status = os.environ.get("EXIT_CODE", ""), os.environ.get("EXIT_STATUS", "")
    if not code:
        return 0  # Not run by systemd: nothing to account.
    if code == "exited" and status.isdigit() and int(status) in GATE_EXITS:
        return 0
    if code == "exited" and status == "0":
        _clear_failures()
        return 0
    try:
        generation = selected_generation()
    except (GateError, OSError):
        generation = None
    corrupt = kind == "coordinator" and code == "exited" and status == str(EXIT_CORRUPT_QUEUE)
    _count_failure("corrupt_queue" if corrupt else "worker_crash", generation)
    return 0


def _exec_legacy(mode_argument: str) -> int:
    runner = SCRIPTS_ROOT / "run_configured_updater.sh"
    os.execv("/bin/bash", ["/bin/bash", str(runner), str(CONFIG_PATH), mode_argument])
    return 1  # pragma: no cover - execv does not return


LEGACY_BLOCKED_MESSAGE = ("An earlier update could not be confirmed. Review it under Update service "
                          "before checking or installing again.")


def _hold_response() -> None:
    response = DATA_ROOT / "update-response.json"
    if response.exists() or response.is_symlink():
        # Preserve the approval as evidence; never replay it later.
        _move_aside(response, DISPATCH_ROOT / "held", "response-")


def _legacy_blocked_view() -> None:
    """Tell the retained update screens why nothing runs (a derived view only)."""
    path = DATA_ROOT / "update-web-state.json"
    try:
        current = _read_json(path) if path.exists() else {}
    except (GateError, OSError):
        current = {}
    try:
        _write_json(path, {**current, "state": "error", "message": LEGACY_BLOCKED_MESSAGE,
                           "error": LEGACY_BLOCKED_MESSAGE, "busy": False, "update_available": False,
                           "updated_at": now()}, mode=0o644)
    except (GateError, OSError) as exc:
        log(f"could not publish the blocked update view: {exc}")


def command_route(kind: str) -> int:
    """Route a timer run or a legacy prompt response by the current mode."""
    if recovery_work_pending():
        if kind == "response":
            _hold_response()
        _legacy_blocked_view()
        return EXIT_REFUSED
    record = read_mode()
    if record["mode"] == "legacy":
        # Re-check at every dispatch: choosing the previous updater earlier
        # must not bypass records found since. The retained flow cannot be
        # split into read-only and installing parts (a scheduled run installs
        # under Auto-Update; a response is an approval), so nothing runs until
        # every blocking record has been reviewed.
        blocking = uncertain_jobs()
        if blocking or execution_busy():
            if kind == "response":
                _hold_response()
            _legacy_blocked_view()
            log(f"previous updater not started ({kind}): "
                + (f"review required for {', '.join(blocking)}" if blocking else "an update executor is running"))
            return EXIT_REFUSED
        return _exec_legacy("scheduled" if kind == "scheduled" else "process-response")
    if record["mode"] == "suspended":
        if kind == "response":
            _hold_response()
        log(f"update worker is suspended; {kind} work not admitted")
        return 0
    try:
        generation = selected_generation()
    except (GateError, OSError) as exc:
        log(f"update worker generation is invalid: {exc}")
        generation = None
    if generation is None:
        _count_failure("generation_invalid", None)
        return 1
    completed = run_generation(generation, "adapters", [kind])
    if completed.returncode != 0:
        _count_failure("worker_crash", generation)
    return completed.returncode


# -- control -----------------------------------------------------------------
def _unit_active(job_id: str) -> bool:
    for template in ("shotdeck-update-apply@{}.service", "shotdeck-update-check@{}.service"):
        try:
            completed = subprocess.run(("systemctl", "is-active", template.format(job_id)), check=False,
                                       capture_output=True, text=True, timeout=20)
        except (OSError, subprocess.SubprocessError):
            return True
        if completed.stdout.strip() in {"active", "activating", "deactivating", "reloading"}:
            return True
    return False


def apply_control(action: str, source: str, *, job_id: str | None = None, request_id: str = "") -> dict:
    with _lock(DISPATCH_ROOT / ".lock"):
        record = read_mode()
        outcome, message = "ok", ""
        if action == "suspend":
            record = write_mode(record, mode="suspended", reason="user", source=source, latched=False, pending="")
            message = "Update worker suspended. A running installation continues to completion."
        elif action == "resume":
            try:
                generation = selected_generation()
            except (GateError, OSError):
                generation = None
            if not capability_valid(generation):
                outcome, message = "refused", "The update worker is not installed on this device."
            elif not qualification(generation)[0]:
                outcome, message = "refused", "The update worker is not qualified for this device."
            else:
                record = write_mode(record, mode="worker", reason="user", source=source, latched=False,
                                    failures=0, pending="", latched_generation="")
                message = "Update worker resumed."
        elif action == "legacy":
            if execution_busy() or uncertain_jobs():
                record = write_mode(record, mode="suspended", reason="legacy_pending", source=source,
                                    pending="legacy")
                outcome = "pending"
                message = ("The previous updater will be used after the current operation is finished "
                           "and any unconfirmed update has been reviewed.")
            else:
                record = write_mode(record, mode="legacy", reason="user", source=source, pending="",
                                    latched=False)
                message = "The previous updater is in use."
        elif action == "acknowledge":
            # Explicit review of one blocking job. The gate applies the worker's
            # full record contract itself, so only jobs that actually block can
            # be reviewed, and never while their executor or unit is running.
            if not job_id or not _JOB_ID.fullmatch(job_id) or job_id not in uncertain_jobs():
                outcome, message = "refused", "There is no unconfirmed update to review."
            elif _lock_held(JOBS_ROOT / "run" / f"{job_id}.lock") or _unit_active(job_id):
                outcome, message = "refused", "The update is still running."
            else:
                version = "unknown"
                try:
                    with open(INSTALL_ROOT / "current/.shotdeck-version", "rb") as stream:
                        version = stream.read(129).decode("utf-8", "replace").strip()[:128] or "unknown"
                except OSError:
                    pass
                _write_json(DISPATCH_ROOT / "acknowledged" / f"{job_id}.json",
                            {"schema_version": 1, "job_id": job_id, "acknowledged_at": now(),
                             "source": source, "running_version": version})
                message = f"Recorded. Version {version} is running."
        else:
            outcome, message = "refused", "Unsupported update control action."
        record = write_mode(read_mode(), last_control={"request_id": request_id, "action": action,
                                                        "outcome": outcome, "message": message, "at": now()})
        if action == "acknowledge" and outcome == "ok":
            record = _settle_pending(record)
        return record


def command_control() -> int:
    requests = DISPATCH_ROOT / "requests"
    processed = 0
    if requests.is_dir():
        for name in sorted(os.listdir(requests))[:32]:
            path = requests / name
            if name.startswith("."):
                # A write in progress (current clients stage elsewhere); only an
                # abandoned one is moved aside, so the path unit cannot loop.
                try:
                    if time.time() - os.lstat(path).st_mtime < 60:
                        continue
                except FileNotFoundError:
                    continue
            try:
                value = _read_json(path, 4096)
                if (set(value) != {"schema_version", "request_id", "action", "source", "job_id", "created_at"}
                        or value["schema_version"] != 1 or not _JOB_ID.fullmatch(str(value["request_id"]))
                        or value["action"] not in CONTROL_ACTIONS or value["source"] not in CONTROL_SOURCES
                        or (value["job_id"] is not None and not _JOB_ID.fullmatch(str(value["job_id"])))):
                    raise GateError("invalid control request")
            except (GateError, OSError) as exc:
                log(f"ignoring control request {name}: {exc}")
                _move_aside(path, DISPATCH_ROOT / "rejected", "")
                continue
            apply_control(value["action"], value["source"], job_id=value["job_id"], request_id=value["request_id"])
            path.unlink(missing_ok=True)
            _fsync_dir(requests)
            processed += 1
    with _lock(DISPATCH_ROOT / ".lock"):
        _settle_pending(read_mode())
    return 0


# -- activation --------------------------------------------------------------
def retained_fallback_ready() -> bool:
    launcher = SCRIPTS_ROOT / "prompted_update_flow.py"
    runner = SCRIPTS_ROOT / "run_configured_updater.sh"
    try:
        source = _read(launcher, 1024 * 1024)
        _read(runner, 256 * 1024)
        compile(source, str(launcher), "exec")
    except (GateError, OSError, SyntaxError, ValueError) as exc:
        log(f"retained update launcher is unavailable: {exc}")
        return False
    return True


def units_ready() -> bool:
    missing = [name for name in REQUIRED_UNITS if not (SYSTEMD_ROOT / name).is_file()]
    if missing:
        log(f"update worker units are missing: {', '.join(missing)}")
    return not missing


def command_activate() -> int:
    """Enable the worker only after generation, fallback and unit probes pass."""
    try:
        generation = selected_generation()
    except (GateError, OSError) as exc:
        log(f"selected update worker generation is invalid: {exc}")
        generation = None
    probed = None
    if generation and mode_recorded() and capability_valid(generation):
        # Already probed and published for exactly this generation; the
        # application bootstrap calls activate on every start.
        try:
            record = _read_json(capability_file())
            probed = {"protocol": record["protocol"], "revision": record["revision"],
                      "capabilities": record["capabilities"]}
        except (GateError, OSError, KeyError):
            probed = None
    if generation and probed is None:
        probed = probe(generation)
    ready = bool(probed) and retained_fallback_ready() and units_ready()
    qualified, reasons, basis = qualification(generation) if ready else (False, [], "")
    with _lock(DISPATCH_ROOT / ".lock"):
        record = read_mode()
        if not ready or not qualified:
            if ready:
                log("update worker not enabled on this device: " + "; ".join(reasons))
            _deactivate(record, "probe_failed" if not ready else "unqualified", generation)
            return 1 if not ready else EXIT_NOT_QUALIFIED
        automatic = (record["mode"] != "worker" and record.get("source") == "activation"
                     and record.get("reason") in AUTOMATIC_REASONS)
        try:
            previous_basis = _read_json(capability_file()).get("qualification")
        except (FileNotFoundError, GateError, OSError):
            previous_basis = None
        if capability_valid(generation) and mode_recorded() and not automatic and previous_basis == basis and not (
                record.get("latched") and record.get("reason") in FAULT_REASONS
                and record.get("latched_generation") != generation["digest"]):
            return 0
        _write_json(capability_file(), {
            "schema_version": 1, "protocol": probed["protocol"], "revision": probed["revision"],
            "generation": generation["digest"], "name": generation["path"].name,
            "capabilities": probed["capabilities"], "qualification": basis,
            "verified_at": now()}, mode=0o644)
        if not mode_recorded() or automatic:
            write_mode(record, mode="worker", reason="activated", source="activation", pending="",
                       latched=False)
        elif (record.get("latched") and record.get("reason") in FAULT_REASONS
              and record.get("latched_generation") != generation["digest"]):
            # A qualified replacement generation may clear a fault latch; a
            # user's deliberate choice is never overridden.
            write_mode(record, mode="worker", reason="replacement", source="activation", latched=False,
                       failures=0, pending="", latched_generation="")
    return 0


def command_status() -> int:
    try:
        generation = selected_generation()
    except (GateError, OSError) as exc:
        generation = {"error": str(exc)}
    record = read_mode()
    print(json.dumps({
        "mode": record,
        "generation": {k: str(v) for k, v in (generation or {}).items()},
        "capability_valid": capability_valid() if generation and "error" not in generation else False,
        "uncertain_jobs": uncertain_jobs(),
        "qualification": dict(zip(("qualified", "reasons", "basis"), qualification(
            generation if generation and "error" not in generation else None))),
        "device_profile": device_profile(),
    }, indent=2, sort_keys=True))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Shotdeck update dispatch gate")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("coordinator")
    execute = sub.add_parser("execute")
    execute.add_argument("job_id")
    wake = sub.add_parser("wake")
    wake.add_argument("job_id")
    stopped = sub.add_parser("stopped")
    stopped.add_argument("kind", choices=("coordinator", "execute"))
    stopped.add_argument("job_id", nargs="?")
    sub.add_parser("scheduled")
    sub.add_parser("response")
    sub.add_parser("control")
    install = sub.add_parser("install-generation")
    install.add_argument("--source", type=Path, required=True)
    sub.add_parser("activate")
    sub.add_parser("status")
    for action in ("suspend", "resume", "legacy"):
        sub.add_parser(action)
    acknowledge = sub.add_parser("acknowledge")
    acknowledge.add_argument("job_id")
    args = parser.parse_args(argv)
    try:
        if args.command == "coordinator":
            return command_coordinator()
        if args.command == "execute":
            return command_execute(args.job_id)
        if args.command == "wake":
            return command_wake(args.job_id)
        if args.command == "stopped":
            return command_stopped(args.kind, args.job_id)
        if args.command in {"scheduled", "response"}:
            return command_route(args.command)
        if args.command == "control":
            return command_control()
        if args.command == "install-generation":
            return install_generation(args.source)
        if args.command == "activate":
            return command_activate()
        if args.command == "status":
            return command_status()
        record = apply_control(args.command, "operator",
                               job_id=getattr(args, "job_id", None))
        print(json.dumps(record.get("last_control"), sort_keys=True))
        return 0 if record["last_control"]["outcome"] != "refused" else 1
    except GateError as exc:
        log(str(exc))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
