#!/usr/bin/python3
"""Fixed, stdlib-only seed bootstrap. Never import an unverified generation.

This file belongs to full application delivery, not the signed helper archive.
Its only installation source is a completed, protected normal-install receipt.
"""
from __future__ import annotations

import hashlib
import json
from itertools import islice
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile

INSTALL = Path("/opt/shotdeck")
STATE = Path("/var/lib/shotdeck/updater")
SHA = re.compile(r"[0-9a-f]{64}\Z")
SEED = re.compile(r"s[1-9][0-9]{0,5}-[0-9a-f]{12}\Z")
MAX_MANIFEST = 4 * 1024 * 1024


class Refused(RuntimeError): pass


def canonical(value): return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()
def digest(raw): return hashlib.sha256(raw).hexdigest()


def bounded_paths(root, maximum):
    paths = list(islice(root.rglob("*"), maximum + 1))
    if len(paths) > maximum: raise Refused("Recovery tree exceeds its entry bound")
    return sorted(paths)


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result: raise Refused("Duplicate protected state key")
        result[key] = value
    return result


def directory(path):
    path = Path(path).absolute()
    if path.parent != path: directory(path.parent)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise Refused("Unprotected directory in recovery bootstrap")
    return path


def read(path, maximum=512 * 1024):
    directory(path.parent)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        info = os.fstat(descriptor)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != 0
                or info.st_mode & 0o022 or info.st_size > maximum):
            raise Refused("Unprotected or oversized recovery input")
        with os.fdopen(descriptor, "rb", closefd=False) as stream: raw = stream.read(maximum + 1)
        if len(raw) > maximum: raise Refused("Recovery input exceeded its bound")
        return raw
    finally: os.close(descriptor)


def read_metric(path, maximum):
    """Read fixed procfs metrics; PSI files are kernel-owned mode 0666.

    Signing state still uses read() and its strict write-permission checks.
    No caller-selected path or writable file outside procfs is accepted here.
    """
    if path not in {Path('/proc/meminfo'), Path('/proc/pressure/memory'), Path('/proc/pressure/io')}:
        raise Refused('Unknown kernel metric')
    directory(path.parent)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC | os.O_NONBLOCK)
    try:
        info = os.fstat(descriptor)
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_nlink != 1
                or info.st_dev != os.stat('/proc').st_dev or info.st_size > maximum):
            raise Refused('Kernel metric is not a bounded procfs file')
        with os.fdopen(descriptor, 'rb', closefd=False) as stream: raw = stream.read(maximum + 1)
        if len(raw) > maximum: raise Refused('Kernel metric exceeded its bound')
        return raw
    finally: os.close(descriptor)


def document(path, maximum=512 * 1024):
    value = json.loads(read(path, maximum), object_pairs_hook=unique)
    if not isinstance(value, dict): raise Refused("Invalid protected document")
    return value


def envelope(path):
    value = document(path)
    if set(value) != {"record", "sha256"} or not isinstance(value["record"], dict) or digest(canonical(value["record"])) != value["sha256"]:
        raise Refused("Protected recovery receipt is corrupt")
    return value["record"]


def identity(path):
    directory(path.parent)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != 0 or info.st_mode & 0o022 or info.st_size > 512 * 1024 * 1024:
            raise Refused("Immutable recovery file changed ownership/type")
        checksum = hashlib.sha256()
        for chunk in iter(lambda: stream.read(1024 * 1024), b""): checksum.update(chunk)
    return {"sha256": checksum.hexdigest(), "size": info.st_size, "mode": stat.S_IMODE(info.st_mode)}


def verify_seed(row):
    if (not isinstance(row, dict) or set(row) != {"name", "revision", "sha256"}
            or type(row["revision"]) is not int or not 1 <= row["revision"] <= 999999
            or not isinstance(row["sha256"], str) or not SHA.fullmatch(row["sha256"])
            or row["name"] != f"s{row['revision']}-{row['sha256'][:12]}"):
        raise Refused("Invalid accepted seed identity")
    root = directory(INSTALL / "recovery-seeds" / row["name"])
    manifest = document(root / "SEED.json", MAX_MANIFEST)
    if digest(canonical(manifest)) != row["sha256"] or manifest.get("python") != "bin/python":
        raise Refused("Seed identity differs from its durable acceptance")
    expected = manifest.get("files")
    if not isinstance(expected, dict) or not 1 <= len(expected) <= 10000:
        raise Refused("Seed file inventory is invalid")
    observed = {}; total = 0
    for path in bounded_paths(root, 20000):
        relative = path.relative_to(root).as_posix()
        if relative == "SEED.json": continue
        info = path.lstat()
        if info.st_uid != 0: raise Refused("Seed ownership changed")
        if stat.S_ISDIR(info.st_mode):
            directory(path); continue
        if "__pycache__" in path.parts or path.suffix in {".pyc", ".pth"}: raise Refused("Seed has unrecorded executable bytecode/import hooks")
        if stat.S_ISLNK(info.st_mode):
            if not path.resolve(strict=True).is_relative_to(root): raise Refused("Seed links outside its retained runtime")
            observed[relative] = {"link": os.readlink(path)}
        elif stat.S_ISREG(info.st_mode):
            observed[relative] = identity(path); total += info.st_size
        else: raise Refused("Unsupported seed filesystem entry")
        if len(observed) > 10000 or total > 384 * 1024 * 1024: raise Refused("Seed exceeds bounded inventory")
    if observed != expected: raise Refused("Seed files differ from its accepted complete inventory")
    python = root / "bin/python"
    if python.is_symlink() or not os.access(python, os.X_OK): raise Refused("Seed has no independent interpreter")
    if not re.search(rb"^include-system-site-packages\s*=\s*false\s*$", read(root / "pyvenv.cfg", 16384), re.MULTILINE):
        raise Refused("Seed inherits mutable dependencies")
    return python


def selected_seed():
    state = envelope(STATE / "seed/state.json")
    if (set(state) != {"schema_version", "high_water_revision", "revisions", "selected", "previous"}
            or type(state["schema_version"]) is not int or state["schema_version"] != 1
            or type(state["high_water_revision"]) is not int or not 0 <= state["high_water_revision"] <= 999999
            or not isinstance(state["revisions"], dict) or len(state["revisions"]) > 4096):
        raise Refused("Seed selection receipt is corrupt")
    for key in ("selected", "previous"):
        row = state[key]
        if row is None: continue
        if (not isinstance(row, dict) or type(row.get("revision")) is not int
                or state["revisions"].get(str(row["revision"])) != row.get("sha256")):
            raise Refused("Seed selection is absent from immutable revision history")
        try: return verify_seed(row)
        except (OSError, ValueError, Refused): continue
    raise Refused("No accepted independent seed is usable; attended recovery is required")


def completed_application():
    directory(INSTALL)
    link = INSTALL / "current"
    if not link.is_symlink(): raise Refused("Application selector is unavailable")
    target = Path(os.readlink(link)); root = target if target.is_absolute() else INSTALL / target
    if root.parent != INSTALL / "releases" or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+\-]{0,199}", root.name):
        raise Refused("Application selector escaped its immutable release directory")
    directory(root)
    if document(STATE / "activation-enrolled.json") != {"schema_version": 1}:
        raise Refused("Application install journaling is not enrolled")
    journal = envelope(STATE / "activation-journal.json")
    if (journal.get("phase") != "completed" or journal.get("operation") != "install"
            or journal.get("service_name") not in ("shotdeck", "shotdeck.service") or journal.get("recovery") is not None):
        raise Refused("Wait for the normal application install to complete")
    candidate = journal.get("candidate")
    if (not isinstance(candidate, dict) or candidate.get("directory") != root.name
            or candidate.get("metadata_matches") is not True or not isinstance(candidate.get("tree_sha256"), str)
            or not SHA.fullmatch(candidate["tree_sha256"])):
        raise Refused("Application source lacks an authenticated completed receipt")
    checksum = hashlib.sha256(); count = 0
    for path in bounded_paths(root, 40000):
        if path.name == ".shotdeck-release.json": continue
        relative = path.relative_to(root).as_posix(); count += 1
        if count > 40000: raise Refused("Application exceeds its inventory bound")
        info = path.lstat()
        if stat.S_ISDIR(info.st_mode):
            directory(path); checksum.update(f"dir:{relative}\n".encode())
        elif stat.S_ISREG(info.st_mode):
            checksum.update(f"file:{relative}\n".encode())
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            with os.fdopen(descriptor, "rb") as stream:
                opened = os.fstat(stream.fileno())
                if (not stat.S_ISREG(opened.st_mode) or opened.st_uid != 0 or opened.st_nlink != 1
                        or opened.st_mode & 0o022 or opened.st_size > 512 * 1024 * 1024):
                    raise Refused("Application file is not immutable")
                for chunk in iter(lambda: stream.read(1024 * 1024), b""): checksum.update(chunk)
        else: raise Refused("Application source contains aliases or special files")
    if checksum.hexdigest() != candidate["tree_sha256"]: raise Refused("Authenticated application source changed")
    return root


def seed_install_admission():
    """Safe staging-phase deferral, never a deadline around seed activation."""
    values = {}
    for line in read_metric(Path("/proc/meminfo"), 32768).decode("ascii").splitlines():
        match = re.fullmatch(r"([A-Za-z_()]+):\s+(\d+) kB", line)
        if match: values[match[1]] = int(match[2]) * 1024
    if not {"MemAvailable", "Dirty", "Writeback"}.issubset(values): raise Refused("Seed installation waits for reliable memory information")
    available = values["MemAvailable"] - values["Dirty"] - values["Writeback"]
    if available < 192 * 1024 * 1024: raise Refused("Seed installation waits for at least 192 MiB of clean available memory")
    for resource, limits in (("memory", {"some": 5.0, "full": 1.0}), ("io", {"some": 10.0, "full": 2.0})):
        observed = {}
        for line in read_metric(Path("/proc/pressure") / resource, 16384).decode("ascii").splitlines():
            fields = line.split()
            if not fields or fields[0] not in limits: continue
            numbers = dict(item.split("=", 1) for item in fields[1:])
            value = numbers.get("avg10", "")
            if not re.fullmatch(r"[0-9]+(?:\.[0-9]+)?", value): raise Refused("Seed installation waits for reliable pressure information")
            observed[fields[0]] = float(value)
        if set(observed) != set(limits) or any(observed[key] > limit for key, limit in limits.items()):
            raise Refused("Seed installation waits for low " + resource + " pressure")
    for path in (INSTALL, Path("/var/tmp")):
        disk = os.statvfs(path)
        if disk.f_bavail * disk.f_frsize < 768 * 1024 * 1024:
            raise Refused("Seed installation waits for sufficient staging disk space")


def application_binding(python):
    """Identify the completed app receipt without importing or executing it."""
    journal = envelope(STATE / 'activation-journal.json')
    link = INSTALL / 'current'
    if not link.is_symlink(): raise Refused('Application selector is unavailable')
    target = Path(os.readlink(link)); target = target if target.is_absolute() else INSTALL / target
    if (target.parent != INSTALL / 'releases' or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._+\-]{0,199}', target.name)
            or journal.get('phase') != 'completed' or journal.get('operation') != 'install'
            or journal.get('service_name') not in ('shotdeck', 'shotdeck.service')
            or not isinstance(journal.get('candidate'), dict)
            or journal['candidate'].get('directory') != target.name
            or journal['candidate'].get('metadata_matches') is not True):
        raise Refused('Seed source needs a completed normal application receipt')
    manifest = document(python.parent.parent / 'SEED.json', MAX_MANIFEST)
    return {'schema_version': 1, 'application_directory': target.name,
            'activation_journal_sha256': digest(canonical(journal)), 'seed_manifest_sha256': digest(canonical(manifest))}


def remember_application(binding):
    """Optimization receipt only; immutable seed provenance is never rewritten."""
    folder = directory(STATE / 'seed'); target = folder / 'application-source.json'
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=folder, prefix='.application-source-', delete=False) as stream:
            temporary = Path(stream.name); os.fchmod(stream.fileno(), 0o600)
            stream.write(canonical({'record': binding, 'sha256': digest(canonical(binding))}) + b'\n')
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temporary, target)
        descriptor = os.open(folder, os.O_RDONLY | os.O_DIRECTORY)
        try: os.fsync(descriptor)
        finally: os.close(descriptor)
    finally:
        if temporary is not None: temporary.unlink(missing_ok=True)


def install_seed():
    # A repeated timer pass must not recreate an offline venv or rehash the
    # large app. The existing seed and exact completed receipt prove this
    # source was already handled. Each new app receipt takes the full path once,
    # even when its identical seed revision retains the original provenance.
    if not os.path.lexists(STATE / "seed/pending.json"):
        try:
            python = selected_seed()
            source = document(python.parent.parent / "SEED.json", MAX_MANIFEST)["source"]
            binding = application_binding(python)
            initial = (source['application_directory'] == binding['application_directory']
                       and source['activation_journal_sha256'] == binding['activation_journal_sha256'])
            try: handled = envelope(STATE / 'seed/application-source.json') == binding
            except (OSError, ValueError, KeyError, Refused): handled = False
            if initial or handled:
                enable_surface(python)
                print('{"outcome":"already_completed"}'); return 0
        except (OSError, ValueError, KeyError, Refused): pass
    seed_install_admission()
    root = completed_application()
    source = root / "updater-bootstrap/public-updater"
    wheels = source / "seed-wheels"
    inventory = document(wheels / "inventory.json")
    if set(inventory) != {"schema_version", "files"} or inventory["schema_version"] != 1 or not isinstance(inventory["files"], dict) or not 1 <= len(inventory["files"]) <= 64:
        raise Refused("Offline bootstrap dependencies are incomplete")
    for name, expected in inventory["files"].items():
        if not re.fullmatch(r"[A-Za-z0-9_.+\-]{1,180}\.whl", name) or not isinstance(expected, dict) or set(expected) != {"sha256", "size"}:
            raise Refused("Offline dependency inventory is invalid")
        actual = identity(wheels / name)
        if {key: actual[key] for key in ("sha256", "size")} != expected: raise Refused("Offline dependency identity changed")
    if set(path.name for path in wheels.iterdir()) != set(inventory["files"]) | {"inventory.json"}:
        raise Refused("Offline dependencies contain unrecorded files")
    workspace = Path(tempfile.mkdtemp(prefix="shotdeck-seed-install-", dir="/var/tmp"))
    os.chmod(workspace, 0o700)
    environment = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "TMPDIR": str(workspace), "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        venv = workspace / "bootstrap"
        subprocess.run(["/usr/bin/python3", "-m", "venv", "--copies", str(venv)], check=True, timeout=180, env=environment)
        python = venv / "bin/python"
        subprocess.run([str(python), "-I", "-B", "-m", "pip", "--isolated", "install", "--no-index", "--no-deps", "--no-compile", "--no-cache-dir", "--disable-pip-version-check",
                        *[str(wheels / name) for name in sorted(inventory["files"])]], check=True, timeout=300, env=environment)
        for hook in venv.rglob("*.pth"): hook.unlink()
        code = ("import json,sys;sys.path.insert(0," + repr(str(source / "src")) + ");"
                + "from shotdeck_seed.lifecycle import SeedInstaller;"
                + "result=SeedInstaller().install_from_application(" + repr(str(root)) + ");"
                + "print(json.dumps(result));raise SystemExit(0 if result['outcome'] in {'accepted','already_completed','newer_seed_retained'} else 75)")
        # Never introduce an outer kill deadline across activation. Its durable
        # journal and phase-specific subprocess bounds own interruption safety.
        result = subprocess.run([str(python), "-I", "-B", "-c", code], check=False, env=environment).returncode
        if result == 0:
            python = selected_seed(); enable_surface(python)
            binding = application_binding(python)
            if binding['application_directory'] == root.name: remember_application(binding)
        return result
    finally:
        # All synchronous children have exited before cleanup; no active app,
        # service or immutable seed ever uses this private disk workspace.
        shutil.rmtree(workspace)


def enable_surface(python):
    code = "from shotdeck_seed.lifecycle import SeedManager;SeedManager().enable_surface()"
    subprocess.run([str(python), "-I", "-B", "-c", code], check=True,
                   env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "PYTHONDONTWRITEBYTECODE": "1"})


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    if os.geteuid() != 0: raise Refused("Recovery selection requires the protected root launcher")
    if args == ["install-seed"]: return install_seed()
    if args in (["app-start-condition"], ["app-prepare-start"]) and not os.path.lexists(Path("/var/lib/shotdeck/recovery-access/access-latch.json")):
        # Before C enrollment the B lifecycle gate remains authoritative.
        # A missing seed must never prevent an ordinary app from starting.
        return 0
    if args == ["restore-network"] and not os.path.lexists(Path("/var/lib/shotdeck/recovery-access/network-lease.json")):
        return 0
    allowed = {"gateway", "gateway-executor", "portal", "screen", "restore-network", "app-start-condition",
               "app-prepare-start", "seed-status", "seed-reconcile", "worker-info", "worker-run", "admin-review"}
    if not args or args[0] not in allowed or len(args) > (8 if args[0] == "admin-review" else 5):
        raise Refused("Unknown fixed recovery command")
    python = selected_seed()
    environment = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1"}
    for key in ("LISTEN_PID", "LISTEN_FDS", "LISTEN_FDNAMES", "NOTIFY_SOCKET", "INVOCATION_ID"):
        if key in os.environ: environment[key] = os.environ[key]
    os.chdir("/")
    os.execve(python, [str(python), "-I", "-B", "-m", "shotdeck_seed.dispatch", *args], environment)
    return 0


if __name__ == "__main__":
    try: raise SystemExit(main())
    except (OSError, ValueError, Refused, subprocess.SubprocessError) as exc:
        print("Independent recovery unavailable: " + str(exc)[:300], file=sys.stderr)
        raise SystemExit(75)
