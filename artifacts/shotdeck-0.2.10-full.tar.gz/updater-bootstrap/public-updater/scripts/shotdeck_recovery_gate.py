#!/usr/bin/env python3
"""Fixed, stdlib-only service admission before any replaceable app is loaded.

An unused/clean normal activation needs no recovery runtime. Any persistent
uncertainty must be inspected by the integrity-verified protected runtime;
failure to select it refuses startup. No environment variable selects a root,
runtime, capability, or alternate executable.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys
import tempfile
import time

STATE_ROOT = Path("/var/lib/shotdeck/updater")
DATA_ROOT = Path("/var/lib/shotdeck")
SCRIPTS_ROOT = Path("/opt/shotdeck/public-updater-installer/scripts")
COMMANDS = {"start", "observe-stop", "failure", "watchdog", "boot"}
TERMINAL = {"completed", "rolled_back", "reconciled"}
FIELDS = {"schema_version", "transaction_id", "operation", "service_name", "phase",
          "candidate", "current_before", "previous_before", "boot_id", "owner", "recovery"}
OWNER_FIELDS = {"pid", "start_ticks", "lock_fd", "lock_device", "lock_inode"}


def present(path):
    return os.path.lexists(path)


def recovery_capabilities():
    root = STATE_ROOT / "recovery"
    candidates = (root / "capability.json", root / "customer-capability.json")
    return [path for path in candidates if present(path)]


def protected_directories(path):
    for parent in (Path(path), *Path(path).parents):
        if not present(parent):
            continue
        info = parent.stat(follow_symlinks=False)
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise ValueError("Unprotected recovery directory")


def protected(path, *, limit=1024 * 1024):
    path = Path(path)
    protected_directories(path.parent)
    descriptor = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0
                or info.st_mode & 0o022 or info.st_size > limit):
            raise ValueError("Unprotected recovery file")
        value = stream.read(limit + 1)
        if len(value) > limit:
            raise ValueError("Oversized recovery file")
        return value


def parse_json(payload):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate recovery property")
            result[key] = value
        return result
    return json.loads(payload, object_pairs_hook=unique)


def identity(value, *, required=False):
    if value is None and not required:
        return True
    return (isinstance(value, dict)
        and set(value) == {"directory", "version", "tree_sha256", "metadata_matches"}
        and isinstance(value["directory"], str)
        and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+\-]{0,199}", value["directory"]) is not None
        and isinstance(value["version"], str) and 0 < len(value["version"]) <= 128
        and isinstance(value["tree_sha256"], str) and re.fullmatch(r"[0-9a-f]{64}", value["tree_sha256"]) is not None
        and type(value["metadata_matches"]) is bool)


def clean_activation():
    journal = STATE_ROOT / "activation-journal.json"
    enrolled = STATE_ROOT / "activation-enrolled.json"
    if not present(journal) and not present(enrolled):
        return not present(STATE_ROOT / "activation-start-permit.json")
    marker = parse_json(protected(enrolled))
    envelope = parse_json(protected(journal))
    if marker != {"schema_version": 1} or type(marker["schema_version"]) is not int:
        return False
    if not isinstance(envelope, dict) or set(envelope) != {"record", "sha256"}:
        return False
    record = envelope["record"]
    if not isinstance(record, dict):
        return False
    legacy_terminal = set(record) == FIELDS - {"boot_id", "owner", "recovery"} and record.get("phase") in {"completed", "rolled_back"}
    if set(record) != FIELDS and not legacy_terminal:
        return False
    checksum = hashlib.sha256(json.dumps(record, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()
    if checksum != envelope["sha256"]:
        return False
    if (type(record["schema_version"]) is not int or record["schema_version"] != 1
            or not isinstance(record["transaction_id"], str) or re.fullmatch(r"[0-9a-f]{32}", record["transaction_id"]) is None
            or record["operation"] not in {"install", "manual_rollback"}
            or record["service_name"] not in {"shotdeck", "shotdeck.service"} or record["phase"] not in TERMINAL
            or not all(identity(record[key], required=key == "candidate")
                       for key in ("candidate", "current_before", "previous_before"))):
        return False
    if not legacy_terminal and (not isinstance(record["boot_id"], str) or not 0 < len(record["boot_id"]) <= 64
            or not isinstance(record["owner"], dict) or set(record["owner"]) != OWNER_FIELDS
            or any(type(value) is not int or value < (1 if key in {"pid", "start_ticks", "lock_inode"} else 0)
                   for key, value in record["owner"].items())):
        return False
    if record["phase"] == "reconciled":
        # A recovery receipt must always be checked by the protected runtime.
        return False
    return record.get("recovery") is None and not present(STATE_ROOT / "activation-start-permit.json")


def recovery_needed():
    protected_directories(STATE_ROOT)
    root = STATE_ROOT / "recovery"
    # Presence of any durable recovery artifact, including an orphaned permit,
    # prevents a directory/record deletion from becoming a clean fast path.
    if present(root):
        protected_directories(root)
        if root.is_symlink() or not root.is_dir():
            return True
        if any(root.iterdir()):
            return True
    return not clean_activation()


def protected_python():
    # Recovery never falls back to the unpinned updater-current symlink.
    protected(DATA_ROOT / "signing/updates/active.json")
    source = protected(SCRIPTS_ROOT / "prompted_update_flow.py")
    namespace = {"__name__": "_shotdeck_recovery_selector", "__file__": str(SCRIPTS_ROOT / "prompted_update_flow.py")}
    for key in tuple(os.environ):
        if key.startswith("SHOTDECK_"):
            os.environ.pop(key)
    exec(compile(source, namespace["__file__"], "exec"), namespace)
    namespace["DATA_ROOT"] = DATA_ROOT
    binary = namespace["select_updater_binary"]()
    return binary.with_name("python")


def observe_stop():
    root = STATE_ROOT / "recovery"
    capabilities = recovery_capabilities()
    if not capabilities:
        return
    # This is observation, never admission. Avoid importing/hashing the pinned
    # runtime while systemd is waiting for the app's stop job to finish.
    for capability in capabilities:
        protected(capability)
    boot = protected(Path("/proc/sys/kernel/random/boot_id"), limit=128).decode().strip()
    value = {"schema_version": 1, "boot_id": boot,
             "invocation_id": os.environ.get("INVOCATION_ID", ""),
             "service_result": os.environ.get("SERVICE_RESULT", ""),
             "exit_code": os.environ.get("EXIT_CODE", ""),
             "exit_status": os.environ.get("EXIT_STATUS", ""),
             "recorded_monotonic_usec": int(time.monotonic() * 1_000_000)}
    if (re.fullmatch(r"[A-Za-z0-9-]{1,64}", boot) is None
            or re.fullmatch(r"[0-9a-f]{32}", value["invocation_id"]) is None
            or any(len(value[key]) > 64 or any(ord(c) < 32 for c in value[key])
                   for key in ("service_result", "exit_code", "exit_status"))):
        raise ValueError("Invalid systemd stop observation")
    path = root / "stop-observation.json"
    if present(path):
        protected(path)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=root, prefix=".stop-observation-", delete=False) as stream:
            temporary = Path(stream.name)
            os.fchmod(stream.fileno(), 0o600)
            stream.write(json.dumps(value, sort_keys=True, separators=(",", ":")).encode() + b"\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        descriptor = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        try:
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1 or argv[0] not in COMMANDS:
        return 2
    command = argv[0]
    try:
        if command == "observe-stop":
            observe_stop()
            return 0
        # File presence only selects the verifier. The pinned runtime grants
        # admission from the exact authenticated capability for the incident.
        if command != "start" and not recovery_capabilities():
            return 0
        needed = recovery_needed()
        if not needed:
            return 0
        python = protected_python()
        os.execv(str(python), [str(python), "-I", "-B", "-m", "shotdeck_updater.recovery_native", command])
    except (OSError, ValueError, KeyError, TypeError, SystemExit) as exc:
        print(f"Shotdeck recovery admission unavailable: {exc}", file=sys.stderr)
        return 1 if command == "start" else 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
