"""Small protected records; never import application or selected updater code."""
from __future__ import annotations

from contextlib import contextmanager
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import tempfile


class Refused(RuntimeError):
    def __init__(self, code, message):
        super().__init__(message)
        self.code = code


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode()


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise Refused("invalid_record", "A recovery record contains duplicate fields.")
        result[key] = value
    return result


def protected_parents(path):
    for parent in Path(path).parents:
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise Refused("unsafe_storage", "Recovery storage needs attended repair.")


def directory(path, mode=0o700):
    path = Path(path)
    if not path.exists():
        protected_parents(path)
        path.mkdir(mode=mode)
        sync(path.parent)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
        raise Refused("unsafe_storage", "Recovery storage needs attended repair.")
    protected_parents(path)
    return path


def sync(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def read(path, limit=262144):
    path = Path(path)
    protected_parents(path)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022
                or info.st_nlink != 1 or info.st_size > limit):
            raise Refused("unsafe_storage", "Recovery record is not a bounded protected file.")
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise Refused("invalid_record", "Recovery record is too large.")
    return raw


def document(path, limit=262144):
    try:
        value = json.loads(read(path, limit), object_pairs_hook=unique,
                           parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (ValueError, UnicodeError) as exc:
        raise Refused("invalid_record", "Recovery record needs attended review.") from exc
    if not isinstance(value, dict):
        raise Refused("invalid_record", "Recovery record has an invalid format.")
    return value


def write(path, value, *, mode=0o600):
    path = Path(path)
    directory(path.parent)
    raw = canonical(value) + b"\n"
    if len(raw) > 262144:
        raise Refused("invalid_record", "Recovery record exceeds its storage budget.")
    if os.path.lexists(path):
        read(path)  # refuse aliased/unprotected destinations before replacement
    descriptor, temporary = tempfile.mkstemp(prefix=".record-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            os.fchmod(stream.fileno(), mode)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        sync(path.parent)
    finally:
        if os.path.lexists(temporary):
            os.unlink(temporary)


def remove(path):
    path = Path(path)
    if os.path.lexists(path):
        read(path)
        path.unlink()
        sync(path.parent)


def envelope(path):
    value = document(path)
    if (set(value) != {"record", "sha256"}
            or hashlib.sha256(canonical(value["record"])).hexdigest() != value["sha256"]):
        raise Refused("invalid_record", "Recovery transaction needs attended review.")
    return value["record"]


def save(path, value):
    write(path, {"record": value, "sha256": hashlib.sha256(canonical(value)).hexdigest()})


@contextmanager
def lock(path):
    path = Path(path)
    directory(path.parent)
    fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o077 or info.st_nlink != 1:
            raise Refused("unsafe_storage", "Recovery ownership needs attended repair.")
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise Refused("busy", "Another recovery operation is in progress.") from exc
        yield fd
    finally:
        os.close(fd)


def boot_id():
    return Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def owner(pid=None):
    pid = os.getpid() if pid is None else pid
    raw = Path(f"/proc/{pid}/stat").read_text()
    return {"pid": pid, "ticks": int(raw[raw.rfind(")") + 2:].split()[19]), "boot": boot_id()}


def alive(value):
    try:
        return value == owner(value["pid"])
    except (OSError, ValueError, KeyError, TypeError):
        return False
