"""Signed Release C access admission, independent of the pinned updater.

Installation alone never enables network recovery. Qualification produces an
exact signed capability; no such capability is shipped by the code-only change.
"""
from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import re

from .records import Refused, canonical, document

PATH = Path("/etc/shotdeck/recovery-access-capability.json")
DOMAIN = b"shotdeck-recovery-access-capability-v1\0"
CHECKS = frozenset({"seed_lifecycle", "whole_support_failure", "pairing_auth", "origin_csrf",
                    "display_ownership", "network_off_hotspot", "offline_exports", "encrypted_diagnostics",
                    "helper_repair", "old_app_bootstrap", "maximum_inputs", "concurrent_memory",
                    "one_app_restart", "next_update", "connected_machine"})
FIELDS = {"schema_version", "product", "scope", "issued_at", "expires_at", "policy_sha256",
          "runtime_sha256", "seed_sha256", "support_manifest_sha256", "support_protocol", "seed_protocol", "profile",
          "qualification_sha256", "checks"}
PROFILE_FIELDS = {"board", "os_codename", "hardware_profile", "control_topology"}
SHA = re.compile(r"[0-9a-f]{64}\Z")


def validate(payload, *, qualified=True):
    if (not isinstance(payload, dict) or set(payload) != FIELDS or payload["schema_version"] != 1
            or type(payload["schema_version"]) is not int or payload["product"] != "shotdeck"
            or payload["scope"] != "customer-recovery-access" or len(canonical(payload)) > 16384
            or type(payload["seed_protocol"]) is not int or payload["seed_protocol"] != 1
            or type(payload["support_protocol"]) is not int or payload["support_protocol"] != 1):
        raise Refused("not_qualified", "Recovery access has not been qualified for this installation.")
    for name in ("policy_sha256", "runtime_sha256", "seed_sha256", "qualification_sha256"):
        if not isinstance(payload[name], str) or not SHA.fullmatch(payload[name]):
            raise Refused("not_qualified", "Recovery qualification identity is invalid.")
    if (payload["support_manifest_sha256"] is not None
            and (not isinstance(payload["support_manifest_sha256"], str) or not SHA.fullmatch(payload["support_manifest_sha256"]))):
        raise Refused("not_qualified", "Recovery helper qualification identity is invalid.")
    profile = payload["profile"]
    if (not isinstance(profile, dict) or set(profile) != PROFILE_FIELDS
            or any(not isinstance(v, str) or not v or len(v) > 128 for v in profile.values())):
        raise Refused("not_qualified", "Recovery hardware qualification is invalid.")
    # This backend reads BCM2837 GPIO registers and drives only the reviewed
    # legacy screen pins. Other topologies need their own implementation/proof.
    if profile != {"board": "Raspberry Pi Zero 2 W Rev 1.0", "os_codename": "trixie",
                   "hardware_profile": "rev1_2_3_5f_bbw", "control_topology": "legacy-holding-latching"}:
        raise Refused("unsupported_hardware", "Use the attended recovery route for this hardware.")
    checks = payload["checks"]
    if (not isinstance(checks, dict) or set(checks) != CHECKS
            or any(type(v) is not bool for v in checks.values()) or qualified and not all(checks.values())):
        raise Refused("not_qualified", "Release C qualification is incomplete.")
    try:
        issued = datetime.fromisoformat(payload["issued_at"].replace("Z", "+00:00"))
        expires = datetime.fromisoformat(payload["expires_at"].replace("Z", "+00:00"))
        if issued.tzinfo is None or expires.tzinfo is None or not 0 < (expires - issued).total_seconds() <= 366 * 86400:
            raise ValueError()
    except (ValueError, TypeError, AttributeError) as exc:
        raise Refused("not_qualified", "Recovery qualification dates are invalid.") from exc
    return payload


def signed(payload, private_key):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    validate(payload)
    if not isinstance(private_key, Ed25519PrivateKey):
        raise Refused("wrong_signer", "Use the authorized update signer.")
    pem = private_key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    return {**payload, "signature": {"algorithm": "ed25519", "key_id": hashlib.sha256(pem).hexdigest()[:16],
            "value": base64.b64encode(private_key.sign(DOMAIN + canonical(payload))).decode()}}


def verify(value, public_key):
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    if not isinstance(value, dict) or set(value) != FIELDS | {"signature"}:
        raise Refused("not_qualified", "Recovery access authorization is invalid.")
    payload = validate({key: val for key, val in value.items() if key != "signature"})
    signature = value["signature"]
    try:
        if not isinstance(signature, dict) or set(signature) != {"algorithm", "key_id", "value"}:
            raise ValueError()
        key = serialization.load_pem_public_key(public_key)
        raw = base64.b64decode(signature["value"], validate=True)
        if (not isinstance(key, Ed25519PublicKey) or signature["algorithm"] != "ed25519"
                or signature["key_id"] != hashlib.sha256(public_key).hexdigest()[:16]
                or len(raw) != 64 or base64.b64encode(raw).decode() != signature["value"]):
            raise ValueError()
        key.verify(raw, DOMAIN + canonical(payload))
    except (ValueError, TypeError, InvalidSignature) as exc:
        raise Refused("wrong_signer", "Recovery access authorization does not match this device's authority.") from exc
    now = datetime.now(timezone.utc)
    if not datetime.fromisoformat(payload["issued_at"].replace("Z", "+00:00")) <= now < datetime.fromisoformat(payload["expires_at"].replace("Z", "+00:00")):
        raise Refused("not_qualified", "Recovery access authorization has expired or the clock needs correction.")
    return payload


def load(authority, seed_sha256, profile, *, path=PATH):
    value = document(path, 16384)
    payload = verify(value, authority["public_key_pem"])
    if (payload["policy_sha256"] != hashlib.sha256(canonical(authority["policy"])).hexdigest()
            or payload["runtime_sha256"] != authority["record"]["runtime_sha256"]
            or payload["seed_sha256"] != seed_sha256 or payload["profile"] != profile):
        raise Refused("not_qualified", "Recovery qualification belongs to a different installation.")
    return payload
