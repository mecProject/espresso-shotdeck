"""Attended, proven-outcome review; no portal action and no generic override.

Review changes only a C operation record after its exact durable completion is
proved. Unknown native work is never retried, declared failed or guessed from a
version string. The original unknown record and a checksummed audit remain.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import sys

from . import environment as env
from .jobs import Jobs, ID, MUTATIONS, TERMINAL, restored_hotspot
from .records import Refused, canonical, directory, document, envelope, read, save, lock, remove

ROOT = Path("/var/lib/shotdeck/recovery-access")
STATE = Path("/var/lib/shotdeck/updater")
SIGNING = Path("/var/lib/shotdeck/signing")
INSTALL = Path("/opt/shotdeck")
SHA = re.compile(r"[0-9a-f]{64}\Z")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


def refuse(message="No exact terminal proof is available. Preserve the records and contact Shotdeck support."):
    raise Refused("review_unproven", message)


def seed_provenance():
    from shotdeck_seed.lifecycle import SeedManager
    seed = SeedManager().select()
    root = seed["path"].resolve(strict=True)
    if Path(sys.prefix).resolve(strict=True) != root or not Path(__file__).resolve(strict=True).is_relative_to(root):
        refuse("Use the verified independent seed's fixed admin-review entrypoint.")


def executor_stopped(record):
    from .executor import unit_for
    observed = env.show(unit_for(record))
    if observed.get("ActiveState") not in {"inactive", "failed"} or observed.get("MainPID") != "0":
        refuse("The operation's system service must fully stop before attended review.")
    group = observed.get("ControlGroup", "")
    if not group:
        if observed.get("SubState") not in {"dead", "failed"}:
            refuse()
        return
    # Template instances normally live in their per-template slice; the exact
    # final unit name and every parent must still be safe kernel cgroup names.
    if (not group.startswith("/") or Path(group).name != unit_for(record)
            or any(part in {".", ".."} for part in Path(group).parts)):
        refuse("The operation's process ownership cannot be established.")
    root = Path("/sys/fs/cgroup") / group.lstrip("/")
    if root.is_symlink() or any(parent.is_symlink() for parent in root.parents):
        refuse("The operation's kernel ownership path is aliased.")
    if not root.exists():
        return
    count = 0
    for parent, folders, files in os.walk(root, followlinks=False):
        count += 1
        if count > 256 or any((Path(parent) / name).is_symlink() for name in folders):
            refuse()
        if "cgroup.procs" not in files or (Path(parent) / "cgroup.procs").read_text().strip():
            refuse("A descendant operation process is still running.")


def no_pending(record, jobs):
    for row in jobs.all():
        if row["job_id"] != record["job_id"] and (row["state"] not in TERMINAL or row["state"] == "interrupted"):
            refuse("Another recovery operation must finish or be reviewed first.")
    from .executor import old_jobs_clear
    old_jobs_clear()
    for path in (STATE / "seed/pending.json", STATE / "support/pending.json", STATE / "restore-transaction.json",
                 STATE / "activation-start-permit.json", STATE / "recovery/permit.json", SIGNING / "maintenance.json",
                 SIGNING / "licence/pending.json", SIGNING / "updates/pending.json", SIGNING / "updates/runtime-transition.json"):
        if os.path.lexists(path):
            refuse("An unfinished native/helper/signing transaction still needs its dedicated recovery route.")
    activation_path = STATE / "activation-journal.json"
    if os.path.lexists(STATE / "activation-enrolled.json") and not os.path.lexists(activation_path):
        refuse()
    if os.path.lexists(activation_path) and envelope(activation_path).get("phase") not in {"completed", "rolled_back", "reconciled"}:
        refuse()
    recovery_path = STATE / "recovery/state.json"
    if os.path.lexists(STATE / "recovery/enrolled.json") and not os.path.lexists(recovery_path):
        refuse()
    if os.path.lexists(recovery_path) and envelope(recovery_path).get("latched") is not False:
        refuse()
    root = Path("/var/lib/shotdeck-restore/jobs")
    if os.path.lexists(root):
        directory(root)
        entries = list(root.iterdir())
        if len(entries) > 1024:
            refuse()
        for entry in entries:
            if not ID.fullmatch(entry.name):
                continue
            directory(entry)
            path = entry / "transaction.json"
            if os.path.lexists(path):
                value = document(path)
                if (value.get("schema_version") != 1 or value.get("restore_id") != entry.name
                        or value.get("state") not in {"committed", "rolled_back"}):
                    refuse("Portable backup restoration has an unresolved outcome.")


def selected_release(identity):
    from shotdeck_seed.authority import tree_digest
    if (not isinstance(identity, dict) or not {"directory", "version", "tree_sha256"} <= set(identity)
            or not isinstance(identity["directory"], str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]{0,199}", identity["directory"])
            or not isinstance(identity["tree_sha256"], str) or not SHA.fullmatch(identity["tree_sha256"])):
        refuse()
    root = INSTALL / "releases"
    path = root / identity["directory"]
    current = INSTALL / "current"
    if (root.is_symlink() or path.is_symlink() or not current.is_symlink()
            or current.resolve(strict=True) != path or path.parent != root
            or read(path / ".shotdeck-version", 128).decode().strip() != identity["version"]
            or tree_digest(path) != identity["tree_sha256"]):
        refuse("The selected release no longer matches the exact completed operation.")


def outcome_receipt(record, jobs):
    path = jobs.root / "outcomes" / (record["job_id"] + ".json")
    if not os.path.lexists(path):
        return None
    value = envelope(path)
    expected = {"schema_version": 1, "job_id": record["job_id"], "request_sha256": record["request_sha256"],
                "action": record["action"], "proof_anchor": record["proof_anchor"]}
    if (set(value) != set(expected) | {"result"} or any(value[name] != item for name, item in expected.items())
            or not isinstance(value["result"], dict)):
        refuse("The recorded operation result differs from its immutable request.")
    return value["result"]


def terminal_proof(record, jobs):
    from shotdeck_seed.authority import read_authority
    authority = read_authority()
    anchor = record.get("proof_anchor")
    if (not isinstance(anchor, dict) or set(anchor) != {"authority_id", "boot_id", "before"}
            or anchor["authority_id"] != authority["authority_id"]):
        refuse("This operation lacks its exact pre-mutation authority anchor.")
    action, params = record["action"], record["params"]
    outcome = outcome_receipt(record, jobs)
    before = anchor["before"]
    if action == "apply":
        journal = envelope(STATE / "activation-journal.json")
        installed = document(SIGNING / "updates/installed.json")
        offer = params["offer"]
        candidate = journal.get("candidate", {})
        if (not isinstance(before, dict) or set(before) != {"transaction_id"}
                or journal.get("phase") != "completed" or journal.get("operation") != "install"
                or journal.get("service_name") not in ("shotdeck", "shotdeck.service") or journal.get("transaction_id") == before["transaction_id"]
                or candidate.get("version") != offer["version"] or candidate.get("metadata_matches") is not True
                or installed.get("generation_id") != authority["authority_id"] or installed.get("manifest_sha256") != offer["manifest_sha256"]
                or installed.get("version") != offer["version"] or installed.get("tree_sha256") != candidate.get("tree_sha256")):
            refuse()
        selected_release(candidate)
        result = {"offer": offer, "outcome": "installed", "transaction_id": journal["transaction_id"]}
        if outcome is not None and outcome != result:
            refuse()
        return result, {"activation": digest(journal), "installed": digest(installed)}
    if action == "rollback":
        state = envelope(STATE / "recovery/state.json")
        incident = state.get("incident_id", "")
        if not isinstance(incident, str) or not SHA.fullmatch(incident):
            refuse()
        receipt = document(STATE / "recovery/receipts" / (incident + ".json"))
        if (state.get("phase") != "completed" or state.get("latched") is not False or state.get("attempts") != 1
                or receipt.get("incident_id") != incident or receipt.get("outcome") != "recovered"
                or receipt.get("target") != params["target"] or state.get("target") != params["target"]
                or receipt.get("authority_id") != authority["authority_id"]
                or receipt.get("capability_sha256") != params["capability_sha256"]
                or state.get("capability_sha256") != params["capability_sha256"]):
            refuse()
        quarantine = document(STATE / "recovery/quarantine.json")
        failed_key = digest({name: receipt["failed"][name] for name in ("version", "tree_sha256")})
        if quarantine.get("releases", {}).get(failed_key) != incident:
            refuse()
        selected_release(params["target"])
        if outcome is not None and outcome != receipt:
            refuse()
        proof = {"recovery": digest(state), "receipt": digest(receipt), "quarantine": digest(quarantine)}
        latch = ROOT / "access-latch.json"
        archived = jobs.root / "reviews" / (record["job_id"] + ".access-latch.json")
        if os.path.lexists(latch) or os.path.lexists(archived):
            value = envelope(latch if os.path.lexists(latch) else archived)
            if value.get("identity") != receipt.get("failed"):
                refuse("Temporary access belongs to a different recovery incident.")
            proof["released_access"] = digest(value)
        return receipt, proof
    if action in {"repair_helpers", "repair_local"}:
        from shotdeck_seed.support import SupportManager
        from shotdeck_seed.lifecycle import SeedManager
        manager = SupportManager()
        offered = params["offer"]
        candidate_sha = offered["manifest_sha256"]
        if not isinstance(candidate_sha, str) or not SHA.fullmatch(candidate_sha):
            refuse()
        receipt = envelope(manager.root / "receipts" / (candidate_sha + ".json"))
        accepted = manager._accepted(); manager._history()
        fields = {"schema_version", "candidate", "previous", "authority_id", "phase", "created_at", "outcome", "initial"}
        phases = {"accepted": "completed", "retained_previous": "reverted", "seed_only": "seed_only"}
        if (set(receipt) != fields or type(receipt["schema_version"]) is not int or receipt["schema_version"] != 1
                or receipt.get("authority_id") != authority["authority_id"]
                or receipt.get("candidate", {}).get("manifest_sha256") != candidate_sha
                or receipt.get("outcome") not in phases or receipt.get("phase") != phases[receipt["outcome"]]
                or type(receipt["initial"]) is not bool
                or not isinstance(before, dict) or set(before) != {"accepted_sha256"}
                or not isinstance(before["accepted_sha256"], str) or not SHA.fullmatch(before["accepted_sha256"])):
            refuse()
        for name in ("candidate", "previous"):
            identity = receipt[name]
            if name == "previous" and identity is None: continue
            if (not isinstance(identity, dict) or set(identity) != {"name", "revision", "manifest_sha256"}
                    or type(identity["revision"]) is not int or not 1 <= identity["revision"] <= 999999
                    or not isinstance(identity["manifest_sha256"], str) or not SHA.fullmatch(identity["manifest_sha256"])
                    or identity["name"] != f"c{identity['revision']}-{identity['manifest_sha256'][:12]}"):
                refuse()
        completed = receipt["outcome"]
        if completed == "accepted":
            expected = candidate_sha
        elif completed == "retained_previous":
            if receipt["previous"] is None: refuse()
            expected = receipt["previous"]["manifest_sha256"]
        else:
            if receipt["previous"] is not None: refuse()
            expected = None
        if action == "repair_local":
            if (offered["target"] == "seed" and completed != "seed_only"
                    or offered["target"] == "previous" and completed == "accepted"
                    or offered["target"] == "previous" and completed == "retained_previous"
                       and expected != offered["retained_manifest_sha256"]):
                refuse("The terminal helper receipt differs from the requested local repair target.")
        proof = {"support_receipt": digest(receipt), "support_acceptance": digest(accepted)}
        if expected is None:
            seed = SeedManager().select()
            if (accepted["selected"] is not None or os.path.lexists(manager.paths.support_current)
                    or action == "repair_local" and seed["sha256"] != offered["seed_sha256"]):
                refuse()
            proof["seed_sha256"] = seed["sha256"]
        else:
            if manager.selected_generation()["manifest_sha256"] != expected:
                refuse()
        if outcome is not None and (outcome.get("outcome") != completed
                or outcome.get("manifest_sha256") != (candidate_sha if completed == "seed_only" else expected)):
            refuse("The completed helper result conflicts with its protected terminal receipt.")
        return {"outcome": completed, "manifest_sha256": expected, "requested_manifest_sha256": candidate_sha,
                "requested_package_installed": completed == "accepted", "reviewed": True}, proof
    if action == "enter":
        from shotdeck_recovery_access.hardware import app_stopped
        value = envelope(ROOT / "access-latch.json")
        if (before is not None or value.get("phase") != "stopped" or value.get("owner") is not None
                or not isinstance(value.get("data"), dict) or not app_stopped()):
            refuse()
        selected_release(value["identity"])
        result = {"entered": True, "access_id": value["id"]}
        if outcome is not None and outcome != result:
            refuse()
        return result, {"access_latch": digest(value)}
    if action == "resume":
        if not isinstance(before, dict) or set(before) != {"access_id"} or not ID.fullmatch(str(before["access_id"])):
            refuse()
        receipt = envelope(ROOT / "access-receipts" / (before["access_id"] + ".json"))
        if (os.path.lexists(ROOT / "access-latch.json") or receipt.get("outcome") != "returned"
                or receipt.get("access_id") != before["access_id"]):
            refuse()
        selected_release(receipt["identity"])
        if outcome is not None and outcome != receipt:
            refuse()
        return receipt, {"access_receipt": digest(receipt)}
    if action == "network_join":
        lease = document(ROOT / "network-lease.json")
        if (not isinstance(before, dict) or before.get("phase") != "hotspot_active" or outcome is None
                or lease.get("station_candidate") is not None or lease.get("connection_uuid") != before.get("connection_uuid")
                or lease.get("boot_id") != anchor["boot_id"]):
            refuse()
        if restored_hotspot(outcome) and lease.get("phase") in {"hotspot_active", "restored"}:
            return outcome, {"network_lease": digest(lease)}
        if (outcome.get("connected") is not True or outcome.get("settings_preserved") is not True
                or lease.get("phase") != "restored"):
            refuse("Network completion is unproved or its temporary lease is not restored. Use attended support.")
        return {**outcome, "network_restored": True}, {"network_lease": digest(lease)}
    refuse()


def review(job_id, expected_sha256, operator):
    if os.geteuid() != 0:
        refuse("Attended review requires the root administrator.")
    if (not isinstance(job_id, str) or not ID.fullmatch(job_id) or not isinstance(expected_sha256, str)
            or not SHA.fullmatch(expected_sha256) or not isinstance(operator, str)
            or not 1 <= len(operator.strip()) or len(operator) > 120 or any(ord(char) < 32 for char in operator)):
        refuse("Provide the exact operation, digest and attended operator name.")
    from shotdeck_seed.storage import lock as system_lock
    jobs = Jobs(); jobs.prepare()
    with ExitStack() as leases:
        leases.enter_context(lock(ROOT / "heavy.lock"))
        leases.enter_context(lock(jobs.root / "queue.lock"))
        for path in (Path("/run/lock/shotdeck-updater.lock"), Path("/run/lock/shotdeck-backup-restore.lock"), Path("/run/lock/shotdeck-brew.lock")):
            leases.enter_context(system_lock(path, shared_device_lock=True))
        leases.enter_context(system_lock(SIGNING / "writer.lock"))
        record = jobs.read(job_id)
        if record["state"] != "interrupted" or record["action"] not in MUTATIONS or not record["mutation_started"] or digest(record) != expected_sha256:
            refuse("The unknown operation changed; inspect its current protected record first.")
        executor_stopped(record)
        no_pending(record, jobs)
        result, proof = terminal_proof(record, jobs)
        archive = directory(jobs.root / "reviews")
        unknown_path = archive / (job_id + ".unknown.json")
        if os.path.lexists(unknown_path):
            if envelope(unknown_path) != record:
                refuse("A different immutable review already owns this operation.")
        else:
            save(unknown_path, record)
        if "released_access" in proof and os.path.lexists(ROOT / "access-latch.json"):
            value = envelope(ROOT / "access-latch.json")
            if digest(value) != proof["released_access"]:
                refuse()
            archived = archive / (job_id + ".access-latch.json")
            if os.path.lexists(archived):
                if envelope(archived) != value:
                    refuse()
            else:
                save(archived, value)
        audit_path = archive / (job_id + ".review.json")
        if os.path.lexists(audit_path):
            audit = envelope(audit_path)
            if (audit.get("job_sha256") != expected_sha256 or audit.get("result") != result or audit.get("proof") != proof):
                refuse("The existing review proof changed; preserve it for support.")
        else:
            audit = {"schema_version": 1, "job_id": job_id, "job_sha256": expected_sha256,
                "operator": operator, "reviewed_at": datetime.now(timezone.utc).isoformat(),
                "outcome": "proved_completed", "proof": proof, "result": result}
            save(audit_path, audit)
        if "released_access" in proof:
            remove(ROOT / "access-latch.json")
        # Audit is durable first. A cut before this final write can rerun only
        # the same review; no service, GPIO, network or installer action occurs.
        jobs.finish(record, {**result, "attended_review_sha256": digest(audit)})
        return {"reviewed": True, "job_id": job_id, "outcome": "proved_completed", "review_sha256": digest(audit)}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("show", "review"))
    parser.add_argument("--job-id", required=True)
    parser.add_argument("--expected-sha256")
    parser.add_argument("--operator")
    args = parser.parse_args(argv)
    try:
        if os.geteuid() != 0:
            refuse("Attended review requires the root administrator.")
        seed_provenance()
        if args.command == "show":
            if args.expected_sha256 is not None or args.operator is not None:
                refuse("Show accepts only the exact operation identifier.")
            value = Jobs().read(args.job_id)
            result = {"job": Jobs.public(value), "sha256": digest(value), "reviewable": value["state"] == "interrupted"}
        else:
            result = review(args.job_id, args.expected_sha256, args.operator)
        print(json.dumps(result, sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({"blocked": getattr(exc, "code", "review_unproven"),
                          "message": str(exc) if isinstance(exc, Refused) else "Preserve the operation and contact Shotdeck support."}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
