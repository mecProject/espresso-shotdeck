"""Provisional Release C phase admission; not hardware qualification evidence.

All figures below are engineering estimates until the signed C qualification
records measure complete phases. Installation does not enable them. Source
inventory binds every value to that qualification. Resident portal, gateway,
screen and coordinator memory is already absent from MemAvailable: nothing is
credited back. Future overlap covers only additional wake-up/import growth.

The A apply demand/reserve/background overlap remain unchanged. C adds16MiB
of anticipated future helper growth. Lighter phases do not inherit an install
budget; resume includes app startup and deliberately retains the apply budget.
"""
from __future__ import annotations

import math
from pathlib import Path

from shotdeck_recovery.admission import (Decision, RESERVE_MIB, DEMAND_MIB, OVERLAP_MIB,
    MEMORY_PRESSURE_LIMIT, IO_PRESSURE_LIMIT, read_meminfo, read_pressure)

# phase -> additional demand, background overlap, future C helper growth (MiB)
BUDGETS = {
    "check": (DEMAND_MIB["check"], OVERLAP_MIB["check"], 16),
    "apply": (DEMAND_MIB["apply"], OVERLAP_MIB["apply"], 16),
    "rollback": (DEMAND_MIB["apply"], OVERLAP_MIB["apply"], 16),
    "resume": (DEMAND_MIB["apply"], OVERLAP_MIB["apply"], 16),
    "enter": (48, 12, 8),
    "support_check": (48, 12, 16),
    "repair_helpers": (48, 12, 16),
    "repair_local": (48, 12, 16),
    "diagnostics_create": (32, 8, 8),
    "network_join": (24, 8, 8),
}


def admit(action, *, proc_root=Path("/proc")):
    if action not in BUDGETS:
        raise ValueError("Unknown fixed recovery admission phase")
    demand, background, future = BUDGETS[action]
    required = RESERVE_MIB + demand + background + future
    base = {"phase": action, "provisional_release_c": True, "reserve_mib": RESERVE_MIB,
            "demand_mib": demand, "overlap_mib": background, "release_c_future_overlap_mib": future}
    memory = read_meminfo(proc_root / "meminfo")
    if (memory is None or any(type(value) not in {int, float} or not math.isfinite(value) or value < 0 for value in memory.values())
            or memory["SwapFree"] > memory["SwapTotal"] or memory["MemAvailable"] > memory["MemTotal"]):
        return Decision(False, "memory_unknown", None, required, base)
    effective = int(memory["MemAvailable"] - memory["Dirty"] - memory["Writeback"])
    base.update(mem_available_mib=round(memory["MemAvailable"], 1), dirty_mib=round(memory["Dirty"], 1),
                writeback_mib=round(memory["Writeback"], 1), swap_used_mib=round(memory["SwapTotal"] - memory["SwapFree"], 1))
    pressures = [read_pressure(proc_root / "pressure" / name) for name in ("memory", "io")]
    if any(value is None or "some" not in value or any(type(number) not in {int, float}
            or not math.isfinite(number) or not 0 <= number <= 100 for number in value.values()) for value in pressures):
        return Decision(False, "pressure_unknown", effective, required, base)
    memory_pressure, io_pressure = (value["some"] for value in pressures)
    base.update(memory_some_avg10=memory_pressure, io_some_avg10=io_pressure)
    reason = ("memory" if effective < required else "memory_pressure" if memory_pressure > MEMORY_PRESSURE_LIMIT
              else "io_pressure" if io_pressure > IO_PRESSURE_LIMIT else "")
    return Decision(not reason, reason, effective, required, base)
