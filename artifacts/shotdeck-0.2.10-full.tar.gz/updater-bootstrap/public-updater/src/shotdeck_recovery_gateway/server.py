"""On-demand root gateway. Only fixed typed operations cross the Unix socket."""
from __future__ import annotations

import array
import json
import os
from pathlib import Path
import pwd
import re
import socket
import stat
import struct
import subprocess
import time

from shotdeck_recovery_portal.auth import AuthStore
from shotdeck_recovery_portal.protected import AccessError

from . import PROTOCOL
from . import environment as env
from .jobs import Jobs, ID
from .records import Refused, boot_id, canonical, directory, document, envelope, read, remove, unique, write

SOCKET = "/run/shotdeck-recovery/gateway.sock"
MAX_REQUEST = 16384
MAX_RESPONSE = 262144
PHYSICAL = {"physical_state", "physical_pair", "physical_auth_reset", "physical_network_enable",
            "physical_hotspot_start", "physical_network_restore", "physical_exit"}
APP_PHYSICAL = {"physical_app_pair", "physical_app_enter"}
MUTATING = {"logout", "check", "apply", "rollback", "support_check", "repair_helpers", "repair_local",
            "diagnostics_create", "network_join", "return_to_app"}
PAIRED = MUTATING | {"session", "status", "exports", "export_open"}


def exact(value, names):
    if not isinstance(value, dict) or set(value) != set(names):
        raise Refused("invalid_request", "Unexpected recovery request fields.")


def offer(value):
    from shotdeck_recovery.protocol import validate_offer
    try:
        return validate_offer(value)
    except ValueError as exc:
        raise Refused("offer_changed", "Check again and confirm the exact available update.") from exc


def target(value):
    exact(value, {"directory", "version", "tree_sha256"})
    if (not isinstance(value["directory"], str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._+-]{0,199}", value["directory"])
            or not isinstance(value["version"], str) or not re.fullmatch(r"[0-9A-Za-z][0-9A-Za-z.+-]{0,79}", value["version"])
            or not isinstance(value["tree_sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", value["tree_sha256"])):
        raise Refused("target_changed", "The verified recovery target has changed.")
    return value


def return_available():
    try:
        value = envelope(env.ACCESS_ROOT / "access-latch.json")
        return value.get("phase") == "stopped" and isinstance(value.get("data"), dict)
    except (OSError, Refused, AttributeError):
        return False


def network_state(*, physical=False):
    from shotdeck_recovery_access.network import RecoveryNetwork
    try:
        network = RecoveryNetwork()
        return network.local_state() if physical else network.status()
    except Exception:
        # A broken wireless manager must not hide Ethernet pairing, local
        # signed repair or the physical recovery reason.
        return {"available": False, "temporary": False, "hotspot_active": False,
                "addresses": [], "reason": "Wireless status is unavailable; use Ethernet or attended support."}


class Gateway:
    def __init__(self):
        self.auth = AuthStore(allowed_hosts=env.allowed_hosts)
        self.jobs = Jobs()

    def require_access(self, *, fresh=False):
        try:
            return env.access_capability(fresh=fresh)
        except FileNotFoundError as exc:
            raise Refused("not_qualified", "Recovery access is not enabled for this installation.") from exc

    def enqueue(self, action, params, request, principal):
        # Queue acceptance remains quick. The executor repeats complete seed
        # verification before work; cached authorization still checks expiry,
        # signature and every protected authority/selector change.
        self.require_access()
        result = self.jobs.enqueue(action, params, request_id=request["id"], principal=principal)
        # PID1 owns execution; disconnection and gateway idle exit cannot kill it.
        env.wake_maintenance()
        return {**result, "id": result["job_id"]}, None

    def physical_state(self, *, app=False):
        try:
            self.require_access()
            enabled, reason = True, ""
        except Exception:
            enabled, reason = False, "Recovery access needs qualification or attended support."
        state = env.recovery_state()
        jobs = self.jobs.snapshot()
        latch = env.ACCESS_ROOT / "access-latch.json"
        temporary_entry = os.path.lexists(latch)
        pairing = {}
        try:
            filename = env.APP_CHALLENGE_FILE if app else env.SCREEN_CHALLENGE_FILE
            challenge = document(env.RUN_ROOT / filename)
            if (challenge["boot_id"] == boot_id() and type(challenge["expires_monotonic"]) in {int, float}
                    and 0 < challenge["expires_monotonic"] - time.monotonic() <= 300
                    and isinstance(challenge["pin"], str) and re.fullmatch(r"[0-9]{6}", challenge["pin"])):
                pairing = {"pin": challenge["pin"], "expires_at": challenge.get("expires_at", "")}
        except (OSError, Refused, KeyError, TypeError):
            pass
        return {"enabled": enabled, "ready": env.health().get("status") == "ready",
                "recovery_active": state.get("latched", False) or temporary_entry,
                "can_exit": enabled and return_available() and not state.get("latched", True) and not jobs["needs_review"] and not jobs["jobs_running"],
                "pairing": pairing, "url": env.public_url(), "tls_fingerprint": env.tls_fingerprint(),
                "operation": jobs["jobs"][0] if jobs["jobs"] else {}, "reason": reason or state.get("reason", ""),
                "network": network_state(physical=True)}

    def challenge(self, *, reset=False, app=False):
        self.require_access()
        env.refresh_pairing_tls()
        value = self.auth.physical_pairing(reset=reset)
        directory(env.RUN_ROOT)
        # Recovery-screen PINs must never become unsolicited app PIN overlays.
        filename = env.APP_CHALLENGE_FILE if app else env.SCREEN_CHALLENGE_FILE
        other = env.SCREEN_CHALLENGE_FILE if app else env.APP_CHALLENGE_FILE
        remove(env.RUN_ROOT / other)
        write(env.RUN_ROOT / filename, {"schema_version": 1, "id": value["challenge_id"],
              "boot_id": boot_id(), "pin": value["pin"], "url": env.public_url(),
              "tls_fingerprint": env.tls_fingerprint(),
              "expires_at": value["expires_at"], "expires_monotonic": time.monotonic() + 300})
        return self.physical_state(app=app)

    def status(self):
        observed = env.health()
        running = env.show()
        jobs = self.jobs.snapshot()
        try:
            self.require_access()
            enabled, message = True, ""
        except Exception:
            enabled, message = False, "Recovery access is not qualified for this installation."
        runtime = env.runtime_status()
        idle = enabled and not jobs["jobs_running"]
        clean = idle and not jobs["needs_review"]
        valid_runtime = clean and runtime.get("runtime_verified") is True and runtime.get("support_qualified") is True
        rollback = runtime.get("rollback", {"available": False, "reason": runtime.get("reason", "No verified target is available.")})
        if not isinstance(rollback, dict):
            rollback = {"available": False, "reason": "Recovery target needs review."}
        normal_ready = observed.get("status") == "ready" and observed.get("control_ready") is True and observed.get("brew_active") is False
        update_enabled = runtime.get("updates_enabled") is True
        response_jobs = [{**item, "id": item["job_id"]} for item in jobs["jobs"]]
        current_offer = None
        support_result = {}
        for item in reversed(jobs["jobs"]):
            if item["state"] != "succeeded":
                continue
            result = item["result"] or {}
            if item["action"] == "check":
                current_offer = result.get("offer")
            elif item["action"] == "apply" and result.get("outcome") == "installed" and result.get("offer") == current_offer:
                current_offer = None
            elif item["action"] == "support_check":
                support_result = result
        support_offer = support_result.get("offer")
        local_support_offer = support_result.get("local_offer")
        network = network_state()
        recovery = env.recovery_state()
        return {"app": {"version": str(observed.get("version") or "")[:80],
                         "state": running["ActiveState"], "ready": observed.get("status") == "ready"},
                "recovery": recovery, "jobs": response_jobs, "offer": current_offer,
                "support_offer": support_offer, "local_support_offer": local_support_offer, "rollback": rollback,
                "capabilities": {"check": valid_runtime and update_enabled,
                    "apply": valid_runtime and update_enabled and normal_ready and current_offer is not None,
                    "rollback": valid_runtime and rollback.get("available") is True,
                    "repair_helpers": clean and support_offer is not None, "support_check": idle,
                    "repair_local": clean and local_support_offer is not None,
                    "diagnostics_create": idle, "network_join": clean and network.get("hotspot_active") is True,
                    "return_to_app": clean and valid_runtime and return_available() and not recovery.get("latched", True)},
                "message": message or ("An earlier operation needs attended review." if jobs["needs_review"] else "")}

    def dispatch(self, request, peer):
        exact(request, {"schema_version", "id", "action", "params", "auth", "context"})
        if type(request["schema_version"]) is not int or request["schema_version"] != PROTOCOL or not isinstance(request["id"], str) or not ID.fullmatch(request["id"]):
            raise Refused("invalid_request", "Unsupported recovery request.")
        action, params, context = request["action"], request["params"], request["context"]
        if not isinstance(action, str) or not isinstance(params, dict):
            raise Refused("invalid_request", "Unsupported recovery action.")
        pid, uid, _gid = peer
        portal_uid = pwd.getpwnam("shotdeck-recovery").pw_uid
        if action in PHYSICAL | APP_PHYSICAL:
            units = {"shotdeck.service"} if action in APP_PHYSICAL else {"shotdeck-recovery-screen.service"}
            if uid != 0 or not env.peer_unit(pid, units):
                raise Refused("physical_required", "Use the physical recovery controls.")
            exact(params, set())
            exact(request["auth"], set())
            exact(context, set())
            self.require_access(fresh=action != "physical_state")
            if action == "physical_state":
                return self.physical_state(), None
            if action in {"physical_pair", "physical_app_pair", "physical_auth_reset"}:
                return self.challenge(reset=action == "physical_auth_reset", app=action == "physical_app_pair"), None
            if action == "physical_app_enter":
                # Check the display-only profile while the healthy app is
                # still visible. Never pause into a known unusable screen.
                from shotdeck_recovery_access.hardware import legacy_profile
                from shotdeck_recovery_access.state import AccessError
                try:
                    legacy_profile()
                except (AccessError, OSError) as exc:
                    raise Refused("display_unavailable", "Recovery display needs attended hardware setup. Shotdeck has not been paused.") from exc
                return self.enqueue("enter", {}, request, "physical-app")
            if action == "physical_exit":
                return self.enqueue("resume", {}, request, "physical-screen")
            from shotdeck_recovery_access.network import RecoveryNetwork
            network = RecoveryNetwork()
            method = {"physical_network_enable": network.enable_temporary,
                      "physical_hotspot_start": network.start_hotspot,
                      "physical_network_restore": network.restore}[action]
            return method(), None
        if uid != portal_uid or not env.peer_unit(pid, {"shotdeck-recovery.service"}):
            raise Refused("forbidden", "Only the independent recovery portal may use this endpoint.")
        exact(request["auth"], {"session", "csrf"})
        if any(not isinstance(value, str) or len(value) > 1024 for value in request["auth"].values()):
            raise Refused("invalid_request", "Invalid recovery authentication fields.")
        if action == "portal_idle":
            exact(params, set())
            return {"jobs_running": self.jobs.snapshot()["jobs_running"]}, None
        if action == "info":
            exact(params, set())
            return {"product": "Shotdeck", "pairing_required": True, "support_route": "Use the physical Recovery screen or contact Shotdeck support."}, None
        if action == "pair":
            exact(params, {"pin"})
            self.require_access()
            return self.auth.pair(params["pin"], context), None
        if action not in PAIRED:
            raise Refused("invalid_request", "Unsupported recovery action.")
        session = self.auth.authorize(request["auth"]["session"], request["auth"]["csrf"], context,
                                      mutating=action in MUTATING)
        if action == "session":
            exact(params, set())
            return {**session, "paired": True}, None
        if action == "logout":
            exact(params, set())
            self.auth.logout(request["auth"]["session"], request["auth"]["csrf"], context)
            return {"paired": False}, None
        self.require_access()
        if action == "status":
            exact(params, set())
            return self.status(), None
        if action in {"exports", "export_open"}:
            from shotdeck_recovery_portal.exports import ExportStore
            exports = ExportStore()
            if action == "exports":
                exact(params, set())
                return {"exports": exports.list()}, None
            exact(params, {"export_id"})
            return exports.open(params["export_id"])
        if action in {"check", "support_check", "return_to_app"}:
            exact(params, set())
            actual = "resume" if action == "return_to_app" else action
        elif action == "apply":
            exact(params, {"offer"})
            params = {"offer": offer(params["offer"])}
            actual = action
        elif action == "rollback":
            exact(params, {"target", "capability_sha256"})
            target(params["target"])
            if not isinstance(params["capability_sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", params["capability_sha256"]):
                raise Refused("target_changed", "Recovery authority has changed.")
            actual = action
        elif action == "repair_helpers":
            exact(params, {"offer"})
            exact(params["offer"], {"schema_version", "channel", "revision", "manifest_sha256", "archive_sha256", "size", "authority_id"})
            if (type(params["offer"]["schema_version"]) is not int or params["offer"]["schema_version"] != 1
                    or params["offer"]["channel"] not in {"stable", "beta"}
                    or type(params["offer"]["size"]) is not int or not 1 <= params["offer"]["size"] <= 16 * 1024 * 1024
                    or type(params["offer"]["revision"]) is not int or params["offer"]["revision"] < 1
                    or any(not isinstance(params["offer"][key], str) or not re.fullmatch(r"[0-9a-f]{64}", params["offer"][key])
                           for key in ("manifest_sha256", "archive_sha256", "authority_id"))):
                raise Refused("offer_changed", "Check helper availability again.")
            actual = action
        elif action == "repair_local":
            exact(params, {"offer"})
            value = params["offer"]
            exact(value, {"schema_version", "source", "target", "manifest_sha256", "retained_manifest_sha256", "seed_sha256", "authority_id"})
            if (type(value["schema_version"]) is not int or value["schema_version"] != 1 or value["source"] != "local"
                    or value["target"] not in {"selected", "previous", "seed"}
                    or any(not isinstance(value[key], str) or not re.fullmatch(r"[0-9a-f]{64}", value[key])
                           for key in ("manifest_sha256", "seed_sha256", "authority_id"))
                    or (value["retained_manifest_sha256"] is not None and (not isinstance(value["retained_manifest_sha256"], str)
                        or not re.fullmatch(r"[0-9a-f]{64}", value["retained_manifest_sha256"])))):
                raise Refused("offer_changed", "Check the local helper recovery choice again.")
            actual = action
        elif action == "diagnostics_create":
            exact(params, {"upload"})
            if type(params["upload"]) is not bool:
                raise Refused("invalid_request", "Choose whether to send encrypted diagnostics.")
            actual = action
        elif action == "network_join":
            from shotdeck_recovery_access.network import valid_station_credentials
            exact(params, {"ssid", "password"})
            if context.get("secure") is not True:
                raise Refused("secure_transport_required", "Use the encrypted recovery connection to enter network credentials.")
            if not valid_station_credentials(params["ssid"], params["password"]):
                raise Refused("invalid_request", "Enter a Wi-Fi name and an 8–63 character WPA2 password.")
            # Secret is volatile and separate from durable operation transcripts.
            directory(env.RUN_ROOT)
            credentials = env.RUN_ROOT / ("network-" + request["id"] + ".json")
            if os.path.lexists(credentials):
                raise Refused("busy", "A network request is already pending.")
            write(credentials, {"ssid": params["ssid"], "password": params["password"],
                                "boot_id": boot_id(), "expires": time.monotonic() + 300})
            try:
                return self.enqueue("network_join", {"credential_id": request["id"]}, request, session["session_id"])
            except BaseException:
                remove(credentials)
                raise
        else:
            raise Refused("invalid_request", "Unsupported recovery action.")
        return self.enqueue(actual, params, request, session["session_id"])


def receive(connection):
    raw = bytearray()
    while b"\n" not in raw:
        block = connection.recv(min(4096, MAX_REQUEST + 1 - len(raw)))
        if not block:
            raise Refused("invalid_request", "Incomplete recovery request.")
        raw.extend(block)
        if len(raw) > MAX_REQUEST:
            raise Refused("invalid_request", "Recovery request is too large.")
    line, rest = bytes(raw).split(b"\n", 1)
    if rest:
        raise Refused("invalid_request", "Only one recovery request is accepted per connection.")
    try:
        return json.loads(line, object_pairs_hook=unique, parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (ValueError, UnicodeError) as exc:
        raise Refused("invalid_request", "Invalid recovery JSON.") from exc


def main(argv=None):
    if os.geteuid() != 0 or int(os.environ.get("LISTEN_PID", "0")) != os.getpid() or os.environ.get("LISTEN_FDS") != "1":
        raise SystemExit("Recovery gateway requires its fixed root-owned system socket")
    listener = socket.socket(fileno=3)
    if listener.family != socket.AF_UNIX or listener.getsockname() != SOCKET:
        raise SystemExit("Unexpected recovery gateway socket")
    listener.settimeout(60)
    gateway = Gateway()
    while True:
        try:
            connection, _ = listener.accept()
        except socket.timeout:
            return 0
        fd = None
        request_id = ""
        with connection:
            connection.settimeout(10)
            try:
                peer = struct.unpack("3i", connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i")))
                request = receive(connection)
                if isinstance(request, dict) and isinstance(request.get("id"), str) and ID.fullmatch(request["id"]):
                    request_id = request["id"]
                result, fd = gateway.dispatch(request, peer)
                response = {"schema_version": PROTOCOL, "id": request_id, "ok": True, "result": result}
            except (Refused, AccessError) as exc:
                response = {"schema_version": PROTOCOL, "id": request_id, "ok": False,
                            "error": {"code": exc.code, "message": str(exc)}}
            except Exception:
                response = {"schema_version": PROTOCOL, "id": request_id, "ok": False,
                            "error": {"code": "unavailable", "message": "Recovery needs attended support."}}
            try:
                raw = canonical(response) + b"\n"
                if len(raw) > MAX_RESPONSE:
                    raise Refused("too_large", "Recovery response exceeds its limit.")
                if fd is not None:
                    info = os.fstat(fd)
                    import fcntl
                    if not stat.S_ISREG(info.st_mode) or fcntl.fcntl(fd, fcntl.F_GETFL) & os.O_ACCMODE != os.O_RDONLY:
                        raise Refused("unsafe_export", "Encrypted export is unavailable.")
                    os.lseek(fd, 0, os.SEEK_SET)
                    sent = connection.sendmsg([raw], [(socket.SOL_SOCKET, socket.SCM_RIGHTS, array.array("i", [fd]))])
                    if sent < len(raw):
                        connection.sendall(raw[sent:])
                else:
                    connection.sendall(raw)
            except (OSError, Refused):
                pass
            finally:
                if fd is not None:
                    os.close(fd)


if __name__ == "__main__":
    raise SystemExit(main())
