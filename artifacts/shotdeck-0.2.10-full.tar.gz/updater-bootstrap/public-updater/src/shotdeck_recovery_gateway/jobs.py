"""Durable fixed-action jobs; unknown mutation outcomes never become retries."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path
import re
import time
import uuid

from .records import Refused, alive, canonical, directory, envelope, lock, owner, save

ROOT = Path("/var/lib/shotdeck/recovery-access/jobs")
ID = re.compile(r"[0-9a-f]{32}\Z")
ACTIONS = {"check", "apply", "rollback", "support_check", "repair_helpers", "repair_local", "diagnostics_create",
           "network_join", "enter", "resume"}
MUTATIONS = {"apply", "rollback", "repair_helpers", "repair_local", "enter", "resume", "network_join"}
INSPECTIONS = {"support_check", "diagnostics_create"}
TERMINAL = {"succeeded", "failed", "interrupted"}
MAX_JOBS = 128
FIELDS = {"schema_version", "job_id", "request_id", "request_sha256", "action", "params", "principal",
          "state", "phase", "owner", "created_at", "updated_at", "mutation_started", "result", "error_code", "message"}
PHASES = {"queued", "waiting_for_memory", "dispatching", "validating", "executing", "completed", "failed", "outcome_unknown"}


def now():
    return datetime.now(timezone.utc).isoformat()


def restored_hotspot(result):
    return (isinstance(result, dict) and result.get("connected") is False
            and result.get("hotspot_restored") is True and result.get("settings_preserved") is True)


class Jobs:
    def __init__(self, root=ROOT):
        self.root = Path(root)

    def prepare(self):
        directory(self.root.parent)
        directory(self.root)

    def path(self, job_id):
        if not isinstance(job_id, str) or not ID.fullmatch(job_id):
            raise Refused("invalid_request", "Invalid recovery operation identifier.")
        return self.root / (job_id + ".json")

    def read(self, job_id):
        record = envelope(self.path(job_id))
        if (not isinstance(record, dict) or not FIELDS <= set(record) or set(record) - FIELDS - {"admission", "proof_anchor"}
                or type(record.get("schema_version")) is not int or record["schema_version"] != 1 or record.get("job_id") != job_id
                or record.get("action") not in ACTIONS
                or record.get("state") not in TERMINAL | {"queued", "dispatching", "running", "waiting"}
                or record.get("phase") not in PHASES or type(record.get("mutation_started")) is not bool
                or not isinstance(record.get("params"), dict) or len(canonical(record["params"])) > 8192
                or not isinstance(record.get("request_id"), str) or not ID.fullmatch(record["request_id"])
                or not isinstance(record.get("principal"), str) or not 1 <= len(record["principal"]) <= 128
                or any(not isinstance(record.get(name), str) or len(record[name]) > maximum
                       for name, maximum in (("message", 512), ("error_code", 80), ("created_at", 80), ("updated_at", 80)))
                or (record["result"] is not None and (not isinstance(record["result"], dict) or len(canonical(record["result"])) > 196608))):
            raise Refused("invalid_record", "Recovery operation needs attended review.")
        expected = hashlib.sha256(canonical({name: record[name] for name in ("action", "params", "principal")})).hexdigest()
        if record["request_sha256"] != expected:
            raise Refused("invalid_record", "Recovery request identity changed.")
        try:
            created, updated = (datetime.fromisoformat(record[name]) for name in ("created_at", "updated_at"))
            if created.tzinfo is None or updated.tzinfo is None or updated < created:
                raise ValueError()
        except (ValueError, TypeError) as exc:
            raise Refused("invalid_record", "Recovery operation timestamps are invalid.") from exc
        owner_record = record["owner"]
        if owner_record is not None and (not isinstance(owner_record, dict) or set(owner_record) != {"pid", "ticks", "boot"}
                or any(type(owner_record[name]) is not int or owner_record[name] <= 0 for name in ("pid", "ticks"))
                or not isinstance(owner_record["boot"], str) or not re.fullmatch(r"[0-9a-f-]{36}", owner_record["boot"])):
            raise Refused("invalid_record", "Recovery operation owner is invalid.")
        if (record["state"] == "running" and owner_record is None
                or record["state"] != "running" and owner_record is not None
                or record["state"] == "succeeded" and record["result"] is None
                or record["state"] == "failed" and record["mutation_started"] and record["action"] in MUTATIONS
                or record["state"] == "interrupted" and (not record["mutation_started"] or record["action"] not in MUTATIONS)):
            raise Refused("invalid_record", "Recovery operation outcome or ownership is inconsistent.")
        if "admission" in record and (not isinstance(record["admission"], dict) or len(canonical(record["admission"])) > 4096):
            raise Refused("invalid_record", "Recovery admission evidence exceeds its bound.")
        if "proof_anchor" in record and (not isinstance(record["proof_anchor"], dict) or len(canonical(record["proof_anchor"])) > 4096):
            raise Refused("invalid_record", "Recovery mutation proof anchor is invalid.")
        return record

    def all(self):
        if not self.root.exists():
            return []
        directory(self.root)
        paths = sorted(self.root.glob("*.json"))
        if len(paths) > MAX_JOBS:
            raise Refused("storage_full", "Recovery operation history needs review.")
        return [self.read(path.stem) for path in paths]

    def enqueue(self, action, params, *, request_id, principal):
        if (action not in ACTIONS or not isinstance(request_id, str) or not ID.fullmatch(request_id)
                or not isinstance(params, dict) or len(canonical(params)) > 8192
                or not isinstance(principal, str) or not 1 <= len(principal) <= 128):
            raise Refused("invalid_request", "Invalid bounded recovery operation.")
        self.prepare()
        with lock(self.root / "queue.lock"):
            records = self.all()
            request_digest = hashlib.sha256(canonical({"action": action, "params": params,
                                                       "principal": principal})).hexdigest()
            for record in records:
                if record["request_id"] == request_id:
                    if record["request_sha256"] != request_digest:
                        raise Refused("request_changed", "This request was already used for another operation.")
                    return self.public(record)
            if action not in INSPECTIONS and any(item["state"] == "interrupted" and item["action"] in MUTATIONS for item in records):
                raise Refused("outcome_unknown", "An earlier operation needs attended review.")
            if any(item["state"] not in TERMINAL for item in records):
                raise Refused("busy", "Wait for the current recovery operation to finish.")
            # Never delete unknown outcomes. Only oldest immutable successful or
            # pre-mutation failures can leave the bounded public operation list.
            if len(records) >= MAX_JOBS:
                removable = sorted((item for item in records if item["state"] in {"succeeded", "failed"}),
                                   key=lambda item: item["created_at"])
                if not removable:
                    raise Refused("storage_full", "Recovery history needs attended review.")
                from .records import remove
                remove(self.path(removable[0]["job_id"]))
            job_id = uuid.uuid4().hex
            record = {"schema_version": 1, "job_id": job_id, "request_id": request_id,
                      "request_sha256": request_digest, "action": action, "params": params,
                      "principal": principal, "state": "queued", "phase": "queued", "owner": None,
                      "created_at": now(), "updated_at": now(), "mutation_started": False,
                      "result": None, "error_code": "", "message": "Waiting to start."}
            save(self.path(job_id), record)
            return self.public(record)

    def update(self, record, **changes):
        record = {**record, **changes, "updated_at": now()}
        save(self.path(record["job_id"]), record)
        return record

    def claim(self, job_id):
        record = self.read(job_id)
        if record["state"] not in {"queued", "dispatching", "waiting"} or record["mutation_started"]:
            raise Refused("outcome_unknown", "This operation cannot be executed again.")
        if record.get("owner") and alive(record["owner"]):
            raise Refused("busy", "This operation already has an owner.")
        return self.update(record, state="running", phase="validating", owner=owner(), message="Checking requirements.")

    def finish(self, record, result):
        # Caller must first verify the native operation-specific terminal proof.
        message = "Operation completed."
        if record["action"] == "network_join" and restored_hotspot(result):
            message = "Wi-Fi connection failed. The recovery hotspot is available. Try again or return to Shotdeck."
        if record["action"] in {"repair_helpers", "repair_local"}:
            if result.get("requested_package_installed") is False:
                message = "Review confirmed the verified fallback. The requested helper package was not installed."
            elif result.get("outcome") in {"retained_previous", "seed_only"}:
                message = "Verified retained recovery helpers are active."
            elif result.get("qualified") is False:
                message = "Helper repair completed; these exact helpers still require qualification."
        elif record["action"] == "network_join" and result.get("hotspot_restored") is True:
            message = "Could not join Wi-Fi. The recovery hotspot is available again."
        return self.update(record, state="succeeded", phase="completed", result=result,
                           owner=None, error_code="", message=message)

    def fail(self, record, code, message):
        uncertain = record["mutation_started"] and record["action"] in MUTATIONS
        return self.update(record, state="interrupted" if uncertain else "failed",
                           phase="outcome_unknown" if uncertain else "failed", owner=None,
                           error_code="outcome_unknown" if uncertain else code,
                           message="The outcome needs attended review." if uncertain else message)

    def reconcile(self):
        self.prepare()
        with lock(self.root / "queue.lock"):
            for record in self.all():
                if record["state"] in TERMINAL or record["state"] in {"queued", "waiting"}:
                    continue
                if record.get("owner") and alive(record["owner"]):
                    continue
                # A unit launch may have raced this observer. Dispatching is
                # reconciled by the dispatcher only after inspecting PID1.
                if record["state"] == "dispatching":
                    continue
                self.fail(record, "executor_lost", "The recovery operation stopped before completion.")

    @staticmethod
    def public(record):
        view = {key: record[key] for key in ("job_id", "action", "state", "phase", "created_at",
                                            "updated_at", "result", "error_code", "message")}
        # The durable transaction completed with verified compensation. The
        # user-facing operation was a Wi-Fi join and that request failed.
        if record["action"] == "network_join" and record["state"] == "succeeded" and restored_hotspot(record["result"]):
            view.update(state="failed", phase="failed", error_code="network_join_failed")
        return view

    def snapshot(self):
        records = sorted(self.all(), key=lambda row: row["created_at"], reverse=True)
        return {"jobs": [self.public(item) for item in records[:16]],
                "jobs_running": any(item["state"] not in TERMINAL for item in records),
                "needs_review": any(item["state"] == "interrupted" for item in records)}
