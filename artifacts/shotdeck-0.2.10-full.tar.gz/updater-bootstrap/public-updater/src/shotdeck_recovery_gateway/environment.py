"""Fixed local observations used by the privileged recovery gateway."""
from __future__ import annotations

import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import socket
import stat
import subprocess
import threading
import time

from shotdeck_recovery.health import read_local_health

from . import PORT
from .records import Refused, boot_id, canonical, document, envelope, protected_parents, read, unique, write

ACCESS_ROOT = Path("/var/lib/shotdeck/recovery-access")
RUN_ROOT = Path("/run/shotdeck-recovery-access")
APP_CHALLENGE_FILE = "app-challenge.json"
SCREEN_CHALLENGE_FILE = "screen-challenge.json"
_ACCESS_CACHE = {}
_ACCESS_LOCK = threading.RLock()
CGROUP_ROOT = Path("/sys/fs/cgroup")
PROC_ROOT = Path("/proc")


def command(argv, *, timeout=15):
    result = subprocess.run(argv, capture_output=True, text=True, timeout=timeout, check=False)
    if len(result.stdout) > 262144 or len(result.stderr) > 65536 or result.returncode:
        raise Refused("service_unavailable", "A required recovery service is unavailable.")
    return result.stdout


def show(unit="shotdeck.service"):
    raw = command(["systemctl", "show", unit, "--property=LoadState,MainPID,ActiveState,SubState,ControlGroup,InvocationID"])
    values = dict(line.split("=", 1) for line in raw.splitlines() if "=" in line)
    if not {"LoadState", "ActiveState", "SubState", "ControlGroup", "InvocationID"} <= set(values):
        raise Refused("service_unavailable", "Application service state is unavailable.")
    return values


def wake_maintenance():
    """A lost wake-up cannot change a durable acceptance or terminal result."""
    try:
        subprocess.run(["systemctl", "start", "--no-block", "shotdeck-recovery-maintenance.service"],
                       capture_output=True, timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired):
        # The independent maintenance timer retries from the saved jobs.
        pass


def peer_unit(pid, allowed):
    """Kernel-reported local peer must actually belong to the fixed service."""
    try:
        value = Path(f"/proc/{pid}/cgroup").read_text()
        if len(value) > 16384:
            return False
        groups = [line.split(":", 2)[2] for line in value.splitlines() if line.startswith("0::")]
        for unit in allowed:
            service = show(unit)
            group = service.get("ControlGroup", "")
            if (group and service["ActiveState"] in {"active", "activating"}
                    and any(item == group or item.startswith(group + "/") for item in groups)):
                return True
    except (OSError, ValueError, Refused):
        pass
    return False


def health():
    try:
        value = read_local_health(2, max_bytes=16384)
        return {key: value.get(key) for key in ("status", "version", "control_ready", "brew_active")}
    except OSError:
        return {}


def addresses():
    values = ["127.0.0.1", "[::1]"]
    rows = json.loads(command(["/usr/sbin/ip", "-j", "address", "show"], timeout=5))
    for row in rows:
        for entry in row.get("addr_info", []):
            try:
                address = ipaddress.ip_address(entry["local"])
            except (KeyError, ValueError):
                continue
            if address.is_unspecified or address.is_multicast or address.is_link_local and address.version == 6:
                continue
            value = str(address) if address.version == 4 else "[" + str(address) + "]"
            if value not in values:
                values.append(value)
    return values[:32]


def allowed_hosts():
    names = addresses()
    hostname = socket.gethostname()
    if re.fullmatch(r"[a-zA-Z0-9][a-zA-Z0-9-]{0,62}", hostname):
        names += [hostname, hostname + ".local"]
    return tuple(value + ":" + str(PORT) for value in names)


def public_url():
    candidates = [value for value in addresses() if value not in {"127.0.0.1", "[::1]"}]
    return "https://" + (candidates[0] if candidates else "127.0.0.1") + ":" + str(PORT)


def profile():
    board = Path("/proc/device-tree/model").read_bytes().decode().strip("\x00\n")
    release = Path("/etc/os-release").resolve(strict=True)
    if release not in {Path("/etc/os-release"), Path("/usr/lib/os-release")}:
        raise Refused("unsupported_hardware", "Operating system identity is unavailable.")
    values = dict(line.split("=", 1) for line in read(release, 16384).decode().splitlines()
                  if "=" in line and not line.startswith("#"))
    try:
        hardware = document(Path("/etc/shotdeck/hardware-profile.json"))
    except FileNotFoundError:
        # Same explicit legacy default as the protected updater, never a
        # fallback for corrupt or unknown hardware identity records.
        hardware = {"schema_version": 1, "profile_id": "rev1_2_3_5f_bbw"}
    # Installation records use profile_id; do not infer a profile from the board.
    profile_id = hardware.get("profile_id", hardware.get("hardware_profile"))
    return {"board": board, "os_codename": values.get("VERSION_CODENAME", "").strip('"'),
            "hardware_profile": profile_id, "control_topology": "legacy-holding-latching"}


def runtime_status():
    try:
        record = document(ACCESS_ROOT / "runtime-status.json")
        if record["boot_id"] != boot_id() or not 0 <= time.time() - record["observed_at"] <= 300:
            return {"enabled": False, "reason": "Recovery runtime status needs refresh."}
        return record["status"]
    except (FileNotFoundError, KeyError, TypeError, Refused):
        return {"enabled": False, "reason": "Recovery runtime has not passed its local admission."}


def recovery_state():
    root = Path("/var/lib/shotdeck/updater/recovery")
    if not (root / "state.json").exists() and not (root / "enrolled.json").exists():
        return {"latched": False, "reason": ""}
    try:
        value = envelope(root / "state.json")
        return {key: value.get(key) for key in ("latched", "reason", "phase", "attempts")}
    except (OSError, Refused):
        return {"latched": True, "reason": "Recovery records need attended review."}


def _stat_identity(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_uid, info.st_gid,
            info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _record_identity(path, limit=512 * 1024):
    """A small protected file's exact bytes and identity, never just mtime."""
    before = _stat_identity(path.lstat())
    raw = read(path, limit)
    if before != _stat_identity(path.lstat()):
        raise Refused("seed_changed", "Recovery authority changed during this request.")
    return (before, hashlib.sha256(raw).hexdigest()), raw


def _access_identity(manager, authority, capability_path):
    if os.path.lexists(manager.journal):
        raise Refused("seed_pending", "Independent recovery installation needs reconciliation.")
    selector = manager.paths.seed_current
    protected_parents(selector)
    try:
        info = selector.lstat()
    except FileNotFoundError:
        pointer = None  # A fresh selection may explicitly verify its retained slot.
    else:
        if info.st_uid != 0:
            raise Refused("unsafe_storage", "Recovery selector ownership changed.")
        target = os.readlink(selector) if stat.S_ISLNK(info.st_mode) else None
        pointer = (_stat_identity(info), target)
        if _stat_identity(selector.lstat()) != pointer[0]:
            raise Refused("seed_changed", "Recovery selector changed during this request.")
    state, _ = _record_identity(manager.state)
    # verify_slot also rejects corrupt/incompatible support state. Preserve
    # that behavior on read cache hits rather than silently skipping its inputs.
    support = []
    for name in ("support/high-water.json", "support/accepted.json"):
        path = manager.paths.state / name
        support.append(_record_identity(path)[0] if os.path.lexists(path) else None)
    capability, _ = _record_identity(capability_path, 16384)
    return (pointer, state, tuple(support), authority["authority_id"], capability)


def _seed_manifest_identity(selected):
    identity, raw = _record_identity(selected["path"] / "SEED.json", 4 * 1024 * 1024)
    try:
        value = json.loads(raw, object_pairs_hook=unique,
                           parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        if hashlib.sha256(canonical(value)).hexdigest() != selected["sha256"]:
            raise ValueError()
    except (ValueError, TypeError, RecursionError) as exc:
        raise Refused("seed_changed", "The independent recovery manifest changed.") from exc
    return identity


def access_capability(*, fresh=False):
    from shotdeck_seed.authority import read_authority
    from . import capability
    # Imported lazily so a broken metadata record produces a visible refusal,
    # never a legacy-key or application-code fallback.
    from shotdeck_seed.lifecycle import SeedManager
    with _ACCESS_LOCK:
        try:
            manager = SeedManager()
            authority = read_authority()
            before = _access_identity(manager, authority, capability.PATH)
            cached_identity = _ACCESS_CACHE.get("identity")
            selected = (_ACCESS_CACHE.get("selected") if not fresh and cached_identity
                        and cached_identity[0] == before else None)
            manifest = None if selected is None else _seed_manifest_identity(selected)
            if fresh or selected is None or _ACCESS_CACHE.get("identity") != (before, manifest):
                _ACCESS_CACHE.clear()
                verified = manager.select()  # Full immutable runtime inventory.
                selected = {"path": verified["path"], "sha256": verified["sha256"]}
                manifest = _seed_manifest_identity(selected)
            # The signature, expiry, current profile and exact policy/runtime
            # binding are checked on every call, including cached read paths.
            value = capability.load(authority, selected["sha256"], profile(), path=capability.PATH)
            after = _access_identity(manager, read_authority(), capability.PATH)
            if after != before or _seed_manifest_identity(selected) != manifest:
                raise Refused("seed_changed", "Recovery authority changed during this request.")
            _ACCESS_CACHE.update(selected=selected, identity=(after, manifest))
            return value
        except Exception:
            # Missing, unreadable, aliased, corrupt or changed inputs never
            # keep a previous successful capability alive.
            _ACCESS_CACHE.clear()
            raise


def _read_kernel_pressure(resource):
    """Read kernel PSI, whose writable interface registers per-fd triggers.

    Unlike a stored authorization, a PSI file can legitimately have mode 0666.
    Keep the fixed path, protected parents, same proc filesystem, no-follow
    open and bounded read; never relax the reader for durable records.
    https://docs.kernel.org/accounting/psi.html#monitoring-for-pressure-thresholds
    """
    if resource not in {"memory", "io"}:
        raise ValueError("Unknown pressure resource")
    path = PROC_ROOT / "pressure" / resource
    protected_parents(path)
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_nlink != 1
                or info.st_dev != PROC_ROOT.lstat().st_dev or info.st_size > 4096):
            raise ValueError("Pressure source is not a bounded kernel file")
        raw = stream.read(4097)
    if len(raw) > 4096:
        raise ValueError("Pressure source exceeds its bound")
    return raw


def require_memory_monitoring():
    """Past signed qualification cannot enable native work after a boot change."""
    try:
        controllers = read(CGROUP_ROOT / "cgroup.controllers", 4096).decode("ascii").split()
        if "memory" not in controllers:
            raise ValueError()
        groups = read(PROC_ROOT / str(os.getpid()) / "cgroup", 8192).decode("ascii").splitlines()
        unified = [line.removeprefix("0::") for line in groups if line.startswith("0::")]
        if len(unified) != 1:
            raise ValueError()
        group = unified[0]
        parts = group.removeprefix("/").split("/") if group != "/" else []
        if not group.startswith("/") or any(not part or part in {".", ".."} for part in parts):
            raise ValueError()
        current = CGROUP_ROOT.joinpath(*parts)
        # These files exist only when the memory controller actually applies
        # to this process's cgroup, not merely when the kernel supports it.
        usage = read(current / "memory.current", 128).decode("ascii").strip()
        limit = read(current / "memory.max", 128).decode("ascii").strip()
        if not re.fullmatch(r"[0-9]{1,20}", usage) or not (limit == "max" or re.fullmatch(r"[0-9]{1,20}", limit)):
            raise ValueError()
        for resource in ("memory", "io"):
            lines = _read_kernel_pressure(resource).decode("ascii").splitlines()
            rows = {}
            for line in lines:
                fields = line.split()
                if not fields or fields[0] not in {"some", "full"} or fields[0] in rows:
                    raise ValueError()
                values = dict(item.split("=", 1) for item in fields[1:])
                if len(fields) != 5 or set(values) != {"avg10", "avg60", "avg300", "total"}:
                    raise ValueError()
                if any(not re.fullmatch(r"[0-9]{1,3}(?:\.[0-9]{1,6})?", values[key])
                       or not 0 <= float(values[key]) <= 100 for key in ("avg10", "avg60", "avg300")):
                    raise ValueError()
                if not re.fullmatch(r"[0-9]{1,24}", values["total"]):
                    raise ValueError()
                rows[fields[0]] = values
            if set(rows) != {"some", "full"}:
                raise ValueError()
    except (OSError, ValueError, Refused) as exc:
        raise Refused("memory_monitoring_unavailable", "Native updates need active memory limits and memory/I/O pressure monitoring.") from exc


def require_support_qualified(*, fresh=False):
    """Native actions require the exact helper code named by qualification.

    Independent seed access remains usable for repair when selected helpers
    cannot pass this stricter gate. Authentication and exports use the seed
    capability without trusting or executing the damaged selected generation.
    """
    from shotdeck_seed.support import SupportManager
    value = access_capability(fresh=fresh)
    require_memory_monitoring()
    manager = SupportManager()
    if os.path.lexists(manager.journal):
        raise Refused("support_pending", "Recovery helper maintenance needs reconciliation.")
    markers = (manager.enrolled, manager.high_water, manager.accepted)
    if any(os.path.lexists(path) for path in markers) and not all(os.path.lexists(path) for path in markers):
        raise Refused("support_unavailable", "Recovery helper enrollment is incomplete.")
    manager._history()
    accepted = manager._accepted()
    if accepted["selected"] is not None:
        selected = manager.selected_generation()
        if value["support_manifest_sha256"] != selected["manifest_sha256"]:
            raise Refused("support_unqualified", "The installed recovery helpers still need qualification.")
    elif value["support_manifest_sha256"] is not None:
        raise Refused("support_unavailable", "The qualified recovery helpers are unavailable.")
    elif os.path.lexists(manager.paths.support_current):
        if any(os.path.lexists(path) for path in markers):
            raise Refused("support_unavailable", "The selected recovery helpers lack accepted authority.")
        # Initial C seed enrollment may retain A's separately qualified worker
        # pointer. It is never imported for C; only its protected legacy shape
        # is permitted alongside an absent C support enrollment.
        from shotdeck_seed.storage import selected_path
        selected_path(manager.paths.support_current, manager.paths.support_releases, r"[0-9]{1,6}-[0-9a-f]{12}")
    return value


def refresh_pairing_tls():
    """Physical pairing renews the certificate before publishing its hash."""
    from shotdeck_seed.tls import ensure_portal_tls
    if ensure_portal_tls():
        # A running SSLContext retains its old certificate until restarted.
        # Leave an inactive portal cold and socket-activated; never touch app.
        command(['systemctl', 'try-restart', '--no-block', 'shotdeck-recovery.service'])


def tls_fingerprint():
    import ssl
    try:
        raw = read(Path("/etc/shotdeck/recovery-portal/server.crt"), 32768)
        der = ssl.PEM_cert_to_DER_cert(raw.decode())
        return hashlib.sha256(der).hexdigest()
    except (OSError, ValueError, Refused):
        return ""


def publish_availability(enabled):
    from .records import directory, remove
    directory(RUN_ROOT)
    target = RUN_ROOT / "available.json"
    if enabled:
        write(target, {"schema_version": 1, "enabled": True, "boot_id": boot_id()})
    else:
        remove(target)
