"""Cross-entrypoint exclusion survives loss of process locks after a crash."""
from __future__ import annotations

import os
from pathlib import Path
import re

from .jobs import Jobs, TERMINAL, MUTATIONS
from .records import Refused, alive


def assert_clear(*, allow_owned=False, helper_journals=True, access_latch=True, allow_inspection=False,
                 helper_reconcile_identity=None):
    root = Path("/var/lib/shotdeck/updater")
    if helper_journals and any(os.path.lexists(root / name / "pending.json") for name in ("seed", "support")):
        raise Refused("helper_pending", "Recovery helper maintenance needs reconciliation.")
    if access_latch and os.path.lexists(Path("/var/lib/shotdeck/recovery-access/access-latch.json")):
        raise Refused("recovery_active", "Return from recovery before starting an ordinary update.")
    for item in Jobs().all():
        if (helper_reconcile_identity is not None and isinstance(helper_reconcile_identity, str)
                and re.fullmatch(r"[0-9a-f]{64}", helper_reconcile_identity)
                and item["state"] == "interrupted" and item["action"] in {"repair_helpers", "repair_local"}
                and item["params"].get("offer", {}).get("manifest_sha256") == helper_reconcile_identity):
            # Only the dedicated helper reconciler supplies this digest from
            # its validated protected pending journal, while holding all native
            # locks. Resolve that transaction, never replay an app mutation or
            # clear the unknown job. Attended terminal-proof review remains
            # mandatory after reconciliation. Live descendants still block it.
            from .admin import executor_stopped
            executor_stopped(item)
            continue
        if allow_inspection and item["state"] == "interrupted" and item["action"] in MUTATIONS:
            continue
        if item["state"] in TERMINAL and not (item["state"] == "interrupted" and item["action"] in MUTATIONS):
            continue
        owner = item.get("owner")
        # No environment bypass. A child must be the direct child of the
        # still-live executor recorded before launch, in that exact PID1 unit.
        if allow_owned and owner and item["state"] == "running" and alive(owner):
            pid = owner.get("pid")
            if pid in {os.getpid(), os.getppid()}:
                from .environment import peer_unit
                unit = ("shotdeck-recovery-read@" if item["action"] in {"check", "support_check", "diagnostics_create"}
                        else "shotdeck-recovery-operation@") + item["job_id"] + ".service"
                if peer_unit(os.getpid(), {unit}) and peer_unit(pid, {unit}):
                    continue
        raise Refused("recovery_pending", "An independent recovery operation is active or needs review.")
