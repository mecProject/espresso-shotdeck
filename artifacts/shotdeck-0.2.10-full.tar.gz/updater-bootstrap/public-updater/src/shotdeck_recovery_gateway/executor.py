"""PID1-owned fixed recovery actions, with durable outcome and native proof.

No process is bound to a browser, gateway, Bluetooth or app lifecycle. Mutation
children have no whole-operation deadline or new memory kill limit. Bounded
read-only work is separate. A crash after intent never causes automatic replay.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import selectors
import shutil
import subprocess
import tempfile
import time

from . import environment as env
from .barrier import assert_clear
from .jobs import Jobs, MUTATIONS, TERMINAL, ID, INSPECTIONS
from .records import Refused, boot_id, canonical, directory, document, envelope, lock, remove, save, write

READ_ACTIONS = {"check", *INSPECTIONS}
MAX_OUTPUT = 262144
WAIT_SECONDS = 900
ROOT = env.ACCESS_ROOT


def runtime_command(module, args, *, timeout=None):
    from shotdeck_seed.authority import verify_runtime
    runtime = verify_runtime()
    if module not in {"shotdeck_updater.cli", "shotdeck_updater.recovery_customer", "shotdeck_updater.recovery_access"}:
        raise Refused("invalid_request", "Unrecognized protected entrypoint.")
    # Workspaces and child output are never retained on a RAM-backed /tmp.
    workspace = Path(tempfile.mkdtemp(prefix="shotdeck-recovery-", dir="/var/tmp"))
    child = None
    try:
        child_env = {key: value for key, value in os.environ.items() if not key.startswith("PYTHON")}
        child_env["TMPDIR"] = str(workspace)
        child = subprocess.Popen([str(runtime / "bin/python"), "-I", "-B", "-m", module, *args],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=child_env, close_fds=True)
        streams = selectors.DefaultSelector()
        outputs = {"stdout": bytearray(), "stderr": bytearray()}
        for name, stream in (("stdout", child.stdout), ("stderr", child.stderr)):
            os.set_blocking(stream.fileno(), False)
            streams.register(stream, selectors.EVENT_READ, name)
        deadline = time.monotonic() + timeout if timeout is not None else None
        overflow = False
        while streams.get_map():
            if deadline is not None and time.monotonic() >= deadline:
                child.terminate()
                try:
                    child.wait(5)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait()
                raise Refused("check_timeout", "The read-only recovery check timed out.")
            for key, _event in streams.select(1):
                block = os.read(key.fileobj.fileno(), 8192)
                if not block:
                    streams.unregister(key.fileobj); key.fileobj.close()
                elif len(outputs[key.data]) + len(block) <= MAX_OUTPUT:
                    outputs[key.data].extend(block)
                else:
                    # Drain without keeping output or killing a mutation.
                    overflow = True
        # A read-only child can close both pipes before it exits. Its deadline
        # still applies; an unbounded wait here would strand status/check work.
        try:
            code = child.wait(timeout=max(0, deadline - time.monotonic()) if deadline is not None else None)
        except subprocess.TimeoutExpired:
            child.terminate()
            try:
                child.wait(5)
            except subprocess.TimeoutExpired:
                child.kill(); child.wait()
            raise Refused("check_timeout", "The read-only recovery check timed out.")
        streams.close()
        if code or overflow:
            raise Refused("native_refused", "The protected operation did not return a confirmed result.")
        from .records import unique
        result = json.loads(outputs["stdout"], object_pairs_hook=unique,
                            parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        if not isinstance(result, dict):
            raise Refused("native_result", "The protected result is invalid.")
        return result
    finally:
        # Never remove a workspace still used by a mutation after an I/O error.
        if child is None or child.poll() is not None:
            shutil.rmtree(workspace)


def preferences():
    from shotdeck_recovery.executor import read_preferences, read_only_mode
    value = read_preferences(environ={})
    if read_only_mode():
        value["updates_enabled"] = False
    return value


def runtime_status():
    result = {"runtime_verified": False, "support_qualified": False, "updates_enabled": preferences()["updates_enabled"],
              "rollback": {"available": False, "reason": "Protected runtime needs repair."}}
    try:
        env.require_support_qualified(fresh=True)
        result["support_qualified"] = True
        from shotdeck_seed.authority import verify_runtime
        verify_runtime()
        result["runtime_verified"] = True
        try:
            result["rollback"] = runtime_command("shotdeck_updater.recovery_customer", ["status"], timeout=180)
        except Exception:
            result["rollback"] = {"available": False, "reason": "Customer recovery qualification or records need attended review."}
    except Exception:
        pass  # intact independent seed still serves helper repair and exports
    directory(ROOT)
    write(ROOT / "runtime-status.json", {"boot_id": boot_id(), "observed_at": time.time(), "status": result})
    return result


def refresh_status():
    """Independent bounded reader; never spend the portal's service budget."""
    directory(ROOT)
    with lock(ROOT / "heavy.lock"):
        # Prefer admitted user work; the timer refreshes again after it ends.
        if any(record["state"] not in TERMINAL for record in Jobs().all()):
            return {"deferred": True}
        admitted, evidence = admission("check")
        if not admitted:
            return {"deferred": True, "admission": evidence}
        return runtime_status()


def schedule_status():
    try:
        subprocess.run(["systemctl", "start", "--no-block", "shotdeck-recovery-status.service"],
                       capture_output=True, timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired):
        # The periodic unit retries; a refresh failure never rewrites a proven
        # mutation outcome or turns the completed action into an unknown one.
        pass


def admission(action):
    from .admission import admit
    value = admit(action)
    return value.admitted, value.evidence()


def old_jobs_clear(*, allow_unknown=False):
    from shotdeck_recovery.queue import JobStore
    from shotdeck_recovery.status import snapshot
    store = JobStore()
    view = snapshot(store)
    if view["active"] or not allow_unknown and (view["unknown"] or store.mutation_barrier()):
        raise Refused("update_pending", "An update is active or needs review.")


def unit_for(record):
    prefix = "shotdeck-recovery-read@" if record["action"] in READ_ACTIONS else "shotdeck-recovery-operation@"
    return prefix + record["job_id"] + ".service"


def maybe_start_screen(jobs):
    """Failure presentation only: this path never stops or restarts Shotdeck."""
    from contextlib import ExitStack
    from shotdeck_recovery_access.hardware import app_stopped, legacy_profile
    from shotdeck_recovery_access.state import lock as activity_lock
    try:
        if any(record["state"] not in TERMINAL for record in jobs.all()):
            return
        old_jobs_clear()
        env.access_capability()
        legacy_profile()
        with ExitStack() as leases:
            for name, shared in (("shotdeck-updater.lock", True), ("shotdeck-backup-restore.lock", False), ("shotdeck-brew.lock", False)):
                leases.enter_context(activity_lock(Path("/run/lock") / name, shared=shared))
            observed = env.show()
            if not app_stopped():
                return
            latched = env.recovery_state().get("latched") is True or os.path.lexists(ROOT / "access-latch.json")
            failed = (observed.get("ActiveState") == "failed" and observed.get("SubState") == "failed"
                      and isinstance(observed.get("InvocationID"), str)
                      and __import__("re").fullmatch(r"[0-9a-f]{32}", observed["InvocationID"]))
            if not latched and not failed:
                return
            subprocess.run(["systemctl", "start", "--no-block", "shotdeck-recovery-screen.service"],
                           capture_output=True, timeout=10, check=False)
    except Exception:
        # Missing qualification/ownership never becomes permission to seize a
        # healthy display. The next maintenance observation can try again.
        return


def reconcile():
    jobs = Jobs()
    jobs.reconcile()
    try:
        env.access_capability()
        env.publish_availability(True)
    except Exception:
        env.publish_availability(False)
        return
    with lock(jobs.root / "queue.lock"):
        for record in jobs.all():
            if record["state"] not in {"queued", "waiting", "dispatching"}:
                continue
            unit = unit_for(record)
            service = env.show(unit)
            if service["ActiveState"] in {"active", "activating", "deactivating"}:
                continue
            if record["state"] == "dispatching":
                jobs.fail(record, "dispatch_lost", "The operation could not be started.")
                continue
            created = datetime.fromisoformat(record["created_at"]).timestamp()
            if not 0 <= time.time() - created <= WAIT_SECONDS:
                jobs.fail(record, "admission_expired", "The operation expired while waiting for resources.")
                continue
            admitted, evidence = admission(record["action"])
            if not admitted:
                jobs.update(record, state="waiting", phase="waiting_for_memory", admission=evidence,
                            message="Waiting for enough memory and low system pressure.")
                continue
            jobs.update(record, state="dispatching", phase="dispatching", admission=evidence)
            result = subprocess.run(["systemctl", "start", "--no-block", unit], capture_output=True, timeout=10)
            if result.returncode:
                jobs.fail(jobs.read(record["job_id"]), "dispatch_failed", "The operation could not be started.")
    maybe_start_screen(jobs)


def normal_ready():
    if not preferences()["updates_enabled"]:
        raise Refused("updates_disabled", "Software updates are disabled.")
    observed = env.health()
    if observed.get("status") != "ready" or observed.get("control_ready") is not True or observed.get("brew_active") is not False:
        raise Refused("not_idle", "Return to the ready, idle application before installing an update.")


def check():
    if not preferences()["updates_enabled"]:
        raise Refused("updates_disabled", "Software updates are disabled.")
    payload = runtime_command("shotdeck_updater.cli", ["--config", "/etc/shotdeck/updater.json", "check"], timeout=180)
    from shotdeck_recovery.protocol import offer_from_check
    return {"offer": offer_from_check(payload), "applicable": payload.get("applicable") is True}


def intent(jobs, record, *, before=None):
    from shotdeck_seed.authority import read_authority
    anchor = {"authority_id": read_authority()["authority_id"], "boot_id": boot_id(), "before": before}
    return jobs.update(record, mutation_started=True, phase="executing", proof_anchor=anchor, message="Operation in progress.")


def execute(job_id):
    jobs = Jobs(); jobs.prepare()
    with lock(ROOT / "heavy.lock"):
        with lock(jobs.root / "queue.lock"):
            record = jobs.claim(job_id)
        try:
            env.access_capability(fresh=True)
            action, params = record["action"], record["params"]
            inspection = action in INSPECTIONS
            assert_clear(allow_owned=True, access_latch=False, helper_journals=not inspection, allow_inspection=inspection)
            old_jobs_clear(allow_unknown=inspection)
            if action in {"check", "apply", "rollback", "enter", "resume"}:
                env.require_support_qualified(fresh=True)
            if action == "check":
                result = check()
            elif action == "apply":
                normal_ready()
                expected = params["offer"]
                if check()["offer"] != expected:
                    raise Refused("offer_changed", "The update changed. Check and confirm it again.")
                previous = envelope(Path("/var/lib/shotdeck/updater/activation-journal.json"))
                record = intent(jobs, record, before={"transaction_id": previous["transaction_id"]})
                result = runtime_command("shotdeck_updater.cli", ["--config", "/etc/shotdeck/updater.json", "apply",
                    "--expected-version", expected["version"], "--expected-artifact-sha256", expected["artifact_sha256"],
                    "--expected-manifest-sha256", expected["manifest_sha256"]])
                proof = envelope(Path("/var/lib/shotdeck/updater/activation-journal.json"))
                if (result.get("installed_version") != expected["version"]
                        or result.get("artifact_sha256") != expected["artifact_sha256"]
                        or result.get("manifest_sha256") != expected["manifest_sha256"]
                        or proof["transaction_id"] == previous["transaction_id"]
                        or proof["phase"] != "completed" or proof["operation"] != "install"
                        or proof["candidate"]["version"] != expected["version"] or proof["candidate"]["metadata_matches"] is not True):
                    raise Refused("unconfirmed", "The exact installation completion could not be verified.")
                result = {"offer": expected, "outcome": "installed", "transaction_id": proof["transaction_id"]}
            elif action == "rollback":
                current = runtime_command("shotdeck_updater.recovery_customer", ["status"], timeout=180)
                if (current.get("available") is not True or current.get("target") != params["target"]
                        or current.get("capability_sha256") != params["capability_sha256"]):
                    raise Refused("target_changed", "The qualified recovery target changed.")
                record = intent(jobs, record, before={"capability_sha256": params["capability_sha256"]})
                result = runtime_command("shotdeck_updater.recovery_customer", ["recover", "--expected-target",
                    canonical(params["target"]).decode(), "--expected-capability", params["capability_sha256"]])
                incident = result.get("incident_id", "")
                if not isinstance(incident, str) or not __import__("re").fullmatch(r"[0-9a-f]{64}", incident):
                    raise Refused("unconfirmed", "Recovery completion proof is unavailable.")
                receipt = document(Path("/var/lib/shotdeck/updater/recovery/receipts") / (incident + ".json"))
                completed = envelope(Path("/var/lib/shotdeck/updater/recovery/state.json"))
                if (receipt != result or result.get("outcome") != "recovered" or result.get("target") != params["target"]
                        or result.get("capability_sha256") != params["capability_sha256"]
                        or completed.get("phase") != "completed" or completed.get("latched") is not False
                        or completed.get("incident_id") != incident or completed.get("target") != result["target"]
                        or completed.get("capability_sha256") != result["capability_sha256"]):
                    raise Refused("unconfirmed", "Recovery completion proof differs from the approved target.")
                remove(ROOT / "access-latch.json")
            elif action in {"support_check", "repair_helpers", "repair_local"}:
                from shotdeck_seed.client import SupportClient
                from shotdeck_seed.support import SupportManager
                if action == "support_check":
                    result = {"offer": None, "local_offer": None, "remote_available": False}
                    try:
                        result["local_offer"] = SupportManager().local_offer()
                    except Exception:
                        pass
                    try:
                        value = SupportClient().check()
                        result.update(offer={key: item for key, item in value.items() if key != "document"}, remote_available=True)
                    except Exception:
                        result["message"] = "Online support metadata is unavailable; retained local repair remains available when verified."
                else:
                    from shotdeck_seed.support import SupportManager
                    prior = SupportManager()._accepted()
                    record = intent(jobs, record, before={"accepted_sha256": hashlib.sha256(canonical(prior)).hexdigest()})
                    result = (SupportManager().repair_local(params["offer"]) if action == "repair_local"
                              else SupportClient().repair(params["offer"]))
                    try:
                        env.require_support_qualified(fresh=True)
                        result = {**result, "qualified": True}
                    except Exception:
                        result = {**result, "qualified": False,
                            "message": "Helper repair completed. Ordinary recovery actions await qualification for these exact helpers."}
            elif action == "diagnostics_create":
                from shotdeck_recovery_portal.diagnostics import DiagnosticsCollector
                collector = DiagnosticsCollector()
                result = collector.create()
                if params["upload"]:
                    result = collector.upload(result["export_id"])
            elif action == "network_join":
                from shotdeck_recovery_access.network import RecoveryNetwork
                from shotdeck_recovery_access.state import AccessError
                credential_id = params["credential_id"]
                if not ID.fullmatch(credential_id):
                    raise Refused("invalid_request", "Invalid network credential reference.")
                path = env.RUN_ROOT / ("network-" + credential_id + ".json")
                credentials = document(path)
                if credentials["boot_id"] != boot_id() or not 0 <= credentials["expires"] - time.monotonic() <= 300:
                    remove(path)
                    raise Refused("expired", "Network credentials expired. Enter them again.")
                def record_network_intent(before):
                    nonlocal record
                    record = intent(jobs, record, before=before)

                try:
                    result = RecoveryNetwork().join_station(credentials["ssid"], credentials["password"],
                                                           before_mutation=record_network_intent)
                except AccessError as exc:
                    if not record["mutation_started"]:
                        raise Refused("network_refused", str(exc)) from exc
                    raise
                finally:
                    remove(path)
            elif action in {"enter", "resume"}:
                if action == "enter" and record["principal"] != "physical-app":
                    raise Refused("physical_required", "Enter recovery using the physical display.")
                if action == "enter":
                    # The record may change after queue acceptance; refuse
                    # before mutation intent and before stopping a healthy app.
                    from shotdeck_recovery_access.hardware import legacy_profile
                    legacy_profile()
                if action == "resume" and not os.path.lexists(ROOT / "access-latch.json"):
                    raise Refused("no_access_session", "There is no temporary recovery session to return from.")
                before = (envelope(ROOT / "access-latch.json") if action == "resume" else None)
                if action == "resume":
                    # Also retire app projections written by a retained helper
                    # before it separated app and recovery-screen challenges.
                    remove(env.RUN_ROOT / env.APP_CHALLENGE_FILE)
                    remove(env.RUN_ROOT / env.SCREEN_CHALLENGE_FILE)
                record = intent(jobs, record, before={"access_id": before["id"]} if before else None)
                result = runtime_command("shotdeck_updater.recovery_access", [action])
                if action == "enter":
                    subprocess.run(["systemctl", "start", "--no-block", "shotdeck-recovery-screen.service"],
                                   capture_output=True, timeout=10, check=True)
            else:
                raise Refused("invalid_request", "Unknown recovery operation.")
            if record.get("mutation_started"):
                receipts = directory(jobs.root / "outcomes")
                save(receipts / (record["job_id"] + ".json"), {"schema_version": 1, "job_id": record["job_id"],
                     "request_sha256": record["request_sha256"], "action": action,
                     "proof_anchor": record.get("proof_anchor"), "result": result})
            jobs.finish(record, result)
        except Exception as exc:
            jobs.fail(record, getattr(exc, "code", "operation_failed"),
                      str(exc) if isinstance(exc, Refused) else "The recovery operation needs review.")
        finally:
            env.wake_maintenance()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("run", "reconcile", "status", "refresh-status", "boot", "start-condition", "prepare-start"))
    parser.add_argument("job_id", nargs="?")
    args = parser.parse_args(argv)
    try:
        if os.geteuid() != 0:
            raise Refused("forbidden", "Protected recovery execution requires root.")
        if args.command == "run":
            if args.job_id is None or not ID.fullmatch(args.job_id):
                raise Refused("invalid_request", "Invalid operation identifier.")
            execute(args.job_id)
            schedule_status()  # execute has released heavy.lock before launch
        elif args.job_id is not None:
            raise Refused("invalid_request", "Unexpected operation identifier.")
        elif args.command == "reconcile":
            reconcile()
        elif args.command in {"status", "refresh-status"}:
            print(json.dumps(refresh_status(), sort_keys=True))
        elif args.command == "boot":
            from shotdeck_seed.lifecycle import SeedManager
            from shotdeck_seed.support import SupportManager
            SeedManager().reconcile(); SupportManager().reconcile()
            from shotdeck_recovery_access.network import RecoveryNetwork
            RecoveryNetwork().reconcile_boot()
            if os.path.lexists(ROOT / "access-latch.json"):
                runtime_command("shotdeck_updater.recovery_access", ["boot"], timeout=180)
            reconcile()
            schedule_status()
        elif args.command == "start-condition":
            if os.path.lexists(ROOT / "access-latch.json"):
                # Keep PID1's ControlPID as the sole process in the app cgroup.
                # A subprocess would make the released-relay proof ambiguous.
                from shotdeck_seed.authority import verify_runtime
                runtime = verify_runtime()
                python = str(runtime / "bin/python")
                os.execve(python, [python, "-I", "-B", "-m", "shotdeck_updater.recovery_access", "start"],
                    {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8",
                     "TMPDIR": os.environ.get("TMPDIR", "/var/tmp")})
        elif args.command == "prepare-start":
            from shotdeck_recovery_access.network import RecoveryNetwork
            RecoveryNetwork().restore()
        return 0
    except Exception as exc:
        print(json.dumps({"blocked": getattr(exc, "code", "recovery_unavailable")}), file=__import__("sys").stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
