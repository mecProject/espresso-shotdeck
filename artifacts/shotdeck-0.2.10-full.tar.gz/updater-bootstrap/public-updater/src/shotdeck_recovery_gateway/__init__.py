"""Seed-owned authorization and execution boundary for Release C recovery."""

PROTOCOL = 1
PORT = 8081
