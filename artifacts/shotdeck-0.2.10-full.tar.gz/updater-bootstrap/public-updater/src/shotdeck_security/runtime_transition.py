"""Detached, authenticated post-enrollment updater transitions.

This protocol does not enroll licences, restart applications, or enable recovery.
Callers hold updater then brew exclusion; the durable maintenance lease also
blocks older installers between attempts. Existing immutable trees are retained.
"""
from __future__ import annotations

import base64
from copy import deepcopy
from datetime import datetime
import os
from pathlib import Path
import re

from .storage import MigrationError, canonical, digest, directory, guard, read, read_json, remove, version, write_json
from .updates import MARKER, tree_digest, validate_policy

DOMAIN = b'shotdeck-post-enrollment-runtime-transition-v1\0'
RUNTIME_TRANSITION_PROTOCOL = 1
CHECKS = frozenset({'source_verified', 'runtime_probe', 'normal_update', 'interruption',
    'replay', 'licence_preserved', 'recovery_compatibility', 'one_app_restart', 'plan_complete'})
HEX = re.compile(r'[0-9a-f]{64}')
MAX_DOCUMENT_BYTES = 128 * 1024


def _present(path):
    return os.path.lexists(path)


def _fields(value, expected, label):
    if not isinstance(value, dict) or set(value) != set(expected):
        raise MigrationError(f'Invalid {label} fields')


def _sha(value):
    if not isinstance(value, str) or not HEX.fullmatch(value):
        raise MigrationError('Invalid transition digest')
    return value


def _version(value):
    parsed = version(value)
    if str(parsed) != value or not re.fullmatch(r'[A-Za-z0-9._+-]{1,80}', value):
        raise MigrationError('Transition versions must be canonical')
    return parsed


def validate_payload(payload, *, require_qualification=True):
    _fields(payload, {'schema_version', 'transition_id', 'issued_at', 'activation_scope',
        'source', 'destination', 'app', 'cohort', 'qualification'}, 'transition')
    if (type(payload['schema_version']) is not int or payload['schema_version'] != 1
            or not isinstance(payload['transition_id'], str)
            or not re.fullmatch(r'[a-z0-9][a-z0-9._-]{0,95}', payload['transition_id'])
            or payload['activation_scope'] not in ('workshop', 'customer')
            or len(canonical(payload)) > MAX_DOCUMENT_BYTES):
        raise MigrationError('Invalid runtime transition protocol')
    try:
        issued = datetime.fromisoformat(payload['issued_at'].replace('Z', '+00:00'))
        if issued.tzinfo is None:
            raise ValueError()
    except (ValueError, TypeError, AttributeError) as exc:
        raise MigrationError('Transition issuance requires an explicit timezone') from exc
    source, destination, app = payload['source'], payload['destination'], payload['app']
    _fields(source, {'policy_sha256', 'runtime_sha256', 'recovery_version', 'recovery_tree_sha256'}, 'source')
    _fields(destination, {'policy', 'runtime_version', 'runtime_name', 'runtime_tree_sha256',
        'recovery_tree_sha256'}, 'destination')
    _fields(app, {'version', 'tree_sha256'}, 'application')
    policy = validate_policy(destination['policy'])
    for value in (source['policy_sha256'], source['runtime_sha256'], source['recovery_tree_sha256'],
                  destination['runtime_tree_sha256'], destination['recovery_tree_sha256'], app['tree_sha256']):
        _sha(value)
    _version(source['recovery_version'])
    _version(policy['recovery_version'])
    _version(policy['minimum_updater_version'])
    runtime_version = _version(destination['runtime_version'])
    if (not isinstance(destination['runtime_name'], str)
            or not re.fullmatch(re.escape(destination['runtime_version']) + r'-[0-9a-f]{12}', destination['runtime_name'])
            or runtime_version < version(policy['minimum_updater_version'])
            or _version(app['version']) < version(policy['minimum_app_version'])):
        raise MigrationError('Transition runtime or application is incompatible with destination policy')
    cohort = payload['cohort']
    _fields(cohort, {'product', 'hardware_profile', 'boards', 'os_codenames', 'channels'}, 'cohort')
    for field in ('product', 'hardware_profile'):
        if not isinstance(cohort[field], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', cohort[field]):
            raise MigrationError('Invalid transition cohort identity')
    for field in ('boards', 'os_codenames', 'channels'):
        entries = cohort[field]
        if (not isinstance(entries, list) or not 1 <= len(entries) <= 16
                or any(not isinstance(entry, str) or not entry or len(entry) > 128
                       or any(ord(c) < 32 for c in entry) for entry in entries)
                or len(set(entries)) != len(entries)):
            raise MigrationError('Invalid transition cohort list')
    if set(cohort['channels']) - {'stable', 'beta'}:
        raise MigrationError('Invalid transition channel')
    qualification = payload['qualification']
    _fields(qualification, {'approved_by', 'evidence_sha256', 'checks'}, 'qualification')
    _sha(qualification['evidence_sha256'])
    if (not isinstance(qualification['approved_by'], str) or len(qualification['approved_by']) > 200
            or (require_qualification and not qualification['approved_by'].strip())):
        raise MigrationError('Transition needs an independent qualification approver')
    checks = qualification['checks']
    _fields(checks, CHECKS, 'qualification checks')
    if any(type(value) is not bool for value in checks.values()):
        raise MigrationError('Qualification checks must be boolean observations')
    if require_qualification:
        required = CHECKS - {'plan_complete'}
        if (payload['activation_scope'] == 'customer'
                or source['recovery_version'] != policy['recovery_version']
                or source['recovery_tree_sha256'] != destination['recovery_tree_sha256']):
            required = CHECKS
        if any(not checks[name] for name in required):
            raise MigrationError('Transition qualification is incomplete; recovery replacement requires the completed plan')
    return payload


def sign_transition(payload, private_key):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    validate_payload(payload)
    if not isinstance(private_key, Ed25519PrivateKey):
        raise MigrationError('Transition requires an Ed25519 update signer')
    pem = private_key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    return {**payload, 'signature': {'algorithm': 'ed25519', 'key_id': digest(pem)[:16],
        'value': base64.b64encode(private_key.sign(DOMAIN + canonical(payload))).decode('ascii')}}


def verify_transition(document, source_public_key):
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    if not isinstance(document, dict) or len(canonical(document)) > MAX_DOCUMENT_BYTES:
        raise MigrationError('Invalid bounded transition document')
    signature = document.get('signature')
    _fields(signature, {'algorithm', 'key_id', 'value'}, 'signature')
    payload = {key: value for key, value in document.items() if key != 'signature'}
    validate_payload(payload)
    try:
        key = serialization.load_pem_public_key(source_public_key)
        raw = base64.b64decode(signature['value'], validate=True)
        if (not isinstance(key, Ed25519PublicKey) or signature['algorithm'] != 'ed25519'
                or signature['key_id'] != digest(source_public_key)[:16] or len(raw) != 64
                or base64.b64encode(raw).decode('ascii') != signature['value']):
            raise ValueError()
        key.verify(raw, DOMAIN + canonical(payload))
    except (ValueError, TypeError, InvalidSignature) as exc:
        raise MigrationError('Runtime transition signature does not match the active update authority') from exc
    return payload


def _matches_source(record, payload):
    source = payload['source']
    return (digest(canonical(record['policy'])) == source['policy_sha256']
        and record['runtime_sha256'] == source['runtime_sha256']
        and record['policy']['recovery_version'] == source['recovery_version']
        and record['recovery_tree_sha256'] == source['recovery_tree_sha256'])


def _matches_destination(record, payload, install_root):
    destination = payload['destination']
    return (record['policy'] == destination['policy']
        and record['runtime'] == str(install_root / 'updater-runtimes' / destination['runtime_name'])
        and record['runtime_sha256'] == destination['runtime_tree_sha256']
        and record['recovery_tree_sha256'] == destination['recovery_tree_sha256'])


def _policies(source, destination):
    validate_policy(source)
    validate_policy(destination)
    if (destination['generation'] <= source['generation']
            or destination['public_key_pem'] != source['public_key_pem']
            or destination['fingerprint'] != source['fingerprint']
            or destination['feeds'] != source['feeds']
            or version(destination['minimum_app_version']) < version(source['minimum_app_version'])
            or version(destination['minimum_updater_version']) < version(source['minimum_updater_version'])):
        raise MigrationError('Transition must advance policy without changing keys/feeds or lowering floors')


def _receipt_path(store, identity):
    return store.folder / 'runtime-transitions' / (_sha(identity) + '.json')


def _validate_snapshot(snapshot):
    """Capture and completed receipts have identical bounds and identities."""
    if not isinstance(snapshot, dict) or not 3 <= len(snapshot) <= 256 or not {
            'licence', 'licence/floor.json', 'licence/enrolled.json'} <= set(snapshot):
        raise MigrationError('Invalid transition licence snapshot')
    for name, value in snapshot.items():
        if not isinstance(name, str) or (name != 'licence' and (
                not name.startswith('licence/')
                or any(part in ('', '.', '..') for part in name.split('/'))
                or not re.fullmatch(r'[A-Za-z0-9._/-]+', name))):
            raise MigrationError('Invalid transition licence snapshot path')
        _sha(value)
    return snapshot


def _receipt(store, active):
    pointer = read_json(store.folder / 'runtime-transition-verified.json')
    _fields(pointer, {'schema_version', 'transition_sha256', 'receipt_sha256'}, 'transition proof pointer')
    if type(pointer['schema_version']) is not int or pointer['schema_version'] != 1:
        raise MigrationError('Invalid transition proof pointer')
    record = read_json(_receipt_path(store, pointer['transition_sha256']))
    if digest(canonical(record)) != _sha(pointer['receipt_sha256']):
        raise MigrationError('Transition receipt was changed')
    _fields(record, {'schema_version', 'document', 'source_record', 'destination_generation_id',
        'licence_snapshot', 'source_proof_sha256', 'observations'}, 'transition receipt')
    if record['schema_version'] != 1 or type(record['schema_version']) is not int:
        raise MigrationError('Invalid transition receipt version')
    document = record['document']
    if digest(canonical(document)) != pointer['transition_sha256']:
        raise MigrationError('Transition proof identity differs')
    payload = verify_transition(document, active['policy']['public_key_pem'].encode('ascii'))
    source = record['source_record']
    _fields(source, {'schema_version', 'policy', 'runtime', 'runtime_sha256', 'highest_seen_version',
        'recovery_tree_sha256'}, 'source authority')
    if (type(source['schema_version']) is not int or source['schema_version'] != 1
            or not isinstance(source['runtime'], str)
            or Path(source['runtime']).parent != store.install_root / 'updater-runtimes'
            or not _matches_source(source, payload)
            or not _matches_destination(active, payload, store.install_root)
            or record['destination_generation_id'] != digest(canonical(active))
            or version(active['highest_seen_version']) < version(source['highest_seen_version'])):
        raise MigrationError('Transition proof is not bound to the active authority')
    _policies(source['policy'], active['policy'])
    _validate_snapshot(record['licence_snapshot'])
    _sha(record['source_proof_sha256'])
    _fields(record['observations'], {'app_ready', 'runtime_probed', 'licence_validated', 'licence_unchanged',
        'recovery_mutations_enabled', 'service_restarts'}, 'transition observations')
    if (any(record['observations'][name] is not True for name in
            ('app_ready', 'runtime_probed', 'licence_validated', 'licence_unchanged'))
            or record['observations']['recovery_mutations_enabled'] is not False
            or type(record['observations']['service_restarts']) is not int
            or record['observations']['service_restarts'] != 0):
        raise MigrationError('Transition completion observations are incomplete')
    return record


def verified_transition(store, active):
    """Validate new generation evidence without inventing legacy cold boots."""
    _receipt(store, active)
    return active


class RuntimeTransition:
    def __init__(self, store, licence_path, *, checkpoint=lambda stage: None):
        self.store = store
        self.licence_path = Path(licence_path)
        self.checkpoint = checkpoint
        self.journal = store.folder / 'runtime-transition.json'
        self.lease_path = store.root / 'maintenance.json'

    def _write(self, path, value, label):
        write_json(path, value, lambda step: self.checkpoint(label + '_' + step))

    def _snapshot(self):
        from .licence import LicenceStore
        if LicenceStore(self.store.root, self.licence_path).floor() < 1:
            raise MigrationError('Completed licence enrollment is required before transition')
        result = {'licence': digest(read(self.licence_path, 256 * 1024, protected=False))}
        folder = self.store.root / 'licence'
        if folder.is_symlink() or not folder.is_dir():
            raise MigrationError('Completed licence enrollment is required before transition')
        # Include immutable entitlement/floor/receipt bytes, not clock or app
        # state. A legitimate renewal can occur after this transaction ends.
        for path in folder.rglob('*'):
            if path.is_symlink():
                raise MigrationError('Aliased licence state prevents transition')
            if path.is_file():
                if len(result) >= 256:
                    raise MigrationError('Invalid transition licence snapshot')
                result[str(path.relative_to(self.store.root))] = digest(read(path))
        if 'licence/floor.json' not in result or 'licence/enrolled.json' not in result:
            raise MigrationError('Completed licence enrollment is required before transition')
        return _validate_snapshot(result)

    def _trees(self, payload, current_version):
        store, destination = self.store, payload['destination']
        if current_version != payload['app']['version']:
            raise MigrationError('Transition belongs to a different running application')
        current = store.install_root / 'current'
        releases = store.install_root / 'releases'
        app = current.resolve()
        if (not current.is_symlink() or releases.is_symlink() or app.parent != releases
                or (releases / app.name).is_symlink()
                or read(app / '.shotdeck-version', 128).decode().strip() != current_version
                or read(app / MARKER, 16) != b'1\n'
                or tree_digest(app) != payload['app']['tree_sha256']):
            raise MigrationError('Installed application differs from the signed transition')
        runtime = store.install_root / 'updater-runtimes' / destination['runtime_name']
        recovery = store.install_root / 'releases' / destination['policy']['recovery_version']
        if (runtime.parent.is_symlink() or recovery.parent.is_symlink()
                or tree_digest(runtime, runtime=True) != destination['runtime_tree_sha256']
                or tree_digest(recovery) != destination['recovery_tree_sha256']
                or read(recovery / MARKER, 16) != b'1\n'
                or not os.access(recovery / 'shotdeck', os.X_OK)):
            raise MigrationError('Staged runtime or recovery tree differs from the signed transition')
        return app, runtime, recovery

    def _pending(self):
        for path in (self.store.root / 'licence/pending.json',):
            if os.path.lexists(path):
                raise MigrationError('Finish the pending licence transaction before runtime transition')
        automatic = self.store.root / 'automatic/transaction.json'
        if os.path.lexists(automatic) and read_json(automatic).get('phase') != 'complete':
            raise MigrationError('Finish the existing automatic enrollment before runtime transition')

    def apply(self, document, *, accepted_policy_sha256, cohort, current_version,
              probe_runtime, check_feed, validate_licence, assert_idle, assert_clear,
              workshop_authorized=False):
        """Apply/resume under caller-owned updater and brew locks. Never reboot."""
        from .transition_source import verify_source_proofs
        store = self.store
        document = deepcopy(document)
        active = store.active()
        if active is None:
            raise MigrationError('Post-enrollment transition requires active update authority')
        payload = verify_transition(document, active['policy']['public_key_pem'].encode('ascii'))
        identity = digest(canonical(document))
        lease = {'schema_version': 1, 'kind': 'runtime_transition', 'transition_sha256': identity}
        pins = (accepted_policy_sha256,) if isinstance(accepted_policy_sha256, str) else tuple(accepted_policy_sha256)
        if digest(canonical(payload['destination']['policy'])) not in pins:
            raise MigrationError('Destination policy is not pinned by this application')
        expected = payload['cohort']
        _fields(cohort, {'product', 'hardware_profile', 'board', 'os_codename', 'channel'}, 'device cohort')
        if (cohort['product'] != expected['product'] or cohort['hardware_profile'] != expected['hardware_profile']
                or cohort['board'] not in expected['boards'] or cohort['os_codename'] not in expected['os_codenames']
                or cohort['channel'] not in expected['channels']):
            raise MigrationError('Device is outside the signed transition cohort')
        if payload['activation_scope'] == 'workshop' and workshop_authorized is not True:
            raise MigrationError('Workshop transition needs an explicit local workshop authorization')

        # A verified completed replay is read-only even if the app has since
        # moved on. It may finish cleanup of this transaction's own lease.
        proof_pointer = store.folder / 'runtime-transition-verified.json'
        if (_matches_destination(active, payload, store.install_root) and _present(proof_pointer)
                and read_json(proof_pointer).get('transition_sha256') == identity):
            completed = _receipt(store, active)
            if completed['document'] != document:
                raise MigrationError('A different transition owns the active destination')
            with guard(store.root, maintenance=True):
                if _present(self.lease_path) and read_json(self.lease_path) != lease:
                    raise MigrationError('Another maintenance operation is pending')
                if _present(self.journal):
                    if read_json(self.journal).get('transition_sha256') != identity:
                        raise MigrationError('A different transition journal is pending')
                    remove(self.journal)
                if _present(self.lease_path):
                    remove(self.lease_path)
            return active

        if not (_matches_source(active, payload) or _matches_destination(active, payload, store.install_root)):
            raise MigrationError('Transition source differs from the installed policy/runtime/recovery')
        if _matches_source(active, payload):
            _policies(active['policy'], payload['destination']['policy'])
        if os.path.lexists(self.lease_path) and read_json(self.lease_path) != lease:
            raise MigrationError('Another maintenance operation is pending')
        initial_licence = self._snapshot()
        self._pending()
        assert_clear()
        assert_idle()
        app, runtime, recovery = self._trees(payload, current_version)
        probe_runtime(runtime, payload['destination']['policy']['minimum_updater_version'])
        validate_licence(app, recovery)
        with guard(store.root, maintenance=True):
            self._pending()
            if self._snapshot() != initial_licence:
                raise MigrationError('Licence state changed during transition preflight')
            active = store.active()
            if _present(self.lease_path) and read_json(self.lease_path) != lease:
                raise MigrationError('Another maintenance operation is pending')
            if _present(self.journal):
                journal = read_json(self.journal)
                _fields(journal, {'schema_version', 'transition_sha256', 'document', 'source_record',
                    'licence_snapshot', 'source_proof_sha256', 'source_proofs'}, 'runtime transition journal')
                if (type(journal['schema_version']) is not int or journal['schema_version'] != 1
                        or journal['transition_sha256'] != identity or journal['document'] != document
                        or not _matches_source(journal['source_record'], payload)):
                    raise MigrationError('Pending transition differs from the approved document')
                if not (_matches_source(active, payload) or _matches_destination(active, payload, store.install_root)):
                    raise MigrationError('Active authority conflicts with the pending transition')
            else:
                if _present(self.lease_path) or _present(store.journal):
                    raise MigrationError('Incomplete signing transition requires reconciliation')
                if not _matches_source(active, payload):
                    raise MigrationError('Transition source differs from the installed policy/runtime/recovery')
                _policies(active['policy'], payload['destination']['policy'])
                verified_source, source_proofs = store.require_transition_source_verified(licence_path=self.licence_path)
                if verified_source != active:
                    raise MigrationError('Transition source changed during proof verification')
                journal = {'schema_version': 1, 'transition_sha256': identity, 'document': document,
                    'source_record': active, 'licence_snapshot': self._snapshot(),
                    'source_proof_sha256': digest(canonical(source_proofs)), 'source_proofs': source_proofs}
                self._write(self.journal, journal, 'transition_prepared')
            verify_source_proofs(store, journal['source_proofs'], journal['source_proof_sha256'],
                destination_generation=payload['destination']['policy']['generation']
                if _matches_destination(active, payload, store.install_root) else None)
            _policies(journal['source_record']['policy'], payload['destination']['policy'])
            if self._snapshot() != journal['licence_snapshot']:
                raise MigrationError('Licence state changed during the pending transition')
            if not _present(self.lease_path):
                self._write(self.lease_path, lease, 'transition_lease')

        # The active-pointer writer owns its own signing lock; the lease makes
        # releasing/reacquiring that lock safe, including for pre-transition code.
        previous_checkpoint = store.checkpoint
        store.checkpoint = lambda step: self.checkpoint('authority_' + step)
        def precommit_check():
            if self._snapshot() != journal['licence_snapshot']:
                raise MigrationError('Licence state changed before transition commit')
            if read_json(self.lease_path) != lease or read_json(self.journal) != journal:
                raise MigrationError('Transition ownership changed before commit')
            verify_source_proofs(store, journal['source_proofs'], journal['source_proof_sha256'],
                destination_generation=payload['destination']['policy']['generation']
                if _matches_destination(store.active(verify_trees=False), payload, store.install_root) else None)
            self._trees(payload, current_version)
            assert_idle()
        try:
            result = store.stage_and_activate(payload['destination']['policy'],
                digest(canonical(payload['destination']['policy'])), runtime,
                probe_runtime=probe_runtime, check_feed=check_feed, current_version=current_version,
                recovery_sha256=payload['destination']['recovery_tree_sha256'], maintenance_lease=lease,
                expected_runtime_sha256=payload['destination']['runtime_tree_sha256'], precommit_check=precommit_check)
        finally:
            store.checkpoint = previous_checkpoint
        if not _matches_destination(result, payload, store.install_root):
            raise MigrationError('Committed transition does not match the exact destination')
        self._trees(payload, current_version)
        assert_idle()
        validate_licence(app, recovery)
        with guard(store.root, maintenance=True):
            if read_json(self.lease_path) != lease or read_json(self.journal) != journal:
                raise MigrationError('Transition ownership changed before completion')
            if self._snapshot() != journal['licence_snapshot']:
                raise MigrationError('Licence state changed before transition completion')
            verify_source_proofs(store, journal['source_proofs'], journal['source_proof_sha256'],
                destination_generation=payload['destination']['policy']['generation'])
            record = {'schema_version': 1, 'document': document, 'source_record': journal['source_record'],
                'destination_generation_id': digest(canonical(result)),
                'licence_snapshot': journal['licence_snapshot'], 'source_proof_sha256': journal['source_proof_sha256'],
                'observations': {'app_ready': True, 'runtime_probed': True, 'licence_validated': True,
                    'licence_unchanged': True, 'recovery_mutations_enabled': False, 'service_restarts': 0}}
            self._write(_receipt_path(store, identity), record, 'transition_receipt')
            self._write(proof_pointer, {'schema_version': 1, 'transition_sha256': identity,
                'receipt_sha256': digest(canonical(record))}, 'transition_verified')
            verified_transition(store, result)
            remove(self.journal)
            self.checkpoint('transition_journal_removed')
            remove(self.lease_path)
            self.checkpoint('transition_lease_removed')
        return result
