"""Read-only source proof for a post-enrollment runtime transition.

A completed fresh installation is an initial baseline, not a migration. Its
real final boot and signed retained inputs can authorize a later transition
without manufacturing the three distinct migration boot observations. Ordinary
licence/update migration verification deliberately keeps its existing contract.
"""
from __future__ import annotations

import os
from pathlib import Path
import re
import stat

from .storage import MigrationError, canonical, digest, read, read_json, version

MIGRATION_PROOFS = ("verified.json", "automatic-qualification.json", "automatic-verified.json",
                    "runtime-transition-verified.json")
INTENT_FIELDS = {"schema_version", "purpose", "cpu_serial", "hostname", "device_id",
                 "licence_sha256", "licence_key_id", "qualification_sha256", "update_fingerprint",
                 "version", "target_tree_sha256", "recovery_tree_sha256", "settings_sha256"}
STATE_FIELDS = {"schema_version", "intent", "phase", "install_boot", "initialized_boot",
                "update_generation_id", "verified_boot", "health", "recovery_basis",
                "unit_recovery_boot_observed", "physical_checks"}
HEX = re.compile(r"[0-9a-f]{64}\Z")
FRESH_PROOFS = frozenset({"provisioning/fresh-install.json", "provisioning/fresh-initialized",
    "provisioning/fresh-inputs/intent.json", "provisioning/fresh-inputs/qualification.json",
    "provisioning/fresh-inputs/target-manifest.json", "provisioning/fresh-inputs/update-public.pem",
    "licence/fresh-install-receipt.json", "licence/floor.json", "licence/enrolled.json",
    "update-enrolled.json"})
OPTIONAL_MANIFEST = "provisioning/fresh-inputs/target-manifest.json"
REQUIRED_FRESH_PROOFS = FRESH_PROOFS - {OPTIONAL_MANIFEST}
TRANSITION_RECEIPT = re.compile(r"runtime-transitions/[0-9a-f]{64}\.json\Z")


def _transition_receipt_name(pointer):
    if (set(pointer) != {"schema_version", "transition_sha256", "receipt_sha256"}
            or type(pointer["schema_version"]) is not int or pointer["schema_version"] != 1
            or any(not isinstance(pointer[key], str) or not HEX.fullmatch(pointer[key])
                   for key in ("transition_sha256", "receipt_sha256"))):
        raise MigrationError("Invalid source transition proof pointer")
    return "runtime-transitions/" + pointer["transition_sha256"] + ".json"


def _migration_names(names):
    receipts = names - set(MIGRATION_PROOFS)
    if "runtime-transition-verified.json" in names:
        return len(receipts) == 1 and bool(TRANSITION_RECEIPT.fullmatch(next(iter(receipts))))
    return not receipts


def _present(path):
    return os.path.lexists(path)


def _directory(path):
    """Inspect existing authority directories without creating or following them."""
    info = path.lstat()
    if (not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid()
            or info.st_mode & 0o022):
        raise MigrationError("Fresh source proof directory is not protected")


def verify_source_proofs(store, proofs, expected_digest, *, destination_generation=None):
    """Recheck an already verified journal's fixed paths without re-enrollment.

    Only the update-generation floor legitimately changes after authority
    commitment; active() checks that floor against the signed destination.
    Every historical boot, qualification and licence proof remains immutable.
    """
    if (not isinstance(proofs, dict) or not proofs
            or not isinstance(expected_digest, str) or not HEX.fullmatch(expected_digest)
            or not (set(proofs) in (FRESH_PROOFS, REQUIRED_FRESH_PROOFS)
                    or _migration_names(set(proofs)))
            or any(not isinstance(value, str) or not HEX.fullmatch(value) for value in proofs.values())
            or digest(canonical(proofs)) != expected_digest):
        raise MigrationError("Transition source proof map is invalid")
    if destination_generation is not None and (type(destination_generation) is not int or destination_generation < 1):
        raise MigrationError("Invalid committed transition generation")
    for name, expected in proofs.items():
        if name in MIGRATION_PROOFS or TRANSITION_RECEIPT.fullmatch(name):
            path = store.folder / name
        elif name.startswith("provisioning/"):
            path = store.root.parent / name
        else:
            path = store.root / name
        try:
            parent = path.parent
            while parent != store.root.parent:
                _directory(parent)
                parent = parent.parent
            _directory(store.root.parent)
            if digest(read(path)) != expected:
                if name == "update-enrolled.json" and destination_generation is not None:
                    floor = read_json(path)
                    if (floor == {"schema_version": 1, "minimum_generation": destination_generation}
                            and type(floor["schema_version"]) is int and type(floor["minimum_generation"]) is int):
                        continue
                raise MigrationError("Transition source proof changed")
        except OSError as exc:
            raise MigrationError("Transition source proof is missing") from exc
    if "runtime-transition-verified.json" in proofs:
        pointer = read_json(store.folder / "runtime-transition-verified.json")
        name = _transition_receipt_name(pointer)
        if name not in proofs or digest(canonical(read_json(store.folder / name))) != pointer["receipt_sha256"]:
            raise MigrationError("Source transition receipt differs from its verified pointer")


def fresh_source(store, active, *, licence_path):
    from shotdeck_manifest import canonical_json_bytes, verify_manifest_payload, ReleaseManifest
    from .automatic import validate_plan
    from .licence import LicenceStore

    base = store.root.parent
    provisioning = base / "provisioning"
    inputs = provisioning / "fresh-inputs"
    for path in (base, store.root, store.root / "licence", provisioning, inputs):
        _directory(path)
    if any(_present(path) for path in (store.root / "automatic", store.root / "licence/pending.json",
                                      store.journal, store.intent)):
        raise MigrationError("Existing migration or enrollment work cannot become a fresh source proof")
    proof_paths = {
        "provisioning/fresh-install.json": provisioning / "fresh-install.json",
        "provisioning/fresh-initialized": provisioning / "fresh-initialized",
        "provisioning/fresh-inputs/intent.json": inputs / "intent.json",
        "provisioning/fresh-inputs/qualification.json": inputs / "qualification.json",
        "provisioning/fresh-inputs/target-manifest.json": inputs / "target-manifest.json",
        "provisioning/fresh-inputs/update-public.pem": inputs / "update-public.pem",
        "licence/fresh-install-receipt.json": store.root / "licence/fresh-install-receipt.json",
        "licence/floor.json": store.root / "licence/floor.json",
        "licence/enrolled.json": store.root / "licence/enrolled.json",
        "update-enrolled.json": store.enrolled,
    }
    # Some completed fresh baselines retained the signed qualification but
    # removed the original target manifest after provisioning. The signed
    # qualification independently binds that target and exact update policy;
    # the completed receipt binds its installed authority. Never manufacture
    # a replacement manifest. When retained, it is an additional immutable
    # proof and must pass its own signature and exact qualification binding.
    if not _present(proof_paths[OPTIONAL_MANIFEST]):
        del proof_paths[OPTIONAL_MANIFEST]
    # Bind the bytes actually read, then verify they stayed unchanged while
    # their relationships and signatures were checked.
    proofs = {name: digest(read(path)) for name, path in proof_paths.items()}
    assert set(proofs) in (FRESH_PROOFS, REQUIRED_FRESH_PROOFS)
    state = read_json(provisioning / "fresh-install.json")
    intent = read_json(inputs / "intent.json")
    if (set(state) != STATE_FIELDS or type(state.get("schema_version")) is not int
            or state["schema_version"] != 1 or state["phase"] != "complete"
            or state["intent"] != intent or set(intent) != INTENT_FIELDS
            or type(intent.get("schema_version")) is not int or intent["schema_version"] != 1
            or intent["purpose"] != "fresh-device-baseline"):
        raise MigrationError("A completed exact fresh installation source is required")
    for field in ("licence_sha256", "qualification_sha256", "update_fingerprint",
                  "target_tree_sha256", "recovery_tree_sha256", "settings_sha256"):
        if not isinstance(intent[field], str) or not HEX.fullmatch(intent[field]):
            raise MigrationError("Fresh source intent has an invalid digest")
    if (not isinstance(intent["cpu_serial"], str) or not re.fullmatch(r"[0-9a-f]{16}", intent["cpu_serial"])
            or not isinstance(intent["licence_key_id"], str) or not re.fullmatch(r"[0-9a-f]{16}", intent["licence_key_id"])
            or not isinstance(intent["hostname"], str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,62}", intent["hostname"])
            or not isinstance(intent["device_id"], str) or not re.fullmatch(r"SD-[0-9A-F]{8}", intent["device_id"])
            or not isinstance(intent["version"], str) or str(version(intent["version"])) != intent["version"]):
        raise MigrationError("Fresh source device identity is invalid")
    for field in ("install_boot", "initialized_boot", "verified_boot"):
        if not isinstance(state[field], str) or not re.fullmatch(r"[A-Za-z0-9-]{1,128}", state[field]):
            raise MigrationError("Fresh source lost its actual boot observations")
    health = state["health"]
    if (state["verified_boot"] == state["initialized_boot"]
            or not isinstance(health, dict) or health.get("version") != intent["version"]
            or health.get("status") != "ready" or health.get("control_ready") is not True
            or health.get("brew_active") is not False
            or state["unit_recovery_boot_observed"] is not False
            or state["physical_checks"] != "pending operator observation"
            or state["recovery_basis"] != "exact signed release qualification; tree and licence checked on this unit"):
        raise MigrationError("Fresh source needs its real final ready boot, not invented migration observations")
    # A resume after initialization can restore this marker as an empty file.
    if read(provisioning / "fresh-initialized", 16) not in (b"", b"1\n"):
        raise MigrationError("Fresh initialization marker is invalid")
    public = active["policy"]["public_key_pem"].encode("ascii")
    qualification = read_json(inputs / "qualification.json")
    plan = validate_plan(qualification, public, channel="stable")
    if (read(inputs / "update-public.pem", 16384) != public
            or digest(canonical(qualification)) != intent["qualification_sha256"]
            or digest(public) != intent["update_fingerprint"]
            or plan["update_policy"] != active["policy"]
            or state["update_generation_id"] != digest(canonical(active))
            or plan["target"]["version"] != intent["version"]
            or plan["target"]["tree_sha256"] != intent["target_tree_sha256"]
            or plan["compatibility"]["tree_sha256"] != intent["recovery_tree_sha256"]
            or active["recovery_tree_sha256"] != intent["recovery_tree_sha256"]):
        raise MigrationError("Fresh source signed inputs differ from the exact active authority")
    if OPTIONAL_MANIFEST in proofs:
        manifest = read_json(inputs / "target-manifest.json")
        verify_manifest_payload(manifest, public)
        parsed = ReleaseManifest.from_dict(manifest)
        if (digest(canonical_json_bytes(manifest)) != plan["target"]["manifest_sha256"]
                or parsed.version != intent["version"] or parsed.product != "shotdeck" or parsed.channel != "stable"
                or parsed.full_artifact.install_tree_sha256 != intent["target_tree_sha256"]
                or parsed.full_artifact.sha256 != plan["target"]["artifact_sha256"]):
            raise MigrationError("Retained fresh manifest differs from its signed qualification")
    enrolled = read_json(store.enrolled)
    licence_enrolled = read_json(store.root / "licence/enrolled.json")
    floor = read_json(store.root / "licence/floor.json")
    if (LicenceStore(store.root, licence_path).floor() != 1
            or licence_enrolled != {"schema_version": 1} or type(licence_enrolled["schema_version"]) is not int
            or enrolled != {"schema_version": 1, "minimum_generation": active["policy"]["generation"]}
            or type(enrolled["schema_version"]) is not int or type(enrolled["minimum_generation"]) is not int
            or read_json(store.root / "licence/fresh-install-receipt.json") != intent
            or floor["key_id"] != intent["licence_key_id"]
            or floor["licence_sha256"] != intent["licence_sha256"]
            or floor["receipt_sha256"] != digest(canonical(intent))
            or digest(read(licence_path, 256 * 1024, protected=False)) != intent["licence_sha256"]):
        raise MigrationError("Fresh source licence enrollment no longer matches its original receipt")
    if any(digest(read(path)) != proofs[name] for name, path in proof_paths.items()):
        raise MigrationError("Fresh source proof changed during verification")
    return active, proofs


def require_transition_source_verified(store, *, licence_path=None):
    """Return active authority and actual proof hashes; never write evidence."""
    from shotdeck_manifest.errors import ManifestError
    # A broken existing proof must never be downgraded to another proof kind.
    try:
        if any(_present(store.folder / name) for name in MIGRATION_PROOFS):
            active = store.require_verified()
            proofs = {name: digest(read(store.folder / name)) for name in MIGRATION_PROOFS
                      if _present(store.folder / name)}
            if "runtime-transition-verified.json" in proofs:
                name = _transition_receipt_name(read_json(store.folder / "runtime-transition-verified.json"))
                proofs[name] = digest(read(store.folder / name))
            verify_source_proofs(store, proofs, digest(canonical(proofs)))
            return active, proofs
        active = store.active()  # Rehash the committed runtime and retained recovery.
        if active is None:
            raise MigrationError("Transition requires an enrolled update authority")
        return fresh_source(store, active, licence_path=Path(licence_path) if licence_path is not None
                            else store.install_root / "hardware.dat")
    except (OSError, KeyError, TypeError, AttributeError, ManifestError) as exc:
        raise MigrationError("Completed fresh source proof is missing or invalid") from exc
