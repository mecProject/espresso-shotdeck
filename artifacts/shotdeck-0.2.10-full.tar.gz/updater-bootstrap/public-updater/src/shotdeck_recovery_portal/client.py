"""Bounded local RPC; the browser-facing process has no root state access."""

from __future__ import annotations

import array
from dataclasses import dataclass
import fcntl
import json
import os
from pathlib import Path
import re
import secrets
import socket
import stat
import struct

from .protected import canonical, unique

MAX_REQUEST = 16 * 1024
MAX_RESPONSE = 256 * 1024


class GatewayError(RuntimeError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


@dataclass
class GatewayReply:
    result: dict
    fd: int | None = None


class GatewayClient:
    def __init__(self, path=Path("/run/shotdeck-recovery/gateway.sock"), *, timeout=60):
        self.path = Path(path)
        self.timeout = timeout

    def call(self, action, params, *, session="", csrf="", context, want_fd=False, request_id=None) -> GatewayReply:
        request_id = request_id or secrets.token_hex(16)
        if not re.fullmatch(r"[0-9a-f]{32}", request_id):
            raise GatewayError("invalid_request", "Invalid recovery request identity")
        request = {"schema_version": 1, "id": request_id, "action": action, "params": params,
                   "auth": {"session": session, "csrf": csrf}, "context": context}
        raw = canonical(request) + b"\n"
        if len(raw) > MAX_REQUEST:
            raise GatewayError("request_limit", "Recovery request exceeds its limit")
        descriptors = []
        connection = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            for parent in (self.path.parent, *self.path.parent.parents):
                info = parent.lstat()
                if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
                    raise GatewayError("gateway_unavailable", "Recovery gateway is unavailable")
            info = self.path.lstat()
            if not stat.S_ISSOCK(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o007:
                raise GatewayError("gateway_unavailable", "Recovery gateway is unavailable")
            connection.settimeout(self.timeout)
            connection.connect(str(self.path))
            credentials = connection.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("3i"))
            _, uid, _ = struct.unpack("3i", credentials)
            if uid != 0:
                raise GatewayError("gateway_unavailable", "Recovery authority could not be verified")
            connection.sendall(raw)
            response = bytearray()
            while b"\n" not in response:
                data, ancillary, flags, _ = connection.recvmsg(min(65536, MAX_RESPONSE + 1 - len(response)), socket.CMSG_SPACE(4 * 4))
                for level, kind, content in ancillary:
                    if level != socket.SOL_SOCKET or kind != socket.SCM_RIGHTS:
                        raise GatewayError("gateway_invalid", "Unexpected recovery gateway descriptor")
                    values = array.array("i")
                    values.frombytes(content[:len(content) - len(content) % values.itemsize])
                    descriptors.extend(values)
                if flags & (socket.MSG_CTRUNC | socket.MSG_TRUNC):
                    raise GatewayError("gateway_invalid", "Recovery gateway response exceeded its limit")
                if len(descriptors) > 1:
                    raise GatewayError("gateway_invalid", "Unexpected recovery gateway descriptors")
                if not data:
                    raise GatewayError("gateway_unavailable", "Recovery gateway closed before replying")
                response.extend(data)
                if len(response) > MAX_RESPONSE:
                    raise GatewayError("gateway_invalid", "Recovery gateway response exceeded its limit")
            if response.count(b"\n") != 1 or not response.endswith(b"\n"):
                raise GatewayError("gateway_invalid", "Invalid recovery gateway response boundary")
            value = json.loads(response, object_pairs_hook=unique)
            if (not isinstance(value, dict) or value.get("schema_version") != 1 or value.get("id") != request_id
                    or type(value.get("ok")) is not bool):
                raise GatewayError("gateway_invalid", "Recovery gateway reply does not match this request")
            if not value["ok"]:
                error = value.get("error", {})
                code, message = error.get("code"), error.get("message")
                if not isinstance(code, str) or not re.fullmatch(r"[a-z0-9_]{1,80}", code) or not isinstance(message, str) or len(message) > 512:
                    raise GatewayError("gateway_invalid", "Recovery gateway refused the request")
                raise GatewayError(code, message)
            if set(value) != {"schema_version", "id", "ok", "result"} or not isinstance(value["result"], dict):
                raise GatewayError("gateway_invalid", "Invalid recovery gateway result")
            if bool(descriptors) != want_fd:
                raise GatewayError("gateway_invalid", "Missing or unexpected encrypted export")
            if descriptors:
                fd = descriptors[0]
                os.set_inheritable(fd, False)
                info = os.fstat(fd)
                if (not stat.S_ISREG(info.st_mode) or fcntl.fcntl(fd, fcntl.F_GETFL) & os.O_ACCMODE != os.O_RDONLY
                        or info.st_size != value["result"].get("size") or os.lseek(fd, 0, os.SEEK_CUR) != 0):
                    raise GatewayError("gateway_invalid", "Encrypted export descriptor is invalid")
                descriptors.clear()
                return GatewayReply(value["result"], fd)
            return GatewayReply(value["result"])
        except (OSError, ValueError, TypeError, KeyError) as exc:
            raise GatewayError("gateway_unavailable", "Recovery is temporarily unavailable; retry or use the device's support route") from exc
        finally:
            connection.close()
            for fd in descriptors:
                os.close(fd)

