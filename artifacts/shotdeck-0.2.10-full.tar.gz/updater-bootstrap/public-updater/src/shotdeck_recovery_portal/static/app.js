"use strict";
const $ = (id) => document.getElementById(id);
let csrf = "";
let paired = false;
let state = null;
let busy = false;
let polling = false;
let exportsRefreshed = 0;
let requestsInFlight = 0;

function notice(message, error = false) {
  $("notice").textContent = message;
  $("notice").classList.toggle("error", error);
}
function identity() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
async function request(action, params = null, requestId = null) {
  requestsInFlight += 1;
  $("notice").classList.add("working");
  $("notice").setAttribute("aria-busy", "true");
  try {
  const options = {method: params === null ? "GET" : "POST", credentials: "same-origin", cache: "no-store", redirect: "error"};
  if (params !== null) {
    options.headers = {"Content-Type": "application/json", "X-Shotdeck-Recovery-CSRF": csrf};
    options.body = JSON.stringify({request_id: requestId || identity(), params});
  }
  const response = await fetch("/recovery/api/" + action, options);
  const payload = await response.json();
  if (!response.ok || payload.ok !== true) {
    if (response.status === 401 && action !== "pair") showPairing();
    throw new Error(payload.error?.message || "Recovery did not accept this request.");
  }
  return payload.result;
  } finally {
    requestsInFlight -= 1;
    $("notice").classList.toggle("working", requestsInFlight > 0);
    $("notice").setAttribute("aria-busy", requestsInFlight > 0 ? "true" : "false");
  }
}
function showPairing() {
  paired = false; csrf = ""; state = null;
  $("pairing").hidden = false; $("paired").hidden = true;
}
function showPaired(result) {
  paired = true; csrf = result.csrf || csrf;
  $("pairing").hidden = true; $("paired").hidden = false;
}
function actionLabel(job) {
  const labels = {check:"Update check", apply:"Application update", rollback:"Recovery", repair_helpers:"Helper repair", diagnostics_create:"Recovery report", support_check:"Helper check", return_to_app:"Return to Shotdeck", resume:"Return to Shotdeck", enter:"Enter recovery", network_join:"Network connection"};
  return labels[job.action] || "Recovery operation";
}
function renderStatus(value) {
  state = value;
  const app = value.app || {};
  $("app-state").textContent = [app.version ? "Version " + app.version : "Application version unavailable", app.ready === true ? "Ready" : app.state || "Not ready"].join(" · ");
  $("recovery-reason").textContent = value.message || value.recovery?.reason || "";
  $("jobs").replaceChildren();
  for (const job of Array.isArray(value.jobs) ? value.jobs.slice(0, 20) : []) {
    const li = document.createElement("li"); const title = document.createElement("strong");
    li.classList.toggle("working", ["queued", "dispatching", "running", "waiting"].includes(job.state));
    const stateLabel = job.state === "succeeded" && job.action === "network_join" && job.result?.hotspot_restored === true
      ? "Hotspot restored" : job.state === "succeeded" && job.result?.requested_package_installed === false
      ? "Completed with verified fallback" : (job.state || "Unknown outcome");
    title.textContent = actionLabel(job) + " · " + stateLabel;
    const detail = document.createElement("span"); detail.textContent = job.message || job.phase || "";
    li.append(title, detail); $("jobs").append(li);
  }
  const cap = value.capabilities || {};
  $("check").disabled = busy || cap.check !== true;
  $("install").hidden = !value.offer || cap.apply !== true;
  $("install").disabled = busy;
  $("offer").textContent = value.offer ? "Available update: " + value.offer.version : value.offer_reason || "No eligible update is currently recorded. Check when internet access is available.";
  const rollback = value.rollback || {};
  $("rollback").hidden = cap.rollback !== true || rollback.available !== true;
  $("rollback").disabled = busy;
  $("rollback").textContent = "Return to " + (rollback.target?.version || "verified version");
  $("rollback-reason").textContent = rollback.reason || (rollback.available ? "This uses the verified local recovery version and does not restore older user data." : "No eligible local recovery target is currently available.");
  $("helpers-panel").hidden = cap.support_check !== true && cap.repair_helpers !== true && cap.repair_local !== true;
  $("support-check").disabled = busy || cap.support_check !== true;
  $("repair").hidden = !value.support_offer || cap.repair_helpers !== true;
  $("repair").disabled = busy;
  $("repair-local").hidden = !value.local_support_offer || cap.repair_local !== true;
  $("repair-local").disabled = busy;
  $("local-support-offer").textContent = value.local_support_offer ? "A verified local helper recovery copy is available. This does not need internet access." : "";
  $("support-offer").textContent = value.support_offer ? "Available helper revision: " + (value.support_offer.revision ?? value.support_offer.support_revision) : value.support_reason || "Check for an authenticated helper repair package.";
  $("diagnostics-actions").hidden = cap.diagnostics_create !== true;
  $("diagnostics").disabled = busy; $("diagnostics-send").disabled = busy;
  $("network-panel").hidden = cap.network_join !== true || location.protocol !== "https:";
  $("return-app").hidden = cap.return_to_app !== true;
  $("return-app").disabled = busy;
}
async function refreshExports() {
  const value = await request("exports");
  exportsRefreshed = Date.now();
  const rows = Array.isArray(value.exports) ? value.exports : [];
  $("exports").replaceChildren(); $("exports-empty").hidden = rows.length > 0;
  $("exports-empty").textContent = "No existing encrypted exports are available.";
  for (const row of rows.slice(0, 64)) {
    if (!/^[a-f0-9]{64}$/.test(row.export_id) || row.encrypted !== true) continue;
    const li = document.createElement("li"); const link = document.createElement("a");
    link.href = "/recovery/api/exports/" + row.export_id;
    link.textContent = (row.kind === "backup" ? "Encrypted backup" : "Encrypted recovery report") + " · " + (row.created_at || "Date unavailable") + " · " + (Number(row.size) / 1048576).toFixed(1) + " MiB";
    li.append(link); $("exports").append(li);
  }
}
async function refresh() {
  if (!paired || polling) return;
  polling = true;
  try {
    const value = await request("status"); renderStatus(value);
    if (Date.now() - exportsRefreshed >= 30000) await refreshExports();
  } catch (error) {notice(error.message, true);} finally {polling = false;}
}
async function act(action, params = {}, confirmation = "") {
  if (busy || !paired || confirmation && !window.confirm(confirmation)) return;
  busy = true; if (state) renderStatus(state);
  notice(action === "return_to_app" ? "Returning to Shotdeck… This may take a few minutes." : "Sending request…");
  const requestId = identity();
  try {
    const result = await request(action, params, requestId);
    notice(result.message || "Request accepted. Completion is shown in the saved operation result.");
    await refresh();
  } catch (error) {
    notice(error.message + " If the connection was lost, refresh status before submitting another request.", true);
  } finally {busy = false; if (state) renderStatus(state);}
}
$("pair-form").addEventListener("submit", async (event) => {
  event.preventDefault(); const pin = $("pin").value; $("pin").value = "";
  try {const result = await request("pair", {pin}); showPaired(result); notice("Browser paired for recovery."); await refresh();}
  catch (error) {notice(error.message, true);}
});
$("refresh").addEventListener("click", () => {exportsRefreshed = 0; refresh();});
$("check").addEventListener("click", () => act("check"));
$("install").addEventListener("click", () => {if (state?.offer) act("apply", {offer: state.offer}, "Install the exact offered version " + state.offer.version + "? Shotdeck will restart once during a successful update.");});
$("rollback").addEventListener("click", () => {const rollback = state?.rollback; if (rollback?.available) act("rollback", {target: rollback.target, capability_sha256: rollback.capability_sha256}, "Return to verified version " + rollback.target.version + "? Current user data will be preserved.");});
$("support-check").addEventListener("click", () => act("support_check"));
$("repair").addEventListener("click", () => {if (state?.support_offer) act("repair_helpers", {offer: state.support_offer}, "Install this exact authenticated helper repair package?");});
$("repair-local").addEventListener("click", () => {if (state?.local_support_offer) act("repair_local", {offer: state.local_support_offer}, "Repair helpers using this exact verified local recovery copy? No application update will be installed.");});
$("diagnostics").addEventListener("click", () => act("diagnostics_create", {upload: false}, "Create an encrypted recovery report for support? It includes bounded recovery and service observations, not shot history or settings contents."));
$("diagnostics-send").addEventListener("click", () => act("diagnostics_create", {upload: true}, "Create and send an encrypted recovery report to Shotdeck support? If upload is unavailable, the encrypted report stays available here for download."));
$("return-app").addEventListener("click", () => act("return_to_app", {}, "Leave the recovery screen and return to the verified application?"));
$("network-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  if (location.protocol !== "https:") {notice("A secure connection is required for network credentials.", true); return;}
  const ssid = $("ssid").value; const password = $("wifi-password").value; $("wifi-password").value = "";
  await act("network_join", {ssid, password}, "Connect Shotdeck to this Wi-Fi network? This connection may close; use the new address shown on the device.");
});
$("logout").addEventListener("click", async () => {try {await request("logout", {}); showPairing(); notice("Recovery session ended.");} catch (error) {notice(error.message, true);}});
document.addEventListener("visibilitychange", () => {if (!document.hidden) refresh();});
setInterval(() => {if (paired && !document.hidden) refresh();}, 5000);
(async () => {
  if (location.protocol !== "https:") {notice("Use the secure recovery address shown on the device.", true); return;}
  try {const session = await request("session"); showPaired(session); notice("Connected to recovery."); await refresh();}
  catch (error) {showPairing(); notice(error.message);}
})();
