"""Physical recovery pairing and purpose-bound sessions owned by the gateway.

The HTTP process receives neither the pairing PIN nor the signing secret.
Missing/corrupt state never creates an unauthenticated network fallback.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import time
from urllib.parse import urlsplit

from .protected import AccessError, canonical, ownership, read_json, sync_dir, unique, write_private

COOKIE = "shotdeck_recovery_session"
PURPOSE = "shotdeck-recovery-access-v1"
SESSION_SECONDS = 1800
IDLE_SECONDS = 600
CHALLENGE_SECONDS = 300
RATE_SECONDS = 300
MAX_SESSIONS = 8
MAX_PEERS = 64
CONTEXT_KEYS = {"peer_ip", "host", "origin", "secure", "method"}
_HEX = re.compile(r"[0-9a-f]{64}\Z")


def _b64(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _unb64(value: str) -> bytes:
    if not isinstance(value, str) or len(value) > 4096 or not re.fullmatch(r"[A-Za-z0-9_-]+", value):
        raise AccessError("unauthorized", "Recovery pairing is required")
    try:
        return base64.b64decode(value + "=" * (-len(value) % 4), altchars=b"-_", validate=True)
    except (ValueError, UnicodeError) as exc:
        raise AccessError("unauthorized", "Recovery pairing is required") from exc


def canonical_host(value: str) -> str:
    if (not isinstance(value, str) or not 1 <= len(value) <= 255 or value != value.strip()
            or any(char in value for char in "/\\@?#\r\n\t ")):
        raise AccessError("invalid_origin", "Invalid recovery address")
    try:
        parsed = urlsplit("http://" + value)
        host, port = parsed.hostname, parsed.port
        if host is None or port != 8081 or parsed.username or parsed.password:
            raise ValueError("Unexpected recovery port")
        try:
            address = ipaddress.ip_address(host)
            host = "[" + address.compressed + "]" if address.version == 6 else address.compressed
        except ValueError:
            if not re.fullmatch(r"[a-zA-Z0-9](?:[a-zA-Z0-9.-]{0,251}[a-zA-Z0-9])?", host):
                raise ValueError("Invalid hostname")
            host = host.lower()
        return host + ":8081"
    except ValueError as exc:
        raise AccessError("invalid_origin", "Invalid recovery address") from exc


def validate_context(context: dict, allowed_hosts, *, mutating=False) -> tuple[str, str]:
    if not isinstance(context, dict) or set(context) != CONTEXT_KEYS or context["secure"] is not True:
        raise AccessError("invalid_origin", "Invalid recovery request context")
    try:
        peer = ipaddress.ip_address(context["peer_ip"]).compressed
    except (ValueError, TypeError) as exc:
        raise AccessError("invalid_origin", "Invalid recovery client address") from exc
    method = context["method"]
    if method not in {"GET", "POST"} or (mutating and method != "POST"):
        raise AccessError("invalid_origin", "Recovery changes require an explicit request")
    hosts = allowed_hosts() if callable(allowed_hosts) else allowed_hosts
    host = canonical_host(context["host"])
    if host not in {canonical_host(item) for item in hosts}:
        raise AccessError("invalid_origin", "Use the recovery address shown on the device")
    expected = ("https://" if context["secure"] else "http://") + host
    origin = context["origin"]
    if not isinstance(origin, str) or len(origin) > 300 or (origin != expected and (origin or mutating)):
        raise AccessError("invalid_origin", "Cross-origin recovery requests are refused")
    return peer, expected


class AuthStore:
    def __init__(self, root=Path("/var/lib/shotdeck/recovery-access"), *, allowed_hosts=()):
        self.root = Path(root)
        self.path = self.root / "auth.json"
        self.allowed_hosts = allowed_hosts

    @staticmethod
    def _boot() -> str:
        value = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        if not re.fullmatch(r"[0-9a-f-]{36}", value):
            raise AccessError("unavailable", "Recovery boot identity is unavailable")
        return value

    def _read(self, now: int) -> dict:
        try:
            state = read_json(self.path)
        except FileNotFoundError as exc:
            raise AccessError("pairing_required", "Open Recovery on the device to pair this browser") from exc
        expected = {"schema_version", "purpose", "epoch", "secret", "last_clock", "challenge", "sessions", "attempts"}
        if (set(state) != expected or type(state["schema_version"]) is not int or state["schema_version"] != 1
                or state["purpose"] != PURPOSE or not _HEX.fullmatch(str(state["epoch"]))
                or type(state["last_clock"]) is not int or now < state["last_clock"] - 5
                or not isinstance(state["sessions"], dict) or len(state["sessions"]) > MAX_SESSIONS
                or not isinstance(state["attempts"], dict) or len(state["attempts"]) > MAX_PEERS + 1
                or len(_unb64(state["secret"])) != 32):
            raise AccessError("invalid_auth_state", "Use the physical recovery controls to reset recovery pairing")
        for key, row in state["sessions"].items():
            if (not _HEX.fullmatch(key) or not isinstance(row, dict)
                    or set(row) != {"expires", "last_used", "origin", "peer_hash", "boot"}
                    or any(type(row[x]) is not int for x in ("expires", "last_used"))
                    or not isinstance(row["origin"], str) or len(row["origin"]) > 300
                    or not _HEX.fullmatch(str(row["peer_hash"])) or not isinstance(row["boot"], str)):
                raise AccessError("invalid_auth_state", "Recovery session state is corrupt")
        for key, row in state["attempts"].items():
            if (key != "global" and not _HEX.fullmatch(key)) or not isinstance(row, dict) or set(row) != {"start", "count"}:
                raise AccessError("invalid_auth_state", "Recovery pairing rate state is corrupt")
            if type(row["start"]) is not int or type(row["count"]) is not int or not 0 <= row["count"] <= 1000:
                raise AccessError("invalid_auth_state", "Recovery pairing rate state is corrupt")
        challenge = state["challenge"]
        if challenge is not None and (not isinstance(challenge, dict)
                or set(challenge) != {"id", "pin_digest", "expires", "boot"}
                or not _HEX.fullmatch(str(challenge["id"])) or not _HEX.fullmatch(str(challenge["pin_digest"]))
                or type(challenge["expires"]) is not int or not isinstance(challenge["boot"], str)):
            raise AccessError("invalid_auth_state", "Recovery pairing challenge is corrupt")
        state["last_clock"] = max(state["last_clock"], now)
        return state

    @staticmethod
    def _mac(state, purpose: str, value: str) -> str:
        return hmac.new(_unb64(state["secret"]), (PURPOSE + "\0" + purpose + "\0" + value).encode(), hashlib.sha256).hexdigest()

    def physical_pairing(self, *, reset=False) -> dict:
        """Called only by the authenticated local physical-control gateway.

        A reset intentionally replaces recovery authentication only. Corrupt
        prior bytes are retained, never silently repaired by a network call.
        """
        now = int(time.time())
        with ownership(self.root, create=True):
            if reset and os.path.lexists(self.path):
                # Retain the exact bounded previous bytes, including corruption.
                from .protected import read_private
                previous = read_private(self.path)
                archive = self.root / ("auth-reset-" + secrets.token_hex(16) + ".json")
                fd = os.open(archive, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
                with os.fdopen(fd, "wb") as stream:
                    stream.write(previous); stream.flush(); os.fsync(stream.fileno())
                os.unlink(self.path); sync_dir(self.root)
            if not os.path.lexists(self.path):
                state = {"schema_version": 1, "purpose": PURPOSE, "epoch": secrets.token_hex(32),
                         "secret": _b64(secrets.token_bytes(32)), "last_clock": now,
                         "challenge": None, "sessions": {}, "attempts": {}}
            else:
                state = self._read(now)
            pin = f"{secrets.randbelow(1_000_000):06d}"
            challenge = {"id": secrets.token_hex(32), "expires": now + CHALLENGE_SECONDS, "boot": self._boot()}
            challenge["pin_digest"] = self._mac(state, "pin", challenge["id"] + ":" + pin)
            state["challenge"] = challenge
            write_private(self.path, state)
            return {"pin": pin, "expires_at": challenge["expires"], "challenge_id": challenge["id"]}

    def pair(self, pin: str, context: dict) -> dict:
        peer, origin = validate_context(context, self.allowed_hosts, mutating=True)
        if not isinstance(pin, str) or not re.fullmatch(r"[0-9]{6}", pin):
            raise AccessError("pairing_failed", "The recovery PIN was not accepted")
        now = int(time.time())
        with ownership(self.root):
            state = self._read(now)
            peer_hash = self._mac(state, "peer", peer)
            attempts = {key: row for key, row in state["attempts"].items() if now - row["start"] < RATE_SECONDS}
            if peer_hash not in attempts and len(attempts) >= MAX_PEERS:
                raise AccessError("rate_limited", "Recovery pairing is temporarily limited")
            for key, limit in (("global", 20), (peer_hash, 5)):
                row = attempts.setdefault(key, {"start": now, "count": 0})
                if row["count"] >= limit:
                    raise AccessError("rate_limited", "Wait before trying recovery pairing again")
            for key in ("global", peer_hash):
                attempts[key]["count"] += 1
            state["attempts"] = attempts
            write_private(self.path, state)  # Failed attempts survive process death.
            challenge = state["challenge"]
            if (challenge is None or challenge["expires"] <= now or challenge["boot"] != self._boot()
                    or not hmac.compare_digest(challenge["pin_digest"], self._mac(state, "pin", challenge["id"] + ":" + pin))):
                raise AccessError("pairing_failed", "The recovery PIN was not accepted; open Recovery on the device")
            state["sessions"] = {key: row for key, row in state["sessions"].items()
                                 if row["expires"] > now and now - row["last_used"] < IDLE_SECONDS and row["boot"] == self._boot()}
            if len(state["sessions"]) >= MAX_SESSIONS:
                raise AccessError("session_limit", "Use the device to reset old recovery sessions")
            sid = secrets.token_hex(32)
            state["sessions"][sid] = {"expires": now + SESSION_SECONDS, "last_used": now,
                                       "origin": origin, "peer_hash": peer_hash, "boot": self._boot()}
            payload = _b64(canonical({"purpose": PURPOSE, "epoch": state["epoch"], "sid": sid}))
            token = payload + "." + self._mac(state, "session", payload)
            state["challenge"] = None
            write_private(self.path, state)
            return {"session": token, "csrf": self._mac(state, "csrf", sid), "expires_at": now + SESSION_SECONDS}

    def authorize(self, session: str, csrf: str, context: dict, *, mutating=False) -> dict:
        peer, origin = validate_context(context, self.allowed_hosts, mutating=mutating)
        now = int(time.time())
        with ownership(self.root):
            state = self._read(now)
            sid, row = self._verify(state, session, csrf, peer, origin, mutating=mutating, now=now)
            if now - row["last_used"] >= 30:
                row["last_used"] = now
                write_private(self.path, state)
            return {"session_id": sid, "expires_at": row["expires"], "csrf": self._mac(state, "csrf", sid)}

    def _verify(self, state, session, csrf, peer, origin, *, mutating, now):
        try:
            payload, signature = session.split(".")
            if len(session) > 2048 or not _HEX.fullmatch(signature) or not hmac.compare_digest(signature, self._mac(state, "session", payload)):
                raise ValueError()
            decoded = json.loads(_unb64(payload), object_pairs_hook=unique)
            if set(decoded) != {"purpose", "epoch", "sid"} or decoded["purpose"] != PURPOSE or decoded["epoch"] != state["epoch"]:
                raise ValueError()
            sid = decoded["sid"]
            row = state["sessions"][sid]
            if (row["expires"] <= now or now - row["last_used"] >= IDLE_SECONDS or row["boot"] != self._boot()
                    or row["origin"] != origin or row["peer_hash"] != self._mac(state, "peer", peer)):
                raise ValueError()
            if mutating and (not isinstance(csrf, str) or not hmac.compare_digest(csrf, self._mac(state, "csrf", sid))):
                raise AccessError("csrf_refused", "Reload the recovery page before trying again")
            return sid, row
        except (AttributeError, TypeError, ValueError, KeyError, UnicodeError) as exc:
            if isinstance(exc, AccessError) and exc.code == "csrf_refused":
                raise
            raise AccessError("unauthorized", "Recovery pairing is required") from exc

    def logout(self, session: str, csrf: str, context: dict) -> dict:
        peer, origin = validate_context(context, self.allowed_hosts, mutating=True)
        now = int(time.time())
        with ownership(self.root):
            state = self._read(now)
            sid, _ = self._verify(state, session, csrf, peer, origin, mutating=True, now=now)
            del state["sessions"][sid]
            write_private(self.path, state)
        return {"paired": False}
