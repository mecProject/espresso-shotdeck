"""Independent recovery access; never imports the application or its stores."""

PROTOCOL_VERSION = 1
PORT = 8081

