"""Bounded, redacted diagnostics without application imports or database access.

Run only in the seed's independently admitted executor after an explicit paired
request. No plaintext is written to disk and uploads never fall back to HTTP.
"""

from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import http.client
import io
import json
import os
from pathlib import Path
import re
import secrets
import selectors
import ssl
import subprocess
import time
import zipfile

from .exports import ExportStore
from .protected import AccessError, canonical, ownership, protected_directory, read_private, sync_dir, unique, write_private

RECIPIENT_PATH = Path("/etc/shotdeck/support-diagnostics-recipient.pem")
TOKEN_PATH = Path("/etc/shotdeck/diagnostics-upload-token")
DEFAULT_RECIPIENT = "CsL3/GHADYe6cbm6SmCwGKNQgPOiuG63rlDfK3eeBC4="
UPLOAD_HOST = "support.espresso-shotdeck.com"
UPLOAD_PATH = "/diagnostics/upload.php"
UNITS = ("shotdeck.service", "bluetooth.service", "shotdeck-update-queue.service",
         "shotdeck-recovery-watchdog.service", "shotdeck-recovery-gateway.service",
         "shotdeck-recovery.service")
PROPERTIES = ("Id", "ActiveState", "SubState", "Result", "ExecMainCode", "ExecMainStatus",
              "NRestarts", "MemoryCurrent", "MemoryPeak", "MemoryHigh", "MemoryMax")
MAX_PLAINTEXT = 2 * 1024 * 1024


def bounded_command(argv, *, limit=262144, timeout=10) -> bytes:
    process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                               stderr=subprocess.DEVNULL, close_fds=True)
    output = bytearray(); deadline = time.monotonic() + timeout
    try:
        with selectors.DefaultSelector() as poller:
            poller.register(process.stdout, selectors.EVENT_READ)
            while poller.get_map():
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise AccessError("diagnostics_timeout", "A diagnostic observation timed out")
                for key, _ in poller.select(min(remaining, 1)):
                    chunk = os.read(key.fileobj.fileno(), min(65536, limit + 1 - len(output)))
                    if not chunk:
                        poller.unregister(key.fileobj)
                    else:
                        output.extend(chunk)
                        if len(output) > limit:
                            raise AccessError("diagnostics_limit", "A diagnostic observation exceeded its limit")
            if process.wait(timeout=max(0.1, deadline - time.monotonic())):
                raise AccessError("diagnostics_unavailable", "A diagnostic observation is unavailable")
        return bytes(output)
    finally:
        if process.poll() is None:
            process.kill(); process.wait()
        process.stdout.close()


def recipient_key(path=RECIPIENT_PATH) -> bytes:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PublicKey
    try:
        raw = read_private(path, limit=8192, private=False)
    except FileNotFoundError:
        return base64.b64decode(DEFAULT_RECIPIENT, validate=True)
    try:
        if raw.startswith(b"-----BEGIN"):
            public = serialization.load_pem_public_key(raw)
            if not isinstance(public, X25519PublicKey):
                raise ValueError("Wrong recipient algorithm")
            raw = public.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
        elif len(raw) != 32:
            raw = base64.b64decode(raw.strip(), validate=True)
        if len(raw) != 32:
            raise ValueError("Wrong recipient size")
        X25519PublicKey.from_public_bytes(raw)
        return raw
    except (TypeError, ValueError) as exc:
        raise AccessError("invalid_recipient", "The configured support encryption recipient is invalid") from exc


def encrypt(plaintext: bytes, public_key: bytes) -> bytes:
    # Existing Shotdeck diagnostics wire format; no app dependency or fallback.
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    ephemeral = X25519PrivateKey.generate()
    shared = ephemeral.exchange(X25519PublicKey.from_public_bytes(public_key))
    key = HKDF(algorithm=hashes.SHA256(), length=32, salt=None, info=b"shotdeck-diagnostic-v1").derive(shared)
    nonce = secrets.token_bytes(12)
    return ephemeral.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw) + nonce + AESGCM(key).encrypt(nonce, plaintext, None)


def _scalar(value):
    return (type(value) in {bool, int} or value is None
            or isinstance(value, str) and len(value) <= 128 and re.fullmatch(r"[A-Za-z0-9_.:+ /-]*", value))


class DiagnosticsCollector:
    def __init__(self, root=Path("/var/lib/shotdeck/recovery-access"), *, exports: ExportStore | None = None):
        self.root = Path(root)
        self.directory = self.root / "exports"
        self.exports = exports or ExportStore(diagnostics_root=self.directory)

    def _observations(self) -> dict:
        units = {}
        for unit in UNITS:
            try:
                raw = bounded_command(["/usr/bin/systemctl", "show", unit, "--no-pager", "--property=" + ",".join(PROPERTIES)], limit=16384)
                values = dict(line.split("=", 1) for line in raw.decode("utf-8", "replace").splitlines() if "=" in line)
                units[unit] = {key: value for key, value in values.items() if key in PROPERTIES and _scalar(value)}
            except (AccessError, OSError, subprocess.SubprocessError):
                units[unit] = {"observation": "unavailable"}
        journal = []
        try:
            raw = bounded_command(["/usr/bin/journalctl", "--boot", "--no-pager", "-n", "128", "-o", "json",
                                   *[argument for unit in UNITS for argument in ("-u", unit)]])
            for line in raw.splitlines():
                row = json.loads(line, object_pairs_hook=unique)
                unit = row.get("_SYSTEMD_UNIT", row.get("UNIT"))
                if unit not in UNITS:
                    continue
                projected = {key: row[key] for key in ("__REALTIME_TIMESTAMP", "MESSAGE_ID", "PRIORITY") if key in row and _scalar(row[key])}
                projected["unit"] = unit
                # Free text is intentionally omitted, not regex-redacted: it may
                # contain customer labels or secrets we cannot safely identify.
                projected["message_text"] = "omitted"
                journal.append(projected)
        except (AccessError, OSError, ValueError, subprocess.SubprocessError):
            journal = [{"observation": "unavailable"}]
        records = {}
        fixed = {
            "activation": Path("/var/lib/shotdeck/updater/activation-journal.json"),
            "recovery": Path("/var/lib/shotdeck/updater/recovery/state.json"),
            "worker": Path("/var/lib/shotdeck/updater/dispatch/mode.json"),
            "support": Path("/var/lib/shotdeck/updater/support-bootstrap.json"),
        }
        for label, path in fixed.items():
            try:
                raw = read_private(path)
                row = json.loads(raw, object_pairs_hook=unique)
                record = row.get("record", row) if isinstance(row, dict) else {}
                fields = ("schema_version", "phase", "state", "reason", "error_code", "attempts", "latched", "mode", "revision")
                records[label] = {"sha256": hashlib.sha256(raw).hexdigest(),
                    "observed": {key: record[key] for key in fields if key in record and _scalar(record[key])}}
            except FileNotFoundError:
                records[label] = {"observation": "absent"}
            except (AccessError, OSError, ValueError, TypeError):
                records[label] = {"observation": "unreadable_or_invalid"}
        receipts = []
        folder = Path("/var/lib/shotdeck/updater/jobs/receipts")
        try:
            protected_directory(folder)
            with os.scandir(folder) as paths:
                for index, entry in enumerate(paths):
                    if index >= 64:
                        break
                    if not re.fullmatch(r"[A-Za-z0-9_-]{1,100}\.json", entry.name):
                        continue
                    try:
                        row = json.loads(read_private(Path(entry.path)), object_pairs_hook=unique)
                        fields = ("schema_version", "action", "state", "outcome", "error_code", "created_at", "completed_at")
                        receipts.append({key: row[key] for key in fields if key in row and _scalar(row[key])})
                    except (AccessError, OSError, ValueError, TypeError):
                        receipts.append({"observation": "unreadable_or_invalid"})
        except (FileNotFoundError, AccessError):
            pass
        return {"units": units, "journal_events": journal, "records": records, "job_receipts": receipts}

    def create(self) -> dict:
        public_key = recipient_key()  # Invalid configured recipient refuses before collection.
        created = datetime.now(timezone.utc).isoformat()
        bundle_id = secrets.token_hex(16)
        try:
            cpuinfo = read_private(Path("/proc/cpuinfo"), limit=131072, private=False)
            serial = re.search(rb"^Serial\s*:\s*([0-9a-fA-F]{16})\s*$", cpuinfo, re.MULTILINE)
            device_short_id = hashlib.sha256(serial.group(1).lower()).hexdigest()[:12] if serial else "unknown"
        except (AccessError, OSError):
            device_short_id = "unavailable"
        software_version = "unavailable"
        try:
            current = Path("/opt/shotdeck/current")
            selected = current.resolve(strict=True)
            if current.is_symlink() and selected.parent == Path("/opt/shotdeck/releases"):
                version = read_private(selected / ".shotdeck-version", limit=128, private=False).decode("ascii").strip()
                if re.fullmatch(r"[A-Za-z0-9.+_-]{1,80}", version):
                    software_version = version
        except (AccessError, OSError, UnicodeError):
            pass
        upload_metadata = {"bundle_id": bundle_id, "device_short_id": device_short_id,
                           "software_version": software_version, "created_at": created}
        observations = self._observations()
        manifest = {"schema_version": 1, "purpose": "shotdeck-recovery-diagnostics", "bundle_id": bundle_id,
                    "created_at": created, "upload_metadata": upload_metadata,
                    "privacy": {"database_access": "none", "customer_data": "excluded", "device_identifier": "sha256_truncated",
                    "free_text_log_messages": "excluded", "network_identifiers": "excluded", "settings": "excluded"}}
        data = io.BytesIO()
        with zipfile.ZipFile(data, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("manifest.json", canonical(manifest))
            archive.writestr("recovery-observations.json", canonical(observations))
        plaintext = data.getvalue()
        if len(plaintext) > MAX_PLAINTEXT:
            raise AccessError("diagnostics_limit", "Diagnostic export exceeds its limit")
        ciphertext = encrypt(plaintext, public_key)
        filename = "shotdeck-recovery-" + created[:10] + "-" + bundle_id + ".zip.enc"
        with ownership(self.root, create=True):
            protected_directory(self.directory, create=True)
            # Bounded retention without deleting evidence implicitly.
            if sum(1 for _ in self.directory.iterdir()) >= 32:
                raise AccessError("export_limit", "Remove older diagnostic exports through local support before creating another")
            path = self.directory / filename
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
            with os.fdopen(fd, "wb") as stream:
                stream.write(ciphertext); stream.flush(); os.fsync(stream.fileno())
            sync_dir(self.directory)
            receipt = {"schema_version": 1, "kind": "encrypted_recovery_diagnostics", "filename": filename,
                       "size": len(ciphertext), "sha256": hashlib.sha256(ciphertext).hexdigest(), "created_at": created,
                       "recipient_sha256": hashlib.sha256(public_key).hexdigest(), "upload_metadata": upload_metadata}
            write_private(path.with_suffix(path.suffix + ".json"), receipt)
        metadata, fd = self.exports._open("diagnostics", path)
        os.close(fd)
        return {**metadata, "status": "saved", "bundle_id": bundle_id, "upload_available": self.upload_available()}

    @staticmethod
    def upload_available() -> bool:
        try:
            token = read_private(TOKEN_PATH, limit=4096).decode("ascii").strip()
            return bool(re.fullmatch(r"[A-Za-z0-9._~+/-]{16,4096}", token))
        except (AccessError, OSError, UnicodeError):
            return False

    def upload(self, export_id: str) -> dict:
        """Explicit upload of an existing encrypted diagnostic, never a backup."""
        metadata, fd = self.exports.open(export_id)
        connection = None
        try:
            if metadata["kind"] != "diagnostics":
                raise AccessError("invalid_export", "Only recovery diagnostics can be sent to support")
            try:
                token = read_private(TOKEN_PATH, limit=4096).decode("ascii").strip()
            except (AccessError, OSError, UnicodeError) as exc:
                raise AccessError("upload_unavailable", "Encrypted export is saved; support upload credentials are unavailable") from exc
            if not re.fullmatch(r"[A-Za-z0-9._~+/-]{16,4096}", token):
                raise AccessError("upload_unavailable", "Encrypted export is saved; support upload credentials are invalid")
            boundary = "shotdeck-recovery-" + secrets.token_hex(16)
            receipt = json.loads(read_private(self.directory / (metadata["filename"] + ".json")), object_pairs_hook=unique)
            fields = receipt.get("upload_metadata")
            if not isinstance(fields, dict) or set(fields) != {"bundle_id", "device_short_id", "software_version", "created_at"}:
                raise AccessError("invalid_export", "Encrypted diagnostic upload metadata is invalid")
            if any(not isinstance(value, str) or not 1 <= len(value) <= 128 or "\r" in value or "\n" in value for value in fields.values()):
                raise AccessError("invalid_export", "Encrypted diagnostic upload metadata is invalid")
            prefix = b"".join(("--" + boundary + '\r\nContent-Disposition: form-data; name="' + name
                              + '"\r\n\r\n' + value + "\r\n").encode("ascii") for name, value in fields.items())
            prefix += ("--" + boundary + '\r\nContent-Disposition: form-data; name="bundle"; filename="'
                      + metadata["filename"] + '"\r\nContent-Type: application/octet-stream\r\n\r\n').encode("ascii")
            suffix = ("\r\n--" + boundary + "--\r\n").encode("ascii")
            connection = http.client.HTTPSConnection(UPLOAD_HOST, timeout=30, context=ssl.create_default_context())
            connection.putrequest("POST", UPLOAD_PATH)
            connection.putheader("Authorization", "Bearer " + token)
            connection.putheader("Content-Type", "multipart/form-data; boundary=" + boundary)
            connection.putheader("Content-Length", str(len(prefix) + metadata["size"] + len(suffix)))
            connection.putheader("User-Agent", "ShotdeckRecoveryDiagnostics/1")
            connection.endheaders(); connection.send(prefix)
            remaining = metadata["size"]
            while remaining:
                chunk = os.read(fd, min(65536, remaining))
                if not chunk:
                    raise AccessError("export_changed", "Encrypted export changed before upload completed")
                connection.send(chunk); remaining -= len(chunk)
            connection.send(suffix)
            response = connection.getresponse()
            raw = response.read(16385)
            if response.status != 200 or len(raw) > 16384:
                raise AccessError("upload_failed", "Support upload failed; the encrypted export is still saved")
            value = json.loads(raw, object_pairs_hook=unique)
            code = value.get("support_code", "") if isinstance(value, dict) else ""
            if not isinstance(value, dict) or value.get("status") not in {"saved", "sent", "ok"} or not re.fullmatch(r"[A-Za-z0-9-]{0,64}", str(code)):
                raise AccessError("upload_failed", "Support did not confirm the encrypted upload")
            return {"export_id": export_id, "status": "sent", "support_code": code}
        except (OSError, http.client.HTTPException, ValueError) as exc:
            if isinstance(exc, AccessError):
                raise
            raise AccessError("upload_failed", "Support upload failed; the encrypted export is still saved") from exc
        finally:
            os.close(fd)
            if connection is not None:
                connection.close()
