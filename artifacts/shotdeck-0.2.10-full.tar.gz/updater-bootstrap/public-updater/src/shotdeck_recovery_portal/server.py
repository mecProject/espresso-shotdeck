"""Small TLS-only, socket-activated recovery portal with bounded HTTP parsing."""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
import ipaddress
import json
import os
from pathlib import Path
import re
import select
import signal
import socket
import ssl
import stat
import threading
import time

from .auth import COOKIE, SESSION_SECONDS, canonical_host
from .client import GatewayClient, GatewayError
from .protected import AccessError, canonical, unique

ROOT = "/recovery/"
MAX_HEADER = 16 * 1024
MAX_BODY = 12 * 1024
IDLE_SECONDS = 120
CERTIFICATE = Path("/etc/shotdeck/recovery-portal/server.crt")
PRIVATE_KEY = Path("/etc/shotdeck/recovery-portal/server.key")
ASSETS = {ROOT: ("index.html", "text/html; charset=utf-8"),
          ROOT + "app.js": ("app.js", "text/javascript; charset=utf-8"),
          ROOT + "style.css": ("style.css", "text/css; charset=utf-8")}
POST_ACTIONS = {"check", "apply", "rollback", "support_check", "repair_helpers", "repair_local", "diagnostics_create",
                "network_join", "return_to_app", "logout"}
GET_ACTIONS = {"session", "status", "exports"}
REASONS = {200: "OK", 202: "Accepted", 303: "See Other", 400: "Bad Request", 401: "Unauthorized",
           403: "Forbidden", 404: "Not Found", 405: "Method Not Allowed", 409: "Conflict",
           413: "Payload Too Large", 429: "Too Many Requests", 503: "Service Unavailable"}


def allowed_hosts(local_address: str) -> set[str]:
    hosts = {"localhost:8081"}
    name = socket.gethostname().lower().rstrip(".")
    if re.fullmatch(r"[a-z0-9][a-z0-9.-]{0,251}", name):
        hosts.add(name + ":8081")
        if "." not in name:
            hosts.add(name + ".local:8081")
    address = ipaddress.ip_address(local_address.split("%", 1)[0])
    if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped:
        address = address.ipv4_mapped
    hosts.add(("[" + address.compressed + "]" if address.version == 6 else address.compressed) + ":8081")
    return hosts


def parse_request(connection) -> tuple[str, str, dict, bytes]:
    raw = bytearray(); deadline = time.monotonic() + 10
    while b"\r\n\r\n" not in raw:
        if time.monotonic() >= deadline:
            raise GatewayError("request_timeout", "Recovery request took too long")
        connection.settimeout(max(0.1, deadline - time.monotonic()))
        chunk = connection.recv(min(4096, MAX_HEADER + MAX_BODY + 4 - len(raw)))
        if not chunk:
            raise GatewayError("invalid_request", "Incomplete recovery request")
        raw.extend(chunk)
        if len(raw.split(b"\r\n\r\n", 1)[0]) > MAX_HEADER:
            raise GatewayError("request_limit", "Recovery request headers exceed their limit")
    head, body = bytes(raw).split(b"\r\n\r\n", 1)
    try:
        lines = head.decode("ascii").split("\r\n")
        method, path, version = lines[0].split(" ")
    except (UnicodeError, ValueError) as exc:
        raise GatewayError("invalid_request", "Invalid recovery request") from exc
    if method not in {"GET", "POST"} or version not in {"HTTP/1.0", "HTTP/1.1"}:
        raise GatewayError("invalid_method", "Recovery accepts only GET and POST")
    if len(path) > 256 or not re.fullmatch(r"/[A-Za-z0-9_./-]*", path) or ".." in path.split("/"):
        raise GatewayError("invalid_request", "Invalid recovery request path")
    headers = {}
    if len(lines) > 49:
        raise GatewayError("request_limit", "Too many recovery headers")
    for line in lines[1:]:
        if not line or line[0].isspace() or ":" not in line:
            raise GatewayError("invalid_request", "Invalid recovery request header")
        name, value = line.split(":", 1); name = name.lower(); value = value.strip()
        if not re.fullmatch(r"[a-z0-9-]+", name) or name in headers or any(ord(c) < 32 or ord(c) == 127 for c in value):
            raise GatewayError("invalid_request", "Duplicate or invalid recovery header")
        headers[name] = value
    if "transfer-encoding" in headers or "expect" in headers or "upgrade" in headers:
        raise GatewayError("invalid_request", "Unsupported recovery transfer mode")
    length = headers.get("content-length", "0")
    if not re.fullmatch(r"[0-9]{1,6}", length) or int(length) > MAX_BODY or method == "GET" and int(length):
        raise GatewayError("request_limit", "Recovery request body exceeds its limit")
    length = int(length)
    if len(body) > length:
        raise GatewayError("invalid_request", "Pipelined recovery requests are not accepted")
    while len(body) < length:
        if time.monotonic() >= deadline:
            raise GatewayError("request_timeout", "Recovery request took too long")
        connection.settimeout(max(0.1, deadline - time.monotonic()))
        chunk = connection.recv(length - len(body))
        if not chunk:
            raise GatewayError("invalid_request", "Incomplete recovery request body")
        body += chunk
    return method, path, headers, body


def session_cookie(headers):
    raw = headers.get("cookie", "")
    if len(raw) > 4096:
        raise GatewayError("invalid_request", "Recovery cookie exceeds its limit")
    found = []
    for item in raw.split(";"):
        if "=" in item:
            name, value = item.strip().split("=", 1)
            if name == COOKIE:
                found.append(value)
    if len(found) > 1:
        raise GatewayError("invalid_request", "Ambiguous recovery cookie")
    return found[0] if found else ""


def response(connection, status, body=b"", *, content_type="application/json; charset=utf-8", extra=None, length=None):
    fields = {"Content-Type": content_type, "Content-Length": str(len(body) if length is None else length),
              "Connection": "close", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff",
              "Referrer-Policy": "no-referrer", "X-Frame-Options": "DENY",
              "Content-Security-Policy": "default-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"}
    fields.update(extra or {})
    header = "HTTP/1.1 " + str(status) + " " + REASONS[status] + "\r\n"
    header += "".join(key + ": " + value + "\r\n" for key, value in fields.items()) + "\r\n"
    connection.sendall(header.encode("ascii") + body)


class Portal:
    def __init__(self, gateway=None):
        self.gateway = gateway or GatewayClient()
        self.last_activity = time.monotonic()
        self.active = 0
        self.lock = threading.Lock()

    def handle(self, connection: ssl.SSLSocket, peer):
        with self.lock:
            self.last_activity = time.monotonic()
        fd = None; sent = False
        try:
            connection.settimeout(10)
            method, path, headers, body = parse_request(connection)
            host = canonical_host(headers.get("host", ""))
            if host not in allowed_hosts(connection.getsockname()[0]):
                raise GatewayError("invalid_origin", "Use the recovery address shown on the device")
            origin = headers.get("origin", "")
            expected = "https://" + host
            # Opening the public landing page from a camera/QR scanner is a
            # legitimate cross-site navigation. It serves fixed HTML only and
            # cannot call the privileged gateway. API reads, exports, pairing
            # and mutations retain their exact Origin/Fetch Metadata checks.
            landing = method == "GET" and path in {"/", ROOT}
            if not landing and (origin and origin != expected or method == "POST" and origin != expected):
                raise GatewayError("invalid_origin", "Cross-origin recovery requests are refused")
            if not landing and headers.get("sec-fetch-site") not in {None, "same-origin", "none"}:
                raise GatewayError("invalid_origin", "Cross-site recovery requests are refused")
            secure = isinstance(connection, ssl.SSLSocket) and bool(connection.cipher())
            if not secure:
                raise GatewayError("invalid_origin", "Recovery requires its encrypted connection")
            context = {"peer_ip": peer[0], "host": host, "origin": origin, "method": method, "secure": secure}
            if method == "GET" and path == "/":
                response(connection, 303, extra={"Location": ROOT}); return
            if method == "GET" and path in ASSETS:
                name, content_type = ASSETS[path]
                asset = Path(__file__).with_name("static") / name
                if asset.is_symlink() or asset.stat().st_size > 65536:
                    raise GatewayError("unavailable", "Recovery page is unavailable")
                response(connection, 200, asset.read_bytes(), content_type=content_type); return
            if not path.startswith(ROOT + "api/"):
                response(connection, 404, canonical({"error": {"code": "not_found", "message": "Recovery page not found"}})); return
            endpoint = path.removeprefix(ROOT + "api/")
            token = session_cookie(headers); csrf = headers.get("x-shotdeck-recovery-csrf", "")
            if method == "GET" and endpoint.startswith("exports/"):
                export_id = endpoint.removeprefix("exports/")
                if not re.fullmatch(r"[0-9a-f]{64}", export_id):
                    raise GatewayError("invalid_export", "Unknown encrypted export")
                reply = self.gateway.call("export_open", {"export_id": export_id}, session=token, csrf=csrf, context=context, want_fd=True)
                fd = reply.fd; metadata = reply.result
                if (not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,180}", str(metadata.get("filename")))
                        or metadata.get("encrypted") is not True or type(metadata.get("size")) is not int
                        or not 1 <= metadata["size"] <= 272 * 1024 * 1024):
                    raise GatewayError("invalid_export", "Encrypted export metadata is invalid")
                response(connection, 200, content_type="application/octet-stream", length=metadata["size"],
                         extra={"Content-Disposition": 'attachment; filename="' + metadata["filename"] + '"'})
                sent = True; remaining = metadata["size"]
                # The FD is the exact gateway-opened object, not a browser path.
                while remaining:
                    chunk = os.read(fd, min(65536, remaining))
                    if not chunk:
                        raise GatewayError("export_changed", "Encrypted export ended unexpectedly")
                    connection.sendall(chunk); remaining -= len(chunk)
                return
            if method == "GET" and endpoint in GET_ACTIONS:
                reply = self.gateway.call(endpoint, {}, session=token, csrf=csrf, context=context)
                value = reply.result
                if endpoint == "session":
                    value = {**value, "paired": True}
                response(connection, 200, canonical({"ok": True, "result": value})); return
            if method != "POST" or endpoint not in POST_ACTIONS | {"pair"}:
                raise GatewayError("invalid_method", "Recovery action is not available")
            if headers.get("content-type", "").split(";", 1)[0].strip().lower() != "application/json":
                raise GatewayError("invalid_request", "Recovery actions require JSON")
            try:
                value = json.loads(body, object_pairs_hook=unique,
                                   parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Non-finite JSON")))
            except (ValueError, UnicodeError, RecursionError) as exc:
                raise GatewayError("invalid_request", "Invalid recovery action") from exc
            if not isinstance(value, dict) or set(value) != {"request_id", "params"} or not isinstance(value["params"], dict):
                raise GatewayError("invalid_request", "Invalid recovery action envelope")
            request_id = value["request_id"]
            if not isinstance(request_id, str) or not re.fullmatch(r"[0-9a-f]{32}", request_id):
                raise GatewayError("invalid_request", "Invalid recovery action identity")
            # Gateway owns strict action-specific schema, qualification and locks.
            reply = self.gateway.call(endpoint, value["params"], session=token, csrf=csrf, context=context, request_id=request_id)
            result = dict(reply.result); extra = {}
            if endpoint == "pair":
                session = result.pop("session", None)
                if not isinstance(session, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,2048}", session):
                    raise GatewayError("gateway_invalid", "Recovery pairing response is invalid")
                extra["Set-Cookie"] = COOKIE + "=" + session + "; Path=/recovery/; Max-Age=" + str(SESSION_SECONDS) + "; HttpOnly; Secure; SameSite=Strict"
                result["paired"] = True
            elif endpoint == "logout":
                extra["Set-Cookie"] = COOKIE + "=; Path=/recovery/; Max-Age=0; HttpOnly; Secure; SameSite=Strict"
            response(connection, 200 if endpoint in {"pair", "logout"} else 202, canonical({"ok": True, "result": result}), extra=extra)
        except (GatewayError, AccessError) as exc:
            statuses = {"unauthorized": 401, "pairing_required": 401, "pairing_failed": 401, "invalid_origin": 403,
                        "csrf_refused": 403, "invalid_method": 405, "request_limit": 413, "rate_limited": 429,
                        "gateway_unavailable": 503, "gateway_invalid": 503}
            if not sent:
                try:
                    response(connection, statuses.get(exc.code, 409), canonical({"ok": False, "error": {"code": exc.code, "message": str(exc)}}))
                except OSError:
                    pass
        except (OSError, ValueError, TypeError):
            if not sent:
                try:
                    response(connection, 503, canonical({"ok": False, "error": {"code": "unavailable", "message": "Recovery is temporarily unavailable"}}))
                except OSError:
                    pass
        finally:
            if fd is not None:
                os.close(fd)
            connection.close()
            with self.lock:
                self.last_activity = time.monotonic()


def tls_context():
    for path in (CERTIFICATE, PRIVATE_KEY):
        for parent in path.parents:
            info = parent.lstat()
            if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
                raise RuntimeError("Recovery TLS directory is not protected")
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_nlink != 1 or info.st_mode & 0o022 or info.st_size > 16384:
            raise RuntimeError("Recovery TLS material is invalid")
        if path == PRIVATE_KEY and info.st_mode & 0o007:
            raise RuntimeError("Recovery TLS private key is world accessible")
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.minimum_version = ssl.TLSVersion.TLSv1_2
    context.load_cert_chain(CERTIFICATE, PRIVATE_KEY)
    return context


def inherited_socket():
    if os.environ.get("LISTEN_PID") != str(os.getpid()) or os.environ.get("LISTEN_FDS") != "1":
        raise RuntimeError("Recovery portal requires one systemd-owned listening socket")
    descriptor = socket.socket(fileno=3)
    if descriptor.family not in {socket.AF_INET, socket.AF_INET6} or descriptor.getsockopt(socket.SOL_SOCKET, socket.SO_TYPE) != socket.SOCK_STREAM:
        raise RuntimeError("Invalid recovery listening socket")
    if descriptor.getsockname()[1] != 8081 or not descriptor.getsockopt(socket.SOL_SOCKET, socket.SO_ACCEPTCONN):
        raise RuntimeError("Unexpected recovery listening address")
    os.set_inheritable(descriptor.fileno(), False)
    descriptor.setblocking(False)
    return descriptor


def main():
    if os.geteuid() == 0:
        raise RuntimeError("The recovery portal must run as its restricted service user")
    listener = inherited_socket(); tls = tls_context(); portal = Portal()
    stopping = threading.Event(); semaphore = threading.BoundedSemaphore(2)
    signal.signal(signal.SIGTERM, lambda *_: stopping.set())
    signal.signal(signal.SIGINT, lambda *_: stopping.set())
    threading.stack_size(256 * 1024)
    def accept_client(client, peer):
        try:
            client.settimeout(5)
            secured = tls.wrap_socket(client, server_side=True)
            portal.handle(secured, peer)
        except (OSError, ssl.SSLError):
            client.close()
        finally:
            with portal.lock:
                portal.active -= 1; portal.last_activity = time.monotonic()
            semaphore.release()
    with ThreadPoolExecutor(max_workers=2, thread_name_prefix="recovery-http") as workers:
        try:
            while not stopping.is_set():
                readable, _, _ = select.select([listener], [], [], 1)
                if readable:
                    client, peer = listener.accept()
                    if semaphore.acquire(blocking=False):
                        with portal.lock:
                            portal.active += 1; portal.last_activity = time.monotonic()
                        workers.submit(accept_client, client, peer)
                    else:
                        client.close()
                with portal.lock:
                    idle = portal.active == 0 and time.monotonic() - portal.last_activity >= IDLE_SECONDS
                if idle:
                    try:
                        reply = portal.gateway.call("portal_idle", {}, context={"peer_ip": "127.0.0.1", "host": "localhost:8081",
                            "origin": "", "secure": True, "method": "GET"})
                        if reply.result.get("jobs_running") is False:
                            break
                    except GatewayError:
                        pass
                    portal.last_activity = time.monotonic() - IDLE_SECONDS + 30
        finally:
            listener.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
