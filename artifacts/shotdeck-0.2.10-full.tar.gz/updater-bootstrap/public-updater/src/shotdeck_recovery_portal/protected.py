"""Small bounded storage primitives shared by the seed-owned gateway adapters."""

from __future__ import annotations

from contextlib import contextmanager
import fcntl
import json
import os
from pathlib import Path
import stat
import tempfile


class AccessError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise AccessError("invalid_record", "Duplicate record property")
        result[key] = value
    return result


def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode("ascii")


def protected_directory(path: Path, *, create=False) -> Path:
    path = Path(path)
    if not path.is_absolute() or ".." in path.parts:
        raise AccessError("invalid_path", "Protected directory must be absolute")
    for parent in reversed((path, *path.parents)):
        try:
            info = parent.lstat()
        except FileNotFoundError:
            if not create:
                raise
            parent.mkdir(mode=0o700)
            sync_dir(parent.parent)
            info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise AccessError("unprotected_state", "Recovery state directory is not protected")
    return path


def read_private(path: Path, *, limit=65536, private=True) -> bytes:
    protected_directory(Path(path).parent)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        info = os.fstat(fd)
        forbidden = 0o077 if private else 0o022
        if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & forbidden
                or info.st_nlink != 1 or info.st_size > limit):
            raise AccessError("unprotected_state", "Recovery record is not a bounded protected file")
        raw = bytearray()
        while len(raw) <= limit:
            chunk = os.read(fd, min(65536, limit + 1 - len(raw)))
            if not chunk:
                break
            raw.extend(chunk)
        if len(raw) > limit:
            raise AccessError("invalid_record", "Recovery record exceeds its limit")
        return bytes(raw)
    finally:
        os.close(fd)


def read_json(path: Path, *, limit=65536):
    try:
        value = json.loads(read_private(path, limit=limit), object_pairs_hook=unique,
                           parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Non-finite JSON")))
    except (UnicodeError, ValueError, RecursionError) as exc:
        raise AccessError("invalid_record", "Recovery record is corrupt; use the physical recovery controls") from exc
    if not isinstance(value, dict):
        raise AccessError("invalid_record", "Recovery record is not an object")
    return value


def sync_dir(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_private(path: Path, value) -> None:
    protected_directory(path.parent)
    raw = canonical(value) + b"\n"
    if len(raw) > 65536:
        raise AccessError("invalid_record", "Recovery state exceeds its limit")
    if os.path.lexists(path):
        read_private(path)
    fd, name = tempfile.mkstemp(prefix=".recovery-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            os.fchmod(stream.fileno(), 0o600)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        sync_dir(path.parent)
    finally:
        if os.path.lexists(name):
            os.unlink(name)


@contextmanager
def ownership(root: Path, *, create=False):
    if os.geteuid() != 0:
        raise AccessError("permission_denied", "Recovery authority requires the protected gateway")
    protected_directory(root, create=create)
    path = root / "access.lock"
    fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o077 or info.st_nlink != 1:
            raise AccessError("unprotected_state", "Recovery ownership is not protected")
        fcntl.flock(fd, fcntl.LOCK_EX)
        yield
    finally:
        os.close(fd)

