"""Read-only catalog of already encrypted artifacts, independent of app stores."""

from __future__ import annotations

import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import struct
import uuid

from .protected import AccessError, canonical, protected_directory, read_json, unique

BACKUP_MAGIC = b"SHOTDECK-SDBAK\0"
MAX_BACKUP_BYTES = 272 * 1024 * 1024
MAX_DIAGNOSTICS_BYTES = 4 * 1024 * 1024
MAX_CATALOG = 64
_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,180}\Z")


def _read(fd, size):
    raw = bytearray()
    while len(raw) < size:
        chunk = os.read(fd, size - len(raw))
        if not chunk:
            raise AccessError("invalid_export", "Encrypted artifact is truncated")
        raw.extend(chunk)
    return bytes(raw)


def _b64(value, length):
    try:
        # Existing app backups use URL-safe Base64 without padding. Decode
        # the same bounded representation as the shipped envelope reader.
        if not isinstance(value, str) or not 1 <= len(value) <= 4 * ((length + 2) // 3):
            raise ValueError()
        encoded = value.encode("ascii")
        raw = base64.b64decode(encoded + b"=" * (-len(encoded) % 4), altchars=b"-_", validate=True)
        if len(raw) != length:
            raise ValueError()
    except (TypeError, ValueError) as exc:
        raise AccessError("invalid_export", "Encrypted artifact header is invalid") from exc


def backup_header(fd, size) -> dict:
    """Validate the public encrypted envelope without loading/decrypting data."""
    if not 64 <= size <= MAX_BACKUP_BYTES or _read(fd, len(BACKUP_MAGIC)) != BACKUP_MAGIC:
        raise AccessError("invalid_export", "Not a supported encrypted backup")
    documents = []
    for _ in range(2):
        length = struct.unpack(">I", _read(fd, 4))[0]
        if not 2 <= length <= 65536:
            raise AccessError("invalid_export", "Encrypted backup header exceeds its limit")
        raw = _read(fd, length)
        try:
            value = json.loads(raw, object_pairs_hook=unique,
                               parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Non-finite JSON")))
        except (ValueError, UnicodeError, RecursionError) as exc:
            raise AccessError("invalid_export", "Encrypted backup header is corrupt") from exc
        if not isinstance(value, dict) or canonical(value) != raw:
            raise AccessError("invalid_export", "Encrypted backup header is not canonical")
        documents.append(value)
    header, slots = documents
    required = {"document_type", "purpose", "envelope", "payload_algorithm", "backup_id", "salt",
                "payload_nonce", "ciphertext_length", "payload_tag_length", "recipients"}
    if (set(header) != required or header["document_type"] != "shotdeck-encrypted-container"
            or header["purpose"] != "customer-backup" or header["payload_algorithm"] != "AES-256-GCM"
            or not isinstance(header["envelope"], dict) or set(header["envelope"]) != {"major", "minor"}
            or type(header["envelope"]["major"]) is not int or header["envelope"]["major"] != 1
            or type(header["envelope"]["minor"]) is not int or header["envelope"]["minor"] < 0
            or type(header["ciphertext_length"]) is not int or not 1 <= header["ciphertext_length"] <= 256 * 1024 * 1024
            or header["payload_tag_length"] != 16
            or os.lseek(fd, 0, os.SEEK_CUR) + header["ciphertext_length"] + 16 != size):
        raise AccessError("invalid_export", "Unsupported encrypted backup envelope")
    try:
        uuid.UUID(header["backup_id"])
    except (ValueError, TypeError, AttributeError) as exc:
        raise AccessError("invalid_export", "Invalid encrypted backup identity") from exc
    _b64(header["salt"], 32); _b64(header["payload_nonce"], 12)
    recipients = header["recipients"]
    if not isinstance(recipients, list) or not 1 <= len(recipients) <= 2:
        raise AccessError("invalid_export", "Invalid encrypted backup recipients")
    ids = set(); kinds = set()
    for row in recipients:
        if (not isinstance(row, dict) or set(row) != {"slot_id", "recipient_type", "key_id", "nonce", "wrap_algorithm"}
                or not isinstance(row["slot_id"], str) or not re.fullmatch(r"[0-9a-f]{32}", row["slot_id"]) or row["slot_id"] in ids
                or not isinstance(row["recipient_type"], str) or row["recipient_type"] not in {"device", "customer"} or row["recipient_type"] in kinds
                or not isinstance(row["key_id"], str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,96}", row["key_id"])
                or row["wrap_algorithm"] != "HKDF-SHA256+AES-256-GCM"):
            raise AccessError("invalid_export", "Invalid encrypted backup recipient")
        _b64(row["nonce"], 12); ids.add(row["slot_id"]); kinds.add(row["recipient_type"])
    if "device" not in kinds or set(slots) != {"slots"} or not isinstance(slots["slots"], list):
        raise AccessError("invalid_export", "Invalid encrypted backup key slots")
    found = set()
    for row in slots["slots"]:
        if (not isinstance(row, dict) or set(row) != {"slot_id", "wrapped_key"}
                or not isinstance(row["slot_id"], str) or row["slot_id"] not in ids or row["slot_id"] in found):
            raise AccessError("invalid_export", "Invalid encrypted backup key slot")
        _b64(row["wrapped_key"], 48); found.add(row["slot_id"])
    if found != ids:
        raise AccessError("invalid_export", "Incomplete encrypted backup key slots")
    return {"backup_id": header["backup_id"], "envelope_sha256": hashlib.sha256(canonical(header)).hexdigest()}


class ExportStore:
    def __init__(self, backup_root=Path("/var/lib/shotdeck/backups/artifacts"),
                 diagnostics_root=Path("/var/lib/shotdeck/recovery-access/exports")):
        self.roots = {"backup": Path(backup_root), "diagnostics": Path(diagnostics_root)}

    def _files(self):
        seen = 0
        for kind, root in self.roots.items():
            try:
                protected_directory(root)
            except FileNotFoundError:
                continue
            with os.scandir(root) as entries:
                for entry in entries:
                    seen += 1
                    if seen > MAX_CATALOG:
                        raise AccessError("catalog_limit", "The encrypted export catalog requires local maintenance")
                    name = entry.name
                    if not _NAME.fullmatch(name):
                        continue
                    if (kind == "backup" and name.endswith(".sdbak")) or (kind == "diagnostics" and name.endswith(".zip.enc")):
                        yield kind, root / name

    def _open(self, kind, path):
        protected_directory(path.parent)
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
        try:
            info = os.fstat(fd)
            maximum = MAX_BACKUP_BYTES if kind == "backup" else MAX_DIAGNOSTICS_BYTES
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022
                    or info.st_nlink != 1 or not 60 <= info.st_size <= maximum):
                raise AccessError("invalid_export", "Encrypted export is not a protected bounded file")
            sha = None
            if kind == "backup":
                binding = backup_header(fd, info.st_size)["envelope_sha256"]
            else:
                receipt = read_json(path.with_suffix(path.suffix + ".json"))
                if (set(receipt) != {"schema_version", "kind", "filename", "size", "sha256", "created_at", "recipient_sha256", "upload_metadata"}
                        or receipt["schema_version"] != 1 or receipt["kind"] != "encrypted_recovery_diagnostics"
                        or receipt["filename"] != path.name or receipt["size"] != info.st_size
                        or not re.fullmatch(r"[0-9a-f]{64}", str(receipt["sha256"]))):
                    raise AccessError("invalid_export", "Encrypted diagnostic receipt is invalid")
                hasher = hashlib.sha256()
                while chunk := os.read(fd, 65536):
                    hasher.update(chunk)
                sha = hasher.hexdigest()
                if sha != receipt["sha256"]:
                    raise AccessError("invalid_export", "Encrypted diagnostics changed after creation")
                binding = sha
            identity = hashlib.sha256(canonical({"kind": kind, "name": path.name, "inode": info.st_ino,
                "device": info.st_dev, "size": info.st_size, "mtime_ns": info.st_mtime_ns, "binding": binding})).hexdigest()
            metadata = {"export_id": identity, "kind": kind, "filename": path.name,
                        "content_type": "application/octet-stream", "size": info.st_size, "sha256": sha,
                        "created_at": datetime.fromtimestamp(info.st_mtime, timezone.utc).isoformat(), "encrypted": True}
            os.lseek(fd, 0, os.SEEK_SET)
            return metadata, fd
        except BaseException:
            os.close(fd)
            raise

    def list(self) -> list[dict]:
        rows = []
        for kind, path in self._files():
            try:
                metadata, fd = self._open(kind, path)
            except (AccessError, OSError):
                continue  # Invalid artifacts never become downloadable exports.
            os.close(fd); rows.append(metadata)
        return sorted(rows, key=lambda row: (row["created_at"], row["export_id"]), reverse=True)

    def open(self, export_id: str) -> tuple[dict, int]:
        if not isinstance(export_id, str) or not re.fullmatch(r"[0-9a-f]{64}", export_id):
            raise AccessError("invalid_export", "Unknown encrypted export")
        for kind, path in self._files():
            try:
                metadata, fd = self._open(kind, path)
            except (AccessError, OSError):
                continue
            if metadata["export_id"] == export_id:
                return metadata, fd
            os.close(fd)
        raise AccessError("export_changed", "The encrypted export is unavailable or changed; refresh the list")

