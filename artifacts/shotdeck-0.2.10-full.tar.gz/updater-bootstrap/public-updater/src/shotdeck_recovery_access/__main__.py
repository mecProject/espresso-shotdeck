"""Fixed seed entry points; no path, command or GPIO arguments."""
from __future__ import annotations
import sys


def main(argv=None):
    args = sys.argv[1:] if argv is None else argv
    if args in ([], ["screen"]):
        from .screen import run
        return run()
    if args == ["restore-network"]:
        from .network import RecoveryNetwork
        RecoveryNetwork().reconcile_boot()
        return 0
    raise SystemExit("Expected screen or restore-network")


if __name__ == "__main__":
    raise SystemExit(main())
