"""Physical-only, journaled temporary NetworkManager access.

The persisted Wi-Fi preference is never rewritten. The root gateway authorizes
each call; methods independently require a stopped app and the normal activity
locks. A boot reconciler restores any incomplete temporary lease before app
startup. No network request can supply an interface, command or output path.
"""
from __future__ import annotations

from contextlib import ExitStack
import hashlib
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import time
import uuid

from .state import AccessError, assert_activity_leases, boot_id, lock, read_bytes, read_json, secure_directory, sync_directory, write_json

ROOT = Path("/var/lib/shotdeck/recovery-access")
WIFI_PREFERENCE = Path("/var/lib/shotdeck/wifi-settings.json")
INTERFACE = "wlan0"
NMCLI = "/usr/bin/nmcli"
MAX_LEASE_SECONDS = 30 * 60
HOTSPOT_PASSWORD_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"
# Retained seeds and protected updaters require at least 16 characters in the
# shared lease record, including when they only need to restore the radio.
HOTSPOT_PASSWORD_LENGTH = 16
UUID = re.compile(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\Z")


def fields(row: str) -> list[str]:
    result, part, escaped = [], [], False
    for char in row:
        if escaped:
            part.append(char); escaped = False
        elif char == "\\":
            escaped = True
        elif char == ":":
            result.append("".join(part)); part = []
        else:
            part.append(char)
    if escaped:
        raise AccessError("Malformed NetworkManager response")
    return result + ["".join(part)]


def valid_station_credentials(ssid, password) -> bool:
    if not isinstance(ssid, str):
        return False
    try:
        encoded = ssid.encode("utf-8")
    except UnicodeEncodeError:
        return False
    return (1 <= len(encoded) <= 32 and all(ord(c) >= 32 and ord(c) != 127 for c in ssid)
            and isinstance(password, str) and 8 <= len(password) <= 63
            and all(32 <= ord(c) <= 126 for c in password))


class RecoveryNetwork:
    def __init__(self, root: Path = ROOT, portal_port: int = 8081, *, runner=subprocess.run):
        if type(portal_port) is not int or not 1024 <= portal_port <= 65535:
            raise AccessError("Invalid fixed recovery port")
        self.root, self.port, self.runner = Path(root), portal_port, runner
        self.lease_path = self.root / "network-lease.json"

    def _run(self, args: list[str], *, check: bool = True, timeout: int = 20, tmpdir: Path | None = None):
        result = self.runner(args, capture_output=True, text=True, timeout=timeout,
                             env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LC_ALL": "C.UTF-8",
                                  "TMPDIR": str(tmpdir or "/var/tmp")})
        if len(result.stdout) > 65536 or len(result.stderr) > 16384:
            raise AccessError("Network response exceeds its bound")
        if check and result.returncode:
            # Never return nmcli stderr: it can contain SSIDs or secret paths.
            raise AccessError("Network operation failed; saved settings were preserved")
        return result

    def _nm(self, *args: str, check: bool = True, timeout: int = 20, tmpdir: Path | None = None):
        return self._run([NMCLI, *args], check=check, timeout=timeout, tmpdir=tmpdir)

    def _radio(self) -> tuple[bool, bool]:
        raw = self._nm("-t", "-f", "WIFI,WIFI-HW", "general").stdout.strip()
        parts = raw.split(":")
        if len(parts) != 2 or any(value not in {"enabled", "disabled"} for value in parts):
            raise AccessError("Wi-Fi radio state is unavailable")
        return parts[0] == "enabled", parts[1] == "enabled"

    def _preference(self):
        raw = read_bytes(WIFI_PREFERENCE, limit=4096, optional=True)
        if raw is None:
            return None, None
        try:
            value = json.loads(raw)
            if not isinstance(value, dict) or value.get("schema") != 1 or type(value.get("enabled")) is not bool:
                raise ValueError()
        except (ValueError, UnicodeError) as exc:
            raise AccessError("Wi-Fi preference needs attended repair") from exc
        return value["enabled"], hashlib.sha256(raw).hexdigest()

    def _assert_stopped(self, *, restoring=False):
        raw = self._run(["/usr/bin/systemctl", "show", "shotdeck.service", "--property=MainPID,ActiveState,ControlGroup"]).stdout
        state = dict(line.split("=", 1) for line in raw.splitlines() if "=" in line)
        allowed = {"inactive", "failed", "activating"} if restoring else {"inactive", "failed"}
        if state.get("MainPID") != "0" or state.get("ActiveState") not in allowed:
            raise AccessError("Use the physical recovery screen after Shotdeck has stopped")
        group = state.get("ControlGroup") or "/system.slice/shotdeck.service"
        if group != "/system.slice/shotdeck.service":
            raise AccessError("Unexpected app cgroup")
        folder = Path("/sys/fs/cgroup") / group.lstrip("/")
        if folder.exists():
            events = dict(line.split() for line in (folder / "cgroup.events").read_text().splitlines())
            if events.get("populated") != "0" or any(p.read_text().strip() for p in folder.rglob("cgroup.procs")):
                raise AccessError("Shotdeck still owns hardware")

    def _ownership(self, *, restoring=False, held_activity=False):
        if os.geteuid() != 0:
            raise AccessError("Temporary networking requires the protected physical gateway")
        stack = ExitStack()
        try:
            if held_activity:
                if not restoring:
                    raise AccessError("Existing leases authorize restoration only")
                assert_activity_leases()
                needed = (("shotdeck-wifi.lock", False),)
            else:
                needed = (("shotdeck-updater.lock", True), ("shotdeck-backup-restore.lock", False),
                          ("shotdeck-brew.lock", False), ("shotdeck-wifi.lock", False))
            for name, shared in needed:
                stack.enter_context(lock(Path("/run/lock") / name, shared=shared))
            self._assert_stopped(restoring=restoring)
            secure_directory(self.root, create=True)
            return stack
        except BaseException:
            stack.close(); raise

    def _lease(self):
        value = read_json(self.lease_path, optional=True)
        if value is None:
            return None
        expected = {"schema_version", "boot_id", "started_at", "expires_at", "phase", "before_radio", "preference_sha256",
                    "connection_uuid", "ssid", "password", "previous_active", "station_candidate", "restored_at"}
        if (set(value) != expected or type(value["schema_version"]) is not int or value["schema_version"] != 1
                or value["phase"] not in {"prepared", "wifi_enabled", "hotspot_intent", "hotspot_active", "station_intent", "restoring", "restored"}
                or type(value["before_radio"]) is not bool or not UUID.fullmatch(str(value["connection_uuid"]))
                or not isinstance(value["previous_active"], list) or len(value["previous_active"]) > 32
                or any(not UUID.fullmatch(str(item)) for item in value["previous_active"])
                or len(set(value["previous_active"])) != len(value["previous_active"])
                or value["station_candidate"] is not None and not UUID.fullmatch(str(value["station_candidate"]))
                or not isinstance(value["ssid"], str) or not 1 <= len(value["ssid"].encode()) <= 32
                or not isinstance(value["password"], str) or not re.fullmatch(r"[A-Za-z0-9_-]{16,63}", value["password"])
                or not isinstance(value["boot_id"], str) or not UUID.fullmatch(value["boot_id"])
                or value["preference_sha256"] is not None and not re.fullmatch(r"[0-9a-f]{64}", str(value["preference_sha256"]))
                or any(type(value[key]) not in {int, float} for key in ("started_at", "expires_at"))
                or any(not math.isfinite(value[key]) for key in ("started_at", "expires_at"))
                or value["restored_at"] is not None and (type(value["restored_at"]) not in {int, float} or not math.isfinite(value["restored_at"]))
                or not 0 < value["expires_at"] - value["started_at"] <= MAX_LEASE_SECONDS):
            raise AccessError("Temporary network record needs attended review")
        return value

    def _active(self) -> list[str]:
        rows = self._nm("-t", "-f", "UUID,TYPE,DEVICE", "connection", "show", "--active").stdout.splitlines()
        values = [parts[0] for row in rows if len(parts := fields(row)) == 3
                  and parts[1] in {"802-11-wireless", "wifi"} and parts[2] == INTERFACE]
        if len(values) > 32 or any(not UUID.fullmatch(value) for value in values):
            raise AccessError("Unexpected active Wi-Fi connection identity")
        return values

    def _prepare(self):
        existing = self._lease()
        if existing is not None and existing["phase"] != "restored":
            if existing["boot_id"] != boot_id() or time.time() >= existing["expires_at"]:
                raise AccessError("Restore the previous temporary network session first")
            if existing["station_candidate"] is not None or existing["phase"] == "restoring":
                raise AccessError("Restore the interrupted network change before starting another")
            return existing
        enabled, hardware = self._radio()
        if not hardware:
            raise AccessError("Wi-Fi hardware is disabled; Ethernet remains available")
        _, preference_sha = self._preference()
        suffix = secrets.token_hex(2)
        now = time.time()
        lease = {"schema_version": 1, "boot_id": boot_id(), "started_at": now,
                 "expires_at": now + MAX_LEASE_SECONDS, "phase": "prepared", "before_radio": enabled,
                 "preference_sha256": preference_sha, "connection_uuid": str(uuid.uuid4()),
                 "ssid": "Shotdeck-Recovery-" + suffix,
                 "password": "".join(secrets.choice(HOTSPOT_PASSWORD_ALPHABET) for _ in range(HOTSPOT_PASSWORD_LENGTH)),
                 "previous_active": self._active(), "station_candidate": None, "restored_at": None}
        write_json(self.lease_path, lease)
        return lease

    def status(self) -> dict:
        enabled, hardware = self._radio()
        preference, _ = self._preference()
        devices = [fields(row) for row in self._nm("-t", "-f", "DEVICE,TYPE,STATE", "device", "status").stdout.splitlines()]
        addresses = []
        for row in devices:
            if len(row) != 3 or row[1] not in {"wifi", "ethernet"} or row[2] != "connected":
                continue
            if not re.fullmatch(r"[A-Za-z0-9_.-]{1,15}", row[0]):
                continue
            for raw in self._nm("-g", "IP4.ADDRESS", "device", "show", row[0]).stdout.splitlines()[:8]:
                try:
                    address = ipaddress.IPv4Interface(raw).ip
                except ValueError:
                    continue
                if not address.is_loopback and not address.is_unspecified:
                    addresses.append({"interface": row[0], "type": row[1], "url": f"https://{address}:{self.port}/"})
        lease = self._lease() if self.root.exists() else None
        temporary = bool(lease and lease["phase"] != "restored")
        return {"wifi_enabled": enabled, "wifi_hardware_enabled": hardware, "saved_preference": preference,
                "addresses": addresses[:8], "temporary": temporary,
                "expires_at": lease["expires_at"] if temporary else None,
                "hotspot_active": bool(temporary and lease["phase"] == "hotspot_active")}

    def local_state(self) -> dict:
        """Credentials are returned only to the gateway's physical peer lane."""
        result = self.status()
        lease = self._lease() if self.root.exists() else None
        if lease and lease["phase"] == "hotspot_active" and lease["boot_id"] == boot_id() and time.time() < lease["expires_at"]:
            result.update(ssid=lease["ssid"], password=lease["password"])
        return result

    def enable_temporary(self) -> dict:
        with self._ownership():
            lease = self._prepare()
            self._nm("radio", "wifi", "on")
            if not self._radio()[0]:
                raise AccessError("Wi-Fi could not be enabled; restore is still recorded")
            if lease["phase"] == "prepared":
                lease["phase"] = "wifi_enabled"; write_json(self.lease_path, lease)
            return self.status()

    def start_hotspot(self) -> dict:
        with self._ownership():
            lease = self._prepare()
            self._nm("radio", "wifi", "on")
            lease["phase"] = "hotspot_intent"; write_json(self.lease_path, lease)
            ident = lease["connection_uuid"]
            known = self._nm("-t", "-f", "UUID", "connection", "show").stdout.splitlines()
            if ident not in known:
                self._nm("connection", "add", "type", "wifi", "ifname", INTERFACE, "con-name", lease["ssid"],
                         "connection.uuid", ident, "autoconnect", "no", "ssid", lease["ssid"])
            self._nm("connection", "modify", "uuid", ident, "connection.autoconnect", "no",
                     "802-11-wireless.mode", "ap", "802-11-wireless.ssid", lease["ssid"],
                     "802-11-wireless.band", "bg", "802-11-wireless.channel", "6", "ipv4.method", "shared",
                     "ipv6.method", "disabled", "802-11-wireless-security.key-mgmt", "wpa-psk",
                     "802-11-wireless-security.proto", "rsn", "802-11-wireless-security.pairwise", "ccmp",
                     "802-11-wireless-security.group", "ccmp", "802-11-wireless-security.pmf", "1",
                     "802-11-wireless-security.psk-flags", "2", "802-11-wireless-security.psk", "")
            workspace = Path(tempfile.mkdtemp(prefix="shotdeck-recovery-network-", dir="/var/tmp"))
            try:
                os.chmod(workspace, 0o700)
                secret = workspace / "nm-password"
                fd = os.open(secret, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
                with os.fdopen(fd, "w") as stream:
                    stream.write("802-11-wireless-security.psk:" + lease["password"] + "\n")
                    stream.flush(); os.fsync(stream.fileno())
                self._nm("--wait", "45", "connection", "up", "uuid", ident, "passwd-file", str(secret),
                         timeout=50, tmpdir=workspace)
            finally:
                # The bounded synchronous nmcli child has completed before its
                # secret file is removed. A timeout is reaped by subprocess.run.
                shutil.rmtree(workspace)
            if ident not in self._active():
                raise AccessError("Hotspot did not become active; use restore and retry")
            lease["phase"] = "hotspot_active"; write_json(self.lease_path, lease)
            return {**self.status(), "ssid": lease["ssid"], "password": lease["password"]}

    def restore(self, *, held_activity=False) -> dict:
        # The normal startup hook is inert when no temporary networking was
        # ever enabled, including while the healthy app owns its cgroup.
        if not self.root.exists():
            return {"restored": True, "changed": False}
        existing = self._lease()
        if existing is None or existing["phase"] == "restored":
            return {"restored": True, "changed": False}
        with self._ownership(restoring=True, held_activity=held_activity):
            lease = self._lease()
            if lease is None or lease["phase"] == "restored":
                return {"restored": True, "changed": False}
            lease["phase"] = "restoring"; write_json(self.lease_path, lease)
            ident = lease["connection_uuid"]
            known = self._nm("-t", "-f", "UUID", "connection", "show").stdout.splitlines()
            pending_station = lease["station_candidate"]
            if pending_station and pending_station in known:
                if pending_station in self._active():
                    self._nm("connection", "down", "uuid", pending_station)
                self._nm("connection", "delete", "uuid", pending_station)
                lease["station_candidate"] = None; write_json(self.lease_path, lease)
            if ident in known:
                if ident in self._active():
                    self._nm("connection", "down", "uuid", ident)
                self._nm("connection", "delete", "uuid", ident)
            preference, digest = self._preference()
            # A deliberate saved preference change wins over the old lease.
            restore_enabled = lease["before_radio"] if digest == lease["preference_sha256"] else preference
            if type(restore_enabled) is not bool:
                raise AccessError("Wi-Fi preference changed ambiguously; attended review is required")
            self._nm("radio", "wifi", "on" if restore_enabled else "off")
            if self._radio()[0] is not restore_enabled:
                raise AccessError("Original Wi-Fi radio state has not been restored")
            if restore_enabled:
                remaining = set(self._nm("-t", "-f", "UUID", "connection", "show").stdout.splitlines())
                for previous in lease["previous_active"]:
                    if previous in remaining:
                        # Failure to reach an absent saved network is harmless:
                        # keep its profile and restore the user's radio intent.
                        result = self._nm("--wait", "10", "connection", "up", "uuid", previous, "ifname", INTERFACE,
                                          check=False, timeout=15)
                        if result.returncode == 0:
                            break
            lease.update(phase="restored", restored_at=time.time())
            write_json(self.lease_path, lease)
            return {"restored": True, "changed": True}

    def join_station(self, ssid: str, password: str, *, before_mutation) -> dict:
        """Join a new WPA2 profile only after paired TLS gateway authorization.

        A rejected join is conclusive only after the candidate is absent and
        the original recovery hotspot is active again.
        """
        if not valid_station_credentials(ssid, password):
            raise AccessError("Enter a Wi-Fi name and an 8–63 character WPA2 password")
        with self._ownership():
            lease = self._lease()
            if (lease is None or lease["phase"] != "hotspot_active" or lease["boot_id"] != boot_id()
                    or lease["station_candidate"] is not None
                    or time.time() >= lease["expires_at"] or lease["connection_uuid"] not in self._active()):
                raise AccessError("Start the physical recovery hotspot before adding Wi-Fi")
            candidate = str(uuid.uuid4())
            with tempfile.TemporaryDirectory(prefix="shotdeck-recovery-network-", dir="/var/tmp") as folder:
                workspace = Path(folder)
                before_mutation({"connection_uuid": lease["connection_uuid"], "phase": lease["phase"]})
                write_json(self.lease_path, {**lease, "station_candidate": candidate, "phase": "station_intent"})
                return self._activate_station(lease, candidate, ssid, password, workspace)

    def _activate_station(self, lease, candidate, ssid, password, workspace):
        try:
            self._nm("connection", "add", "type", "wifi", "ifname", INTERFACE,
                     "con-name", "Shotdeck Wi-Fi " + candidate[:8], "connection.uuid", candidate,
                     "autoconnect", "no", "ssid", ssid)
            self._nm("connection", "modify", "uuid", candidate, "802-11-wireless.mode", "infrastructure",
                     "802-11-wireless-security.key-mgmt", "wpa-psk", "802-11-wireless-security.proto", "rsn",
                     "802-11-wireless-security.pmf", "1", "ipv4.method", "auto", "ipv6.method", "auto",
                     "802-11-wireless-security.psk", "")
            secret = workspace / "station-password"
            with os.fdopen(os.open(secret, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600), "w") as stream:
                stream.write("802-11-wireless-security.psk:" + password + "\n")
                stream.flush(); os.fsync(stream.fileno())
            self._nm("--wait", "45", "connection", "up", "uuid", candidate, "passwd-file", str(secret),
                     timeout=50, tmpdir=workspace)
            if candidate not in self._active():
                raise AccessError("The new Wi-Fi connection did not become active")
            self._nm("connection", "modify", "uuid", candidate, "connection.autoconnect", "yes")
            # Retain the newly accepted connection for restoration when
            # saved radio intent was on. Saved intent itself is unchanged.
            status = self.status()
            write_json(self.lease_path, {**lease, "phase": "wifi_enabled", "station_candidate": None,
                                         "previous_active": [candidate, *lease["previous_active"]][:32]})
            return {"connected": True, "settings_preserved": True, **status}
        except Exception:
            # A timed-out add can still have created the profile.
            if candidate in self._nm("-t", "-f", "UUID", "connection", "show").stdout.splitlines():
                self._nm("connection", "down", "uuid", candidate, check=False)
                self._nm("connection", "delete", "uuid", candidate)
            if candidate in self._nm("-t", "-f", "UUID", "connection", "show").stdout.splitlines():
                raise AccessError("Recovery could not verify removal of the temporary Wi-Fi profile")
            if lease["connection_uuid"] not in self._active():
                hotspot_secret = workspace / "hotspot-password"
                with os.fdopen(os.open(hotspot_secret, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600), "w") as stream:
                    stream.write("802-11-wireless-security.psk:" + lease["password"] + "\n")
                    stream.flush(); os.fsync(stream.fileno())
                self._nm("--wait", "45", "connection", "up", "uuid", lease["connection_uuid"],
                         "passwd-file", str(hotspot_secret), timeout=50, tmpdir=workspace)
            if lease["connection_uuid"] not in self._active():
                raise AccessError("Network change failed; use the physical screen to restore access.")
            write_json(self.lease_path, lease)
            return {"connected": False, "hotspot_restored": True, "settings_preserved": True}

    def reconcile_boot(self) -> dict:
        # Any process exit, reboot, expired session or failed activation is a
        # reason to restore, never permission to silently enable networking.
        return self.restore()
