"""Seed-owned local recovery access, independent of the brewing application.

Importing this package does not open hardware or change networking. All local
actions remain behind the recovery gateway's physical-peer authorization.
"""

PROTOCOL_VERSION = 1
SUPPORTED_PROFILE = "rev1_2_3_5f_bbw"

