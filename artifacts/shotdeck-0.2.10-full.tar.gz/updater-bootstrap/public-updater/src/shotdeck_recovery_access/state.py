"""Small protected records shared by the recovery access adapters."""
from __future__ import annotations

from contextlib import contextmanager
import fcntl
import json
import os
from pathlib import Path
import stat
import tempfile

ACTIVITY_LOCKS = frozenset(Path("/run/lock") / name for name in (
    "shotdeck-updater.lock", "shotdeck-backup-restore.lock", "shotdeck-brew.lock", "shotdeck-wifi.lock"))


class AccessError(RuntimeError):
    pass


def boot_id() -> str:
    return Path("/proc/sys/kernel/random/boot_id").read_text().strip()


def secure_directory(path: Path, *, create: bool = False) -> None:
    path = Path(path)
    if create and not path.exists():
        secure_directory(path.parent)
        path.mkdir(mode=0o700)
        sync_directory(path.parent)
    for folder in (path, *path.parents):
        info = folder.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise AccessError("Recovery state requires protected root-owned directories")


def read_bytes(path: Path, *, limit: int = 65536, optional: bool = False) -> bytes | None:
    secure_directory(path.parent)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    except FileNotFoundError:
        if optional:
            return None
        raise
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022 or info.st_nlink != 1:
            raise AccessError("Recovery record is not protected")
        raw = stream.read(limit + 1)
        if len(raw) > limit:
            raise AccessError("Recovery record exceeds its bound")
        return raw


def unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise AccessError("Duplicate recovery record field")
        result[key] = value
    return result


def read_json(path: Path, *, optional: bool = False):
    raw = read_bytes(path, optional=optional)
    if raw is None:
        return None
    try:
        value = json.loads(raw, object_pairs_hook=unique)
    except (ValueError, UnicodeError) as exc:
        raise AccessError("Recovery record is corrupt; physical review is required") from exc
    if not isinstance(value, dict):
        raise AccessError("Recovery record is not an object")
    return value


def sync_directory(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_json(path: Path, value: dict) -> None:
    secure_directory(path.parent)
    raw = (json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode()
    if len(raw) > 65536:
        raise AccessError("Recovery record exceeds its bound")
    if path.is_symlink():
        raise AccessError("Aliased recovery record refused")
    fd, name = tempfile.mkstemp(prefix=".recovery-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            os.fchmod(stream.fileno(), 0o600)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, path)
        sync_directory(path.parent)
    finally:
        if os.path.lexists(name):
            os.unlink(name)


@contextmanager
def lock(path: Path, *, shared: bool = False):
    # /run/lock is commonly sticky/writable; validate the actual lock inode,
    # never follow a caller-controlled alias or replace a live ownership file.
    if path.parent != Path("/run/lock"):
        secure_directory(path.parent)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    except FileNotFoundError:
        try:
            fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
        except FileExistsError:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        info = os.fstat(fd)
        forbidden = 0o002 if path in ACTIVITY_LOCKS else 0o077
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != 0 or info.st_mode & forbidden:
            raise AccessError("Invalid recovery ownership lock")
        fcntl.flock(fd, (fcntl.LOCK_SH if shared else fcntl.LOCK_EX) | fcntl.LOCK_NB)
        yield fd
    except BlockingIOError as exc:
        raise AccessError("Another operation owns the required resource") from exc
    finally:
        os.close(fd)


def _kernel_flock_owned(raw, metadata, pid):
    """Linux fdinfo must bind WRITE flock to this PID and this exact inode."""
    for line in raw.splitlines():
        fields = line.split()
        if len(fields) != 9 or fields[0] != "lock:" or fields[2:5] != ["FLOCK", "ADVISORY", "WRITE"]:
            continue
        try:
            device = fields[6].split(":")
            if (len(device) == 3 and int(fields[5]) == pid
                    and (int(device[0], 16), int(device[1], 16), int(device[2]))
                    == (os.major(metadata.st_dev), os.minor(metadata.st_dev), metadata.st_ino)
                    and fields[7:] == ["0", "EOF"]):
                return True
        except ValueError:
            continue
    return False


def assert_activity_leases():
    """Verify the current native parent owns all three existing activity locks.

    A flag, inherited environment or an apparently blocked flock is not proof.
    The actual open descriptors and Linux lock records must match protected
    fixed-path inodes and the current process, never another flock owner.
    """
    if os.geteuid() != 0:
        raise AccessError("Existing activity leases require the protected root owner")
    pid = os.getpid()
    opened = list(Path("/proc/self/fd").iterdir())
    if len(opened) > 1024:
        raise AccessError("Activity descriptor inventory exceeds its bound")
    for name in ("shotdeck-updater.lock", "shotdeck-backup-restore.lock", "shotdeck-brew.lock"):
        path = Path("/run/lock") / name
        metadata = path.lstat()
        if (not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != 0 or metadata.st_nlink != 1
                or metadata.st_mode & 0o002):
            raise AccessError("Existing activity lease inode is not protected")
        owned = False
        for item in opened:
            if not item.name.isdecimal():
                continue
            try:
                actual = os.fstat(int(item.name))
                if (actual.st_dev, actual.st_ino) != (metadata.st_dev, metadata.st_ino):
                    continue
                descriptor = os.open(Path("/proc/self/fdinfo") / item.name, os.O_RDONLY | os.O_NOFOLLOW)
                with os.fdopen(descriptor, "r") as stream:
                    raw = stream.read(16385)
                if len(raw) <= 16384 and _kernel_flock_owned(raw, metadata, pid):
                    owned = True; break
            except (OSError, ValueError):
                continue
        if not owned:
            raise AccessError("Current process does not own every required activity lease")
