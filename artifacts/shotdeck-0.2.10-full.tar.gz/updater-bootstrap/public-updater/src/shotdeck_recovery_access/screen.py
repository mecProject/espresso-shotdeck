"""Bounded physical recovery screen; all mutations go through the root gateway."""
from __future__ import annotations

import json
import re
import signal
import time
from urllib.parse import urlsplit

from .client import request
from .hardware import Panel, app_stopped
from .network import RecoveryNetwork
from .state import AccessError


def text(value, length=100):
    return "".join(char for char in str(value or "") if char.isprintable())[:length]


def url(value):
    value = text(value, 200)
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError:
        return ""
    if (parsed.scheme != "https" or parsed.username or parsed.password or parsed.query or parsed.fragment
            or parsed.path not in {"", "/"} or port != 8081 or not parsed.hostname):
        return ""
    return value


def render(state: dict, *, message="", confirmation=None, view="main"):
    from PIL import Image, ImageDraw, ImageFont
    import qrcode
    image = Image.new("RGB", (320, 480), "#171b20")
    draw = ImageDraw.Draw(image)
    font = ImageFont.load_default(size=15)
    small = ImageFont.load_default(size=12)
    title = ImageFont.load_default(size=23)
    button_font = ImageFont.load_default(size=18)
    def line(value, y, *, color="#f1ece1", chosen=font):
        value = text(value, 42)
        while value and draw.textlength(value, font=chosen) > 296:
            value = value[:-1]
        draw.text((12, y), value, font=chosen, fill=color)
    def buttons(actions, *, top, height, gap):
        boxes = []
        for index, (action, label) in enumerate(actions):
            y = top + index * (height + gap)
            box = (10, y, 310, y + height)
            is_return = action == "physical_exit" or action == "confirm" and confirmation == "physical_exit"
            allowed = not is_return or state.get("can_exit") is True
            danger = action == "physical_auth_reset" or action == "confirm" and confirmation == "physical_auth_reset"
            fill = "#653b39" if danger else "#33414d"
            draw.rounded_rectangle(box, radius=8, fill=fill if allowed else "#252a2e")
            bounds = draw.textbbox((0, 0), label, font=button_font)
            draw.text((20, y + (height - bounds[3] + bounds[1]) // 2 - bounds[1]), label,
                      font=button_font, fill="#ffffff" if allowed else "#7a8288")
            if allowed:
                boxes.append((box, action))
        return image, boxes

    if view not in {"main", "options"}:
        raise ValueError("Unknown recovery display view")
    line("Shotdeck recovery", 12, chosen=title)
    if confirmation is not None:
        if confirmation == "physical_exit":
            line("Return to Shotdeck?", 88, chosen=button_font)
            line("The normal app will start again.", 125)
            line("This may take a few minutes.", 153)
            label = "Confirm return"
        elif confirmation == "physical_auth_reset":
            line("Reset recovery pairing?", 88, chosen=button_font)
            line("Every recovery browser will be unpaired.", 125, chosen=small)
            line("Pair again using a fresh PIN.", 153)
            label = "Confirm reset"
        else:
            raise ValueError("Unknown recovery confirmation")
        return buttons([("confirm", label), ("cancel", "Cancel")], top=330, height=56, gap=24)
    operation = state.get("operation")
    if isinstance(operation, dict):
        operation = operation.get("message") or operation.get("phase")
    line(operation or state.get("reason") or "Local recovery access", 45, chosen=small)
    network = state.get("network") if isinstance(state.get("network"), dict) else {}
    network_action = ("physical_network_restore", "Restore Wi-Fi") if network.get("temporary") else ("physical_network_enable", "Wi-Fi temporarily")
    if view == "options":
        line("More options", 76, chosen=button_font)
        line("Wi-Fi on" if network.get("wifi_enabled") else "Wi-Fi off (saved setting preserved)", 114, chosen=small)
        line(message or "Return to app is on the main screen.", 145, chosen=small)
        return buttons([network_action, ("physical_hotspot_start", "Start hotspot"),
                        ("physical_auth_reset", "Reset recovery pairing"), ("back", "Back")],
                       top=220, height=52, gap=12)
    address = url(state.get("url"))
    if not address:
        for row in network.get("addresses", ())[:8]:
            if isinstance(row, dict) and url(row.get("url")):
                address = url(row["url"]); break
    line(address or "Use Ethernet or temporary Wi-Fi", 69, chosen=small)
    pairing = state.get("pairing") if isinstance(state.get("pairing"), dict) else {}
    pin = str(pairing.get("pin", ""))
    if address:
        qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=3, border=2)
        qr.add_data(address); qr.make(fit=True)
        tile = qr.make_image(fill_color="black", back_color="white").convert("RGB")
        tile.thumbnail((126, 126)); image.paste(tile, (12, 85))
    draw.text((151, 102), "PAIRING PIN", font=small, fill="#f1ece1")
    if re.fullmatch(r"[0-9]{6}", pin):
        draw.text((151, 125), pin[:3] + " " + pin[3:], font=ImageFont.load_default(size=25), fill="#d8c49e")
    else:
        draw.text((151, 125), "Tap Pair", font=font, fill="#d8c49e")
    fingerprint = text(state.get("tls_fingerprint"), 95)
    if fingerprint:
        line("Certificate SHA256:", 216, chosen=small)
        compact = fingerprint.replace(":", "")
        line(compact[:32], 232, chosen=small); line(compact[32:64], 248, chosen=small)
    elif address:
        line("Verify the certificate on this display", 232, chosen=small)
    if network.get("ssid"):
        line("Wi-Fi: " + text(network["ssid"], 32), 265, chosen=small)
        line("Password: " + text(network.get("password"), 32), 280, chosen=small)
    else:
        line("Wi-Fi on" if network.get("wifi_enabled") else "Wi-Fi off (saved setting preserved)", 265, chosen=small)
    line(message or state.get("reason") or "Pair from a phone on the same network.", 297, chosen=small)
    # Keep Return away from pairing reset and use full-height finger targets.
    return buttons([("physical_pair", "Pair"), ("more", "More options"), ("physical_exit", "Return to app")],
                   top=316, height=48, gap=8)


def run() -> int:
    stopping = False
    def stop(_signum, _frame):
        nonlocal stopping
        stopping = True
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, stop)
    state = request("physical_state")
    if state.get("enabled") is not True or not app_stopped():
        raise AccessError("Physical recovery access has not been admitted")
    panel = None
    last = None
    next_refresh = next_owner_check = 0.0
    confirmation = None
    view = "main"
    message = ""
    boxes = []
    try:
        panel = Panel()
        while not stopping:
            now = time.monotonic()
            if now >= next_owner_check:
                if not app_stopped():
                    break
                next_owner_check = now + 1
            if now >= next_refresh:
                state = request("physical_state")
                if state.get("enabled") is not True:
                    break
                next_refresh = now + 2
                network = state.get("network", {})
                expires = network.get("expires_at") if isinstance(network, dict) else None
                if type(expires) in {float, int} and time.time() >= expires:
                    RecoveryNetwork().restore()
                    message = "Temporary network session ended"
            image_key = json.dumps([state, message, confirmation, view], sort_keys=True, separators=(",", ":"))
            if image_key != last:
                image, boxes = render(state, message=message, confirmation=confirmation, view=view)
                panel.show(image); last = image_key
            point = panel.touch()
            if point:
                hit = next((action for (left, top, right, bottom), action in boxes
                            if left <= point[0] <= right and top <= point[1] <= bottom), None)
                if hit == "cancel":
                    confirmation = None
                elif hit in {"more", "back"}:
                    view = "options" if hit == "more" else "main"
                    message = ""
                elif hit == "confirm":
                    hit, confirmation = confirmation, None
                    if hit == "physical_exit":
                        # Release display before gateway can resume an old app
                        # which does not yet implement the shared display lock.
                        panel.close(); panel = None
                    result = request(hit)
                    if hit == "physical_exit":
                        return 0
                    state = result; message = "Recovery pairing reset"; next_refresh = 0
                elif hit in {"physical_auth_reset", "physical_exit"}:
                    confirmation = hit
                elif hit:
                    try:
                        image, _ = render(state, message="Working — please wait", view=view)
                        panel.show(image)
                        result = request(hit)
                        if hit in {"physical_hotspot_start", "physical_network_enable", "physical_network_restore"}:
                            state["network"] = result
                        else:
                            state = result
                        message = "Ready"; next_refresh = now + 1
                    except (AccessError, OSError) as exc:
                        message = text(exc, 80)
                last = None
            time.sleep(.05)
        return 0
    finally:
        if panel is not None:
            panel.close()
        # The app's systemd ordering keeps it stopped until this service exits.
        # Failed restoration propagates so startup's independent reconciler can
        # retry; saved preference itself was never changed.
        if app_stopped():
            RecoveryNetwork().restore()
