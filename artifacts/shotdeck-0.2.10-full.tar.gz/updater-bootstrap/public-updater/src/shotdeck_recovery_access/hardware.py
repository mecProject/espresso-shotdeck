"""Explicit v1.2 display/touch ownership; never opens brew/paddle GPIO.

The ST7796S initialization follows the already shipped Waveshare LCD(F)
sequence. This compact seed adapter uses Pillow buffers without importing the
application driver, NumPy, any control manager or a mutable application tree.
"""
from __future__ import annotations

import fcntl
import json
import mmap
import os
from pathlib import Path
import re
import stat
import struct
import subprocess
import time

from . import SUPPORTED_PROFILE
from .state import AccessError, read_json

DISPLAY_LOCK = Path("/run/lock/shotdeck-display.lock")
PROFILE_PATH = Path("/etc/shotdeck/hardware-profile.json")


def app_stopped(runner=subprocess.run) -> bool:
    # A busy device can miss one bounded PID1 query. Retry only that timeout,
    # never an observation that the app is active, and never reuse old proof.
    for attempt in range(2):
        try:
            result = runner(["/usr/bin/systemctl", "show", "shotdeck.service",
                             "--property=MainPID,ActiveState,ControlGroup"],
                            capture_output=True, text=True, timeout=5)
        except subprocess.TimeoutExpired:
            if attempt == 0:
                continue
            return False
        except OSError:
            return False
        break
    if result.returncode or len(result.stdout) > 8192:
        return False
    row = dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)
    if row.get("MainPID") != "0" or row.get("ActiveState") not in {"inactive", "failed"}:
        return False
    group = row.get("ControlGroup") or "/system.slice/shotdeck.service"
    if group != "/system.slice/shotdeck.service":
        return False
    root = Path("/sys/fs/cgroup") / group.lstrip("/")
    if root.exists():
        try:
            events = dict(line.split() for line in (root / "cgroup.events").read_text().splitlines())
            return events.get("populated") == "0" and not any(p.read_text().strip() for p in root.rglob("cgroup.procs"))
        except (OSError, ValueError):
            return False
    return True


def legacy_profile() -> dict:
    try:
        value = read_json(PROFILE_PATH)
    except FileNotFoundError as exc:
        raise AccessError("Recovery display needs an operator-confirmed hardware profile") from exc
    if (value.get("schema_version") != 1 or value.get("profile_id") != SUPPORTED_PROFILE
            or value.get("provenance") != "operator-confirmed-legacy-board"
            or not isinstance(value.get("attestation"), str) or not value["attestation"].strip()):
        raise AccessError("This display/input profile is not enabled for recovery")
    env = value.get("legacy_environment", {})
    if not isinstance(env, dict):
        raise AccessError("Installed display wiring is invalid")
    expected = {"TOUCH_GT911_RST_PIN": {"22"}, "TOUCH_GT911_INT_PIN": {"17"}, "TOUCH_I2C_BUS": {"1"},
                "TOUCH_I2C_ADDRESS": {"0x14", "20", "0x5d", "93"}, "TOUCH_CONTROLLER": {"gt911", ""},
                "DISPLAY_SIZE": {"3.5f", "3_5_f", "3.5", "3.5F"},
                "TOUCH_UI_ENABLED": {"1", "true", "yes", "on"}}
    for key, choices in expected.items():
        if key in env and str(env[key]).lower() not in {v.lower() for v in choices}:
            raise AccessError("Installed display wiring is outside the recovery profile")
    # A differently calibrated touch assembly requires independent qualification;
    # silently inheriting environment overrides could map a safe tap to a reset.
    for name in ("TOUCH_GT911_INVERT_X", "TOUCH_GT911_INVERT_Y"):
        if str(env.get(name, "0")).lower() not in {"0", "false", "no", "off"}:
            raise AccessError("Recovery touch calibration has not been qualified")
    for name in ("TOUCH_ROTATION_OFFSET", "TOUCH_GT911_POST_INVERT_X_ROTATIONS", "TOUCH_GT911_POST_INVERT_Y_ROTATIONS"):
        if str(env.get(name, "")).strip() not in {"", "0"}:
            raise AccessError("Recovery touch rotation has not been qualified")
    return value


class DisplayLease:
    def __init__(self, path: Path = DISPLAY_LOCK):
        self.fd = None
        try:
            fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
        except FileExistsError:
            fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_nlink != 1 or info.st_mode & 0o022:
                raise AccessError("Display ownership record is not protected")
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.fd = fd
        except BaseException:
            os.close(fd); raise

    def close(self):
        if self.fd is not None:
            os.close(self.fd); self.fd = None


class KernelBacklight:
    """Only the legacy GPIO18 PWM0 mapping; never select an arbitrary chip."""

    def __init__(self):
        candidates = []
        for chip in Path("/sys/class/pwm").glob("pwmchip*"):
            try:
                compatible = (chip / "device/of_node/compatible").read_bytes().split(b"\0")
                if b"brcm,bcm2835-pwm" in compatible and int((chip / "npwm").read_text()) == 2:
                    candidates.append(chip)
            except (OSError, ValueError):
                continue
        if len(candidates) != 1:
            raise AccessError("GPIO18 kernel backlight mapping is not qualified")
        chip = candidates[0]
        self.path = chip / "pwm0"
        if not self.path.exists():
            (chip / "export").write_text("0\n")
            for _ in range(50):
                if self.path.exists():
                    break
                time.sleep(.002)
        self.off()
        if (self.path / "enable").read_text().strip() == "1":
            (self.path / "enable").write_text("0\n")
        (self.path / "period").write_text("50000\n")
        (self.path / "enable").write_text("1\n")

    def on(self):
        (self.path / "duty_cycle").write_text("50000\n")

    def off(self):
        (self.path / "duty_cycle").write_text("0\n")

    def close(self):
        self.off()


def backlight_function():
    # The customer capability restricts this driver to BCM2837. Read the one
    # mux field to distinguish its shipped PWM overlay from plain GPIO18.
    descriptor = os.open("/dev/gpiomem", os.O_RDONLY | os.O_NOFOLLOW)
    try:
        if not stat.S_ISCHR(os.fstat(descriptor).st_mode):
            raise AccessError("Backlight mux observation is unavailable")
        with mmap.mmap(descriptor, 4096, flags=mmap.MAP_SHARED, prot=mmap.PROT_READ) as registers:
            return (struct.unpack_from("<I", registers, 4)[0] >> 24) & 7
    finally:
        os.close(descriptor)


class Panel:
    width, height = 320, 480

    def __init__(self):
        # Validate BEFORE importing any GPIO backend or opening SPI/I2C.
        profile = legacy_profile()
        self.address = int(str(profile.get("legacy_environment", {}).get("TOUCH_I2C_ADDRESS", "0x5d")), 0)
        if not app_stopped():
            raise AccessError("Shotdeck still owns the physical display")
        self.lease = DisplayLease()
        self.resources = []
        self.spi = self.bus = None
        self.contact = None
        self._armed = False
        self._released_at = None
        try:
            if not app_stopped():
                raise AccessError("Application ownership changed before display admission")
            from gpiozero import DigitalOutputDevice
            import spidev
            from smbus2 import SMBus
            def output(pin, initial):
                device = DigitalOutputDevice(pin, active_high=True, initial_value=initial)
                self.resources.append(device)
                return device
            self.power = output(23, 1)
            self.dc, self.reset = output(25, 0), output(27, 1)
            function = backlight_function()
            if function == 2:
                self.backlight = KernelBacklight()
                self.resources.append(self.backlight)
            elif function in {0, 1}:
                self.backlight = output(18, 0)
            else:
                raise AccessError("Display backlight mux is outside its qualified profile")
            self.spi = spidev.SpiDev()
            self.spi.open(0, 0); self.spi.max_speed_hz = 20000000; self.spi.mode = 0
            self._initialize()
            self.touch_reset = output(22, 0)
            # Select the operator-recorded GT911 address using the same reset
            # sequence as the shipped app. Never probe arbitrary I2C addresses.
            # Release INT afterwards; polling needs no interrupt claim.
            interrupt = output(17, 1 if self.address == 0x14 else 0)
            time.sleep(.02); self.touch_reset.on(); time.sleep(.006)
            interrupt.off(); time.sleep(.05); interrupt.close(); self.resources.remove(interrupt)
            self.bus = SMBus(1)
            self._read(0x814E, 1)
            self.backlight.on()
        except BaseException:
            self.close(); raise

    def command(self, code: int, values=()):
        self.dc.off(); self.spi.writebytes([code]); self.dc.on()
        if values:
            self.spi.writebytes(list(values))

    def _initialize(self):
        self.reset.on(); time.sleep(.01); self.reset.off(); time.sleep(.01); self.reset.on(); time.sleep(.01)
        self.command(0x11); time.sleep(.12)
        for command, data in ((0x36, [0x48]), (0x3A, [0x05]), (0xF0, [0xC3]), (0xF0, [0x96]),
                              (0xB4, [0x01]), (0xB7, [0xC6]), (0xC0, [0x80, 0x45]), (0xC1, [0x13]),
                              (0xC2, [0xA7]), (0xC5, [0x0A]),
                              (0xE8, [0x40, 0x8A, 0, 0, 0x29, 0x19, 0xA5, 0x33]),
                              (0xE0, [0xD0, 0x08, 0x0F, 0x06, 0x06, 0x33, 0x30, 0x33, 0x47, 0x17, 0x13, 0x13, 0x2B, 0x31]),
                              (0xE1, [0xD0, 0x0A, 0x11, 0x0B, 0x09, 0x07, 0x2F, 0x33, 0x47, 0x38, 0x15, 0x16, 0x2C, 0x32]),
                              (0xF0, [0x3C]), (0xF0, [0x69])):
            self.command(command, data)
        self.command(0x21); self.command(0x11); time.sleep(.1); self.command(0x29)

    def show(self, image):
        if image.size != (self.width, self.height):
            raise AccessError("Unexpected recovery frame size")
        raw = image.convert("RGB").tobytes()
        # Portrait ST7796S MADCTL0x48 selects BGR. Keep each conversion chunk
        # bounded instead of constructing a frame-sized Python integer list.
        self.command(0x2A, [0, 0, 1, 63]); self.command(0x2B, [0, 0, 1, 223]); self.command(0x2C)
        for start in range(0, len(raw), self.width * 3):
            row = raw[start:start + self.width * 3]
            packed = bytearray(self.width * 2)
            for x in range(self.width):
                red, green, blue = row[x * 3:x * 3 + 3]
                value = ((blue & 0xF8) << 8) | ((green & 0xFC) << 3) | (red >> 3)
                packed[x * 2] = value >> 8; packed[x * 2 + 1] = value & 255
            self.spi.writebytes2(packed)

    def _read(self, register: int, count: int):
        from smbus2 import i2c_msg
        request = i2c_msg.write(self.address, [register >> 8, register & 255])
        response = i2c_msg.read(self.address, count)
        self.bus.i2c_rdwr(request, response)
        return bytes(response)

    def touch(self):
        """One action on released contact, never a held-at-entry/stuck touch."""
        from smbus2 import i2c_msg
        status = self._read(0x814E, 1)[0]
        now = time.monotonic()
        if not status & 0x80:
            if self.contact is None and self._released_at is not None and now - self._released_at >= .15:
                self._armed = True
            if self.contact and now - self.contact[2] > 5:
                self.contact = None; self._armed = False
            return None
        try:
            count = status & 15
            if count == 0:
                previous = self.contact; self.contact = None
                if self._released_at is None:
                    self._released_at = now
                if not self._armed:
                    if now - self._released_at >= .15:
                        self._armed = True
                    return None
                if previous and .05 <= now - previous[2] <= 2 and not previous[3]:
                    self._armed = False; self._released_at = now
                    return previous[0], previous[1]
                return None
            self._released_at = None
            if count != 1:
                self.contact = None; self._armed = False
                return None
            point = self._read(0x8150, 4)
            x, y = point[0] | point[1] << 8, point[2] | point[3] << 8
            if not 0 <= x < self.width or not 0 <= y < self.height:
                self.contact = None; self._armed = False
                return None
            if self.contact is None:
                self.contact = (x, y, now, not self._armed)
            elif abs(x - self.contact[0]) + abs(y - self.contact[1]) > 35:
                self.contact = (*self.contact[:3], True)
            return None
        finally:
            self.bus.i2c_rdwr(i2c_msg.write(self.address, [0x81, 0x4E, 0]))

    def close(self):
        if self.spi is not None:
            try:
                self.spi.close()
            except OSError:
                pass
            self.spi = None
        if self.bus is not None:
            try:
                self.bus.close()
            except OSError:
                pass
            self.bus = None
        for device in reversed(self.resources):
            try:
                device.close()
            except Exception:
                pass
        self.resources = []
        self.lease.close()
