"""Root physical client for the fixed seed authorization socket."""
from __future__ import annotations

import json
import socket
import uuid

from .state import AccessError

SOCKET = "/run/shotdeck-recovery/gateway.sock"
PHYSICAL_ACTIONS = frozenset({"physical_state", "physical_pair", "physical_network_enable", "physical_network_restore", "physical_hotspot_start",
                              "physical_exit", "physical_auth_reset"})


def request(action: str) -> dict:
    if action not in PHYSICAL_ACTIONS:
        raise AccessError("Unsupported physical recovery action")
    ident = uuid.uuid4().hex
    raw = json.dumps({"schema_version": 1, "id": ident, "action": action, "params": {}, "auth": {}, "context": {}},
                     separators=(",", ":")).encode() + b"\n"
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as stream:
        stream.settimeout(120 if action in {"physical_network_enable", "physical_network_restore", "physical_hotspot_start", "physical_exit"} else 60)
        stream.connect(SOCKET); stream.sendall(raw)
        result = bytearray()
        while b"\n" not in result:
            part = stream.recv(min(4096, 65537 - len(result)))
            if not part:
                raise AccessError("Recovery gateway closed its response")
            result.extend(part)
            if len(result) > 65536:
                raise AccessError("Recovery gateway response exceeds its bound")
    try:
        document = json.loads(bytes(result))
    except ValueError as exc:
        raise AccessError("Recovery gateway returned invalid data") from exc
    if not isinstance(document, dict) or document.get("id") != ident or document.get("schema_version") != 1:
        raise AccessError("Recovery response identity differs")
    if document.get("ok") is not True:
        error = document.get("error")
        message = error.get("message") if isinstance(error, dict) else None
        raise AccessError(str(message or "Recovery action is unavailable")[:200])
    value = document.get("result")
    if not isinstance(value, dict):
        raise AccessError("Recovery gateway returned invalid state")
    return value
