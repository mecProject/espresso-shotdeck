"""Per-job executor, started by the coordinator as its own systemd unit.

The executor has no lifecycle binding to the application, Bluetooth, the
coordinator or any portal. It owns the protected updater child it starts.

Outcome contract (Release A):

* Success is published only after the CLI exits 0, its result matches the
  exact approved offer, and a job-bound receipt has been fsynced.
* A nonzero exit proves failure, not that the previous version was restored.
* Once activation may have started, executor loss leaves no receipt; the
  coordinator records ``interrupted``/``unknown``. Nothing here infers success
  from the running version or links, and nothing replays an activation.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
import sys
import time
import traceback

from . import fsio
from .admission import admit
from .compat import CompatViews
from .health import read_local_health
from .protocol import (
    CHECKING, FAILED, INSTALLING, INTERRUPTED, SUCCEEDED, WAITING_FOR_IDLE,
    ProtocolError, iso, offer_from_check, parse_time,
)
from .queue import INSTALL_ROOT, JobStore, running_version
from .runtime import (
    CHECK_TIMEOUT_SECONDS, CONFIG_PATH, LAUNCHER, RuntimeUnavailable,
    friendly_error, load_launcher, run_updater, updater_prefix,
)

EXIT_OK = 0
EXIT_INTERNAL = 70
ENV_FILES = (Path("/etc/default/shotdeck-updates"),)
DATA_ROOT = Path("/var/lib/shotdeck")
OFFICIAL_MANIFESTS = frozenset(
    f"https://mecproject.github.io/espresso-shotdeck/metadata/shotdeck-{channel}{suffix}.json"
    for channel in ("stable", "beta") for suffix in ("", "-v2", "-v3")
)
RESULT_KEYS = ("applicable", "reason", "manifest_version", "channel", "artifact_kind",
               "artifact_sha256", "manifest_sha256", "installed_version")
_TRUE = {"1", "true", "yes", "on"}
_FALSE = {"0", "false", "no", "off"}


def _flag(value: str | None, default: bool) -> bool:
    normalized = (value or "").strip().strip("'\"").lower()
    if normalized in _TRUE:
        return True
    if normalized in _FALSE:
        return False
    return default


def read_preferences(env_files=ENV_FILES, environ=None) -> dict:
    """Read the saved user preferences at execution time, not unit start."""
    values = dict(os.environ if environ is None else environ)
    for path in env_files:
        try:
            with open(path, encoding="utf-8") as stream:
                lines = stream.read(65536).splitlines()
        except OSError:
            continue
        for line in lines:
            key, separator, value = line.strip().partition("=")
            if separator and key in {"UPDATES_ENABLED", "AUTO_UPDATE"}:
                values[key] = value
    enabled = _flag(values.get("UPDATES_ENABLED"), True)
    return {"updates_enabled": enabled, "auto_update": enabled and _flag(values.get("AUTO_UPDATE"), False)}


def read_only_mode(cmdline: Path = Path("/proc/cmdline")) -> bool:
    try:
        return "overlayroot=tmpfs" in cmdline.read_text(encoding="utf-8").lower()
    except OSError:
        return False


def local_health(timeout: float = 2.0) -> dict | None:
    """The application's own readiness report; ``None`` when unreachable."""
    try:
        return read_local_health(timeout)
    except OSError:
        return None


def _bounded_result(payload: dict | None) -> dict | None:
    if not isinstance(payload, dict):
        return None
    result = {}
    for key in RESULT_KEYS:
        value = payload.get(key)
        if isinstance(value, bool) or value is None:
            result[key] = value
        else:
            result[key] = str(value)[:200]
    return result


class Executor:
    def __init__(self, store: JobStore | None = None, *, launcher_path: Path = LAUNCHER,
                 config_path: Path = CONFIG_PATH, data_root: Path = DATA_ROOT,
                 install_root: Path = INSTALL_ROOT, env_files=ENV_FILES,
                 proc_root: Path = Path("/proc"), health=local_health,
                 clock=time.monotonic, sleep=time.sleep, idle_wait: float = 1800.0,
                 admission_wait: float = 600.0, poll: float = 5.0, launcher_loader=load_launcher) -> None:
        self.store = store or JobStore()
        self.launcher_path = Path(launcher_path)
        self.config_path = Path(config_path)
        self.data_root = Path(data_root)
        self.install_root = Path(install_root)
        self.env_files = env_files
        self.proc_root = Path(proc_root)
        self.health = health
        self.clock = clock
        self.sleep = sleep
        self.idle_wait = idle_wait
        self.admission_wait = admission_wait
        self.poll = poll
        self.compat = CompatViews(self.data_root)
        self.launcher_loader = launcher_loader

    # -- state helpers -----------------------------------------------------
    def _update(self, job_id: str, **changes) -> dict:
        with self.store.lock():
            state = self.store.state(job_id)
            timings = dict(state.get("phase_timings") or {})
            new_state = changes.get("state")
            if new_state and new_state != state["state"]:
                started = parse_time(state.get("phase_started_at"))
                if started is not None:
                    elapsed = (parse_time(iso()) - started).total_seconds()
                    timings[state["state"]] = round(timings.get(state["state"], 0.0) + max(0.0, elapsed), 3)
                changes["phase_started_at"] = iso()
            extra = changes.pop("timings", None) or {}
            for key, value in extra.items():
                timings[key] = round(timings.get(key, 0.0) + float(value), 3)
            return self.store.write_state({**state, **changes, "phase_timings": timings})

    def _finish(self, job_id: str, **kwargs) -> dict:
        with self.store.lock():
            state = self.store.state(job_id)
            kwargs.setdefault("observations", {"running_version": running_version(self.install_root)})
            return self.store.finish(state, **kwargs)

    def _observed(self) -> str:
        return running_version(self.install_root)

    # -- entry -------------------------------------------------------------
    def run(self, job_id: str) -> int:
        self.store.ensure()
        with self.store.hold_executor(job_id):
            with self.store.lock():
                state = self.store.state(job_id)
                if state is None or self.store.receipt(job_id) is not None:
                    return EXIT_OK
                if not state.get("dispatch") or state.get("executor"):
                    # Never re-run a job another executor already started.
                    print("Update job is not dispatched to a fresh executor; nothing to do", file=sys.stderr)
                    return EXIT_OK
                request = self.store.request(job_id)
                self.store.write_state({**state, "executor": {
                    "started_at": iso(), "pid": os.getpid(),
                    "invocation_id": os.environ.get("INVOCATION_ID", "")[:64]}})
            try:
                if request["action"] == "check":
                    self._user_check(job_id)
                elif request["action"] == "install":
                    self._install(job_id, request["offer"])
                else:
                    self._scheduled(job_id)
            except Exception:  # noqa: BLE001 - every defect still yields a receipt
                traceback.print_exc()
                state = self.store.state(job_id)
                if self.store.receipt(job_id) is None:
                    if state.get("apply_invoked_at"):
                        message = (f"Shotdeck could not confirm whether the update finished. "
                                   f"Version {self._observed()} is running.")
                        self._finish(job_id, terminal=INTERRUPTED, outcome="unknown",
                                     error_code="internal_error", message=message)
                        self.compat.unknown(job_id, state.get("apply_offer"), message)
                    else:
                        self._finish(job_id, terminal=FAILED, outcome="not_started",
                                     error_code="internal_error", message="The update worker failed before installing.")
                return EXIT_INTERNAL
        return EXIT_OK

    # -- checks ------------------------------------------------------------
    def _launcher(self):
        return self.launcher_loader(self.launcher_path)

    def _run_check(self, job_id: str):
        """Return (payload, offer) or ``None`` after recording a failure receipt."""
        self._update(job_id, state=CHECKING, wait_reason="")
        try:
            result = run_updater(self._launcher(), "check", config_path=self.config_path,
                                 timeout=CHECK_TIMEOUT_SECONDS)
        except RuntimeUnavailable as exc:
            self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="runtime_unavailable",
                         message="The updater needs repair.", detail=str(exc))
            return None
        self._update(job_id, timings={f"cli.{key}" if key == "check" else key: value
                                      for key, value in result.timings.items()})
        if result.timed_out:
            self._finish(job_id, terminal=FAILED, outcome="failed", error_code="check_timeout",
                         message="Update check timed out.", detail=result.stderr)
            return None
        if not result.ok:
            code = "runtime_unavailable" if result.spawn_failed else "check_failed"
            self._finish(job_id, terminal=FAILED, outcome="failed", error_code=code,
                         message=friendly_error(result.stderr), detail=result.stderr)
            return None
        try:
            offer = offer_from_check(result.payload)
        except ProtocolError:
            self._finish(job_id, terminal=FAILED, outcome="failed", error_code="offer_incomplete",
                         message="Updater returned incomplete release identity.",
                         result=_bounded_result(result.payload))
            return None
        return result.payload, offer

    def _publish_check(self, job_id: str, payload: dict, offer: dict | None) -> None:
        if offer is not None:
            self.store.set_offer(offer, job_id=job_id)
            self._finish(job_id, terminal=SUCCEEDED, outcome="available",
                         message=f"Version {offer['version']} is available.", result=_bounded_result(payload))
            self.compat.offer(offer)
            return
        reason = str(payload.get("reason") or "")
        up_to_date = "already runs this version" in reason.lower()
        self.store.clear_offer()
        self._finish(job_id, terminal=SUCCEEDED, outcome="up_to_date" if up_to_date else "unavailable",
                     message="Software is up to date." if up_to_date else (reason[:200] or "No update is available right now."),
                     result=_bounded_result(payload))
        self.compat.no_offer(up_to_date=up_to_date, version=str(payload.get("manifest_version") or ""),
                             channel=str(payload.get("channel") or "stable"))

    def _preflight(self, job_id: str, *, user_check: bool = False) -> bool:
        prefs = read_preferences(self.env_files)
        if not prefs["updates_enabled"]:
            self._updates_disabled(job_id)
            return False
        if read_only_mode(self.proc_root / "cmdline"):
            self._finish(job_id, terminal=FAILED, outcome="blocked", error_code="read_only",
                         message="Updates unavailable in read-only mode.")
            return False
        return True

    def _updates_disabled(self, job_id: str, *, scheduled: bool = False) -> None:
        self.store.clear_offer()
        self._finish(job_id, terminal=SUCCEEDED if scheduled else FAILED,
                     outcome="skipped" if scheduled else "blocked", error_code="updates_disabled",
                     message="Updates are disabled.")
        self.compat.updates_disabled()

    def _user_check(self, job_id: str) -> None:
        if not self._preflight(job_id, user_check=True):
            return
        checked = self._run_check(job_id)
        if checked is not None:
            self._publish_check(job_id, *checked)

    # -- installs ----------------------------------------------------------
    def _maintenance_reason(self) -> tuple[str, str] | None:
        try:
            status = fsio.read_json_optional(self.data_root / "signing/automatic/status.json")
        except (fsio.RecordError, OSError):
            status = None
        if status and status.get("state") in {"preparing", "finishing", "restarting"}:
            return "maintenance_active", "Update maintenance is finishing. Try again after it completes."
        if (self.data_root / "signing/licence/pending.json").exists():
            return "licence_pending", "A licence change is pending. Try again after it completes."
        return None

    def _install_preflight(self, job_id: str) -> bool:
        if not self._preflight(job_id):
            return False
        blocked = self._maintenance_reason()
        if blocked is not None:
            self._finish(job_id, terminal=FAILED, outcome="not_started", error_code=blocked[0], message=blocked[1])
            return False
        others = [other for other in self.store.mutation_barrier() if other != job_id]
        if others:
            self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="unknown_apply_pending",
                         message="Shotdeck could not confirm an earlier update. Review it before installing again.")
            return False
        return True

    def _install(self, job_id: str, offer: dict) -> None:
        if not self._install_preflight(job_id):
            return
        checked = self._run_check(job_id)
        if checked is None:
            return
        payload, current = checked
        if current != offer:
            if current is not None:
                self.store.set_offer(current, job_id=job_id)
                self.compat.offer(current)
            else:
                self.store.clear_offer()
            message = ("The available update changed. Check again and confirm the new version."
                       if current is not None else "This update is no longer offered for this device.")
            self._finish(job_id, terminal=FAILED, outcome="not_started",
                         error_code="offer_changed" if current is not None else "offer_unavailable",
                         message=message, result=_bounded_result(payload))
            self.compat.not_started(job_id, offer, message)
            return
        self._apply(job_id, offer)

    def _scheduled(self, job_id: str) -> None:
        prefs = read_preferences(self.env_files)
        if not prefs["updates_enabled"]:
            self._updates_disabled(job_id, scheduled=True)
            return
        if not prefs["auto_update"]:
            self._user_check(job_id)
            return
        try:
            config = json.loads(fsio.read_bytes(self.config_path, 256 * 1024).decode("utf-8")) \
                if self.config_path.exists() else {}
        except (fsio.RecordError, OSError, ValueError):
            config = {}
        policy = config.get("policy") if isinstance(config, dict) else None
        official = isinstance(config, dict) and str(config.get("manifest_url", "")) in OFFICIAL_MANIFESTS
        if policy == "check-only" or (policy == "download-only" and not official):
            # Preserve an operator's explicit check-only or custom download-only policy.
            self._unattended(job_id)
            return
        if not self._install_preflight(job_id):
            return
        checked = self._run_check(job_id)
        if checked is None:
            return
        payload, offer = checked
        if offer is None:
            self._publish_check(job_id, payload, None)
            return
        # Automatic consent comes from the saved Auto-Update preference; the
        # offer is still bound exactly before activation.
        self.store.set_offer(offer, job_id=job_id)
        self.compat.offer(offer)
        self._apply(job_id, offer, automatic_check=payload)

    def _unattended(self, job_id: str) -> None:
        self._update(job_id, state=CHECKING)
        try:
            result = run_updater(self._launcher(), "unattended", config_path=self.config_path)
        except RuntimeUnavailable as exc:
            self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="runtime_unavailable",
                         message="The updater needs repair.", detail=str(exc))
            return
        self._update(job_id, timings={f"cli.{k}" if k == "unattended" else k: v for k, v in result.timings.items()})
        if not result.ok:
            self._finish(job_id, terminal=FAILED, outcome="failed", error_code="check_failed",
                         message=friendly_error(result.stderr), detail=result.stderr)
            return
        self._finish(job_id, terminal=SUCCEEDED, outcome="unavailable", message="Configured update policy completed.",
                     result=_bounded_result(result.payload))

    def _wait_for_idle(self, job_id: str) -> bool:
        deadline = self.clock() + self.idle_wait
        while True:
            health = self.health(2.0)
            if health is None:
                # The protected updater fails closed on missing health itself.
                return True
            if (health.get("status") == "ready" and health.get("control_ready") is True
                    and health.get("brew_active") is False):
                return True
            reason = "brew_active" if health.get("brew_active") is not False else "app_not_ready"
            if self.clock() >= deadline:
                message = ("Finish the active brew, then install again." if reason == "brew_active"
                           else "Shotdeck must be running and idle before an update can start.")
                self._finish(job_id, terminal=FAILED, outcome="not_started", error_code=reason, message=message)
                return False
            self._update(job_id, state=WAITING_FOR_IDLE, wait_reason=reason)
            self.sleep(self.poll)

    def _wait_for_admission(self, job_id: str) -> bool:
        """Immediately before the protected apply: nothing has been changed yet."""
        deadline = self.clock() + self.admission_wait
        while True:
            decision = admit("apply", proc_root=self.proc_root)
            with self.store.lock():
                current = self.store.state(job_id)
                self.store.write_state({**current, "admission": {**dict(current.get("admission") or {}),
                                                                 "apply": {**decision.evidence(), "at": iso()}}})
            if decision.admitted:
                return True
            if self.clock() >= deadline:
                self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="admission_timeout",
                             message="Not enough free memory to start the update safely. Try again later.",
                             detail=f"{decision.reason}: available={decision.available_mib} required={decision.required_mib}")
                return False
            self._update(job_id, wait_reason=decision.reason)
            self.sleep(self.poll)

    def _apply(self, job_id: str, offer: dict, *, automatic_check: dict | None = None) -> None:
        if not self._wait_for_idle(job_id) or not self._wait_for_admission(job_id):
            state = self.store.state(job_id)
            self.compat.not_started(job_id, offer, state.get("message") or "The update did not start.")
            return
        selection_started = self.clock()
        try:
            prefix = updater_prefix(self._launcher())
        except RuntimeUnavailable as exc:
            self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="runtime_unavailable",
                         message="The updater needs repair.", detail=str(exc))
            self.compat.not_started(job_id, offer, "The updater needs repair.")
            return
        prefs = read_preferences(self.env_files)
        if not prefs["updates_enabled"]:
            self._updates_disabled(job_id, scheduled=automatic_check is not None)
            return
        if automatic_check is not None and not prefs["auto_update"]:
            self._publish_check(job_id, automatic_check, offer)
            return
        # Durable activation intent: from here on, executor loss means unknown.
        self._update(job_id, state=INSTALLING, wait_reason="", apply_offer=offer, apply_invoked_at=iso(),
                     timings={"runtime_selection": self.clock() - selection_started})
        self.compat.installing(job_id, offer)
        result = run_updater(self._launcher(), "apply", offer=offer, config_path=self.config_path, prefix=prefix)
        self._update(job_id, timings={f"cli.{k}" if k == "apply" else k: v for k, v in result.timings.items()})
        observed = self._observed()
        if result.spawn_failed:
            message = "The updater could not be started; no installation began."
            self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="runtime_unavailable",
                         message=message, detail=result.stderr)
            self.compat.not_started(job_id, offer, message)
            return
        if result.returncode is None or result.returncode < 0 or result.returncode >= 128:
            # Terminated by a signal (directly, or reported by a wrapper as
            # 128+N): the installer did not finish its own error handling, so
            # links, services and health may be half-way. Never a plain failure.
            message = f"Shotdeck could not confirm whether the update finished. Version {observed} is running."
            self._finish(job_id, terminal=INTERRUPTED, outcome="unknown", error_code="apply_interrupted",
                         message=message, detail=f"updater exit status {result.returncode}: {result.stderr}")
            self.compat.unknown(job_id, offer, message)
            return
        if result.returncode != 0:
            message = f"The update did not complete. Version {observed} is running."
            self._finish(job_id, terminal=FAILED, outcome="failed", error_code="apply_failed",
                         message=message, detail=result.stderr)
            self.compat.failed(job_id, offer, message)
            return
        payload = result.payload or {}
        matches = (
            str(payload.get("installed_version") or "") == offer["version"]
            and all(not payload.get(key) or payload.get(key) == offer[key]
                    for key in ("artifact_sha256", "manifest_sha256"))
            and (not payload.get("manifest_version") or payload.get("manifest_version") == offer["version"])
        )
        if not result.ok or not matches:
            message = f"Shotdeck could not confirm the update result. Version {observed} is running."
            self._finish(job_id, terminal=FAILED, outcome="unknown", error_code="result_mismatch",
                         message=message, result=_bounded_result(payload))
            self.compat.unknown(job_id, offer, message)
            return
        # Receipt first; only then is success visible to any reader.
        self._finish(job_id, terminal=SUCCEEDED, outcome="installed",
                     message=f"Updated to version {offer['version']}.", result=_bounded_result(payload))
        self.store.clear_offer(matching=offer)
        self.compat.installed(job_id, offer)


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    if len(args) != 1:
        print("usage: executor <job-id>", file=sys.stderr)
        return 64
    from .protocol import is_job_id
    if not is_job_id(args[0]):
        print("Invalid update job identifier", file=sys.stderr)
        return 64
    return Executor().run(args[0])


if __name__ == "__main__":
    raise SystemExit(main())
