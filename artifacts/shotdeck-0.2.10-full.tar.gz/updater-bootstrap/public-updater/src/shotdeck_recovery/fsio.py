"""Bounded, protected and durable file primitives for queue records.

Every read refuses symlinks, special files, oversized records and files that
are not owned by the current (root) user or are writable by others. Every
write reaches the disk before it becomes visible: data and directory entries
are fsynced, and exclusive creation never exposes a partial record.
"""

from __future__ import annotations

from contextlib import contextmanager
import errno
import fcntl
import json
import os
from pathlib import Path
import re
import stat
import time
from typing import Iterator

MAX_RECORD_BYTES = 64 * 1024
_NOFOLLOW = getattr(os, "O_NOFOLLOW", 0)
_DIRECTORY = getattr(os, "O_DIRECTORY", 0)
_CLOEXEC = getattr(os, "O_CLOEXEC", 0)


class RecordError(ValueError):
    """A queue record or directory failed validation."""


def _unique(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise RecordError("Duplicate record property")
        result[key] = value
    return result


def fsync_dir(path: Path) -> None:
    fd = os.open(path, os.O_RDONLY | _DIRECTORY | _CLOEXEC)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def _check_protected(info: os.stat_result, *, directory: bool) -> None:
    expected = stat.S_ISDIR(info.st_mode) if directory else stat.S_ISREG(info.st_mode)
    if not expected:
        raise RecordError("Unexpected file type in protected update state")
    if info.st_uid != os.geteuid() or info.st_mode & 0o022:
        raise RecordError("Protected update state has an unexpected owner or mode")


def ensure_dir(path: Path, mode: int = 0o700) -> Path:
    """Create or validate one protected directory without following links."""
    path = Path(path)
    if path.is_symlink():
        raise RecordError("Protected update directory must not be a symlink")
    if not path.exists():
        ensure_dir(path.parent, mode) if not path.parent.exists() else None
        try:
            path.mkdir(mode=mode)
        except FileExistsError:
            pass
        else:
            fsync_dir(path.parent)
    info = os.lstat(path)
    _check_protected(info, directory=True)
    return path


def read_bytes(path: Path, limit: int = MAX_RECORD_BYTES) -> bytes:
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | _NOFOLLOW | _CLOEXEC)
    except OSError as exc:
        if exc.errno == errno.ELOOP:
            raise RecordError("Protected update record must not be a symlink") from exc
        raise
    try:
        info = os.fstat(fd)
        _check_protected(info, directory=False)
        if info.st_size > limit:
            raise RecordError("Protected update record exceeds its size limit")
        chunks = []
        remaining = limit + 1
        while remaining > 0:
            chunk = os.read(fd, min(65536, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        data = b"".join(chunks)
        if len(data) > limit:
            raise RecordError("Protected update record exceeds its size limit")
        return data
    except OSError as exc:
        if exc.errno == errno.ELOOP:
            raise RecordError("Protected update record must not be a symlink") from exc
        raise
    finally:
        os.close(fd)


def read_json(path: Path, limit: int = MAX_RECORD_BYTES) -> dict:
    try:
        value = json.loads(read_bytes(path, limit), object_pairs_hook=_unique)
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise RecordError("Protected update record is corrupt") from exc
    if not isinstance(value, dict):
        raise RecordError("Protected update record must be an object")
    return value


def read_json_optional(path: Path, limit: int = MAX_RECORD_BYTES) -> dict | None:
    try:
        return read_json(path, limit)
    except FileNotFoundError:
        return None


def encode(value: dict) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode() + b"\n"


def _write_temp(directory: Path, name: str, data: bytes, mode: int) -> Path:
    temporary = directory / f".{name}.{os.getpid()}.{time.monotonic_ns()}.tmp"
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | _NOFOLLOW | _CLOEXEC, mode)
    try:
        os.fchmod(fd, mode)
        view = memoryview(data)
        while view:
            written = os.write(fd, view)
            view = view[written:]
        os.fsync(fd)
    except BaseException:
        os.close(fd)
        temporary.unlink(missing_ok=True)
        raise
    os.close(fd)
    return temporary


def write_atomic(path: Path, data: bytes, mode: int = 0o600) -> None:
    """Replace ``path`` with complete, durable content."""
    path = Path(path)
    ensure_dir(path.parent)
    if path.is_symlink():
        raise RecordError("Protected update record must not be a symlink")
    temporary = _write_temp(path.parent, path.name, data, mode)
    try:
        os.replace(temporary, path)
        fsync_dir(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def write_json(path: Path, value: dict, mode: int = 0o600) -> None:
    write_atomic(path, encode(value), mode)


def create_exclusive(path: Path, data: bytes, mode: int = 0o600, *, staging: Path | None = None) -> bool:
    """Durably create ``path`` once; return ``False`` if it already exists.

    A hard link of a complete temporary file never exposes a partial record and
    fails instead of replacing an existing one. For a directory watched by a
    path unit or read by another process, pass ``staging`` (a sibling on the
    same filesystem): the temporary file then never appears in the watched
    directory, where a reader could quarantine it mid-write.
    """
    path = Path(path)
    ensure_dir(path.parent)
    folder = Path(staging) if staging is not None else path.parent
    ensure_dir(folder)
    temporary = _write_temp(folder, path.name, data, mode)
    try:
        try:
            os.link(temporary, path, follow_symlinks=False)
        except FileExistsError:
            return False
        fsync_dir(path.parent)
        return True
    finally:
        temporary.unlink(missing_ok=True)
        try:
            fsync_dir(folder)
        except OSError:
            pass


IN_PROGRESS_GRACE_SECONDS = 60


def in_progress(entry: Path) -> bool:
    """A recent dot-file is someone's write in progress: leave it alone."""
    if not entry.name.startswith("."):
        return False
    try:
        return time.time() - os.lstat(entry).st_mtime < IN_PROGRESS_GRACE_SECONDS
    except FileNotFoundError:
        return True


def move_noreplace(source: Path, destination: Path) -> bool:
    """Atomically move one entry; return ``False`` if the destination exists."""
    source, destination = Path(source), Path(destination)
    ensure_dir(destination.parent)
    try:
        os.link(source, destination, follow_symlinks=False)
    except FileExistsError:
        return False
    except OSError as exc:
        if exc.errno not in {errno.EPERM, errno.EISDIR}:
            raise
        # Directories and other entries that cannot be hard linked: a rename
        # within one filesystem is still atomic. Check first; the queue lock
        # serializes movers.
        if os.path.lexists(destination):
            return False
        os.rename(source, destination)
        fsync_dir(destination.parent)
        if source.parent != destination.parent:
            fsync_dir(source.parent)
        return True
    os.unlink(source)
    fsync_dir(destination.parent)
    if source.parent != destination.parent:
        fsync_dir(source.parent)
    return True


def remove(path: Path) -> None:
    path = Path(path)
    try:
        if path.is_dir() and not path.is_symlink():
            for child in path.iterdir():
                remove(child)
            path.rmdir()
        else:
            path.unlink()
    except FileNotFoundError:
        return
    fsync_dir(path.parent)


JOB_FILE = re.compile(r"^[0-9a-f]{32}\.json$")


def job_files(directory: Path, limit: int = 512) -> list[str]:
    """Return bounded job identifiers present in one queue directory."""
    try:
        names = os.listdir(directory)
    except FileNotFoundError:
        return []
    result = sorted(name[:-5] for name in names if JOB_FILE.fullmatch(name))
    return result[:limit]


@contextmanager
def flock(path: Path, *, shared: bool = False, blocking: bool = True, timeout: float = 30.0) -> Iterator[bool]:
    """Hold an advisory lock; yields ``False`` when non-blocking acquisition fails."""
    path = Path(path)
    ensure_dir(path.parent)
    try:
        fd = os.open(path, os.O_RDONLY | _NOFOLLOW | _CLOEXEC)
    except FileNotFoundError:
        try:
            fd = os.open(path, os.O_RDONLY | os.O_CREAT | os.O_EXCL | _NOFOLLOW | _CLOEXEC, 0o600)
        except FileExistsError:
            fd = os.open(path, os.O_RDONLY | _NOFOLLOW | _CLOEXEC)
    try:
        operation = fcntl.LOCK_SH if shared else fcntl.LOCK_EX
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(fd, operation | fcntl.LOCK_NB)
                acquired = True
                break
            except BlockingIOError:
                if not blocking:
                    acquired = False
                    break
                if time.monotonic() >= deadline:
                    raise RecordError(f"Update state lock remained busy: {path.name}")
                time.sleep(0.05)
        try:
            yield acquired
        finally:
            if acquired:
                fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)
