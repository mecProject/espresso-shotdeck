"""Read Shotdeck's bounded readiness report directly from loopback."""

from http.client import HTTPConnection, HTTPException, HTTPSConnection
import json
import ssl


def read_local_health(timeout: float, *, max_bytes: int = 65536) -> dict:
    # The built-in server keeps port 80 when TLS is enabled. Some installations
    # also expose the local HTTPS endpoint on the standard port.
    last_error = None
    for port, tls in ((80, False), (80, True), (443, True)):
        if tls:
            connection = HTTPSConnection("127.0.0.1", port, timeout=timeout,
                                         context=ssl._create_unverified_context())
        else:
            connection = HTTPConnection("127.0.0.1", port, timeout=timeout)
        try:
            connection.request("GET", "/healthz")
            response = connection.getresponse()
            if response.status != 200:
                raise ValueError("Unexpected health report status")
            raw = response.read(max_bytes + 1)
            if len(raw) > max_bytes:
                raise ValueError("Health report exceeds its bound")
            value = json.loads(raw.decode("utf-8"))
            if not isinstance(value, dict):
                raise ValueError("Invalid health report")
            return value
        except (OSError, HTTPException, ValueError, RecursionError) as exc:
            last_error = exc
        finally:
            connection.close()
    raise OSError("Shotdeck's local health report is unavailable") from last_error
