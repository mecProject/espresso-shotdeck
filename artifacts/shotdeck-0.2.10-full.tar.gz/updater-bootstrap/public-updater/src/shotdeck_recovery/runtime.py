"""Invoke the protected updater through the retained, reviewed runtime selector.

Runtime selection is security-critical: migrated devices must use their
committed runtime, REV15 must use its hardware-aware runtime, and neither may
fall back to a legacy updater. The worker therefore loads the selector from the
retained launcher instead of carrying a second copy that could diverge. The
launcher file is accepted only as a protected regular file.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import time

LAUNCHER = Path("/opt/shotdeck/public-updater-installer/scripts/prompted_update_flow.py")
CONFIG_PATH = Path("/etc/shotdeck/updater.json")
# Matches the reviewed launcher. Disk verification of the retained trees is
# part of every protected check; it can legitimately exceed 30 s on SD cards.
CHECK_TIMEOUT_SECONDS = 180
MAX_OUTPUT_BYTES = 1024 * 1024


class RuntimeUnavailable(RuntimeError):
    """The protected updater runtime could not be selected safely."""


@dataclass(slots=True)
class UpdaterResult:
    command: str
    returncode: int | None
    payload: dict | None
    stderr: str
    timed_out: bool = False
    spawn_failed: bool = False
    timings: dict = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.returncode == 0 and isinstance(self.payload, dict)


_loaded: dict[Path, object] = {}


def load_launcher(path: Path = LAUNCHER):
    path = Path(path)
    if path in _loaded:
        return _loaded[path]
    try:
        info = os.lstat(path)
    except OSError as exc:
        raise RuntimeUnavailable("Retained update launcher is missing") from exc
    if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022):
        raise RuntimeUnavailable("Retained update launcher is not a protected regular file")
    spec = importlib.util.spec_from_file_location("shotdeck_retained_launcher", path)
    if spec is None or spec.loader is None:
        raise RuntimeUnavailable("Retained update launcher cannot be loaded")
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as exc:  # noqa: BLE001 - reported as an unavailable runtime
        raise RuntimeUnavailable("Retained update launcher failed to load") from exc
    for name in ("select_updater_binary", "_installed_profile_id", "CURRENT_UPDATER_BIN", "REV15_PROFILE_ID"):
        if not hasattr(module, name):
            raise RuntimeUnavailable("Retained update launcher lacks the protected selector")
    _loaded[path] = module
    return module


def updater_prefix(launcher) -> list[str]:
    """Select the protected runtime exactly as the retained launcher does."""
    try:
        binary = Path(launcher.select_updater_binary())
        committed = binary.parent.parent.parent == Path(launcher.CURRENT_UPDATER_BIN).parents[2] / "updater-runtimes"
        rev15 = launcher._installed_profile_id() == launcher.REV15_PROFILE_ID
    except SystemExit as exc:
        raise RuntimeUnavailable(str(exc.code or "Protected updater runtime needs repair")) from exc
    if committed or rev15:
        return [str(binary.with_name("python")), "-I", "-m", "shotdeck_updater.cli"]
    return [str(binary)]


def run_updater(launcher, command: str, *, offer: dict | None = None,
                config_path: Path = CONFIG_PATH, timeout: int | None = None,
                prefix: list[str] | None = None) -> UpdaterResult:
    """Run one protected CLI command. ``apply`` is never given a deadline.

    Pass ``prefix`` when runtime selection already happened, so a durable
    activation intent can be recorded between selection and execution.
    """
    timings: dict = {}
    if prefix is None:
        started = time.monotonic()
        prefix = updater_prefix(launcher)
        timings["runtime_selection"] = round(time.monotonic() - started, 3)
    args = [*prefix, "--config", str(config_path), command]
    if command == "apply":
        if offer is None:
            raise ValueError("apply requires the exact approved offer")
        args += ["--expected-version", offer["version"],
                 "--expected-artifact-sha256", offer["artifact_sha256"],
                 "--expected-manifest-sha256", offer["manifest_sha256"]]
        timeout = None
    cli_started = time.monotonic()
    try:
        completed = subprocess.run(args, check=False, capture_output=True, text=True,
                                   timeout=timeout, env=_child_environment())
    except subprocess.TimeoutExpired as exc:
        timings[command] = round(time.monotonic() - cli_started, 3)
        stderr = exc.stderr.decode("utf-8", "replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        return UpdaterResult(command, None, None, stderr[-2000:], timed_out=True, timings=timings)
    except OSError as exc:
        timings[command] = round(time.monotonic() - cli_started, 3)
        return UpdaterResult(command, None, None, str(exc), spawn_failed=True, timings=timings)
    timings[command] = round(time.monotonic() - cli_started, 3)
    payload = None
    if completed.returncode == 0 and len(completed.stdout) <= MAX_OUTPUT_BYTES:
        try:
            value = json.loads(completed.stdout)
        except json.JSONDecodeError:
            value = None
        payload = value if isinstance(value, dict) else None
    return UpdaterResult(command, completed.returncode, payload, (completed.stderr or "")[-2000:], timings=timings)


def _child_environment() -> dict:
    """Do not let inherited interpreter variables alter the protected CLI."""
    blocked = {"PYTHONPATH", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONUSERBASE", "PYTHONINSPECT"}
    return {key: value for key, value in os.environ.items() if key not in blocked}


def friendly_error(stderr: str) -> str:
    """Same user wording as the application's existing check path."""
    normalized = (stderr or "").strip().lower()
    if "does not match verification key" in normalized or "manifest key_id" in normalized:
        return "Update key mismatch. Install matching key."
    if "signature verification failed" in normalized:
        return "Update signature failed. Check update key."
    if "config not found" in normalized:
        return "Updater config missing."
    if "runtime not found" in normalized:
        return "Updater not installed."
    if "access denied" in normalized or "permission denied" in normalized:
        return "Updater permission denied."
    if "timed out" in normalized:
        return "Update check timed out."
    if "name or service not known" in normalized or "temporary failure in name resolution" in normalized:
        return "Update server not reachable."
    if "active brew" in normalized:
        return "Finish the active brew before updating."
    if "not ready for a safe software activation" in normalized or "could not verify shotdeck brew state" in normalized:
        return "Shotdeck must be running and idle before an update can start."
    if "already running" in normalized:
        return "Another update operation is running. Try again shortly."
    return "Update check failed."
