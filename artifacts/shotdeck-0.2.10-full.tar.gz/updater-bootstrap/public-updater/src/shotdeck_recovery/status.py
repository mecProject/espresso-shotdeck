"""Read-only status derived from durable job records and receipts.

Both device UIs use this one reader. It never writes, never infers success
from the running version and treats an executor lost without a receipt as
unresolved, not finished.
"""

from __future__ import annotations

from . import PROTOCOL_VERSION, fsio
from .protocol import ACTIVE_STATES, COALESCED, QUEUED
from .queue import JobStore

CHECK_OUTCOMES = frozenset({"available", "up_to_date", "unavailable", "skipped", "blocked"})


def _summary(state: dict, receipt: dict | None) -> dict:
    source = receipt or state
    return {
        "job_id": state["job_id"],
        "action": state.get("action"),
        "source": state.get("source"),
        "created_at": state.get("created_at"),
        "state": source.get("state"),
        "outcome": receipt.get("outcome") if receipt else "",
        "error_code": source.get("error_code") or "",
        "message": source.get("message") or "",
        "offer": (receipt.get("offer") if receipt else None) or state.get("apply_offer") or state.get("offer"),
        "wait_reason": "" if receipt else (state.get("wait_reason") or ""),
        "phase_started_at": state.get("phase_started_at") or "",
        "completed_at": receipt.get("completed_at") if receipt else "",
        "observations": dict(receipt.get("observations") or {}) if receipt else {},
        "apply_invoked": bool(state.get("apply_invoked_at")),
        "dispatched": bool(state.get("dispatch")),
    }


def _installish(state: dict, receipt: dict) -> bool:
    if state.get("action") == "install":
        return True
    return state.get("action") == "scheduled" and bool(receipt.get("offer")) and receipt.get("outcome") not in CHECK_OUTCOMES


def snapshot(store: JobStore) -> dict:
    states = store.all_states()
    receipts: dict[str, dict | None] = {}
    for state in states:
        try:
            receipts[state["job_id"]] = store.receipt(state["job_id"])
        except (fsio.RecordError, OSError):
            receipts[state["job_id"]] = None
    active = [state for state in states if state.get("state") in ACTIVE_STATES and receipts[state["job_id"]] is None]
    known = {state["job_id"] for state in states}
    for request in store.pending_requests():
        if request["job_id"] not in known:
            # Accepted but not yet claimed: already a durable queued operation.
            active.append({**request, "state": QUEUED, "phase_started_at": request["created_at"],
                           "dispatch": None, "apply_invoked_at": None, "wait_reason": ""})
    dispatched = [state for state in active if state.get("dispatch")]
    current = dispatched[0] if dispatched else (active[0] if active else None)
    latest_check = latest_install = None
    for state in states:
        receipt = receipts[state["job_id"]]
        if not receipt or receipt.get("state") == COALESCED:
            continue
        if _installish(state, receipt):
            latest_install = (state, receipt)
        elif state.get("action") in {"check", "scheduled"}:
            latest_check = (state, receipt)
    unknown = []
    for job_id in store.mutation_barrier():
        state = next((item for item in states if item["job_id"] == job_id), None)
        receipt = receipts.get(job_id)
        if state is not None and receipt is not None:
            unknown.append(_summary(state, receipt))
        else:
            # Unreadable or inconsistent records: shown, never interpreted.
            unknown.append({
                "job_id": job_id, "action": (state or {}).get("action"), "source": (state or {}).get("source"),
                "created_at": (state or {}).get("created_at"), "state": "unknown", "outcome": "unknown",
                "error_code": "records_unreadable",
                "message": "An update record could not be read. Review the device before installing again.",
                "offer": None, "wait_reason": "", "phase_started_at": "", "completed_at": "",
                "observations": {}, "apply_invoked": True, "dispatched": False,
            })
    alive = bool(current and current.get("dispatch") and store.executor_alive(current["job_id"]))
    return {
        "schema_version": PROTOCOL_VERSION,
        "active": _summary(current, None) if current else None,
        "active_executor_alive": alive,
        "queue_depth": len(active),
        "latest_check": _summary(*latest_check) if latest_check else None,
        "latest_install": _summary(*latest_install) if latest_install else None,
        "unknown": unknown,
        "offer": store.offer(),
    }
