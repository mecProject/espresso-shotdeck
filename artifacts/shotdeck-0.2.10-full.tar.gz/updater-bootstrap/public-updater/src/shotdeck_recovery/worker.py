"""Queue coordinator: claim, reconcile and dispatch one job at a time, then exit.

The coordinator is woken by a path unit (new requests), by an executor's
``ExecStopPost`` (a job finished) and once after boot (reconciliation). It
never runs updater commands itself; each admitted job gets its own executor
unit, so restarting or disabling the coordinator cannot stop an executor.

Reconciliation never replays an activation and never accepts a UI assertion.
A job is resumed only when it is proven not to have started; an executor lost
after activation may have started yields ``interrupted``/``unknown``.
"""

from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

from . import fsio
from .admission import admit
from .compat import CompatViews
from .protocol import (
    FAILED, INTERRUPTED, QUEUED, ProtocolError, iso, mutating, parse_time, utc_now,
)
from .queue import DISPATCH_ROOT, INSTALL_ROOT, JobStore, running_version

EXIT_OK = 0
EXIT_CORRUPT = 3
UNIT_TEMPLATES = {
    "check": "shotdeck-update-check@{}.service",
    "install": "shotdeck-update-apply@{}.service",
    "scheduled": "shotdeck-update-apply@{}.service",
}
# Request expiry, always measured from the request's creation time. While a
# request waits for admission the coordinator does not stay resident: it
# records the reason, arms the one-shot retry timer and exits, so waiting
# never consumes the memory it is waiting for. A scheduled run that expires is
# retried by its own timer.
QUEUE_TTL_SECONDS = {"check": 15 * 60, "install": 30 * 60, "scheduled": 30 * 60}
RETRY_TIMER = "shotdeck-update-retry.timer"
DISPATCH_GRACE_SECONDS = 60
CHECK_ATTEMPTS = 2
ACTIVE_UNIT_STATES = frozenset({"active", "activating", "reloading", "deactivating"})


class Systemd:
    """Thin systemctl adapter; replaced by a fake in tests."""

    def start(self, unit: str, timeout: int = 120) -> tuple[bool, str]:
        try:
            completed = subprocess.run(("systemctl", "start", unit), check=False, capture_output=True,
                                       text=True, timeout=timeout)
        except (OSError, subprocess.SubprocessError) as exc:
            return False, str(exc)
        return completed.returncode == 0, (completed.stderr or "").strip()[-400:]

    def arm_retry(self) -> tuple[bool, str]:
        """Arm one bounded retry of the coordinator: the timer fires once, then stops.

        ``restart``, not ``start``: when the timer itself started this run it is
        still active (elapsed) until the run ends, so a plain start is a no-op
        and the timer then deactivates without re-arming, stranding the request
        (found on the workshop unit, 15 November 2026). Restarting re-arms the
        full interval from now, so waits can never shorten it into a loop.
        """
        try:
            completed = subprocess.run(("systemctl", "restart", RETRY_TIMER), check=False, capture_output=True,
                                       text=True, timeout=30)
        except (OSError, subprocess.SubprocessError) as exc:
            return False, str(exc)
        return completed.returncode == 0, (completed.stderr or "").strip()[-400:]

    def show(self, unit: str) -> dict:
        try:
            completed = subprocess.run(
                ("systemctl", "show", unit, "-p", "ActiveState", "-p", "SubState", "-p", "Result",
                 "-p", "ExecMainStatus", "-p", "InvocationID"),
                check=False, capture_output=True, text=True, timeout=20)
        except (OSError, subprocess.SubprocessError):
            return {}
        result = {}
        for line in completed.stdout.splitlines():
            key, _, value = line.partition("=")
            result[key.strip()] = value.strip()[:80]
        return result


def read_mode(dispatch_root: Path = DISPATCH_ROOT) -> str:
    """The gate's mode record; anything unreadable means do not dispatch."""
    try:
        record = fsio.read_json(dispatch_root / "mode.json", 16384)
    except (FileNotFoundError, fsio.RecordError, OSError):
        return "legacy"
    mode = record.get("mode")
    return mode if record.get("schema_version") == 1 and mode in {"worker", "suspended", "legacy"} else "legacy"


class Coordinator:
    def __init__(self, store: JobStore | None = None, *, systemd: Systemd | None = None,
                 mode_reader=read_mode, compat: CompatViews | None = None,
                 install_root: Path = INSTALL_ROOT, proc_root: Path = Path("/proc"),
                 clock=time.monotonic, sleep=time.sleep, poll: float = 10.0, now=utc_now) -> None:
        self.store = store or JobStore()
        self.systemd = systemd or Systemd()
        self.mode_reader = mode_reader
        self.compat = compat or CompatViews()
        self.install_root = Path(install_root)
        self.proc_root = Path(proc_root)
        self.clock = clock
        self.sleep = sleep
        self.poll = poll
        self.now = now

    def run(self) -> int:
        try:
            self.store.ensure()
            self.store.claim()
            for _ in range(3):
                self.reconcile()
                self.dispatch_next()
                remaining = self._grace_remaining()
                if remaining <= 0:
                    break
                # A dispatch intent without a started unit: wait out the grace
                # period here, because nothing else would wake us for it.
                self.sleep(remaining)
            self.store.prune()
        except fsio.RecordError as exc:
            print(f"Update queue state is unusable: {exc}", file=sys.stderr)
            return EXIT_CORRUPT
        return EXIT_OK

    def _grace_remaining(self) -> float:
        remaining = 0.0
        for state in self.store.active_states():
            dispatch = state.get("dispatch")
            if not dispatch or state.get("executor") or self.store.executor_alive(state["job_id"]):
                continue
            if self.systemd.show(dispatch["unit"]).get("ActiveState") in ACTIVE_UNIT_STATES:
                continue
            remaining = max(remaining, DISPATCH_GRACE_SECONDS - self._age(dispatch.get("intent_at")) + 1)
        return min(remaining, DISPATCH_GRACE_SECONDS + 1)

    # -- helpers -----------------------------------------------------------
    def _age(self, value: str | None) -> float:
        parsed = parse_time(value)
        return (self.now() - parsed).total_seconds() if parsed else float("inf")

    def _finish(self, job_id: str, **kwargs) -> dict:
        with self.store.lock():
            state = self.store.state(job_id)
            if self.store.receipt(job_id) is not None:
                return self.store.receipt(job_id)
            observations = {"running_version": running_version(self.install_root)}
            observations.update(kwargs.pop("observations", {}) or {})
            return self.store.finish(state, observations=observations, **kwargs)

    def _unit(self, state: dict) -> str:
        return UNIT_TEMPLATES[state["action"]].format(state["job_id"])

    def _executor_busy(self, state: dict) -> bool:
        if not state.get("dispatch"):
            return False
        if self.store.executor_alive(state["job_id"]):
            return True
        info = self.systemd.show(state["dispatch"]["unit"])
        if info.get("ActiveState") in ACTIVE_UNIT_STATES:
            return True
        return not state.get("executor") and self._age(state["dispatch"].get("intent_at")) < DISPATCH_GRACE_SECONDS

    # -- reconciliation ----------------------------------------------------
    def reconcile(self) -> None:
        for state in self.store.active_states():
            if not state.get("dispatch") or self._executor_busy(state):
                continue
            job_id = state["job_id"]
            info = self.systemd.show(state["dispatch"]["unit"])
            evidence = {"unit_result": info.get("Result", ""), "exec_main_status": info.get("ExecMainStatus", ""),
                        "unit_state": info.get("ActiveState", "")}
            if not state.get("executor"):
                # The executor records itself before doing anything: proven not started.
                if state["action"] == "check" and int(state.get("attempt", 0)) + 1 < CHECK_ATTEMPTS:
                    self._requeue(state)
                else:
                    self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="dispatch_failed",
                                 message="The update did not start. Try again.", observations=evidence)
                    self.compat.not_started(job_id, state.get("offer"), "The update did not start. Try again.")
                continue
            if state.get("apply_invoked_at"):
                message = (f"Shotdeck could not confirm whether the update finished. "
                           f"Version {running_version(self.install_root)} is running.")
                self._finish(job_id, terminal=INTERRUPTED, outcome="unknown", error_code="outcome_unknown",
                             message=message, observations=evidence)
                self.compat.unknown(job_id, state.get("apply_offer") or state.get("offer"), message)
                continue
            if state["action"] == "check" and int(state.get("attempt", 0)) + 1 < CHECK_ATTEMPTS:
                self._requeue(state)
                continue
            code = "check_interrupted" if state["action"] == "check" else "executor_interrupted"
            message = "The update operation was interrupted before installing. Try again."
            self._finish(job_id, terminal=FAILED, outcome="not_started" if state["action"] != "check" else "failed",
                         error_code=code, message=message, observations=evidence)
            if state["action"] != "check":
                self.compat.not_started(job_id, state.get("offer"), message)

    def _requeue(self, state: dict) -> None:
        with self.store.lock():
            current = self.store.state(state["job_id"])
            self.store.write_state({**current, "state": QUEUED, "dispatch": None, "executor": None,
                                    "attempt": int(current.get("attempt", 0)) + 1, "wait_reason": "",
                                    "phase_started_at": iso()})

    # -- dispatch ----------------------------------------------------------
    def dispatch_next(self) -> None:
        while True:
            if self.mode_reader() != "worker":
                return
            active = self.store.active_states()
            if any(self._executor_busy(state) for state in active):
                return  # One heavy task at a time; ExecStopPost wakes us again.
            queued = [state for state in active if not state.get("dispatch")]
            if not queued:
                return
            state = queued[0]
            job_id = state["job_id"]
            try:
                request = self.store.request(job_id)
            except (fsio.RecordError, ProtocolError, OSError):
                self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="internal_error",
                             message="The update request record is unreadable.")
                continue
            if self._age(request["created_at"]) > QUEUE_TTL_SECONDS[request["action"]]:
                self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="expired",
                             message="The update request expired before it could start. Try again.")
                continue
            if mutating(request) and self.store.mutation_barrier():
                message = "Shotdeck could not confirm an earlier update. Review it before installing again."
                self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="unknown_apply_pending",
                             message=message)
                continue
            decision = admit("check", proc_root=self.proc_root)
            if not decision.admitted:
                # Visible wait, then exit: the retry timer (or any new request,
                # executor wake-up or the hourly safety timer) runs us again.
                armed, detail = self.systemd.arm_retry()
                with self.store.lock():
                    current = self.store.state(job_id)
                    self.store.write_state({**current, "wait_reason": decision.reason,
                                            "admission": {**dict(current.get("admission") or {}),
                                                          "check": {**decision.evidence(), "at": iso()}},
                                            "retry": {"armed": armed, "at": iso(),
                                                      "detail": "" if armed else detail[-200:]}})
                if not armed:
                    print(f"Could not arm the update retry timer: {detail}", file=sys.stderr)
                return
            unit = self._unit(state)
            with self.store.lock():
                current = self.store.state(job_id)
                if self.store.receipt(job_id) is not None or current.get("dispatch"):
                    continue
                # Durable dispatch intent before the executor exists.
                self.store.write_state({**current, "wait_reason": "",
                                        "admission": {**dict(current.get("admission") or {}),
                                                      "check": {**decision.evidence(), "at": iso()}},
                                        "dispatch": {"unit": unit, "intent_at": iso(),
                                                     "attempt": int(current.get("attempt", 0)) + 1}})
            started, detail = self.systemd.start(unit)
            if not started:
                current = self.store.state(job_id)
                if not current.get("executor") and not self.store.executor_alive(job_id):
                    if self.mode_reader() != "worker":
                        # Suspended during admission: keep the request as queued evidence.
                        with self.store.lock():
                            self.store.write_state({**self.store.state(job_id), "dispatch": None})
                        return
                    self._finish(job_id, terminal=FAILED, outcome="not_started", error_code="dispatch_failed",
                                 message="The update could not be started. Try again.", detail=detail)
                    self.compat.not_started(job_id, current.get("offer"), "The update could not be started. Try again.")
                    continue
            return


def main(argv: list[str] | None = None) -> int:
    return Coordinator().run()


if __name__ == "__main__":
    raise SystemExit(main())
