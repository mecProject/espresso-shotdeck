"""Versioned update job request, state and receipt contract (schema 1).

Requests contain only fixed actions and bounded identifiers. They never carry
a command, executable, configuration path, URL or destination path. Install
requests bind the exact signed offer the user approved: channel, version,
artifact SHA-256 and manifest SHA-256.
"""

from __future__ import annotations

from datetime import datetime, timezone
import re
import uuid

from . import PROTOCOL_VERSION

MAX_REQUEST_BYTES = 4096
ACTIONS = ("check", "install", "scheduled")
SOURCES = ("touch", "web", "timer", "legacy-response", "operator")
CHANNELS = ("stable", "beta")

# Worker states. Only phases the installed runtime can actually report are
# used; the opaque protected ``apply`` command is reported as "installing".
QUEUED = "queued"
CHECKING = "checking"
WAITING_FOR_IDLE = "waiting-for-idle"
INSTALLING = "installing"
SUCCEEDED = "succeeded"
FAILED = "failed"
INTERRUPTED = "interrupted"
COALESCED = "coalesced"
STATES = (
    QUEUED, CHECKING, "available", WAITING_FOR_IDLE, "downloading", "verifying",
    INSTALLING, "health-checking", "rolling-back", SUCCEEDED, FAILED,
    INTERRUPTED, "recovery-required", COALESCED,
)
ACTIVE_STATES = frozenset({
    QUEUED, CHECKING, WAITING_FOR_IDLE, "downloading", "verifying", INSTALLING,
    "health-checking", "rolling-back",
})
TERMINAL_STATES = frozenset({SUCCEEDED, FAILED, INTERRUPTED, COALESCED, "recovery-required"})

# Receipt outcomes, separate from the request state.
OUTCOMES = (
    "available", "up_to_date", "unavailable", "installed", "skipped",
    "blocked", "not_started", "failed", "unknown", "coalesced",
)

# Stable error codes. User-facing text is derived from these by readers.
ERROR_CODES = frozenset({
    "updates_disabled", "auto_update_disabled", "read_only", "offer_changed",
    "offer_unavailable", "offer_incomplete", "brew_active", "app_not_ready",
    "maintenance_active", "licence_pending", "runtime_unavailable",
    "check_failed", "check_timeout", "check_interrupted", "apply_failed",
    "result_mismatch", "bad_output", "executor_interrupted", "outcome_unknown",
    "admission_timeout", "another_update_active", "unknown_apply_pending",
    "worker_suspended", "dispatch_failed", "expired", "internal_error",
    "apply_interrupted", "records_unreadable",
})

_JOB_ID = re.compile(r"^[0-9a-f]{32}$")
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_VERSION = re.compile(r"^[0-9A-Za-z][0-9A-Za-z.+-]{0,63}$")
_TIMESTAMP = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?\+00:00$")
OFFER_FIELDS = ("channel", "version", "artifact_sha256", "manifest_sha256")
REQUEST_FIELDS = frozenset({"schema_version", "job_id", "action", "source", "created_at", "offer"})


class ProtocolError(ValueError):
    """A request or record does not satisfy the job contract."""


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso(value: datetime | None = None) -> str:
    return (value or utc_now()).astimezone(timezone.utc).isoformat()


def parse_time(value: object) -> datetime | None:
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        return None
    return parsed.astimezone(timezone.utc)


def new_job_id() -> str:
    return uuid.uuid4().hex


def is_job_id(value: object) -> bool:
    return isinstance(value, str) and bool(_JOB_ID.fullmatch(value))


def validate_offer(value: object) -> dict:
    if not isinstance(value, dict) or set(value) != set(OFFER_FIELDS):
        raise ProtocolError("An offer must bind channel, version and both SHA-256 digests")
    if not _member(value["channel"], CHANNELS):
        raise ProtocolError("Unsupported update channel")
    if not isinstance(value["version"], str) or not _VERSION.fullmatch(value["version"]):
        raise ProtocolError("Invalid offered version")
    for key in ("artifact_sha256", "manifest_sha256"):
        if not isinstance(value[key], str) or not _SHA256.fullmatch(value[key]):
            raise ProtocolError("Offer digests must be lowercase SHA-256")
    return {key: value[key] for key in OFFER_FIELDS}


def offer_from_check(payload: object) -> dict | None:
    """Return the exact signed offer from a protected ``check`` result."""
    if not isinstance(payload, dict) or payload.get("applicable") is not True:
        return None
    candidate = {
        "channel": str(payload.get("channel") or "stable").strip().lower(),
        "version": str(payload.get("manifest_version") or "").strip(),
        "artifact_sha256": str(payload.get("artifact_sha256") or "").strip().lower(),
        "manifest_sha256": str(payload.get("manifest_sha256") or "").strip().lower(),
    }
    return validate_offer(candidate)


def offer_key(offer: dict) -> str:
    """Prompt key understood by older application and launcher versions."""
    return f"{offer['channel']}:{offer['version']}:{offer['artifact_sha256']}:{offer['manifest_sha256']}"


def validate_request(value: object) -> dict:
    if not isinstance(value, dict) or set(value) != REQUEST_FIELDS:
        raise ProtocolError("Update request has an unexpected shape")
    if type(value["schema_version"]) is not int or value["schema_version"] != PROTOCOL_VERSION:
        raise ProtocolError("Unsupported update request schema")
    if not is_job_id(value["job_id"]):
        raise ProtocolError("Invalid update job identifier")
    if not _member(value["action"], ACTIONS):
        raise ProtocolError("Unsupported update action")
    if not _member(value["source"], SOURCES):
        raise ProtocolError("Unsupported update request source")
    if not isinstance(value["created_at"], str) or not _TIMESTAMP.fullmatch(value["created_at"]):
        raise ProtocolError("Invalid update request time")
    if value["action"] == "install":
        offer = validate_offer(value["offer"])
    elif value["offer"] is not None:
        raise ProtocolError("Only an install request may bind an offer")
    else:
        offer = None
    if value["action"] == "scheduled" and value["source"] != "timer":
        raise ProtocolError("Only the scheduler may request a scheduled run")
    return {**value, "offer": offer}


def build_request(action: str, source: str, *, offer: dict | None = None,
                  job_id: str | None = None, created_at: datetime | None = None) -> dict:
    return validate_request({
        "schema_version": PROTOCOL_VERSION,
        "job_id": job_id or new_job_id(),
        "action": action,
        "source": source,
        "created_at": iso(created_at),
        "offer": offer,
    })


# -- transaction records (state and receipt) ---------------------------------
#
# The fixed dispatch gate keeps an independent copy of these rules (it must
# work when this generation is damaged); tests keep both classifications equal.
STATE_FIELDS = frozenset({
    "schema_version", "job_id", "action", "source", "created_at", "offer", "state", "attempt",
    "dispatch", "executor", "apply_offer", "apply_invoked_at", "wait_reason", "error_code", "message",
    "coalesced_into", "phase_timings",
})
RECEIPT_FIELDS = frozenset({
    "schema_version", "job_id", "action", "source", "created_at", "offer", "state", "outcome",
    "error_code", "message", "detail", "result", "observations", "coalesced_into", "completed_at",
    "phase_timings",
})
MUTATING_ACTIONS = frozenset({"install", "scheduled"})
_UNIT = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}@([0-9a-f]{32})\.service$")


def _timestamp(value: object) -> bool:
    return isinstance(value, str) and bool(_TIMESTAMP.fullmatch(value))


def _member(value: object, allowed) -> bool:
    """Membership that never raises on unhashable or foreign types."""
    return isinstance(value, str) and value in allowed


def _offer_or_none(value: object) -> dict | None:
    return None if value is None else validate_offer(value)


def _common(value: dict, job_id: str, kind: str) -> None:
    if type(value["schema_version"]) is not int or value["schema_version"] != PROTOCOL_VERSION:
        raise ProtocolError(f"Unsupported update {kind} schema")
    if not is_job_id(job_id) or value["job_id"] != job_id:
        raise ProtocolError(f"Update {kind} does not belong to its job")
    if not _member(value["action"], ACTIONS) or not _member(value["source"], SOURCES) or not _timestamp(
            value["created_at"]):
        raise ProtocolError(f"Update {kind} has an invalid request identity")
    if value["error_code"] != "" and not _member(value["error_code"], ERROR_CODES):
        raise ProtocolError(f"Update {kind} has an unknown error code")
    if not isinstance(value["message"], str) or not isinstance(value["phase_timings"], dict):
        raise ProtocolError(f"Update {kind} has invalid fields")
    coalesced = value["coalesced_into"]
    if coalesced is not None and (not is_job_id(coalesced) or coalesced == job_id):
        raise ProtocolError(f"Update {kind} names an invalid primary job")
    if not _member(value["state"], ACTIVE_STATES | TERMINAL_STATES):
        raise ProtocolError(f"Update {kind} is not in a known phase")
    if (value["state"] == COALESCED) != (coalesced is not None):
        raise ProtocolError(f"Update {kind} coalescing is inconsistent")


def validate_state(value: object, job_id: str) -> dict:
    """A job's mutable phase record, as the coordinator and executor write it."""
    if not isinstance(value, dict) or not STATE_FIELDS <= set(value):
        raise ProtocolError("Update job state lacks required fields")
    _common(value, job_id, "state")
    if type(value["attempt"]) is not int or value["attempt"] < 0:
        raise ProtocolError("Update job state has an invalid attempt counter")
    offer = _offer_or_none(value["offer"])
    if (value["action"] == "install") != (offer is not None):
        raise ProtocolError("Only an install job binds an offer")
    apply_offer = _offer_or_none(value["apply_offer"])
    if apply_offer is not None and (value["action"] not in MUTATING_ACTIONS
                                    or (value["action"] == "install" and apply_offer != offer)):
        raise ProtocolError("Update job state activates an offer it was not approved for")
    if value["apply_invoked_at"] is not None and (not _timestamp(value["apply_invoked_at"]) or apply_offer is None):
        raise ProtocolError("Update job state records activation without its offer")
    dispatch = value["dispatch"]
    if dispatch is not None:
        match = _UNIT.fullmatch(dispatch.get("unit", "")) if isinstance(dispatch, dict) and isinstance(
            dispatch.get("unit"), str) else None
        if (match is None or match.group(1) != job_id or not _timestamp(dispatch.get("intent_at"))
                or type(dispatch.get("attempt")) is not int):
            raise ProtocolError("Update job state has an invalid dispatch record")
    executor = value["executor"]
    if executor is not None and (not isinstance(executor, dict) or not _timestamp(executor.get("started_at"))):
        raise ProtocolError("Update job state has an invalid executor record")
    if not isinstance(value["wait_reason"], str):
        raise ProtocolError("Update job state has an invalid wait reason")
    return value


def validate_receipt(value: object, job_id: str) -> dict:
    """A job's immutable terminal receipt, exactly as ``JobStore.finish`` creates it."""
    if not isinstance(value, dict) or set(value) != RECEIPT_FIELDS:
        raise ProtocolError("Update receipt has an unexpected shape")
    _common(value, job_id, "receipt")
    if not _member(value["state"], TERMINAL_STATES) or not _member(value["outcome"], OUTCOMES):
        raise ProtocolError("Update receipt has an invalid result")
    offer = _offer_or_none(value["offer"])
    if not isinstance(value["detail"], str) or not isinstance(value["observations"], dict) or not (
            value["result"] is None or isinstance(value["result"], dict)) or not _timestamp(value["completed_at"]):
        raise ProtocolError("Update receipt has invalid fields")
    if (value["outcome"] == "coalesced") != (value["state"] == COALESCED):
        raise ProtocolError("Update receipt coalescing is inconsistent")
    if value["outcome"] in {"installed", "unknown"} and value["action"] not in MUTATING_ACTIONS:
        raise ProtocolError("Only an installation can have an activation outcome")
    if value["outcome"] == "installed" and (value["state"] != SUCCEEDED or offer is None):
        raise ProtocolError("An installation receipt must succeed with its exact offer")
    return value


def validate_job(job_id: str, request: dict | None, state: dict | None, receipt: dict | None) -> None:
    """Consistency between a job's (individually valid) request, state and receipt."""
    identity = lambda value: (value["action"], value["source"], value["created_at"])  # noqa: E731
    if request is not None and state is not None and (
            identity(request) != identity(state) or request["offer"] != state["offer"]):
        raise ProtocolError("Update job state differs from its request")
    if request is not None and receipt is not None and identity(request) != identity(receipt):
        raise ProtocolError("Update receipt differs from its request")
    if state is not None and receipt is not None:
        if identity(state) != identity(receipt) or receipt["offer"] != (state["apply_offer"] or state["offer"]):
            raise ProtocolError("Update receipt differs from its job state")
        if state["state"] in TERMINAL_STATES and (
                state["state"] != receipt["state"] or state["coalesced_into"] != receipt["coalesced_into"]):
            raise ProtocolError("Update job state and receipt disagree on the result")
    if state is not None and state["state"] in TERMINAL_STATES and receipt is None:
        raise ProtocolError("A terminal update job state has no receipt")
    if state is not None and request is None and not (state["state"] in TERMINAL_STATES and receipt is not None):
        raise ProtocolError("An unfinished update job has no accepted request")


def coalesce_key(request: dict) -> str:
    """Requests with equal keys describe the same operation."""
    if request["action"] == "install":
        return "install:" + request["offer"]["manifest_sha256"] + ":" + request["offer"]["artifact_sha256"]
    return request["action"]


def mutating(request: dict) -> bool:
    return request["action"] in {"install", "scheduled"}
