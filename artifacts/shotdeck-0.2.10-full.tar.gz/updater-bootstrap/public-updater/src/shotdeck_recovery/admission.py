"""Memory and pressure admission before heavy update phases (design 2).

Admission compares what can be used *now*, conservatively, with what a phase
will *additionally* need, and keeps a reserve for the application and system:

    effective = MemAvailable - (Dirty + Writeback)
    required  = RESERVE_MIB + DEMAND_MIB[phase] + OVERLAP_MIB[phase]
    admitted  = every required input readable, effective >= required, and
                memory and I/O pressure (PSI "some" avg10) below their limits

Points of admission and what is already resident there:

* ``check`` is admitted by the coordinator before it starts an executor. The
  coordinator's own memory is already allocated, so MemAvailable excludes it;
  it exits soon after dispatch. Nothing is added back.
* ``apply`` is admitted by the executor immediately before the protected
  ``apply`` command (before any mutation). The executor and whatever its
  pre-install check left resident are already excluded by MemAvailable.

Why each term:

* MemAvailable counts page cache as reclaimable, but dirty pages and pages
  under writeback cannot be dropped until they reach the card, so they are
  subtracted rather than treating all file cache as immediately reclaimable.
* ``DEMAND_MIB`` is the measured *additional* demand of a phase: the largest
  fall of ``effective`` from the admission point while complete phases ran on
  the qualified profile (anonymous growth of the executor and protected CLI
  plus cache that is dirtied or pinned). It is not the cgroup's total peak,
  which includes reclaimable cache and memory that was already resident.
* ``OVERLAP_MIB`` is explicit room for update processes outside the admitted
  executor that can run during the phase: the coordinator finishing after
  dispatch and the gate's ExecStopPost accounting (check), or a coordinator and
  wake-up unit started by another request while an installation runs (apply).
* ``RESERVE_MIB`` stays free for the application and the system. Provisional.

Swap growth is recorded with every decision for qualification but does not
admit anything: zram swap is RAM. Missing or unreadable inputs never admit;
they produce a visible wait reason (``memory_unknown``, ``pressure_unknown``).
Release A keeps the existing apply lifecycle: no hard cap or whole-install
timeout is added; admission only decides whether the mutation may begin.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

RESERVE_MIB = 64  # provisional during development
# Selection rule: the largest measured demand of complete phases on the
# workshop unit (Pi Zero 2 W, trixie, app running at steady state), plus 15 %,
# rounded up to a multiple of 8 MiB. Measured 15 November 2026 (worker
# generation 2): checks 25.0-39.6 MiB (six runs, cold and warm); installs
# 58.4 MiB (worker) and 62.8 MiB (retained updater, same protected installer),
# with dirty + writeback up to 22.5 MiB and zram swap growth up to 50 MiB.
DEMAND_MIB = {"check": 48, "apply": 80}
# Update processes that can run beside the phase, measured: a coordinator run
# including the gate's ExecStopPost hook peaks at 13.4 MiB; a control or wake
# unit is one short gate process. Check: the resident coordinator is already
# counted at admission; its exit hook or a control/wake unit can overlap.
# Apply: one coordinator run woken by another request or a timer, or a
# control/wake unit, can overlap the installation.
OVERLAP_MIB = {"check": 12, "apply": 16}
MEMORY_PRESSURE_LIMIT = 20.0  # PSI memory "some avg10" percent
IO_PRESSURE_LIMIT = 60.0  # PSI io "some avg10" percent
MEMINFO_FIELDS = ("MemTotal", "MemAvailable", "Dirty", "Writeback", "SwapTotal", "SwapFree")


def required_mib(kind: str) -> int:
    return RESERVE_MIB + DEMAND_MIB[kind] + OVERLAP_MIB[kind]


@dataclass(slots=True)
class Decision:
    admitted: bool
    reason: str = ""
    available_mib: int | None = None  # effective: MemAvailable - Dirty - Writeback
    required_mib: int = 0
    inputs: dict = field(default_factory=dict)

    def evidence(self) -> dict:
        """Bounded, sanitized admission record persisted with the job."""
        return {"admitted": self.admitted, "reason": self.reason, "effective_mib": self.available_mib,
                "required_mib": self.required_mib, **self.inputs}


def read_meminfo(path: Path) -> dict | None:
    """Selected /proc/meminfo fields in MiB, or ``None`` when any is unreadable."""
    values: dict[str, float] = {}
    try:
        with open(path, encoding="ascii") as stream:
            for line in stream:
                key, _, rest = line.partition(":")
                if key in MEMINFO_FIELDS:
                    parts = rest.split()
                    if len(parts) != 2 or parts[1] != "kB":
                        return None
                    values[key] = int(parts[0]) / 1024
    except (OSError, ValueError, UnicodeError):
        return None
    return values if set(values) == set(MEMINFO_FIELDS) else None


def read_pressure(path: Path) -> dict | None:
    """``{"some": avg10, "full": avg10}`` from a PSI file, or ``None``."""
    result: dict[str, float] = {}
    try:
        with open(path, encoding="ascii") as stream:
            for line in stream:
                kind, *fields = line.split()
                for item in fields:
                    key, _, value = item.partition("=")
                    if key == "avg10":
                        result[kind] = float(value)
    except (OSError, ValueError, UnicodeError):
        return None
    return result if "some" in result else None


def admit(kind: str, *, proc_root: Path = Path("/proc")) -> Decision:
    required = required_mib(kind)
    memory = read_meminfo(proc_root / "meminfo")
    if memory is None:
        return Decision(False, "memory_unknown", None, required)
    effective = int(memory["MemAvailable"] - memory["Dirty"] - memory["Writeback"])
    inputs = {
        "mem_available_mib": round(memory["MemAvailable"], 1), "dirty_mib": round(memory["Dirty"], 1),
        "writeback_mib": round(memory["Writeback"], 1),
        "swap_used_mib": round(memory["SwapTotal"] - memory["SwapFree"], 1),
        "reserve_mib": RESERVE_MIB, "demand_mib": DEMAND_MIB[kind], "overlap_mib": OVERLAP_MIB[kind],
    }
    memory_pressure = read_pressure(proc_root / "pressure/memory")
    io_pressure = read_pressure(proc_root / "pressure/io")
    if memory_pressure is None or io_pressure is None:
        return Decision(False, "pressure_unknown", effective, required, inputs)
    inputs.update(memory_some_avg10=memory_pressure["some"], io_some_avg10=io_pressure["some"])
    if effective < required:
        return Decision(False, "memory", effective, required, inputs)
    if memory_pressure["some"] > MEMORY_PRESSURE_LIMIT:
        return Decision(False, "memory_pressure", effective, required, inputs)
    if io_pressure["some"] > IO_PRESSURE_LIMIT:
        return Decision(False, "io_pressure", effective, required, inputs)
    return Decision(True, "", effective, required, inputs)
