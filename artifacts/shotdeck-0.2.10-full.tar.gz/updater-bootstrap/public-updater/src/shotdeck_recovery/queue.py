"""Durable typed job queue under the protected updater state directory.

Layout below ``/var/lib/shotdeck/updater/jobs``::

    incoming/<job>.json   requests written by touch, web, timer and adapters
    claimed/<job>.json    accepted requests, moved atomically from incoming
    state/<job>.json      mutable phase record owned by coordinator/executor
    receipts/<job>.json   terminal receipts, created once and never replaced
    rejected/, held/      bounded quarantine and suspended-mode evidence
    run/<job>.lock        held by a live executor for its whole lifetime
    offer.json            latest exact signed offer, separate from results

A path unit wakes the coordinator when ``incoming`` is not empty; the
directory is not the queue's source of truth once a request is claimed.
"""

from __future__ import annotations

from contextlib import contextmanager
import os
import time
from pathlib import Path
import re
from typing import Iterator

from . import PROTOCOL_VERSION, fsio
from .protocol import (
    ACTIVE_STATES, COALESCED, OUTCOMES, QUEUED, TERMINAL_STATES, ProtocolError,
    coalesce_key, iso, is_job_id, parse_time, validate_job, validate_offer, validate_receipt,
    validate_request, validate_state,
)

STATE_ROOT = Path("/var/lib/shotdeck/updater")
JOBS_ROOT = STATE_ROOT / "jobs"
DISPATCH_ROOT = STATE_ROOT / "dispatch"
INSTALL_ROOT = Path("/opt/shotdeck")
KEEP_TERMINAL_JOBS = 32
KEEP_QUARANTINE = 16
MAX_PENDING_JOBS = 64
_SAFE_NAME = re.compile(r"^[A-Za-z0-9._-]{1,96}$")


class QueueError(RuntimeError):
    """The queue cannot accept or process a request safely."""


def running_version(install_root: Path = INSTALL_ROOT) -> str:
    """Observation only; never evidence that an operation succeeded."""
    for path in (install_root / "current/.shotdeck-version", install_root / ".shotdeck-version"):
        try:
            with open(path, "rb") as stream:
                value = stream.read(129).decode("utf-8", "replace").strip()
        except OSError:
            continue
        if value and len(value) <= 128:
            return value
    return "unknown"


class JobStore:
    def __init__(self, root: Path = JOBS_ROOT, dispatch_root: Path = DISPATCH_ROOT) -> None:
        self.root = Path(root)
        self.dispatch_root = Path(dispatch_root)
        self.incoming = self.root / "incoming"
        self.claimed = self.root / "claimed"
        self.states = self.root / "state"
        self.receipts = self.root / "receipts"
        self.rejected = self.root / "rejected"
        self.held = self.root / "held"
        self.run = self.root / "run"
        # Temporary files for incoming requests: never inside the watched folder.
        self.staging = self.root / "staging"
        self.offer_path = self.root / "offer.json"
        self.lock_path = self.root / ".lock"
        self.acknowledged_dir = self.dispatch_root / "acknowledged"

    # -- setup -------------------------------------------------------------
    def ensure(self) -> None:
        for path in (self.root, self.incoming, self.claimed, self.states, self.receipts,
                     self.rejected, self.held, self.run):
            fsio.ensure_dir(path)

    @contextmanager
    def lock(self) -> Iterator[None]:
        fsio.ensure_dir(self.root)
        with fsio.flock(self.lock_path, timeout=60.0):
            yield

    # -- client side -------------------------------------------------------
    def submit(self, request: dict) -> str:
        """Durably accept one request. Replaying a job ID is the same request."""
        request = validate_request(request)
        data = fsio.encode(request)
        if len(data) > 4096:
            raise ProtocolError("Update request is too large")
        job_id = request["job_id"]
        for existing in (self.incoming / f"{job_id}.json", self.claimed / f"{job_id}.json"):
            try:
                if fsio.read_bytes(existing, 4096) == data:
                    return job_id
                raise QueueError("An update job identifier was reused for a different request")
            except FileNotFoundError:
                continue
        if self.receipt(job_id) is not None:
            return job_id
        fsio.ensure_dir(self.root)
        if not fsio.create_exclusive(self.incoming / f"{job_id}.json", data, staging=self.staging):
            if fsio.read_bytes(self.incoming / f"{job_id}.json", 4096) != data:
                raise QueueError("An update job identifier was reused for a different request")
        return job_id

    def known(self, job_id: str) -> bool:
        """True when this job ID was already accepted (in any queue stage)."""
        return any(os.path.lexists(folder / f"{job_id}.json")
                   for folder in (self.incoming, self.claimed, self.receipts))

    # -- records -----------------------------------------------------------
    def request(self, job_id: str) -> dict:
        value = validate_request(fsio.read_json(self.claimed / f"{job_id}.json", 4096))
        if value["job_id"] != job_id:
            raise fsio.RecordError("Update request does not belong to its job")
        return value

    def state(self, job_id: str) -> dict | None:
        value = fsio.read_json_optional(self.states / f"{job_id}.json")
        if value is None:
            return None
        try:
            return validate_state(value, job_id)
        except ProtocolError as exc:
            raise fsio.RecordError(str(exc)) from exc

    def write_state(self, state: dict) -> dict:
        state = {**state, "updated_at": iso()}
        try:
            validate_state(state, state.get("job_id"))
        except (ProtocolError, KeyError, TypeError) as exc:
            raise fsio.RecordError(f"Refusing to persist an invalid update job state: {exc}") from exc
        fsio.write_json(self.states / f"{state['job_id']}.json", state)
        return state

    def receipt(self, job_id: str) -> dict | None:
        value = fsio.read_json_optional(self.receipts / f"{job_id}.json")
        if value is None:
            return None
        try:
            return validate_receipt(value, job_id)
        except ProtocolError as exc:
            raise fsio.RecordError(str(exc)) from exc

    def finish(self, state: dict, *, terminal: str, outcome: str, error_code: str = "",
               message: str = "", detail: str = "", result: dict | None = None,
               observations: dict | None = None, coalesced_into: str | None = None) -> dict:
        """Create the immutable terminal receipt, then mark the state terminal.

        Callers publish success to any reader only after this returns.
        """
        if terminal not in TERMINAL_STATES or outcome not in OUTCOMES:
            raise fsio.RecordError("Invalid terminal update result")
        job_id = state["job_id"]
        existing = self.receipt(job_id)
        if existing is not None:
            return existing
        receipt = {
            "schema_version": PROTOCOL_VERSION,
            "job_id": job_id,
            "action": state["action"],
            "source": state["source"],
            "created_at": state["created_at"],
            "offer": state.get("apply_offer") or state.get("offer"),
            "state": terminal,
            "outcome": outcome,
            "error_code": error_code,
            "message": message[:400],
            "detail": detail[-800:],
            "result": result,
            "observations": observations or {},
            "coalesced_into": coalesced_into,
            "completed_at": iso(),
            "phase_timings": dict(state.get("phase_timings") or {}),
        }
        try:
            validate_receipt(receipt, job_id)
        except ProtocolError as exc:
            raise fsio.RecordError(f"Refusing to persist an invalid update receipt: {exc}") from exc
        if not fsio.create_exclusive(self.receipts / f"{job_id}.json", fsio.encode(receipt)):
            return self.receipt(job_id) or receipt
        self.write_state({**state, "state": terminal, "error_code": error_code,
                          "message": message[:400], "wait_reason": "",
                          "coalesced_into": coalesced_into})
        return receipt

    # -- claiming ----------------------------------------------------------
    def _quarantine(self, entry: Path, folder: Path) -> None:
        name = entry.name if _SAFE_NAME.fullmatch(entry.name) else "entry"
        target = folder / f"{iso().replace(':', '').replace('+', 'Z')}-{os.getpid()}-{name}"
        if not fsio.move_noreplace(entry, target):
            fsio.remove(entry)

    def hold_incoming(self) -> int:
        """Move unprocessed requests aside without parsing them (suspended mode)."""
        moved = 0
        fsio.ensure_dir(self.held)
        for name in sorted(os.listdir(self.incoming)) if self.incoming.is_dir() else []:
            self._quarantine(self.incoming / name, self.held)
            moved += 1
        self._prune_folder(self.held)
        return moved

    def claim(self) -> tuple[list[str], int]:
        """Claim every incoming request. Return (claimed IDs, rejected count)."""
        self.ensure()
        claimed: list[str] = []
        rejected = 0
        with self.lock():
            accepted = []
            for name in sorted(os.listdir(self.incoming))[:MAX_PENDING_JOBS * 4]:
                entry = self.incoming / name
                if fsio.in_progress(entry):
                    continue
                if not fsio.JOB_FILE.fullmatch(name):
                    self._quarantine(entry, self.rejected)
                    rejected += 1
                    continue
                job_id = name[:-5]
                try:
                    data = fsio.read_bytes(entry, 4096)
                    request = validate_request(fsio.read_json(entry, 4096))
                    if request["job_id"] != job_id:
                        raise ProtocolError("Request name differs from its job identifier")
                except FileNotFoundError:
                    continue
                except (fsio.RecordError, ProtocolError, OSError):
                    self._quarantine(entry, self.rejected)
                    rejected += 1
                    continue
                accepted.append((parse_time(request["created_at"]), job_id, entry, data, request))
            # First come, first served: the earliest request becomes the
            # operation that identical later requests join.
            for _, job_id, entry, data, request in sorted(accepted, key=lambda item: (item[0], item[1])):
                destination = self.claimed / entry.name
                if not fsio.move_noreplace(entry, destination):
                    # A replayed job ID is the same operation, never a second one.
                    try:
                        same = fsio.read_bytes(destination, 4096) == data
                    except (fsio.RecordError, OSError):
                        same = False
                    if same:
                        fsio.remove(entry)
                    else:
                        self._quarantine(entry, self.rejected)
                        rejected += 1
                    continue
                if self.state(job_id) is None and self.receipt(job_id) is None:
                    self._initial_state(request)
                claimed.append(job_id)
            claimed.extend(self._adopt_orphans())
            self._prune_folder(self.rejected)
        return claimed, rejected

    def _adopt_orphans(self) -> list[str]:
        """Give state to claimed requests whose claim was interrupted.

        A crash between the move into ``claimed/`` and the state write leaves a
        validated request with no state. It was never dispatched, so it is
        safely queued again (its TTL still runs from ``created_at``). An
        unreadable request is left in place for ``unreadable_records``.
        """
        orphans = []
        for job_id in fsio.job_files(self.claimed, limit=MAX_PENDING_JOBS * 4):
            if os.path.lexists(self.states / f"{job_id}.json") or os.path.lexists(self.receipts / f"{job_id}.json"):
                continue
            try:
                request = self.request(job_id)
            except (fsio.RecordError, ProtocolError, OSError):
                continue
            if request["job_id"] == job_id:
                orphans.append((parse_time(request["created_at"]), job_id, request))
        adopted = []
        for _, job_id, request in sorted(orphans, key=lambda item: (item[0], item[1])):
            self._initial_state(request)
            adopted.append(job_id)
        return adopted

    def _initial_state(self, request: dict) -> dict:
        state = {
            "schema_version": PROTOCOL_VERSION,
            "job_id": request["job_id"],
            "action": request["action"],
            "source": request["source"],
            "created_at": request["created_at"],
            "offer": request["offer"],
            "state": QUEUED,
            "claimed_at": iso(),
            "phase_started_at": iso(),
            "attempt": 0,
            "dispatch": None,
            "executor": None,
            "apply_offer": None,
            "apply_invoked_at": None,
            "wait_reason": "",
            "error_code": "",
            "message": "",
            "coalesced_into": None,
            "phase_timings": {},
        }
        primary = self._coalesce_target(request)
        state = self.write_state(state)
        if primary is not None:
            return self.finish(state, terminal=COALESCED, outcome="coalesced",
                               message="Joined an identical update operation already in progress.",
                               coalesced_into=primary)
        return state

    def _coalesce_target(self, request: dict) -> str | None:
        key = coalesce_key(request)
        for state in self.active_states():
            if state["job_id"] == request["job_id"]:
                continue
            try:
                other = self.request(state["job_id"])
            except (fsio.RecordError, ProtocolError, OSError):
                continue
            if coalesce_key(other) == key:
                return state["job_id"]
        return None

    # -- queries -----------------------------------------------------------
    def job_ids(self) -> list[str]:
        return fsio.job_files(self.states)

    def all_states(self) -> list[dict]:
        result = []
        for job_id in self.job_ids():
            try:
                state = self.state(job_id)
            except (fsio.RecordError, OSError):
                continue
            if state is not None:
                result.append(state)
        result.sort(key=lambda item: (parse_time(item.get("created_at")) or parse_time("1970-01-01T00:00:00+00:00"),
                                      item["job_id"]))
        return result

    def active_states(self) -> list[dict]:
        return [state for state in self.all_states()
                if state.get("state") in ACTIVE_STATES and not (self.receipts / f"{state['job_id']}.json").exists()]

    def pending_requests(self) -> list[dict]:
        """Accepted requests not yet claimed by the coordinator (read-only)."""
        result = []
        for job_id in fsio.job_files(self.incoming, limit=MAX_PENDING_JOBS):
            try:
                request = validate_request(fsio.read_json(self.incoming / f"{job_id}.json", 4096))
            except (FileNotFoundError, fsio.RecordError, ProtocolError, OSError):
                continue
            if request["job_id"] == job_id:
                result.append(request)
        result.sort(key=lambda item: (parse_time(item["created_at"]), item["job_id"]))
        return result

    def offer(self) -> dict | None:
        try:
            value = fsio.read_json_optional(self.offer_path)
        except (fsio.RecordError, OSError):
            return None
        if value is None:
            return None
        try:
            offer = validate_offer({key: value.get(key) for key in ("channel", "version", "artifact_sha256", "manifest_sha256")})
        except ProtocolError:
            return None
        return {**value, **offer}

    def set_offer(self, offer: dict, *, job_id: str) -> None:
        fsio.write_json(self.offer_path, {**validate_offer(offer), "schema_version": PROTOCOL_VERSION,
                                          "checked_at": iso(), "job_id": job_id}, mode=0o644)

    def clear_offer(self, *, matching: dict | None = None) -> None:
        current = self.offer()
        if current is None:
            return
        if matching is not None and any(current.get(key) != matching.get(key)
                                        for key in ("channel", "version", "artifact_sha256", "manifest_sha256")):
            return
        fsio.remove(self.offer_path)

    # -- executor liveness -------------------------------------------------
    def executor_lock(self, job_id: str) -> Path:
        return self.run / f"{job_id}.lock"

    @contextmanager
    def hold_executor(self, job_id: str) -> Iterator[None]:
        with fsio.flock(self.executor_lock(job_id), timeout=10.0):
            yield

    def executor_alive(self, job_id: str) -> bool:
        """True only while an executor process holds this job's lock."""
        path = self.executor_lock(job_id)
        if not path.exists():
            return False
        try:
            with fsio.flock(path, shared=True, blocking=False) as acquired:
                return not acquired
        except (fsio.RecordError, OSError):
            return False

    # -- acknowledgement and reconciliation ----------------------------------
    def acknowledged(self, job_id: str) -> bool:
        try:
            value = fsio.read_json_optional(self.acknowledged_dir / f"{job_id}.json", 4096)
        except (fsio.RecordError, OSError):
            return False
        return bool(value) and value.get("job_id") == job_id

    def record_job_ids(self) -> list[str]:
        return sorted(set(fsio.job_files(self.states)) | set(fsio.job_files(self.receipts))
                      | set(fsio.job_files(self.claimed)))

    def records(self, job_id: str) -> tuple[dict | None, dict | None, dict | None]:
        """A job's trusted (request, state, receipt); ``RecordError`` when untrustworthy.

        Each record must satisfy the job contract on its own (schema, identity,
        required fields, allowed phases and outcomes), and together they must
        agree: same request identity and offer, a receipt for every terminal
        state, and an accepted request for every unfinished job.
        """
        request = self.request(job_id) if os.path.lexists(self.claimed / f"{job_id}.json") else None
        state, receipt = self.state(job_id), self.receipt(job_id)
        try:
            validate_job(job_id, request, state, receipt)
        except ProtocolError as exc:
            raise fsio.RecordError(str(exc)) from exc
        return request, state, receipt

    def unresolved_unknown(self) -> list[str]:
        """Jobs whose activation outcome is unknown and not yet acknowledged."""
        result = []
        for job_id in fsio.job_files(self.receipts):
            if self.acknowledged(job_id):
                continue
            try:
                _, _, receipt = self.records(job_id)
            except (fsio.RecordError, ProtocolError, OSError):
                continue  # Untrustworthy: reported by unreadable_records.
            if receipt and receipt.get("outcome") == "unknown":
                result.append(job_id)
        return result

    def unreadable_records(self) -> list[str]:
        """Jobs whose transaction records cannot be trusted, not yet reviewed.

        Untrustworthy records (see ``records``) are evidence of an unknown
        transaction: they are never removed and they block new installations
        until acknowledged. The fixed gate applies the same rules on its own.
        """
        problems = []
        for job_id in self.record_job_ids():
            if self.acknowledged(job_id):
                continue
            try:
                self.records(job_id)
            except (fsio.RecordError, ProtocolError, OSError):
                problems.append(job_id)
        return problems

    def mutation_barrier(self) -> list[str]:
        """Everything that must be reviewed before another installation."""
        return sorted(set(self.unresolved_unknown()) | set(self.unreadable_records()))

    # -- retention ---------------------------------------------------------
    def _prune_folder(self, folder: Path) -> None:
        try:
            names = sorted(os.listdir(folder))
        except FileNotFoundError:
            return
        for name in names[:-KEEP_QUARANTINE] if len(names) > KEEP_QUARANTINE else []:
            fsio.remove(folder / name)

    def prune(self) -> None:
        with self.lock():
            states = self.all_states()
            terminal = [state for state in states if state.get("state") in TERMINAL_STATES
                        and (self.receipts / f"{state['job_id']}.json").exists()]
            protected = set(self.mutation_barrier())
            for state in terminal[:-KEEP_TERMINAL_JOBS] if len(terminal) > KEEP_TERMINAL_JOBS else []:
                job_id = state["job_id"]
                if job_id in protected:
                    continue
                for path in (self.claimed / f"{job_id}.json", self.states / f"{job_id}.json",
                             self.receipts / f"{job_id}.json", self.executor_lock(job_id)):
                    fsio.remove(path)
            # Abandoned temporary files of interrupted submissions.
            for name in os.listdir(self.staging) if self.staging.is_dir() else []:
                entry = self.staging / name
                try:
                    if time.time() - os.lstat(entry).st_mtime > 3600:
                        fsio.remove(entry)
                except FileNotFoundError:
                    continue
            # Remove orphaned lock files of finished jobs.
            live = set(self.job_ids())  # Includes unreadable states: never drop a live lock.
            for name in os.listdir(self.run) if self.run.is_dir() else []:
                if name.endswith(".lock") and name[:-5] not in live:
                    fsio.remove(self.run / name)
