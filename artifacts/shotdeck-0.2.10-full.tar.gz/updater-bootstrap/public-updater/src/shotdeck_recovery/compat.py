"""Compatibility views of worker results for older application versions.

Older applications read ``update-status.json`` (offer prompt),
``update-web-state.json`` (paired web UI) and ``update-feedback.json`` (touch
completion screen). The worker's receipts remain authoritative; these files
are derived observations, written only after the authoritative record. A
failure to write a view never changes an operation's outcome.
"""

from __future__ import annotations

import json
from pathlib import Path
import sys

from . import fsio
from .protocol import iso, offer_key

DATA_ROOT = Path("/var/lib/shotdeck")


class CompatViews:
    def __init__(self, data_root: Path = DATA_ROOT) -> None:
        self.data_root = Path(data_root)
        self.status_path = self.data_root / "update-status.json"
        self.response_path = self.data_root / "update-response.json"
        self.web_state_path = self.data_root / "update-web-state.json"
        self.feedback_path = self.data_root / "update-feedback.json"

    # -- helpers -----------------------------------------------------------
    def _read(self, path: Path) -> dict:
        try:
            value = fsio.read_json(path)
        except (FileNotFoundError, fsio.RecordError, OSError):
            return {}
        return value

    def _write(self, path: Path, payload: dict) -> None:
        try:
            fsio.write_atomic(path, (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode(), mode=0o644)
        except (fsio.RecordError, OSError) as exc:
            print(f"Could not publish update view {path.name}: {exc}", file=sys.stderr)

    def _remove(self, path: Path) -> None:
        try:
            fsio.remove(path)
        except OSError as exc:
            print(f"Could not remove update view {path.name}: {exc}", file=sys.stderr)

    def _web(self, **changes) -> None:
        payload = self._read(self.web_state_path)
        payload.update(changes)
        payload["updated_at"] = iso()
        self._write(self.web_state_path, payload)

    def _feedback(self, job_id: str, state: str, version: str) -> None:
        payload = self._read(self.feedback_path)
        if payload.get("id") != job_id:
            payload = {"id": job_id, "version": version, "started_at": iso()}
        payload.update(state=state, version=version, job_id=job_id)
        if state == "installed":
            payload.setdefault("completed_at", iso())
        self._write(self.feedback_path, payload)

    def clear_prompts(self) -> None:
        self._remove(self.status_path)
        self._remove(self.response_path)

    def updates_disabled(self) -> None:
        self.clear_prompts()
        self._web(state="unavailable", target_version="", message="Updates are disabled.",
                  busy=False, update_available=False, error="")

    # -- check results -----------------------------------------------------
    def offer(self, offer: dict) -> None:
        previous = self._read(self.status_path)
        key = offer_key(offer)
        status = {
            "update_available": True,
            "target_version": offer["version"],
            "channel": offer["channel"],
            "summary": f"Update {offer['version']} available. Install now?",
            "key": key,
            "artifact_sha256": offer["artifact_sha256"],
            "manifest_sha256": offer["manifest_sha256"],
        }
        if previous.get("key") == key:
            # Keep release notes another component cached for this exact offer.
            status = {**previous, **status}
        self._write(self.status_path, status)
        if previous and previous.get("key") != key:
            self._remove(self.response_path)
        self._web(state="available", target_version=offer["version"], channel=offer["channel"],
                  message=f"Version {offer['version']} is available.", checked_at=iso(),
                  busy=False, update_available=True, error="",
                  manifest_sha256=offer["manifest_sha256"])

    def no_offer(self, *, up_to_date: bool, version: str, channel: str) -> None:
        self.clear_prompts()
        self._web(state="up_to_date" if up_to_date else "unavailable", target_version=version,
                  channel=channel, checked_at=iso(), busy=False, update_available=False, error="",
                  message="Software is up to date." if up_to_date else "No update is available for this device.")

    def error(self, message: str) -> None:
        self._web(state="error", message=message, error=message, busy=False)

    def skipped(self, version: str, channel: str) -> None:
        self.clear_prompts()
        self._web(state="unavailable", target_version=version, channel=channel,
                  message=f"Update {version} was skipped.", busy=False, update_available=False, error="")

    # -- activation results ------------------------------------------------
    def installing(self, job_id: str, offer: dict) -> None:
        self._feedback(job_id, "installing", offer["version"])
        self._web(state="installing", target_version=offer["version"], channel=offer["channel"],
                  message=f"Installing version {offer['version']}. The page may disconnect while Shotdeck restarts.",
                  busy=True, update_available=False, error="", started_at=iso(), job_id=job_id)

    def installed(self, job_id: str, offer: dict) -> None:
        self._feedback(job_id, "installed", offer["version"])
        self._remove(self.status_path)
        self._web(state="installed", current_version=offer["version"], target_version=offer["version"],
                  message=f"Updated to version {offer['version']}.", busy=False, update_available=False,
                  error="", completed_at=iso(), job_id=job_id)

    def failed(self, job_id: str, offer: dict, message: str) -> None:
        self._feedback(job_id, "error", offer["version"])
        self._web(state="error", target_version=offer["version"], message=message, busy=False,
                  error=message, update_available=self.status_path.exists(), job_id=job_id)

    def unknown(self, job_id: str, offer: dict | None, message: str) -> None:
        version = offer["version"] if offer else ""
        # Older readers ignore this state; they never show a guessed result.
        self._feedback(job_id, "unknown", version)
        self._web(state="outcome_unknown", target_version=version, message=message, busy=False,
                  error=message, update_available=False, job_id=job_id)

    def not_started(self, job_id: str, offer: dict | None, message: str) -> None:
        version = offer["version"] if offer else ""
        self._web(state="error", target_version=version, message=message, busy=False, error=message,
                  update_available=self.status_path.exists(), job_id=job_id)
        current = self._read(self.feedback_path)
        if current.get("id") == job_id and current.get("state") == "installing":
            self._feedback(job_id, "error", version)
