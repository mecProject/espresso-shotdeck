"""Independent Shotdeck update worker (Release A).

This package runs with the system Python outside the policy-pinned updater
runtime and outside the application. It must never import the application
(``lib``), its web server, live stores or display process, and it uses only the
standard library. The application may import :mod:`protocol`, :mod:`queue` and
:mod:`status` from its own bundled copy to write requests and read results.

The package is delivered as a versioned support generation under
``/opt/shotdeck/support-releases`` by the fixed dispatch gate. Increase
``SUPPORT_REVISION`` for every change to any file in this package; the gate
refuses a changed generation that reuses a revision and never selects an older
revision than the recorded high-water mark.
"""

PROTOCOL_VERSION = 1
SUPPORT_REVISION = 5
CAPABILITIES = (
    "jobs-v1",
    "check",
    "install",
    "scheduled",
    "legacy-response",
    "compat-views",
)
