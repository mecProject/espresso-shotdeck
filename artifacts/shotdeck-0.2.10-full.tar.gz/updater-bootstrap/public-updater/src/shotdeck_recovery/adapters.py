"""Turn scheduled runs and validated legacy prompt responses into queue jobs.

Older applications and the touch prompt overlay still write
``update-response.json``. A response is accepted only when its key matches the
current prompt, which binds the exact signed offer. A replayed response maps
to the same job identifier and therefore the same operation.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

from . import fsio
from .compat import CompatViews
from .protocol import ProtocolError, build_request, validate_offer
from .queue import JobStore


def _read_plain(path: Path) -> dict | None:
    try:
        value = fsio.read_json(path, 256 * 1024)
    except FileNotFoundError:
        return None
    except (fsio.RecordError, OSError):
        return {}
    return value


def enqueue_scheduled(store: JobStore) -> str:
    return store.submit(build_request("scheduled", "timer"))


def adapt_response(store: JobStore, compat: CompatViews) -> str | None:
    """Return the accepted install job ID, or ``None`` when nothing is queued."""
    status = _read_plain(compat.status_path)
    response = _read_plain(compat.response_path)
    if response is None:
        return None
    try:
        status_key = str((status or {}).get("key") or "").strip()
        if not status or not status_key or str(response.get("key") or "").strip() != status_key:
            return None
        action = str(response.get("action") or "").strip().lower()
        if action == "skip":
            compat.skipped(str(status.get("target_version") or ""), str(status.get("channel") or "stable"))
            return None
        if action != "install":
            return None
        try:
            offer = validate_offer({
                "channel": str(status.get("channel") or "stable").strip().lower(),
                "version": str(status.get("target_version") or "").strip(),
                "artifact_sha256": str(status.get("artifact_sha256") or "").strip().lower(),
                "manifest_sha256": str(status.get("manifest_sha256") or "").strip().lower(),
            })
        except ProtocolError:
            message = "The update prompt is incomplete. Check for updates again."
            compat.error(message)
            return None
        identity = json.dumps({"key": status_key, "confirmed_at": str(response.get("confirmed_at") or "")},
                              sort_keys=True).encode()
        job_id = hashlib.sha256(identity).hexdigest()[:32]
        if store.known(job_id):
            return job_id  # A replayed response is the same operation.
        return store.submit(build_request("install", "legacy-response", offer=offer, job_id=job_id))
    finally:
        # The legacy launcher consumes the response in every branch; a left-over
        # file would re-trigger the path unit indefinitely.
        try:
            fsio.remove(compat.response_path)
        except OSError:
            pass


def main(argv: list[str] | None = None) -> int:
    args = list(sys.argv[1:] if argv is None else argv)
    store = JobStore()
    store.ensure()
    if args == ["scheduled"]:
        print(enqueue_scheduled(store))
        return 0
    if args == ["response"]:
        job_id = adapt_response(store, CompatViews())
        if job_id:
            print(job_id)
        return 0
    print("usage: adapters scheduled|response", file=sys.stderr)
    return 64


if __name__ == "__main__":
    raise SystemExit(main())
