"""Compatibility probe run by the dispatch gate before enabling a generation."""

from __future__ import annotations

import json
import sys


def main(argv: list[str] | None = None) -> int:
    from . import CAPABILITIES, PROTOCOL_VERSION, SUPPORT_REVISION
    # Import every entry point so a missing or broken module fails here, not
    # during a customer's update.
    from . import adapters, admission, compat, executor, fsio, protocol, queue, runtime, status, worker  # noqa: F401
    print(json.dumps({
        "protocol": PROTOCOL_VERSION,
        "revision": SUPPORT_REVISION,
        "capabilities": list(CAPABILITIES),
        "python": list(sys.version_info[:3]),
    }, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
