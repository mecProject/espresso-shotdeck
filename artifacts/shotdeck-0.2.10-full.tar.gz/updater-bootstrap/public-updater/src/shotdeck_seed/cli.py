"""Fixed seed operations used by the protected local gateway and boot services."""
from __future__ import annotations

import argparse
import json

from .authority import read_authority, verify_runtime
from .client import SupportClient
from .lifecycle import SeedManager
from .storage import SeedError, SeedPaths
from .support import SupportManager


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    command = parser.add_subparsers(dest="action", required=True)
    command.add_parser("status")
    command.add_parser("reconcile")
    check = command.add_parser("support-check"); check.add_argument("--channel", choices=("stable", "beta"), default="stable")
    # Repair executes only through the root gateway's durable typed jobs. This
    # diagnostic CLI accepts no arbitrary path/URL or unjournaled mutation.
    args = parser.parse_args(argv)
    paths = SeedPaths(); manager = SupportManager(paths)
    try:
        if args.action == "status":
            result = {"seed": SeedManager(paths).status(), "support": manager.status()}
            authority = read_authority(paths)
            result["authority"] = {"generation": authority["generation"], "authority_id": authority["authority_id"]}
            try:
                verify_runtime(paths, authority=authority); result["updater"] = {"intact": True}
            except (OSError, SeedError) as exc:
                result["updater"] = {"intact": False, "reason": str(exc), "helper_repair_cannot_restore_runtime": True}
        elif args.action == "reconcile":
            result = {"seed": SeedManager(paths).reconcile(), "support": manager.reconcile()}
        elif args.action == "support-check":
            result = SupportClient(paths, manager=manager).check(args.channel)
            result.pop("document", None)
        print(json.dumps(result, sort_keys=True)); return 0
    except (OSError, ValueError, SeedError) as exc:
        print(json.dumps({"error": str(exc), "support_route_required": True}, sort_keys=True)); return 75


if __name__ == "__main__": raise SystemExit(main())
