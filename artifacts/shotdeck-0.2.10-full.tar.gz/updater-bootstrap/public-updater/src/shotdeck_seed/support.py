"""Journaled independent helper replacement; never signal an app or executor."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import gzip
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tarfile
import tempfile

from .authority import installed_cohort, read_authority
from .manifest import ENTRYPOINTS, ENABLE_UNITS, MAX_ARCHIVE, MAX_CONTENT, MAX_FILE, MAX_FILES, SCRIPT_NAMES, UNIT_NAMES, validate_manifest, worker_contract
from .storage import (SeedError, SeedPaths, atomic, canonical, claim_maintenance, digest, ensure, envelope, integer, maintenance,
                      protected_directory, read, read_json, replace_link, selected_path, sha, sync_directory, write_envelope, write_json)
from .storage import release_maintenance, isolated_probe, bounded_paths, runtime_directory

SUPPORT_NAME = r"c[1-9][0-9]{0,5}-[0-9a-f]{12}"
LEGACY_BRIDGE_BASE = 10000


def timestamp(): return datetime.now(timezone.utc).isoformat()


class BoundedExpansion:
    def __init__(self, stream, maximum): self.stream = stream; self.remaining = maximum
    def read(self, size=-1):
        if size < 0 or size > self.remaining: raise SeedError("Archive expansion exceeds its bounded format")
        raw = self.stream.read(size); self.remaining -= len(raw)
        return raw


def hash_stream(stream):
    checksum = hashlib.sha256(); size = 0
    for block in iter(lambda: stream.read(1024 * 1024), b""):
        size += len(block); checksum.update(block)
    return size, checksum.hexdigest()


def file_identity(path, maximum=384 * 1024 * 1024):
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    with os.fdopen(descriptor, "rb") as stream:
        info = os.fstat(stream.fileno())
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.geteuid()
                or info.st_mode & 0o022 or info.st_size > maximum):
            raise SeedError("Unsupported immutable file")
        size, checksum = hash_stream(stream)
    return {"sha256": checksum, "size": size, "mode": stat.S_IMODE(info.st_mode)}


class SupportManager:
    def __init__(self, paths=SeedPaths(), *, cohort=None, checkpoint=lambda phase: None, runner=subprocess.run):
        self.paths = paths
        self.cohort = cohort
        self.checkpoint = checkpoint
        self.runner = runner
        self.root = paths.support_state
        self.journal = self.root / "pending.json"
        self.high_water = self.root / "high-water.json"
        self.accepted = self.root / "accepted.json"
        self.enrolled = self.root / "enrolled.json"

    def _authority(self): return read_authority(self.paths)
    def _cohort(self): return self.cohort or installed_cohort()

    def verify_offer(self, document, cohort=None):
        return validate_manifest(document, self._authority(), cohort or self._cohort())

    def _history(self):
        initial = None
        if os.path.lexists(self.journal):
            pending = self._read_journal()
            if pending["initial"] and pending["phase"] == "prepared" and pending["previous"] is None:
                initial = pending
        if not os.path.lexists(self.enrolled) and initial is None:
            if any(os.path.lexists(path) for path in (self.high_water, self.accepted, self.journal)):
                raise SeedError("Support enrollment is missing beside protected records")
            return {"schema_version": 1, "revision": 0, "revisions": {}}
        if os.path.lexists(self.enrolled) and read_json(self.enrolled) != {"schema_version": 1}: raise SeedError("Invalid support enrollment")
        if not os.path.lexists(self.high_water) and initial is not None:
            return {"schema_version": 1, "revision": 0, "revisions": {}}
        history = read_json(self.high_water)
        if set(history) != {"schema_version", "revision", "revisions"} or type(history["schema_version"]) is not int or history["schema_version"] != 1:
            raise SeedError("Support high-water state is corrupt")
        integer(history["revision"], 0)
        if not isinstance(history["revisions"], dict) or len(history["revisions"]) > 4096:
            raise SeedError("Support history exceeds bound")
        for revision, identity in history["revisions"].items():
            if not re.fullmatch(r"[1-9][0-9]{0,5}", revision) or int(revision) > history["revision"]:
                raise SeedError("Support revision history is invalid")
            sha(identity)
        if history["revision"] and str(history["revision"]) not in history["revisions"]:
            raise SeedError("Support high-water receipt is missing")
        return history

    def _accepted(self):
        if not os.path.lexists(self.accepted):
            if os.path.lexists(self.enrolled) and not os.path.lexists(self.journal):
                raise SeedError("Support acceptance receipt is missing after enrollment")
            return {"schema_version": 1, "selected": None, "previous": None}
        value = read_json(self.accepted)
        if set(value) != {"schema_version", "selected", "previous"} or type(value["schema_version"]) is not int or value["schema_version"] != 1:
            raise SeedError("Support acceptance receipt is corrupt")
        for key in ("selected", "previous"):
            row = value[key]
            if row is not None and (not isinstance(row, dict) or set(row) != {"name", "manifest_sha256", "revision"}
                    or not isinstance(row["name"], str) or not re.fullmatch(SUPPORT_NAME, row["name"])
                    or row["name"] != self._name(integer(row["revision"]), sha(row["manifest_sha256"]))):
                raise SeedError("Invalid retained support identity")
        return value

    @staticmethod
    def _name(revision, identity): return f"c{revision}-{identity[:12]}"

    def _verify_tree(self, directory, document=None):
        directory = protected_directory(directory)
        if directory.stat().st_mode & 0o555 != 0o555:
            raise SeedError("Public support container is not readable and searchable")
        document = document or read_json(directory / "SUPPORT.json")
        payload = self.verify_offer(document)
        identity = digest(canonical(document))
        if directory.name != self._name(payload["revision"], identity): raise SeedError("Support tree name differs from its signed identity")
        observed = {}
        for path in bounded_paths(directory, MAX_FILES * 4):
            info = path.lstat(); relative = path.relative_to(directory).as_posix()
            if info.st_uid != os.geteuid() or info.st_mode & 0o022: raise SeedError("Support ownership changed")
            if stat.S_ISDIR(info.st_mode):
                if info.st_mode & 0o555 != 0o555:
                    raise SeedError("Public support container is not readable and searchable")
                continue
            if not stat.S_ISREG(info.st_mode): raise SeedError("Support tree contains an alias or special file")
            if relative == "SUPPORT.json": continue
            if relative not in payload["files"]: raise SeedError("Support tree contains an unsigned file")
            observed[relative] = file_identity(path, MAX_FILE)
        if observed != payload["files"]: raise SeedError("Support tree differs from its exact signed inventory")
        contract = worker_contract(read(directory / "shotdeck_recovery/__init__.py", MAX_FILE))
        if not payload["worker_protocol"]["minimum"] <= contract["PROTOCOL_VERSION"] <= payload["worker_protocol"]["maximum"]:
            raise SeedError("Installed worker protocol differs from signed support declaration")
        worker_hash = hashlib.sha256()
        for name in sorted(payload["files"]):
            if name.startswith("shotdeck_recovery/"):
                raw = read(directory / name, MAX_FILE)
                worker_hash.update(Path(name).name.encode() + b"\0" + len(raw).to_bytes(8, "big") + raw)
        return {"path": directory, "manifest_sha256": identity, "revision": payload["revision"],
                "worker_revision": contract["SUPPORT_REVISION"], "worker_protocol": contract["PROTOCOL_VERSION"],
                "worker_digest": worker_hash.hexdigest(), "manifest": document, "payload": payload}

    def selected_generation(self):
        self._history()
        if os.path.lexists(self.journal): raise SeedError("Support activation must reconcile before helper execution")
        accepted = self._accepted(); current = accepted["selected"]
        if current is None: raise SeedError("No complete C support generation is accepted")
        directory = selected_path(self.paths.support_current, self.paths.support_releases, SUPPORT_NAME)
        if directory is None or directory.name != current["name"]: raise SeedError("Support selector differs from durable acceptance")
        value = self._verify_tree(directory)
        if value["manifest_sha256"] != current["manifest_sha256"]: raise SeedError("Support receipt differs from the selected generation")
        return value

    def select_entry(self, component):
        if component not in ENTRYPOINTS: raise SeedError("Unknown fixed support component")
        selected = self.selected_generation()
        return selected["path"], ENTRYPOINTS[component]

    def stage(self, document, archive_path):
        """Validate everything before selecting files; staging cannot execute code."""
        with maintenance(self.paths, "support"):
            ensure(self.root)
            runtime_directory(self.paths.install)
            runtime_directory(self.paths.support_releases, listable=True)
            if os.path.lexists(self.journal): raise SeedError("Existing support activation must reconcile first")
            payload = self.verify_offer(document); identity = digest(canonical(document)); history = self._history()
            previous = history["revisions"].get(str(payload["revision"]))
            if payload["revision"] < history["revision"] or (previous is not None and previous != identity):
                raise SeedError("Support rollback or same-revision changed content refused")
            final = self.paths.support_releases / self._name(payload["revision"], identity)
            if os.path.lexists(final):
                self._verify_tree(final, document)
                return identity
            descriptor = os.open(archive_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            stage = None
            try:
                with os.fdopen(descriptor, "rb") as stream:
                    info = os.fstat(stream.fileno())
                    if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > MAX_ARCHIVE:
                        raise SeedError("Support archive must be a bounded regular file")
                    size, checksum = hash_stream(stream)
                    if size != payload["archive"]["size"] or checksum != payload["archive"]["sha256"]:
                        raise SeedError("Support archive differs from signed offer")
                    stream.seek(0)
                    stage = Path(tempfile.mkdtemp(prefix=".stage-c-", dir=self.paths.support_releases))
                    seen = set(); total = 0
                    uncompressed = gzip.GzipFile(fileobj=stream, mode="rb")
                    bounded = BoundedExpansion(uncompressed, MAX_CONTENT + MAX_FILES * 2048 + 65536)
                    with uncompressed, tarfile.open(fileobj=bounded, mode="r|") as archive:
                        for member in archive:
                            if (not member.isfile() or member.pax_headers or member.sparse or member.name in seen
                                    or member.name not in payload["files"]):
                                raise SeedError("Archive has links, directories, duplicates or unsigned members")
                            row = payload["files"][member.name]; seen.add(member.name); total += member.size
                            if member.size != row["size"] or total > MAX_CONTENT or member.mode != row["mode"]:
                                raise SeedError("Archive member differs from signed size/mode")
                            destination = stage / member.name; runtime_directory(destination.parent, listable=True)
                            source = archive.extractfile(member)
                            if source is None: raise SeedError("Missing archive member data")
                            fd = os.open(destination, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, row["mode"])
                            checksum = hashlib.sha256(); copied = 0
                            with source, os.fdopen(fd, "wb") as output:
                                for block in iter(lambda: source.read(65536), b""):
                                    copied += len(block)
                                    if copied > row["size"]: raise SeedError("Archive member exceeds signed size")
                                    checksum.update(block); output.write(block)
                                output.flush(); os.fsync(output.fileno()); os.fchmod(output.fileno(), row["mode"])
                            if copied != row["size"] or checksum.hexdigest() != row["sha256"]:
                                raise SeedError("Archive member content differs from signature")
                    if seen != set(payload["files"]): raise SeedError("Support archive is truncated")
                atomic(stage / "SUPPORT.json", canonical(document) + b"\n", mode=0o644)
                os.chmod(stage, 0o755)
                for directory in sorted((p for p in stage.rglob("*") if p.is_dir()), reverse=True):
                    runtime_directory(directory, listable=True); sync_directory(directory)
                sync_directory(stage)
                # The selected tree is never rewritten, including a damaged one.
                if os.path.lexists(final): raise SeedError("Concurrent immutable support generation collision")
                os.rename(stage, final); stage = None; sync_directory(self.paths.support_releases)
                self._verify_tree(final)
                self.checkpoint("support_staged")
                return identity
            finally:
                if stage is not None: shutil.rmtree(stage)

    def _write_journal(self, value, phase):
        value["phase"] = phase
        write_envelope(self.journal, value)
        self.checkpoint(phase)

    def _read_journal(self):
        value = envelope(self.journal)
        if (set(value) != {"schema_version", "candidate", "previous", "authority_id", "phase", "created_at", "outcome", "initial"}
                or type(value["schema_version"]) is not int or value["schema_version"] != 1
                or value["phase"] not in {"prepared", "floor_recorded", "bridge_recorded", "pointer_selected", "units_written", "units_reloaded", "units_enabled", "completed", "reverting", "reverted", "seed_only"}
                or value["outcome"] not in {None, "accepted", "retained_previous", "seed_only"} or type(value["initial"]) is not bool):
            raise SeedError("Support transaction journal is corrupt")
        for key in ("candidate", "previous"):
            item = value[key]
            if item is None and key == "previous": continue
            if not isinstance(item, dict) or set(item) != {"name", "revision", "manifest_sha256"} or item["name"] != self._name(integer(item["revision"]), sha(item["manifest_sha256"])):
                raise SeedError("Invalid journaled support target")
        sha(value["authority_id"])
        return value

    def _legacy_bridge(self, history):
        marker = self.paths.state / "support-bootstrap.json"
        candidate = {"revision": LEGACY_BRIDGE_BASE + history["revision"], "sha256": history["revisions"][str(history["revision"]) ]}
        if os.path.lexists(marker):
            old = read_json(marker)
            if set(old) != {"revision", "sha256"}: raise SeedError("Legacy bootstrap marker is corrupt")
            integer(old["revision"], 1, 1999999); sha(old["sha256"])
            if old["revision"] > candidate["revision"] or (old["revision"] == candidate["revision"] and old != candidate):
                raise SeedError("Legacy bridge would overwrite newer or conflicting support authority")
        write_json(marker, candidate)

    def _install_files(self, generation):
        # Whole payload was authenticated before ANY fixed destination changed.
        payload = generation["payload"]; root = generation["path"]
        writes = []
        for name, entry in sorted(payload["files"].items()):
            if name.startswith("scripts/"):
                destination = self.paths.install / "public-updater-installer" / name
            elif name.startswith("systemd/"):
                destination = self.paths.systemd / name.removeprefix("systemd/")
            else: continue
            raw = read(root / name, MAX_FILE)
            if digest(raw) != entry["sha256"]: raise SeedError("Support changed before fixed-file installation")
            writes.append((destination, raw, entry["mode"]))
        for destination, raw, mode in writes: atomic(destination, raw, mode=mode)

    def _systemd(self, action, *units):
        if action not in {"daemon-reload", "enable"} or any(unit not in ENABLE_UNITS for unit in units):
            raise SeedError("Support repair may not start, restart, stop or mask services")
        result = self.runner(["systemctl", action, *units], check=False, capture_output=True, text=True, timeout=60)
        if result.returncode != 0: raise SeedError("Systemd helper reconciliation did not complete")

    def _probe(self, generation):
        """Use only the verified seed interpreter and signed candidate modules."""
        from .lifecycle import SeedManager
        seed = SeedManager(self.paths).select()
        code = ("import importlib,json,sys;from pathlib import Path;sys.path.insert(0," + repr(str(generation["path"])) + ");"
                + ";".join("assert Path(importlib.import_module(" + repr(module) + ").__file__).resolve().is_relative_to(Path("
                           + repr(str(generation["path"])) + ").resolve()),'Support probe imported a fallback module'"
                           for module in sorted(set(ENTRYPOINTS.values())))
                + ";from shotdeck_seed.selfcheck import run;run();"
                + "from shotdeck_recovery import PROTOCOL_VERSION;print(json.dumps({'worker_protocol':PROTOCOL_VERSION}))")
        result = isolated_probe(self.runner, seed["python"], code, identity=generation["manifest_sha256"])
        from .storage import decode
        if result.returncode != 0 or decode(result.stdout) != {"worker_protocol": generation["worker_protocol"]}:
            raise SeedError("Support candidate cannot import its complete fixed component surface")

    def _finish(self, journal, generation, outcome):
        previous = journal["previous"] if outcome == "accepted" else None
        selected = journal["candidate"] if outcome == "accepted" else journal["previous"]
        write_json(self.accepted, {"schema_version": 1, "selected": selected, "previous": previous})
        journal["outcome"] = outcome
        self._write_journal(journal, "completed" if outcome == "accepted" else "reverted")
        ensure(self.root / "receipts")
        write_envelope(self.root / "receipts" / (journal["candidate"]["manifest_sha256"] + ".json"), journal)
        release_maintenance(self.paths, "support", journal["candidate"]["manifest_sha256"])
        self.journal.unlink(); sync_directory(self.root)
        return {"outcome": outcome, "revision": generation["revision"], "manifest_sha256": generation["manifest_sha256"]}

    def _revert(self, journal):
        if journal["previous"] is None:
            # A failed first support generation must not strand repair behind
            # a permanently pending transaction. Prove the independent seed,
            # keep the observed high-water mark, retain a failure receipt and
            # allow a later higher signed offer. Never report it as installed.
            from .lifecycle import SeedManager
            seed = SeedManager(self.paths).select()
            link = self.paths.support_current
            if os.path.lexists(link):
                if not link.is_symlink() or link.lstat().st_uid != os.geteuid():
                    raise SeedError("Unknown support selector prevents a proved seed fallback")
                target = Path(os.readlink(link)); target = target if target.is_absolute() else link.parent / target
                failed_candidate = target == self.paths.support_releases / journal["candidate"]["name"]
                initial_legacy = (journal["initial"] and target.parent == self.paths.support_releases
                                  and re.fullmatch(r"[1-9][0-9]{0,5}-[0-9a-f]{12}", target.name))
                if not failed_candidate and not initial_legacy:
                    raise SeedError("Unexpected support selector prevents a proved seed fallback")
            history = self._history()
            candidate = journal["candidate"]
            history["revision"] = max(history["revision"], candidate["revision"])
            old = history["revisions"].get(str(candidate["revision"]))
            if old is not None and old != candidate["manifest_sha256"]: raise SeedError("Conflicting support high-water evidence")
            history["revisions"][str(candidate["revision"])] = candidate["manifest_sha256"]
            write_json(self.high_water, history); write_json(self.enrolled, {"schema_version": 1})
            self._legacy_bridge(history)
            baseline = {}
            for name in sorted(["scripts/" + item for item in SCRIPT_NAMES] + ["systemd/" + item for item in UNIT_NAMES]):
                row = seed["manifest"]["files"].get("fallback-support/" + name)
                if row is None or "link" in row: raise SeedError("Verified seed lacks its complete repair baseline")
                baseline[name] = row
            self._install_files({"path": seed["path"] / "fallback-support", "payload": {"files": baseline}})
            self._systemd("daemon-reload")
            self._systemd("enable", *sorted(ENABLE_UNITS))
            if os.path.lexists(link):
                # First activation can fail before replacing the old A link.
                # Remove only that validated selector or this exact candidate;
                # retained generation files and A receipts stay untouched.
                link.unlink(); sync_directory(link.parent)
            write_json(self.accepted, {"schema_version": 1, "selected": None, "previous": None})
            journal["outcome"] = "seed_only"; self._write_journal(journal, "seed_only")
            ensure(self.root / "receipts")
            write_envelope(self.root / "receipts" / (candidate["manifest_sha256"] + ".json"), journal)
            release_maintenance(self.paths, "support", candidate["manifest_sha256"])
            self.journal.unlink(); sync_directory(self.root)
            return {"outcome": "seed_only", "revision": candidate["revision"], "manifest_sha256": candidate["manifest_sha256"]}
        previous = self._verify_tree(self.paths.support_releases / journal["previous"]["name"])
        if previous["manifest_sha256"] != journal["previous"]["manifest_sha256"]:
            raise SeedError("Retained support differs from accepted identity")
        self._write_journal(journal, "reverting")
        replace_link(self.paths.support_current, Path("support-releases") / previous["path"].name)
        self._install_files(previous); self._systemd("daemon-reload")
        self._systemd("enable", *previous["payload"]["enable_units"])
        return self._finish(journal, previous, "retained_previous")

    def _continue(self, journal):
        if self._authority()["authority_id"] != journal["authority_id"]:
            raise SeedError("Authority changed during support activation; explicit review required")
        candidate = journal["candidate"]
        claim_maintenance(self.paths, "support", candidate["manifest_sha256"])
        if journal["phase"] in {"reverting", "reverted", "seed_only"}:
            return self._revert(journal)
        try:
            generation = self._verify_tree(self.paths.support_releases / candidate["name"])
            if generation["manifest_sha256"] != candidate["manifest_sha256"]:
                raise SeedError("Support candidate differs from journal identity")
            self._probe(generation)
        except (OSError, ValueError, SeedError):
            # Retained acceptance alone is insufficient: signature, current
            # authority, profile, protocols and every byte are rechecked now.
            return self._revert(journal)
        history = self._history()
        old = history["revisions"].get(str(candidate["revision"]))
        if old is not None and old != candidate["manifest_sha256"]: raise SeedError("Support revision collided with immutable history")
        history["revision"] = max(history["revision"], candidate["revision"])
        history["revisions"][str(candidate["revision"])] = candidate["manifest_sha256"]
        write_json(self.high_water, history)
        write_json(self.enrolled, {"schema_version": 1})
        self._write_journal(journal, "floor_recorded")
        self._legacy_bridge(history); self._write_journal(journal, "bridge_recorded")
        replace_link(self.paths.support_current, Path("support-releases") / candidate["name"])
        self._write_journal(journal, "pointer_selected")
        try:
            self._install_files(generation); self._write_journal(journal, "units_written")
            self._systemd("daemon-reload"); self._write_journal(journal, "units_reloaded")
            self._systemd("enable", *generation["payload"]["enable_units"]); self._write_journal(journal, "units_enabled")
            self._verify_tree(generation["path"])
        except (OSError, ValueError, SeedError):
            return self._revert(journal)
        return self._finish(journal, generation, "accepted")

    def activate(self, manifest_sha256):
        identity = sha(manifest_sha256)
        with maintenance(self.paths, "support"):
            ensure(self.root)
            if os.path.lexists(self.journal):
                pending = self._read_journal()
                if pending["candidate"]["manifest_sha256"] != identity: raise SeedError("A different support transaction owns activation")
                return self._continue(pending)
            candidates = [path for path in self.paths.support_releases.iterdir() if re.fullmatch(SUPPORT_NAME, path.name) and path.name.endswith("-" + identity[:12])]
            if len(candidates) != 1: raise SeedError("Exact staged support candidate not found")
            generation = self._verify_tree(candidates[0])
            if generation["manifest_sha256"] != identity: raise SeedError("Support candidate identity mismatch")
            history = self._history(); accepted = self._accepted()
            if generation["revision"] < history["revision"] or history["revisions"].get(str(generation["revision"]), identity) != identity:
                raise SeedError("Support revision cannot be replayed or rewritten")
            if accepted["selected"] and accepted["selected"]["manifest_sha256"] == identity:
                self.selected_generation()
                return {"outcome": "already_completed", "revision": generation["revision"], "manifest_sha256": identity}
            previous = accepted["selected"]
            if previous is not None:
                try: self._verify_tree(self.paths.support_releases / previous["name"])
                except (OSError, ValueError, SeedError):
                    previous = accepted["previous"]
                    if previous is not None: self._verify_tree(self.paths.support_releases / previous["name"])
            journal = {"schema_version": 1, "candidate": {"name": generation["path"].name, "revision": generation["revision"], "manifest_sha256": identity},
                       "previous": previous, "authority_id": self._authority()["authority_id"], "phase": "prepared", "created_at": timestamp(), "outcome": None,
                       "initial": not os.path.lexists(self.enrolled)}
            self._write_journal(journal, "prepared")
            return self._continue(journal)

    def reconcile(self):
        if not os.path.lexists(self.journal): return {"outcome": "clear"}
        with maintenance(self.paths, "support"):
            if not os.path.lexists(self.journal):
                return {"outcome": "clear", "selected": self.status().get("selected")}
            return self._continue(self._read_journal())

    def local_offer(self):
        """Describe only already accepted local authority, never a new offer."""
        from .lifecycle import SeedManager
        if os.path.lexists(self.journal): raise SeedError("Finish the existing helper transaction first")
        seed = SeedManager(self.paths).select()
        self._history(); accepted = self._accepted()
        selected = accepted["selected"]
        if selected is None:
            raise SeedError("The independent seed is already the retained recovery surface")
        target = None; source = "seed"
        for key in ("selected", "previous"):
            row = accepted[key]
            if row is None: continue
            try:
                value = self._verify_tree(self.paths.support_releases / row["name"])
                if value["manifest_sha256"] != row["manifest_sha256"]: raise SeedError("Retained identity changed")
            except (OSError, ValueError, SeedError): continue
            target = row; source = key; break
        return {"schema_version": 1, "source": "local", "target": source,
                "manifest_sha256": selected["manifest_sha256"],
                "retained_manifest_sha256": None if target is None else target["manifest_sha256"],
                "seed_sha256": seed["sha256"], "authority_id": self._authority()["authority_id"]}

    def repair_local(self, offer):
        """Explicit offline repair; retained rollback never lowers high-water."""
        with maintenance(self.paths, "support"):
            if self.local_offer() != offer: raise SeedError("The retained repair target changed; confirm its exact identity")
            accepted = self._accepted(); selected = accepted["selected"]
            previous = accepted["previous"] if offer["target"] == "selected" else (
                accepted["previous"] if offer["target"] == "previous" else None)
            if previous is not None:
                try: self._verify_tree(self.paths.support_releases / previous["name"])
                except (OSError, ValueError, SeedError): previous = None
            journal = {"schema_version": 1, "candidate": selected, "previous": previous,
                       "authority_id": offer["authority_id"], "phase": "prepared" if offer["target"] == "selected" else "reverting",
                       "created_at": timestamp(), "outcome": None, "initial": False}
            self._write_journal(journal, journal["phase"])
            return self._continue(journal)

    def status(self):
        result = {"schema_version": 1, "available": False, "pending": os.path.lexists(self.journal), "selected": None}
        try:
            history = self._history(); result["high_water_revision"] = history["revision"]
            generation = self.selected_generation()
            result.update(available=True, selected={"revision": generation["revision"], "manifest_sha256": generation["manifest_sha256"]})
        except (OSError, ValueError, SeedError) as exc:
            result["error"] = str(exc)
        return result
