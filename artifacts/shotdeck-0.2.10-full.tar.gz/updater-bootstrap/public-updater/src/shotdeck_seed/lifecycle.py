"""Immutable seed slots, installed only from an authenticated full app release."""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import tempfile
import zipfile

from . import CAPABILITIES, SEED_PROTOCOL, SEED_REVISION, STATE_SCHEMA, SUPPORT_SCHEMA
from .authority import read_authority, tree_digest
from .manifest import ENTRYPOINTS, PACKAGE_NAMES, SCRIPT_NAMES, UNIT_NAMES
from .storage import (SeedError, SeedPaths, atomic, canonical, claim_maintenance, digest, ensure, envelope, integer, maintenance,
                      protected_directory, read, read_json, replace_link, selected_path, sha, sync_directory,
                      write_envelope, write_json)
from .storage import release_maintenance, isolated_probe, bounded_paths, runtime_directory
from .support import file_identity

SEED_NAME = r"s[1-9][0-9]{0,5}-[0-9a-f]{12}"
SEED_MANIFEST_LIMIT = 4 * 1024 * 1024
MAX_SLOT_FILES = 10000
MAX_SLOT_BYTES = 384 * 1024 * 1024
WHEEL_REQUIREMENTS = frozenset({"cryptography", "packaging", "pillow", "qrcode", "gpiozero", "lgpio", "spidev", "smbus2"})


def source_content_digest(source):
    """Bind same-revision source/dependencies independently of app version."""
    checksum = hashlib.sha256()
    for relative in sorted(["src/" + name for name in PACKAGE_NAMES | {"shotdeck_seed"}] + ["seed-wheels"]):
        folder = protected_directory(source / relative)
        for path in bounded_paths(folder, 20000):
            if "__pycache__" in path.parts or path.suffix == ".pyc": continue
            if path.is_symlink(): raise SeedError("Seed source may not contain aliases")
            if path.is_file():
                checksum.update(path.relative_to(source).as_posix().encode() + b"\0" + canonical(file_identity(path)))
    for relative in sorted(["scripts/" + name for name in SCRIPT_NAMES] + ["systemd/" + name for name in UNIT_NAMES]):
        checksum.update(relative.encode() + b"\0" + canonical(file_identity(source / relative)))
    return checksum.hexdigest()


def slot_inventory(root):
    """No mutable bytecode, external code links or unrecorded dependency files."""
    root = protected_directory(root)
    files = {}; total = 0
    for path in bounded_paths(root, MAX_SLOT_FILES * 2):
        relative = path.relative_to(root).as_posix()
        if relative == "SEED.json": continue
        info = path.lstat()
        if info.st_uid != os.geteuid(): raise SeedError("Seed entry ownership changed")
        if stat.S_ISDIR(info.st_mode):
            if info.st_uid != os.geteuid() or info.st_mode & 0o022: raise SeedError("Seed directory permissions changed")
            continue
        if "__pycache__" in path.parts or path.suffix in {".pyc", ".pth"}: raise SeedError("Mutable bytecode/import hooks are not seed artifacts")
        if stat.S_ISLNK(info.st_mode):
            # venv may make lib64→lib. No executable or dependency may point
            # outside the independently retained slot.
            target = path.resolve(strict=True)
            if not target.is_relative_to(root.resolve()): raise SeedError("Seed contains an external filesystem link")
            files[relative] = {"link": os.readlink(path)}
        elif stat.S_ISREG(info.st_mode):
            files[relative] = file_identity(path); total += info.st_size
        else: raise SeedError("Unsupported seed filesystem object")
        if len(files) > MAX_SLOT_FILES or total > MAX_SLOT_BYTES: raise SeedError("Seed exceeds its bounded artifact inventory")
    return files


def authenticate_app_bundle(app_root, paths=SeedPaths()):
    """Trust the qualified protected install receipt, never a caller assertion.

    Bootstrap defers until the normal installer has durably completed. This
    proves that the running/current source is the full tree accepted by that
    installer. A checkout, unsigned tree or pre-journal installation is refused.
    """
    from packaging.version import Version
    app_root = Path(app_root)
    current = selected_path(paths.install / "current", paths.install / "releases", r"[A-Za-z0-9][A-Za-z0-9._+\-]{0,199}")
    if current is None or current != app_root: raise SeedError("Seed source must be the selected immutable application tree")
    authority = read_authority(paths)
    if authority["generation"] < 2: raise SeedError("Qualified post-enrollment updater transition is required before seed installation")
    if read_json(paths.state / "activation-enrolled.json") != {"schema_version": 1}:
        raise SeedError("Normal activation journal is not enrolled")
    journal = envelope(paths.state / "activation-journal.json")
    required = {"schema_version", "transaction_id", "operation", "service_name", "phase", "candidate", "current_before", "previous_before", "boot_id", "owner", "recovery"}
    if (set(journal) != required or type(journal["schema_version"]) is not int or journal["schema_version"] != 1
            or journal["phase"] != "completed" or journal["operation"] != "install" or journal["service_name"] not in ("shotdeck", "shotdeck.service")
            or journal["recovery"] is not None or not re.fullmatch(r"[0-9a-f]{32}", str(journal["transaction_id"]))):
        raise SeedError("Seed installation must wait for a completed authenticated normal install")
    candidate = journal["candidate"]
    if not isinstance(candidate, dict) or candidate.get("directory") != app_root.name or candidate.get("metadata_matches") is not True:
        raise SeedError("Application source differs from its installation receipt")
    expected = sha(candidate.get("tree_sha256")); version = read(app_root / ".shotdeck-version", 128).decode().strip()
    if candidate.get("version") != version or Version(version) < Version(authority["policy"]["minimum_app_version"]):
        raise SeedError("Application source is below the active authority floor")
    if tree_digest(app_root) != expected: raise SeedError("Authenticated full application source has changed")
    return {"schema_version": 1, "authority_id": authority["authority_id"], "policy_generation": authority["generation"],
            "application_version": version, "application_tree_sha256": expected, "application_directory": app_root.name,
            "activation_transaction_id": journal["transaction_id"], "activation_journal_sha256": digest(canonical(journal))}


class SeedManager:
    def __init__(self, paths=SeedPaths(), *, checkpoint=lambda phase: None, runner=subprocess.run):
        self.paths = paths; self.checkpoint = checkpoint; self.runner = runner
        self.root = paths.seed_state
        self.state = self.root / "state.json"
        self.journal = self.root / "pending.json"

    def _state(self):
        if not os.path.lexists(self.state):
            if os.path.lexists(self.paths.seed_current) or os.path.lexists(self.journal):
                raise SeedError("Seed state is missing beside its selector/transaction")
            return {"schema_version": 1, "high_water_revision": 0, "revisions": {}, "selected": None, "previous": None}
        value = envelope(self.state)
        if (set(value) != {"schema_version", "high_water_revision", "revisions", "selected", "previous"}
                or type(value["schema_version"]) is not int or value["schema_version"] != STATE_SCHEMA
                or not isinstance(value["revisions"], dict) or len(value["revisions"]) > 4096):
            raise SeedError("Seed lifecycle state is corrupt")
        integer(value["high_water_revision"], 0)
        for revision, identity in value["revisions"].items():
            if not re.fullmatch(r"[1-9][0-9]{0,5}", revision) or int(revision) > value["high_water_revision"]:
                raise SeedError("Invalid seed high-water history")
            sha(identity)
        if value["high_water_revision"] and str(value["high_water_revision"]) not in value["revisions"]:
            raise SeedError("Seed high-water receipt is missing")
        for field in ("selected", "previous"):
            selected = value[field]
            if selected is not None and (not isinstance(selected, dict) or set(selected) != {"name", "revision", "sha256"}
                    or selected["name"] != self._name(integer(selected["revision"]), sha(selected["sha256"]))
                    or value["revisions"].get(str(selected["revision"])) != selected["sha256"]):
                raise SeedError("Seed selector history is corrupt")
        return value

    @staticmethod
    def _name(revision, identity): return f"s{revision}-{identity[:12]}"

    def verify_slot(self, path):
        path = protected_directory(path)
        manifest = read_json(path / "SEED.json", SEED_MANIFEST_LIMIT)
        if (set(manifest) != {"schema_version", "seed_revision", "seed_protocol", "support_schema", "state_schema", "capabilities", "source", "source_content_sha256", "files", "python"}
                or type(manifest["schema_version"]) is not int or manifest["schema_version"] != 1
                or manifest["seed_protocol"] != SEED_PROTOCOL or manifest["support_schema"] != SUPPORT_SCHEMA
                or manifest["state_schema"] != STATE_SCHEMA or not isinstance(manifest["capabilities"], list)
                or manifest["capabilities"] != sorted(CAPABILITIES)
                or any(type(manifest[name]) is not int for name in ("seed_protocol", "support_schema", "state_schema"))):
            raise SeedError("Seed has incompatible protocol/state capabilities")
        integer(manifest["seed_revision"])
        sha(manifest["source_content_sha256"])
        identity = digest(canonical(manifest))
        if path.name != self._name(manifest["seed_revision"], identity): raise SeedError("Seed path differs from recorded immutable identity")
        source = manifest["source"]; authority = read_authority(self.paths)
        # A newer active authority may invalidate an old seed. There is no
        # automatic fallback to a retired key/generation or unreadable state.
        if (not isinstance(source, dict) or source.get("authority_id") != authority["authority_id"]
                or source.get("policy_generation") != authority["generation"]):
            raise SeedError("Retained seed is incompatible with the current protected authority")
        sha(source.get("application_tree_sha256"))
        if manifest["python"] != "bin/python" or slot_inventory(path) != manifest["files"]:
            raise SeedError("Seed files or dependencies changed")
        python = path / "bin/python"
        if not python.is_file() or python.is_symlink() or not os.access(python, os.X_OK): raise SeedError("Independent seed interpreter is unavailable")
        config = read(path / "pyvenv.cfg", 16384).decode()
        if not re.search(r"^include-system-site-packages\s*=\s*false\s*$", config, re.MULTILINE):
            raise SeedError("Seed must not inherit mutable system/application packages")
        # Existing C support state uses schema1. Unknown/corrupt state never
        # authorizes falling back to an older seed that cannot read it.
        for name in ("support/high-water.json", "support/accepted.json"):
            state_path = self.paths.state / name
            if os.path.lexists(state_path):
                row = read_json(state_path)
                if type(row.get("schema_version")) is not int or row["schema_version"] != manifest["state_schema"]:
                    raise SeedError("Seed cannot read the current support state")
        return {"path": path, "revision": manifest["seed_revision"], "sha256": identity, "manifest": manifest, "python": python}

    def select(self):
        state = self._state()
        if os.path.lexists(self.journal): raise SeedError("Seed replacement requires boot reconciliation")
        try:
            selected = selected_path(self.paths.seed_current, self.paths.seed_releases, SEED_NAME)
            if selected is None or state["selected"] is None or selected.name != state["selected"]["name"]:
                raise SeedError("Seed selection lacks a matching durable receipt")
            value = self.verify_slot(selected)
            if value["sha256"] != state["selected"]["sha256"]: raise SeedError("Selected seed differs from acceptance")
            return value
        except (OSError, ValueError, SeedError):
            previous = state["previous"]
            if previous is None: raise SeedError("Selected seed is unusable; attended recovery is required")
            retained = self.verify_slot(self.paths.seed_releases / previous["name"])
            if retained["sha256"] != previous["sha256"]: raise SeedError("Retained seed identity differs from acceptance")
            return {**retained, "fallback": True}

    def select_entry(self, component):
        if component not in ENTRYPOINTS: raise SeedError("Unknown fixed seed component")
        selected = self.select()
        return selected["python"], ENTRYPOINTS[component], selected["path"]

    def status(self):
        result = {"schema_version": 1, "available": False, "pending": os.path.lexists(self.journal)}
        try:
            value = self.select()
            result.update(available=True, revision=value["revision"], sha256=value["sha256"],
                          seed_protocol=value["manifest"]["seed_protocol"], state_schema=value["manifest"]["state_schema"],
                          fallback=bool(value.get("fallback")))
        except (OSError, ValueError, SeedError) as exc:
            result["error"] = str(exc)
        return result

    def enable_surface(self):
        """Post-commit only; enable sockets/timers without an app restart."""
        self.select()
        from .tls import ensure_portal_tls
        if ensure_portal_tls():
            result = self.runner(["systemctl", "try-restart", "--no-block", "shotdeck-recovery.service"],
                                 check=False, capture_output=True, text=True, timeout=15)
            if result.returncode:
                raise SeedError("Recovery certificate refresh needs a portal restart")
        units = ["shotdeck-recovery-gateway.socket", "shotdeck-recovery.socket",
                 "shotdeck-recovery-maintenance.timer", "shotdeck-recovery-status.timer"]
        result = self.runner(["systemctl", "enable", "--now", *units], check=False,
                             capture_output=True, text=True, timeout=60)
        if result.returncode != 0: raise SeedError("Recovery socket/timer enablement is incomplete")
        return {"outcome": "enabled", "units": units}

    def _record(self, journal, phase):
        journal["phase"] = phase; write_envelope(self.journal, journal); self.checkpoint(phase)

    def _probe(self, slot):
        packages = sorted(PACKAGE_NAMES | {"shotdeck_seed", "shotdeck_recovery_gateway.admin"} | set(ENTRYPOINTS.values()))
        code = ("import importlib,json; "
                + ";".join("importlib.import_module(" + repr(name) + ")" for name in packages)
                + ";import cryptography,packaging,PIL,qrcode,gpiozero,lgpio,spidev,smbus2; "
                + "from shotdeck_seed.selfcheck import run;print(json.dumps(run()))")
        result = isolated_probe(self.runner, slot / "bin/python", code, identity=digest(str(slot).encode()))
        if result.returncode != 0: raise SeedError("Independent seed dependency/protocol probe failed: " + result.stderr[-1500:])
        from .storage import decode
        observed = decode(result.stdout)
        if observed != {"seed_protocol": SEED_PROTOCOL, "state_schema": STATE_SCHEMA, "capabilities": sorted(CAPABILITIES),
                        "auth_boundary": True, "signature_boundary": True, "fallback_boundary": True}:
            raise SeedError("Seed dependency probe returned incompatible capabilities")
        return observed

    def _continue(self, journal):
        if (set(journal) != {"schema_version", "phase", "candidate", "previous", "source", "outcome"}
                or type(journal["schema_version"]) is not int or journal["schema_version"] != 1
                or journal["phase"] not in {"prepared", "floor_recorded", "selected", "completed", "reverting", "reverted"}
                or journal["outcome"] not in {None, "accepted", "retained_previous", "unavailable"}):
            raise SeedError("Seed transaction journal is corrupt")
        candidate = journal["candidate"]
        for field in ("candidate", "previous"):
            row = journal[field]
            if field == "previous" and row is None: continue
            if not isinstance(row, dict) or set(row) != {"name", "revision", "sha256"} or row["name"] != self._name(integer(row["revision"]), sha(row["sha256"])):
                raise SeedError("Invalid seed transaction identity")
        source = journal["source"]
        if not isinstance(source, dict) or source.get("authority_id") != read_authority(self.paths)["authority_id"]:
            raise SeedError("Seed authority changed during replacement")
        claim_maintenance(self.paths, "seed", candidate["sha256"])
        state = self._state()
        if state["revisions"].get(str(candidate["revision"]), candidate["sha256"]) != candidate["sha256"]:
            raise SeedError("Seed revision cannot change content")
        if candidate["revision"] < state["high_water_revision"]: raise SeedError("Seed high-water revision cannot decrease")
        state["high_water_revision"] = max(state["high_water_revision"], candidate["revision"])
        state["revisions"][str(candidate["revision"])] = candidate["sha256"]
        write_envelope(self.state, state)
        try:
            if journal["phase"] in {"reverting", "reverted"}: raise SeedError("Continue the recorded seed rollback")
            slot = self.verify_slot(self.paths.seed_releases / candidate["name"])
            if slot["sha256"] != candidate["sha256"] or slot["manifest"]["source"] != source:
                raise SeedError("Seed candidate identity or provenance changed")
            self._probe(slot["path"])
        except (OSError, ValueError, SeedError):
            previous = journal["previous"]
            self._record(journal, "reverting")
            if previous is not None:
                retained = self.verify_slot(self.paths.seed_releases / previous["name"])
                if retained["sha256"] != previous["sha256"]: raise SeedError("Retained seed identity changed")
                replace_link(self.paths.seed_current, Path("recovery-seeds") / retained["path"].name)
            elif self.paths.seed_current.is_symlink():
                target = Path(os.readlink(self.paths.seed_current))
                target = target if target.is_absolute() else self.paths.seed_current.parent / target
                if target != self.paths.seed_releases / candidate["name"]:
                    raise SeedError("Unknown seed selector prevents initial rollback")
                self.paths.seed_current.unlink(); sync_directory(self.paths.seed_current.parent)
            state.update(selected=previous, previous=None)
            write_envelope(self.state, state)
            journal["outcome"] = "retained_previous" if previous is not None else "unavailable"
            self._record(journal, "reverted")
        else:
            write_envelope(self.state, state); self._record(journal, "floor_recorded")
            replace_link(self.paths.seed_current, Path("recovery-seeds") / candidate["name"])
            self._record(journal, "selected")
            state.update(selected=candidate, previous=journal["previous"])
            write_envelope(self.state, state)
            journal["outcome"] = "accepted"; self._record(journal, "completed")
        ensure(self.root / "receipts")
        write_envelope(self.root / "receipts" / (candidate["sha256"] + ".json"), journal)
        release_maintenance(self.paths, "seed", candidate["sha256"])
        self.journal.unlink(); sync_directory(self.root)
        return {"outcome": journal["outcome"], "selected": state["selected"], "high_water_revision": state["high_water_revision"]}

    def reconcile(self):
        if not os.path.lexists(self.journal): return {"outcome": "clear"}
        with maintenance(self.paths, "seed"):
            if not os.path.lexists(self.journal): return {"outcome": "clear"}
            return self._continue(envelope(self.journal))


class SeedInstaller(SeedManager):
    """Self-contained installer imported from the authenticated application bundle.

    It does not invoke the selected seed or pinned updater. Broken seed slots
    remain immutable; a later full release supplies a higher revision.
    """
    def install_from_application(self, app_root, *, revision=SEED_REVISION):
        integer(revision)
        with maintenance(self.paths, "seed"):
            ensure(self.root)
            runtime_directory(self.paths.install)
            runtime_directory(self.paths.seed_releases, listable=True)
            if os.path.lexists(self.journal): return self._continue(envelope(self.journal))
            provenance = authenticate_app_bundle(app_root, self.paths)
            source = Path(app_root) / "updater-bootstrap/public-updater"
            source.resolve(strict=True)
            if source.is_symlink() or not source.is_relative_to(Path(app_root)): raise SeedError("Seed source escaped the authenticated app bundle")
            current = self._state()
            source_sha = source_content_digest(source)
            if revision < current["high_water_revision"]:
                return {"outcome": "newer_seed_retained", "selected": current["selected"]}
            # A completed same revision is not rebuilt using environment-specific
            # pip/venv output. It must retain the exact previously accepted slot.
            if revision == current["high_water_revision"]:
                old_identity = current["revisions"][str(revision)]
                retained = self.verify_slot(self.paths.seed_releases / self._name(revision, old_identity))
                if retained["sha256"] != old_identity or retained["manifest"]["source_content_sha256"] != source_sha:
                    raise SeedError("Seed content changed without a new seed revision")
                if current["selected"] and current["selected"]["sha256"] == old_identity:
                    self.select()
                    return {"outcome": "already_completed", "selected": current["selected"]}
                # Retry the identical immutable candidate after a transient
                # probe failure; do not build another venv or reuse a revision
                # for different bytes. Current authenticated source must match.
                candidate = {"name": retained["path"].name, "revision": revision, "sha256": old_identity}
                journal = {"schema_version": 1, "phase": "prepared", "candidate": candidate,
                           "previous": current["selected"], "source": retained["manifest"]["source"], "outcome": None}
                self._record(journal, "prepared")
                return self._continue(journal)
            wheels = source / "seed-wheels"; inventory = read_json(wheels / "inventory.json")
            if set(inventory) != {"schema_version", "files"} or type(inventory["schema_version"]) is not int or inventory["schema_version"] != 1:
                raise SeedError("Invalid authenticated seed dependency inventory")
            records = inventory["files"]
            if not isinstance(records, dict) or not 1 <= len(records) <= 64: raise SeedError("Invalid seed wheel inventory bound")
            names = set()
            for name, item in records.items():
                if not re.fullmatch(r"[A-Za-z0-9_.+\-]{1,180}\.whl", name) or not isinstance(item, dict) or set(item) != {"sha256", "size"}:
                    raise SeedError("Invalid exact seed wheel entry")
                sha(item["sha256"]); integer(item["size"], 1, 64 * 1024 * 1024)
                raw = file_identity(wheels / name)
                if raw["sha256"] != item["sha256"] or raw["size"] != item["size"]: raise SeedError("Seed wheel differs from authenticated inventory")
                names.add(name.split("-", 1)[0].lower().replace("_", "-"))
                with zipfile.ZipFile(wheels / name) as archive:
                    if len(archive.infolist()) > 10000 or sum(entry.file_size for entry in archive.infolist()) > 128 * 1024 * 1024:
                        raise SeedError("Seed wheel exceeds safe expansion bounds")
                    for entry in archive.infolist():
                        parts = Path(entry.filename).parts
                        if (entry.filename.startswith("/") or ".." in parts or "\\" in entry.filename
                                or (entry.filename.endswith(".pth") and not (name.lower().startswith("setuptools-")
                                    and entry.filename == "distutils-precedence.pth"))
                                or stat.S_ISLNK(entry.external_attr >> 16)):
                            raise SeedError("Seed wheel contains unsafe paths or import hooks")
            if not WHEEL_REQUIREMENTS.issubset(names): raise SeedError("Authenticated bundle lacks complete offline seed dependencies")
            if set(path.name for path in wheels.iterdir()) != set(records) | {"inventory.json"}:
                raise SeedError("Unsigned seed wheel content exists")
            stage = Path(tempfile.mkdtemp(prefix=".stage-s-", dir=self.paths.seed_releases))
            try:
                env = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "TMPDIR": str(stage), "PYTHONDONTWRITEBYTECODE": "1"}
                self.runner(["/usr/bin/python3", "-m", "venv", "--copies", str(stage)], check=True, capture_output=True, timeout=180, env=env)
                self.runner([str(stage / "bin/python"), "-I", "-B", "-m", "pip", "--isolated", "install", "--no-index", "--no-deps", "--no-compile", "--no-cache-dir", "--disable-pip-version-check",
                             *[str(wheels / name) for name in sorted(records)]], check=True, capture_output=True, timeout=300, env=env)
                # setuptools' wheel carries a distutils import hook. Runtime
                # recovery needs no build hooks or inherited package paths.
                # Remove it before another Python process can import it.
                for hook in stage.rglob("*.pth"): hook.unlink()
                sites = list((stage / "lib").glob("python*/site-packages"))
                if len(sites) != 1: raise SeedError("Unexpected isolated seed Python layout")
                for package in sorted(PACKAGE_NAMES | {"shotdeck_seed"}):
                    origin = source / "src" / package
                    protected_directory(origin)
                    for path in origin.rglob("*"):
                        if path.is_symlink(): raise SeedError("Seed package source must not contain aliases")
                    shutil.copytree(origin, sites[0] / package, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
                # Seed-owned baseline helpers survive a wholly damaged first
                # support generation, including its fixed launcher copies.
                for relative in sorted(["scripts/" + name for name in SCRIPT_NAMES] + ["systemd/" + name for name in UNIT_NAMES]):
                    mode = 0o755 if relative.startswith("scripts/") else 0o644
                    atomic(stage / "fallback-support" / relative, read(source / relative, 2 * 1024 * 1024), mode=mode)
                # venv's bundled pip can create pyc before -B is available.
                # Remove only the new, unselected staging slot's bytecode.
                for cache in stage.rglob("__pycache__"):
                    if cache.is_symlink(): raise SeedError("Aliased seed bytecode directory")
                    shutil.rmtree(cache)
                for path in stage.rglob("*"):
                    if path.is_symlink(): continue
                    mode = 0o755 if path.is_dir() or path.stat().st_mode & 0o111 else 0o644
                    os.chmod(path, mode)
                os.chmod(stage, 0o755)
                self._probe(stage)
                if authenticate_app_bundle(app_root, self.paths) != provenance: raise SeedError("Authenticated seed source changed during staging")
                files = slot_inventory(stage)
                manifest = {"schema_version": 1, "seed_revision": revision, "seed_protocol": SEED_PROTOCOL,
                            "support_schema": SUPPORT_SCHEMA, "state_schema": STATE_SCHEMA, "capabilities": sorted(CAPABILITIES),
                            "source": provenance, "source_content_sha256": source_sha, "files": files, "python": "bin/python"}
                identity = digest(canonical(manifest)); final = self.paths.seed_releases / self._name(revision, identity)
                if os.path.lexists(final): raise SeedError("Seed immutable generation collision")
                atomic(stage / "SEED.json", canonical(manifest) + b"\n", mode=0o644)
                for directory in sorted((path for path in stage.rglob("*") if path.is_dir() and not path.is_symlink()), reverse=True): sync_directory(directory)
                sync_directory(stage); os.rename(stage, final); stage = None; sync_directory(self.paths.seed_releases)
                self.verify_slot(final)
                # Write zero state before the journal so first-install power
                # loss cannot be mistaken for an unenrolled seed after selection.
                if not os.path.lexists(self.state): write_envelope(self.state, current)
                candidate = {"name": final.name, "revision": revision, "sha256": identity}
                journal = {"schema_version": 1, "phase": "prepared", "candidate": candidate,
                           "previous": current["selected"], "source": provenance, "outcome": None}
                self._record(journal, "prepared")
                return self._continue(journal)
            finally:
                if stage is not None: shutil.rmtree(stage)
