"""Independent, immutable recovery seed and signed support transactions.

This package never imports the application or the selected updater. Its own
interpreter and verification dependencies are installed in a retained seed slot.
"""
SEED_REVISION = 11
SEED_PROTOCOL = 1
SUPPORT_SCHEMA = 1
STATE_SCHEMA = 1
CAPABILITIES = frozenset({"jobs-v1", "recovery-auth-v1", "support-repair-v1", "seed-fallback-v1"})
