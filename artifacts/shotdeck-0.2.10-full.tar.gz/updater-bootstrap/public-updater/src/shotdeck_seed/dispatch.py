"""Fixed seed dispatch after the stdlib launcher verifies its whole runtime."""
from __future__ import annotations

import os
import pwd
import re
import sys

from .lifecycle import SeedManager
from .storage import SeedError, SeedPaths, canonical
from .support import SupportManager


def qualified_support(seed, generation):
    from .authority import read_authority
    from shotdeck_recovery_gateway.capability import load
    from shotdeck_recovery_gateway.environment import profile
    payload = load(read_authority(), seed["sha256"], profile())
    if payload.get("support_manifest_sha256") != generation["manifest_sha256"]:
        raise SeedError("Selected helpers have no matching signed qualification")
    return payload


def command(args):
    if not args: raise SeedError("A fixed recovery command is required")
    name, rest = args[0], args[1:]
    fixed = {"gateway": ("gateway", []), "portal": ("portal", []),
             "screen": ("access", ["screen"]), "restore-network": ("access", ["restore-network"]),
             "app-start-condition": ("executor", ["start-condition"]),
             "app-prepare-start": ("executor", ["prepare-start"])}
    if name in fixed and not rest: return name, *fixed[name]
    if name == "admin-review":
        show = len(rest) == 3 and rest[:2] == ["show", "--job-id"]
        review = (len(rest) == 7 and rest[:2] == ["review", "--job-id"]
                  and rest[3] == "--expected-sha256" and re.fullmatch(r"[0-9a-f]{64}", rest[4])
                  and rest[5] == "--operator" and 1 <= len(rest[6]) <= 120 and bool(rest[6].strip())
                  and all(ord(character) >= 32 and ord(character) != 127 for character in rest[6]))
        if (show or review) and re.fullmatch(r"[0-9a-f]{32}", rest[2]):
            return name, "admin", rest
    if name == "gateway-executor":
        if rest in (["reconcile"], ["status"], ["refresh-status"], ["boot"]): return name, "executor", rest
        if len(rest) == 2 and rest[0] == "run" and re.fullmatch(r"[0-9a-f]{32}", rest[1]):
            return name, "executor", rest
    raise SeedError("Unknown or invalid fixed recovery command")


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    paths = SeedPaths(); seeds = SeedManager(paths); support = SupportManager(paths)
    if args == ["seed-status"]:
        print(canonical({"seed": seeds.status(), "support": support.status()}).decode()); return 0
    if args == ["seed-reconcile"]:
        print(canonical({"seed": seeds.reconcile(), "support": support.reconcile()}).decode()); return 0
    if args == ["gateway-executor", "boot"]:
        # The stdlib selector already authenticated this retained seed runtime.
        # Resolve its durable replacement intent before selecting any serving
        # generation; select() deliberately refuses a still-pending journal.
        from shotdeck_recovery_gateway.jobs import Jobs
        Jobs().reconcile()
        seeds.reconcile(); support.reconcile()
    if args == ["worker-info"]:
        seed = seeds.select(); value = support.selected_generation()
        try:
            qualified_support(seed, value); qualified, reason = True, ""
        except Exception:
            qualified, reason = False, "Independent recovery access has no matching signed qualification"
        print(canonical({"path": str(value["path"]), "python": str(seed["python"]), "revision": value["worker_revision"],
                         "protocol": value["worker_protocol"], "digest": value["worker_digest"], "release_c": True,
                         "qualified": qualified, "qualification_reason": reason}).decode())
        return 0
    worker = len(args) >= 2 and args[0] == "worker-run"
    if worker:
        suffix, arguments = args[1], args[2:]
        if not ((suffix in {"worker", "probe"} and not arguments)
                or (suffix == "adapters" and arguments in (["scheduled"], ["response"]))
                or (suffix == "executor" and len(arguments) == 1 and re.fullmatch(r"[0-9a-f]{32}", arguments[0]))):
            raise SeedError("Invalid fixed worker invocation")
        name, component = "worker-run", "worker"
    else: name, component, arguments = command(args)
    selected = seeds.select()
    python, module, source = selected["python"], None, None
    if name == "admin-review":
        module = "shotdeck_recovery_gateway.admin"
    elif worker:
        generation = support.selected_generation(); qualified_support(selected, generation)
        source = generation["path"]
        module = "shotdeck_recovery." + suffix
    else:
        try:
            generation = support.selected_generation(); qualified_support(selected, generation)
            source, module = support.select_entry(component)
        except Exception:
            python, module, _ = seeds.select_entry(component)
    # A replaceable candidate cannot choose an import module or interpreter.
    # Only an exact, completely authenticated generation is inserted in sys.path.
    code = "import runpy,sys;"
    if source is not None: code += "sys.path.insert(0," + repr(str(source)) + ");"
    code += "sys.argv=[" + repr(module) + "]+" + repr(arguments) + ";runpy.run_module(" + repr(module) + ",run_name='__main__')"
    environment = {"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "LANG": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1"}
    for key in ("LISTEN_PID", "LISTEN_FDS", "LISTEN_FDNAMES", "NOTIFY_SOCKET", "INVOCATION_ID"):
        if key in os.environ: environment[key] = os.environ[key]
    if name == "portal":
        account = pwd.getpwnam("shotdeck-recovery")
        if account.pw_uid == 0 or account.pw_gid == 0: raise SeedError("Recovery portal account must be unprivileged")
        os.setgroups([]); os.setgid(account.pw_gid); os.setuid(account.pw_uid)
    os.chdir("/")
    os.execve(python, [str(python), "-I", "-B", "-c", code], environment)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
