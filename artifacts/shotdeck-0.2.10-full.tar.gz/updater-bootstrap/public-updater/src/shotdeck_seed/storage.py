"""Bounded protected files and durable state; no updater dependency."""
from __future__ import annotations

from contextlib import contextmanager, ExitStack
from dataclasses import dataclass
import fcntl
import hashlib
import json
from itertools import islice
import os
from pathlib import Path
import re
import secrets
import stat
import tempfile

MAX_JSON = 512 * 1024
SHA256 = re.compile(r"[0-9a-f]{64}\Z")


class SeedError(RuntimeError):
    pass


@dataclass(frozen=True)
class SeedPaths:
    install: Path = Path("/opt/shotdeck")
    state: Path = Path("/var/lib/shotdeck/updater")
    signing: Path = Path("/var/lib/shotdeck/signing")
    systemd: Path = Path("/etc/systemd/system")
    updater_lock: Path = Path("/run/lock/shotdeck-updater.lock")
    backup_lock: Path = Path("/run/lock/shotdeck-backup-restore.lock")
    brew_lock: Path = Path("/run/lock/shotdeck-brew.lock")

    @property
    def seed_state(self): return self.state / "seed"
    @property
    def support_state(self): return self.state / "support"
    @property
    def seed_releases(self): return self.install / "recovery-seeds"
    @property
    def seed_current(self): return self.install / "recovery-seed-current"
    @property
    def support_releases(self): return self.install / "support-releases"
    @property
    def support_current(self): return self.install / "support-current"


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    result = {}
    for name, value in pairs:
        if name in result:
            raise SeedError("Duplicate protected document key")
        result[name] = value
    return result


def sha(value):
    if not isinstance(value, str) or not SHA256.fullmatch(value):
        raise SeedError("Expected exact SHA256 identity")
    return value


def integer(value, minimum=1, maximum=999999):
    if type(value) is not int or not minimum <= value <= maximum:
        raise SeedError("Integer outside supported protocol range")
    return value


def bounded_paths(root, maximum):
    paths = list(islice(Path(root).rglob("*"), maximum + 1))
    if len(paths) > maximum: raise SeedError("Immutable tree exceeds its entry bound")
    return sorted(paths)


def protected_directory(path, *, create=False, mode=0o700, _ancestor=False):
    path = Path(path).absolute()
    if path.parent != path:
        protected_directory(path.parent, _ancestor=True)
    if not os.path.lexists(path) and create:
        path.mkdir(mode=mode)
        sync_directory(path.parent)
    info = path.lstat()
    owner_ok = info.st_uid in ({0, os.geteuid()} if _ancestor else {os.geteuid()})
    sticky_parent = (_ancestor and info.st_uid == 0 and info.st_mode & stat.S_ISVTX
                     and path in {Path('/var/tmp'), Path('/tmp'), Path('/private/tmp')})
    if not stat.S_ISDIR(info.st_mode) or not owner_ok or (info.st_mode & 0o022 and not sticky_parent):
        raise SeedError("Unprotected or aliased state directory: " + str(path))
    return path


def ensure(path, *, mode=0o700):
    path = Path(path)
    if not os.path.lexists(path.parent):
        ensure(path.parent, mode=mode)
    return protected_directory(path, create=True, mode=mode)


def runtime_directory(path, *, listable=False):
    """Allow runtime traversal without making private state files readable.

    The application root can be 0750 on existing images. Seed/helper children
    contain public code, but their parent must remain owned and write-protected.
    Set explicit container modes after mkdir so service UMask=0077 cannot remove
    the access needed by the isolated probe and unprivileged portal.
    """
    path = ensure(path, mode=0o755 if listable else 0o700)
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022:
            raise SeedError('Runtime parent is unprotected')
        mode = 0o755 if listable else stat.S_IMODE(info.st_mode) | 0o011
        if stat.S_IMODE(info.st_mode) != mode:
            os.fchmod(descriptor, mode); os.fsync(descriptor)
    finally: os.close(descriptor)
    return path


def read(path, limit=MAX_JSON, *, protected=True):
    path = Path(path)
    if protected:
        protected_directory(path.parent)
    fd = os.open(path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        info = os.fstat(fd)
        if (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_size > limit
                or (protected and (info.st_uid != os.geteuid() or info.st_mode & 0o022))):
            raise SeedError("Unprotected or oversized regular file: " + str(path))
        with os.fdopen(fd, "rb", closefd=False) as stream:
            raw = stream.read(limit + 1)
        if len(raw) > limit:
            raise SeedError("Input exceeds its bounded size")
        return raw
    finally:
        os.close(fd)


def decode(raw):
    try:
        value = json.loads(raw, object_pairs_hook=unique)
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise SeedError("Invalid bounded JSON document") from exc
    if not isinstance(value, dict):
        raise SeedError("Expected a JSON object")
    return value


def read_json(path, limit=MAX_JSON):
    return decode(read(path, limit))


def sync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try: os.fsync(fd)
    finally: os.close(fd)


def atomic(path, raw, *, mode=0o600, checkpoint=lambda phase: None):
    path = Path(path)
    ensure(path.parent)
    if os.path.lexists(path):
        read(path, max(MAX_JSON, len(raw)))
    descriptor, temporary = tempfile.mkstemp(prefix="." + path.name + "-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(raw)
            os.fchmod(stream.fileno(), mode)
            stream.flush()
            os.fsync(stream.fileno())
        checkpoint("file_synced")
        os.replace(temporary, path)
        checkpoint("replaced")
        sync_directory(path.parent)
        checkpoint("directory_synced")
    finally:
        if os.path.lexists(temporary): os.unlink(temporary)


def write_json(path, value, *, checkpoint=lambda phase: None):
    atomic(path, canonical(value) + b"\n", checkpoint=checkpoint)


def envelope(path):
    value = read_json(path)
    if set(value) != {"record", "sha256"} or not isinstance(value["record"], dict) or digest(canonical(value["record"])) != value["sha256"]:
        raise SeedError("Protected journal checksum mismatch")
    return value["record"]


def write_envelope(path, value, *, checkpoint=lambda phase: None):
    write_json(path, {"record": value, "sha256": digest(canonical(value))}, checkpoint=checkpoint)


def replace_link(path, target):
    path, target = Path(path), Path(target)
    ensure(path.parent, mode=0o755)
    if os.path.lexists(path) and not path.is_symlink():
        raise SeedError("Protected selector must be a symlink")
    temporary = path.parent / ("." + path.name + "-" + secrets.token_hex(12))
    try:
        temporary.symlink_to(target)
        os.replace(temporary, path)
        sync_directory(path.parent)
    finally:
        temporary.unlink(missing_ok=True)


def selected_path(link, parent, pattern):
    link, parent = Path(link), Path(parent)
    protected_directory(link.parent)
    if not os.path.lexists(link): return None
    if not link.is_symlink(): raise SeedError("Selector is not a symlink")
    target = Path(os.readlink(link))
    if not target.is_absolute(): target = link.parent / target
    if target.parent != parent or not re.fullmatch(pattern, target.name):
        raise SeedError("Selector escaped its immutable release root")
    protected_directory(target)
    return target


@contextmanager
def lock(path, *, shared_device_lock=False):
    path = Path(path)
    if shared_device_lock and path.parent == Path('/run/lock'):
        protected_directory(path.parent.parent)
        parent = path.parent.lstat()
        if (not stat.S_ISDIR(parent.st_mode) or parent.st_uid != 0 or parent.st_gid != 0
                or (parent.st_mode & 0o002 and not parent.st_mode & stat.S_ISVTX)):
            raise SeedError("Shared device lock directory is unprotected")
    else: ensure(path.parent)
    try:
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    except FileNotFoundError:
        fd = os.open(path, os.O_RDONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        info = os.fstat(fd)
        forbidden = 0o002 if shared_device_lock and info.st_gid == 0 else 0o022
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1 or info.st_uid != os.geteuid() or info.st_mode & forbidden:
            raise SeedError("Invalid exclusive ownership lock")
        try: fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc: raise SeedError("Another maintenance owner is active") from exc
        yield
    finally:
        os.close(fd)


@contextmanager
def maintenance(paths, kind):
    # Same order as normal update/recovery; a gateway must not retain these
    # locks while it invokes this executor in another process.
    with ExitStack() as stack:
        for path in (paths.updater_lock, paths.backup_lock, paths.brew_lock):
            stack.enter_context(lock(path, shared_device_lock=True))
        for path in (paths.signing / "writer.lock", paths.state / (kind + ".lock")):
            stack.enter_context(lock(path))
        from shotdeck_recovery_gateway.barrier import assert_clear
        helper_identity = None
        if kind == "support" and os.path.lexists(paths.support_state / "pending.json"):
            # Only the dedicated, fully validated transaction can clear its
            # journal after a dead executor. The interrupted gateway job stays
            # blocked until its separate attended terminal-proof review.
            from .support import SupportManager
            helper_identity = SupportManager(paths)._read_journal()["candidate"]["manifest_sha256"]
        assert_clear(allow_owned=True, helper_journals=False, access_latch=False,
                     helper_reconcile_identity=helper_identity)
        other = "seed" if kind == "support" else "support"
        if os.path.lexists(paths.state / other / "pending.json"):
            raise SeedError("Another helper transaction must reconcile first")
        if os.path.lexists(paths.signing / "maintenance.json"):
            own = paths.state / kind / "pending.json"
            if not os.path.lexists(own): raise SeedError("Another signing maintenance owner is active")
            candidate = envelope(own).get("candidate", {})
            identity = candidate.get("sha256" if kind == "seed" else "manifest_sha256")
            expected = {"schema_version": 1, "kind": "recovery_" + kind, "candidate_sha256": sha(identity)}
            if read_json(paths.signing / "maintenance.json") != expected:
                raise SeedError("Another signing maintenance owner is active")
        for pending in (paths.signing / "licence/pending.json",
                        paths.signing / "updates/pending.json", paths.state / "restore-transaction.json"):
            if os.path.lexists(pending):
                raise SeedError("A signing/restore transaction must finish first")
        if os.path.lexists(paths.state / "activation-journal.json"):
            activation = envelope(paths.state / "activation-journal.json")
            if activation.get("phase") not in {"completed", "rolled_back", "reconciled"}:
                raise SeedError("Application activation outcome is unresolved")
        restore_root = paths.state.parent.parent / "shotdeck-restore/jobs"
        if os.path.lexists(restore_root):
            protected_directory(restore_root)
            from itertools import islice
            entries = list(islice(restore_root.iterdir(), 1025))
            if len(entries) > 1024: raise SeedError("Too many restore records to inspect")
            for entry in entries:
                if not re.fullmatch(r"[0-9a-f]{32}", entry.name): continue
                protected_directory(entry)
                path = entry / "transaction.json"
                if not os.path.lexists(path): continue
                record = read_json(path)
                if (set(record) != {"schema_version", "restore_id", "state", "rollback_path", "updated_at", "error"}
                        or type(record["schema_version"]) is not int or record["schema_version"] != 1
                        or record["restore_id"] != entry.name or record["rollback_path"] != "rollback.sdbak"
                        or record["state"] not in {"committed", "rolled_back"}):
                    raise SeedError("An unfinished restore owns maintenance")
        yield


def claim_maintenance(paths, kind, identity):
    """A journal precedes this lease; both survive loss of process locks."""
    marker = paths.signing / "maintenance.json"
    value = {"schema_version": 1, "kind": "recovery_" + kind, "candidate_sha256": sha(identity)}
    if os.path.lexists(marker) and read_json(marker) != value:
        raise SeedError("Another signing maintenance owner is active")
    write_json(marker, value)


def release_maintenance(paths, kind, identity):
    marker = paths.signing / "maintenance.json"
    if not os.path.lexists(marker): return
    expected = {"schema_version": 1, "kind": "recovery_" + kind, "candidate_sha256": sha(identity)}
    if read_json(marker) != expected: raise SeedError("Maintenance ownership changed before completion")
    marker.unlink(); sync_directory(marker.parent)


def isolated_probe(runner, python, code, *, identity):
    """Import validation cannot touch machine devices, network or live state.

    Candidate modules are authenticated, but hardware qualification is still
    pending. A short-lived dynamic UID and read-only filesystem bound this
    deliberate pre-selection import probe; it never invokes component main().
    """
    unit = "shotdeck-recovery-probe-" + sha(identity)[:12] + "-" + secrets.token_hex(4)
    properties = ["Type=exec", "DynamicUser=yes", "PrivateDevices=yes", "PrivateNetwork=yes",
                  "ProtectSystem=strict", "ProtectHome=yes", "NoNewPrivileges=yes", "CapabilityBoundingSet=",
                  "RuntimeDirectory=" + unit, "RuntimeDirectoryMode=0700", "WorkingDirectory=/run/" + unit,
                  "RestrictSUIDSGID=yes", "RestrictNamespaces=yes", "UMask=0077", "RuntimeMaxSec=90",
                  "InaccessiblePaths=-/run/shotdeck-recovery -/run/dbus -/var/lib/shotdeck",
                  "MemoryMax=128M", "TasksMax=16"]
    return runner(["systemd-run", "--quiet", "--pipe", "--wait", "--collect", "--unit=" + unit,
                   *["--property=" + value for value in properties], str(python), "-I", "-B", "-c", code],
                  check=False, capture_output=True, text=True, timeout=120,
                  env={"PATH": "/usr/sbin:/usr/bin:/sbin:/bin", "PYTHONDONTWRITEBYTECODE": "1"})
