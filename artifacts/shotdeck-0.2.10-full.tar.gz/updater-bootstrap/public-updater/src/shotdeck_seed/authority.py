"""Read protected update authority without importing/executing the updater."""
from __future__ import annotations

import base64
from pathlib import Path
import re
from urllib.parse import urlsplit

from .storage import SeedError, SeedPaths, bounded_paths, canonical, digest, integer, read, read_json, sha


def public_key(raw):
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    try:
        key = serialization.load_pem_public_key(raw)
        if (not isinstance(key, Ed25519PublicKey) or key.public_bytes(
                serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo) != raw):
            raise ValueError()
        return key
    except (ValueError, TypeError) as exc:
        raise SeedError("Expected one canonical Ed25519 update authority") from exc


def verify_signed(document, key_pem):
    if not isinstance(document, dict): raise SeedError("Signed document must be an object")
    signature = document.get("signature")
    if (not isinstance(signature, dict) or set(signature) != {"algorithm", "key_id", "value"}
            or signature["algorithm"] != "ed25519" or signature["key_id"] != digest(key_pem)[:16]):
        raise SeedError("Signature does not name the current update authority")
    try:
        raw = base64.b64decode(signature["value"].encode("ascii"), validate=True)
        if len(raw) != 64: raise ValueError()
        payload = {key: value for key, value in document.items() if key != "signature"}
        public_key(key_pem).verify(raw, canonical(payload))
    except Exception as exc:
        raise SeedError("Signature verification failed") from exc
    return payload


def read_authority(paths=SeedPaths()):
    """Corrupt or missing migrated metadata never enables a legacy-key fallback.

    A damaged runtime is deliberately not executed or silently restored here.
    Helper repair can continue using intact protected authority metadata.
    """
    pointer = read_json(paths.signing / "updates/active.json")
    if set(pointer) != {"schema_version", "generation_id"} or type(pointer["schema_version"]) is not int or pointer["schema_version"] != 1:
        raise SeedError("Invalid active update authority pointer")
    identity = sha(pointer["generation_id"])
    folder = paths.signing / "updates/generations" / identity
    record = read_json(folder / "generation.json")
    fields = {"schema_version", "policy", "runtime", "runtime_sha256", "highest_seen_version", "recovery_tree_sha256"}
    if set(record) != fields or type(record["schema_version"]) is not int or record["schema_version"] != 1 or digest(canonical(record)) != identity:
        raise SeedError("Active authority metadata is corrupt")
    policy = record["policy"]
    expected = {"schema_version", "generation", "public_key_pem", "fingerprint", "feeds", "minimum_app_version", "minimum_updater_version", "recovery_version"}
    if not isinstance(policy, dict) or set(policy) != expected or type(policy["schema_version"]) is not int or policy["schema_version"] != 1:
        raise SeedError("Unsupported update policy")
    integer(policy["generation"])
    try: key = policy["public_key_pem"].encode("ascii")
    except (AttributeError, UnicodeError) as exc: raise SeedError("Invalid policy public key") from exc
    public_key(key)
    if digest(key) != sha(policy["fingerprint"]) or read(folder / "update-public.pem", 16384) != key:
        raise SeedError("Protected public key differs from policy")
    floor = read_json(paths.signing / "update-enrolled.json")
    if (set(floor) != {"schema_version", "minimum_generation"} or type(floor["schema_version"]) is not int
            or floor["schema_version"] != 1 or integer(floor["minimum_generation"]) > policy["generation"]):
        raise SeedError("Update authority is below the committed floor")
    feeds = policy["feeds"]
    if not isinstance(feeds, dict) or set(feeds) != {"stable", "beta"}:
        raise SeedError("Invalid protected feeds")
    for lane, url in feeds.items():
        if not isinstance(url, str): raise SeedError("Invalid protected feed URL")
        parsed = urlsplit(url)
        if (parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password
                or parsed.query or parsed.fragment or not parsed.path.endswith("/shotdeck-" + lane + "-v3.json")):
            raise SeedError("Invalid protected feed URL")
    from packaging.version import Version, InvalidVersion
    try:
        for value in (record["highest_seen_version"], policy["minimum_app_version"], policy["minimum_updater_version"], policy["recovery_version"]): Version(value)
        if Version(policy["minimum_app_version"]) != Version(policy["recovery_version"]): raise ValueError()
    except (ValueError, TypeError, InvalidVersion) as exc:
        raise SeedError("Invalid update/recovery version floors") from exc
    runtime = Path(record["runtime"])
    if runtime.parent != paths.install / "updater-runtimes" or not re.fullmatch(r"[A-Za-z0-9._-]{1,120}", runtime.name):
        raise SeedError("Pinned runtime path is outside its retained directory")
    sha(record["runtime_sha256"]); sha(record["recovery_tree_sha256"])
    return {"authority_id": identity, "generation": policy["generation"], "public_key_pem": key,
            "policy": policy, "record": record}


def tree_digest(root, *, runtime=False):
    """Match the existing policy's immutable tree format, without its runtime."""
    import hashlib
    import os
    import stat
    from .storage import protected_directory
    root = Path(root)
    protected_directory(root)
    result = hashlib.sha256()
    count = 0
    for path in bounded_paths(root, 40000):
        relative = path.relative_to(root)
        if path.name == ".shotdeck-release.json" or (runtime and ("__pycache__" in relative.parts or path.suffix == ".pyc")):
            continue
        count += 1
        if count > 40000: raise SeedError("Pinned tree exceeds its inventory bound")
        info = path.lstat()
        if info.st_uid != os.geteuid() or (not stat.S_ISLNK(info.st_mode) and info.st_mode & 0o022):
            raise SeedError("Pinned tree ownership or permissions changed")
        if stat.S_ISDIR(info.st_mode):
            result.update(f"dir:{relative.as_posix()}\n".encode())
        elif stat.S_ISREG(info.st_mode):
            if info.st_nlink != 1 or info.st_size > 512 * 1024 * 1024: raise SeedError("Invalid pinned regular file")
            result.update(f"file:{relative.as_posix()}\n".encode())
            descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
            with os.fdopen(descriptor, "rb") as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b""): result.update(block)
        elif runtime and stat.S_ISLNK(info.st_mode):
            target = path.resolve(strict=True)
            if not target.is_relative_to(root.resolve()) and not (relative.parent == Path("bin")
                    and re.fullmatch(r"python(?:3(?:\.\d+)?)?", path.name)
                    and target.is_relative_to(Path("/usr").resolve()) and target.stat().st_uid == 0
                    and not target.stat().st_mode & 0o022):
                raise SeedError("Pinned runtime contains an external non-Python link")
            result.update(f"link:{relative.as_posix()}:{os.readlink(path)}\n".encode())
        else:
            raise SeedError("Pinned tree contains a special file")
    return result.hexdigest()


def verify_runtime(paths=SeedPaths(), *, authority=None):
    import os
    authority = authority or read_authority(paths)
    runtime = Path(authority["record"]["runtime"])
    if tree_digest(runtime, runtime=True) != authority["record"]["runtime_sha256"]:
        raise SeedError("Pinned updater runtime is damaged; helper repair cannot restore it")
    for name in ("python", "shotdeck-updater"):
        if not (runtime / "bin" / name).is_file() or not os.access(runtime / "bin" / name, os.X_OK):
            raise SeedError("Pinned updater entrypoint is unavailable")
    return runtime


def installed_cohort(profile_path=Path("/etc/shotdeck/hardware-profile.json"), os_release=Path("/etc/os-release")):
    # Match the protected hardware guard's documented legacy identity default.
    try:
        profile = read_json(profile_path, 16384)
        if type(profile.get("schema_version")) is not int or profile["schema_version"] != 1 or profile.get("profile_id") not in {"rev1_2_3_5f_bbw", "rev15_3_5f"}:
            raise SeedError("Unknown installed hardware identity")
        hardware = profile["profile_id"]
    except FileNotFoundError:
        hardware = "rev1_2_3_5f_bbw"
    resolved = os_release.resolve(strict=True)
    if resolved not in {os_release, Path("/usr/lib/os-release")}:
        raise SeedError("Unexpected OS metadata location")
    values = {}
    for line in read(resolved, 16384).decode("utf-8").splitlines():
        if "=" in line and not line.startswith("#"):
            key, value = line.split("=", 1); values[key] = value.strip('"')
    codename = values.get("VERSION_CODENAME", "")
    if not re.fullmatch(r"[a-z0-9_-]{1,40}", codename): raise SeedError("OS codename is unavailable")
    return {"hardware_profile": hardware, "os_codename": codename}
