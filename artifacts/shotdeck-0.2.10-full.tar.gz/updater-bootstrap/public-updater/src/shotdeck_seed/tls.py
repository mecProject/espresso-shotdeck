"""Device-local TLS: atomic certificates, persistent key, physical hash check.

Certificates renew using the authenticated existing key. Damaged material
never causes key regeneration. Self-signed TLS does not claim public CA trust.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
import grp
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import socket
import stat
import subprocess
import tempfile

from .storage import SeedError, lock, protected_directory, sync_directory, runtime_directory

ROOT = Path("/etc/shotdeck/recovery-portal")
CERTIFICATE_DAYS = 90
RENEW_BEFORE_DAYS = 14


def portal_names():
    from cryptography import x509
    names = [x509.DNSName("localhost"), x509.IPAddress(ipaddress.ip_address("127.0.0.1")),
             x509.IPAddress(ipaddress.ip_address("::1")), x509.IPAddress(ipaddress.ip_address("10.42.0.1"))]
    hostname = socket.gethostname()
    if re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9-]{0,62}", hostname):
        names.extend([x509.DNSName(hostname), x509.DNSName(hostname + ".local")])
    # Cover addresses displayed by recovery without DNS or network contact.
    try:
        result = subprocess.run(['/usr/sbin/ip', '-j', 'address', 'show'], capture_output=True,
                                text=True, timeout=5, check=True)
        if len(result.stdout) > 65536:
            raise ValueError("Interface list exceeds its bound")
        rows = json.loads(result.stdout)
        if not isinstance(rows, list) or len(rows) > 64:
            raise ValueError("Interface list exceeds its bound")
        additions = []
        for row in rows:
            for item in row.get('addr_info', ())[:64]:
                address = ipaddress.ip_address(item['local'])
                value = x509.IPAddress(address)
                if not address.is_unspecified and not address.is_link_local and value not in names + additions:
                    additions.append(value)
        if len(names) + len(additions) > 128:
            raise ValueError("Interface address list exceeds its bound")
        names.extend(additions)
    except (OSError, subprocess.SubprocessError, ValueError, KeyError, TypeError, AttributeError):
        # Offline first enrollment still covers fixed names and the hotspot.
        # Physical pairing adds an actual LAN address once one is available.
        pass
    return names


def certificate(key, names, now):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes
    from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Shotdeck local recovery")])
    return (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(now - timedelta(minutes=5))
            .not_valid_after(now + timedelta(days=CERTIFICATE_DAYS))
            .add_extension(x509.SubjectAlternativeName(names), critical=False)
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False, key_encipherment=False,
                                        data_encipherment=False, key_agreement=False, key_cert_sign=False,
                                        crl_sign=False, encipher_only=False, decipher_only=False), critical=True)
            .sign(key, hashes.SHA256()))


def ensure_portal_tls(root=ROOT):
    """Return whether the certificate changed; never replace an existing key."""
    root = Path(root)
    runtime_directory(root.parent)
    with lock(root.parent / '.recovery-portal-tls.lock'):
        return _ensure_portal_tls(root)


def _ensure_portal_tls(root):
    from cryptography import x509
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.exceptions import InvalidSignature
    from cryptography.x509.oid import ExtendedKeyUsageOID
    group = grp.getgrnam("shotdeck-recovery").gr_gid
    names, now = portal_names(), datetime.now(timezone.utc)
    if os.path.lexists(root):
        protected_directory(root)
        values = []
        for name, mode in (("server.key", 0o640), ("server.crt", 0o644)):
            descriptor = os.open(root / name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(descriptor, "rb") as stream:
                info = os.fstat(stream.fileno())
                if (not stat.S_ISREG(info.st_mode) or info.st_uid != 0 or info.st_gid != group
                        or stat.S_IMODE(info.st_mode) != mode or info.st_nlink != 1 or info.st_size > 32768):
                    raise SeedError("Existing recovery TLS identity needs attended repair")
                values.append(stream.read(32769))
        key = serialization.load_pem_private_key(values[0], password=None)
        cert = x509.load_pem_x509_certificate(values[1])
        encode = lambda public: public.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
        if encode(key.public_key()) != encode(cert.public_key()):
            raise SeedError("Recovery TLS certificate does not match its private key")
        if not isinstance(key, ec.EllipticCurvePrivateKey) or not isinstance(key.curve, ec.SECP256R1):
            raise SeedError("Recovery TLS key needs attended repair")
        try:
            cert.verify_directly_issued_by(cert)
        except (ValueError, TypeError, InvalidSignature) as exc:
            raise SeedError("Recovery TLS certificate needs attended repair") from exc
        try:
            certificate_names = cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
            usage = cert.extensions.get_extension_for_class(x509.ExtendedKeyUsage).value
            renew = (cert.not_valid_after_utc - cert.not_valid_before_utc > timedelta(days=CERTIFICATE_DAYS, minutes=5)
                     or cert.not_valid_after_utc <= now + timedelta(days=RENEW_BEFORE_DAYS)
                     or cert.not_valid_before_utc > now
                     or any(name not in certificate_names for name in names)
                     or ExtendedKeyUsageOID.SERVER_AUTH not in usage)
        except x509.ExtensionNotFound:
            renew = True
        if not renew:
            return False
        raw = certificate(key, names, now).public_bytes(serialization.Encoding.PEM)
        descriptor, temporary = tempfile.mkstemp(prefix='.server-certificate-', dir=root)
        try:
            with os.fdopen(descriptor, 'wb') as stream:
                os.fchown(stream.fileno(), 0, group); os.fchmod(stream.fileno(), 0o644)
                stream.write(raw); stream.flush(); os.fsync(stream.fileno())
            os.replace(temporary, root / 'server.crt')
            sync_directory(root)
        finally:
            if os.path.lexists(temporary):
                os.unlink(temporary)
        return True
    stage = Path(tempfile.mkdtemp(prefix=".recovery-portal-", dir=root.parent))
    try:
        os.chown(stage, 0, group); os.chmod(stage, 0o750)
        key = ec.generate_private_key(ec.SECP256R1())
        cert = certificate(key, names, now)
        contents = (("server.key", key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                                     serialization.NoEncryption()), 0o640),
                    ("server.crt", cert.public_bytes(serialization.Encoding.PEM), 0o644))
        for name, data, mode in contents:
            descriptor = os.open(stage / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
            with os.fdopen(descriptor, "wb") as stream:
                os.fchown(stream.fileno(), 0, group); os.fchmod(stream.fileno(), mode)
                stream.write(data); stream.flush(); os.fsync(stream.fileno())
        sync_directory(stage)
        os.rename(stage, root)
        sync_directory(root.parent)
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    return True
