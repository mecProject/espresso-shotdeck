"""Bounded support-feed transport derived exclusively from protected app feeds."""
from __future__ import annotations

from contextlib import contextmanager
import hashlib
import os
from pathlib import Path
import shutil
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit, urlunsplit
from urllib.request import HTTPRedirectHandler, ProxyHandler, Request, build_opener

from .authority import read_authority
from .manifest import MAX_ARCHIVE
from .storage import SeedError, SeedPaths, canonical, decode, digest, integer, sha
from .support import SupportManager

MAX_MANIFEST = 512 * 1024


class FixedOriginRedirect(HTTPRedirectHandler):
    def __init__(self, origin): self.origin = origin; self.redirects = 0
    def redirect_request(self, request, fp, code, message, headers, newurl):
        self.redirects += 1
        parsed = urlsplit(newurl)
        if self.redirects > 3 or (parsed.scheme, parsed.netloc) != self.origin or parsed.username or parsed.password or parsed.fragment:
            raise SeedError("Support redirect left its protected HTTPS origin")
        return super().redirect_request(request, fp, code, message, headers, newurl)


class SupportClient:
    def __init__(self, paths=SeedPaths(), *, manager=None, opener_factory=build_opener):
        self.paths = paths; self.manager = manager or SupportManager(paths); self.opener_factory = opener_factory

    def _urls(self, channel, revision=None, archive_sha=None):
        if channel not in {"stable", "beta"}: raise SeedError("Unknown protected update channel")
        authority = read_authority(self.paths)
        parsed = urlsplit(authority["policy"]["feeds"][channel])
        metadata = parsed.path.rsplit("/", 1)[0]
        manifest_path = metadata + "/shotdeck-support-" + channel + "-v1.json"
        manifest = urlunsplit((parsed.scheme, parsed.netloc, manifest_path, "", ""))
        artifact = None
        if revision is not None:
            integer(revision); sha(archive_sha)
            if not metadata.endswith("/metadata"): raise SeedError("Protected feed has no supported support-archive layout")
            archive_path = metadata.removesuffix("/metadata") + "/artifacts/support/shotdeck-support-" + str(revision) + "-" + archive_sha[:12] + ".tar.gz"
            artifact = urlunsplit((parsed.scheme, parsed.netloc, archive_path, "", ""))
        return authority, manifest, artifact

    def _open(self, url):
        parsed = urlsplit(url)
        opener = self.opener_factory(ProxyHandler({}), FixedOriginRedirect((parsed.scheme, parsed.netloc)))
        try:
            response = opener.open(Request(url, headers={"User-Agent": "Shotdeck-Recovery-Seed/1", "Accept-Encoding": "identity"}), timeout=30)
        except (OSError, HTTPError, URLError) as exc:
            raise SeedError("Support feed is unavailable; retained local recovery remains available") from exc
        if response.headers.get("Content-Encoding", "identity") not in {"", "identity"}:
            response.close(); raise SeedError("Compressed support HTTP representation is not accepted")
        return response

    def check(self, channel="stable"):
        authority, url, _ = self._urls(channel)
        deadline = time.monotonic() + 60
        with self._open(url) as response:
            pieces = []; count = 0
            while True:
                if time.monotonic() > deadline: raise SeedError("Support metadata exceeded its safe fetch deadline")
                block = response.read1(min(65536, MAX_MANIFEST - count + 1))
                if not block: break
                pieces.append(block); count += len(block)
                if count > MAX_MANIFEST: raise SeedError("Signed support metadata exceeds bound")
            raw = b"".join(pieces)
        if len(raw) > MAX_MANIFEST: raise SeedError("Signed support metadata exceeds bound")
        document = decode(raw); payload = self.manager.verify_offer(document)
        if read_authority(self.paths)["authority_id"] != authority["authority_id"]:
            raise SeedError("Protected authority changed during support check")
        return {"schema_version": 1, "channel": channel, "revision": payload["revision"],
                "manifest_sha256": digest(canonical(document)), "archive_sha256": payload["archive"]["sha256"],
                "size": payload["archive"]["size"], "authority_id": authority["authority_id"], "document": document}

    def repair(self, offer):
        """Recheck the exact accepted offer; no remote URL or local path input."""
        expected_fields = {"schema_version", "channel", "revision", "manifest_sha256", "archive_sha256", "size", "authority_id"}
        if not isinstance(offer, dict) or set(offer) != expected_fields or type(offer["schema_version"]) is not int or offer["schema_version"] != 1:
            raise SeedError("Repair requires a complete exact accepted support offer")
        sha(offer["manifest_sha256"]); sha(offer["archive_sha256"]); sha(offer["authority_id"])
        integer(offer["revision"]); integer(offer["size"], 1, MAX_ARCHIVE)
        checked = self.check(offer["channel"])
        if {key: value for key, value in checked.items() if key != "document"} != offer:
            raise SeedError("The signed support offer changed; confirm the new exact offer")
        _, _, url = self._urls(offer["channel"], offer["revision"], offer["archive_sha256"])
        # Disk-backed and private, never the device's RAM-backed /tmp.
        workspace = Path(tempfile.mkdtemp(prefix="shotdeck-support-fetch-", dir="/var/tmp")); os.chmod(workspace, 0o700)
        try:
            destination = workspace / "support.tar.gz"
            deadline = time.monotonic() + 180
            with self._open(url) as response, destination.open("xb") as stream:
                os.fchmod(stream.fileno(), 0o600)
                checksum = hashlib.sha256(); count = 0
                while True:
                    if time.monotonic() > deadline: raise SeedError("Support archive exceeded its safe fetch deadline")
                    block = response.read1(min(65536, offer["size"] - count + 1))
                    if not block: break
                    count += len(block)
                    if count > offer["size"]: raise SeedError("Support download exceeds its signed size")
                    stream.write(block); checksum.update(block)
                stream.flush(); os.fsync(stream.fileno())
            if count != offer["size"] or checksum.hexdigest() != offer["archive_sha256"]:
                raise SeedError("Support download is incomplete or differs from its signature")
            identity = self.manager.stage(checked["document"], destination)
            if identity != offer["manifest_sha256"]: raise SeedError("Staged support identity differs from accepted offer")
            result = self.manager.activate(identity)
            if result["outcome"] not in {"accepted", "already_completed"}:
                raise SeedError("New helpers failed validation; retained recovery was restored (" + result["outcome"] + ")")
            return result
        finally:
            # This process owns every file and all HTTP/file handles are closed;
            # no child is launched with the fetch workspace as cwd or TMPDIR.
            shutil.rmtree(workspace)
