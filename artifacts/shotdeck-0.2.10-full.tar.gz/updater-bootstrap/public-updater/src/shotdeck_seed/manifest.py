"""Separate signed support protocol, constrained to replaceable helper files."""
from __future__ import annotations

import ast
from pathlib import PurePosixPath
import re

from . import CAPABILITIES, SEED_PROTOCOL, SUPPORT_SCHEMA
from .authority import verify_signed
from .storage import SeedError, canonical, digest, integer, sha

MAX_ARCHIVE = 16 * 1024 * 1024
MAX_CONTENT = 32 * 1024 * 1024
MAX_FILE = 2 * 1024 * 1024
MAX_FILES = 256
PACKAGE_NAMES = frozenset({"shotdeck_recovery", "shotdeck_recovery_portal", "shotdeck_recovery_gateway", "shotdeck_recovery_access"})
SCRIPT_NAMES = frozenset({"check_update_connectivity.py", "prompted_update_flow.py", "run_configured_updater.sh", "shotdeck_update_gate.py", "shotdeck_recovery_gate.py"})
UNIT_NAMES = frozenset({
    "shotdeck-updater.service", "shotdeck-updater-boot.timer", "shotdeck-updater.timer",
    "shotdeck-update-response.service", "shotdeck-update-response.path", "shotdeck-update-control.slice",
    "shotdeck-update-coordinator.slice", "shotdeck-update-check.slice", "shotdeck-update-queue.service",
    "shotdeck-update-queue.path", "shotdeck-update-queue.timer", "shotdeck-update-check@.service",
    "shotdeck-update-apply@.service", "shotdeck-update-wake@.service", "shotdeck-update-retry.timer",
    "shotdeck-update-control.service", "shotdeck-update-control.path", "shotdeck-recovery-boot.service",
    "shotdeck-recovery-failure.service", "shotdeck-recovery-watchdog.service", "shotdeck-recovery-watchdog.timer",
    "shotdeck.service.d/50-shotdeck-recovery.conf",
    "shotdeck-recovery.socket", "shotdeck-recovery.service", "shotdeck-recovery-gateway.socket",
    "shotdeck-recovery-gateway.service", "shotdeck-recovery-operation@.service", "shotdeck-recovery-read@.service",
    "shotdeck-recovery-screen.service", "shotdeck-recovery-screen.slice", "shotdeck-recovery-portal.slice",
    "shotdeck-recovery-network-restore.service", "shotdeck-recovery-maintenance.service", "shotdeck-recovery-maintenance.timer",
    "shotdeck-recovery-status.service", "shotdeck-recovery-status.timer",
    "shotdeck-recovery-access-boot.service",
})
# These are enabled, never started/restarted by a support transaction. Existing
# applications, executors and Bluetooth owners are never signalled during repair.
ENABLE_UNITS = frozenset({"shotdeck-update-queue.path", "shotdeck-update-queue.timer", "shotdeck-update-control.path",
    "shotdeck-updater-boot.timer", "shotdeck-updater.timer", "shotdeck-update-response.path",
    "shotdeck-recovery.socket", "shotdeck-recovery-gateway.socket", "shotdeck-recovery-watchdog.timer",
    "shotdeck-recovery-maintenance.timer", "shotdeck-recovery-status.timer"})
ENTRYPOINTS = {"portal": "shotdeck_recovery_portal.server", "gateway": "shotdeck_recovery_gateway.server",
    "executor": "shotdeck_recovery_gateway.executor", "gateway_reconcile": "shotdeck_recovery_gateway.executor",
    "access": "shotdeck_recovery_access.__main__",
    "worker": "shotdeck_recovery.worker"}


def allowed_file(name):
    if not isinstance(name, str) or len(name) > 160 or "\\" in name or name.startswith("/"):
        raise SeedError("Invalid support archive path")
    path = PurePosixPath(name)
    if path.as_posix() != name or any(part in {"", ".", ".."} for part in name.split("/")):
        raise SeedError("Noncanonical support archive path")
    parts = path.parts
    if len(parts) == 2 and parts[0] in PACKAGE_NAMES and re.fullmatch(r"[a-z_][a-z0-9_]{0,63}\.py", parts[1]):
        return 0o644
    if len(parts) == 3 and parts[0] == "shotdeck_recovery_portal" and parts[1] == "static" and re.fullmatch(r"[a-z][a-z0-9_-]{0,63}\.(?:html|js|css|svg)", parts[2]):
        return 0o644
    if len(parts) == 2 and parts[0] == "scripts" and parts[1] in SCRIPT_NAMES:
        return 0o755
    if parts[0] == "systemd" and "/".join(parts[1:]) in UNIT_NAMES:
        return 0o644
    raise SeedError("Support payload may not modify seed, trust, app or arbitrary system files")


def validate_manifest(document, authority, cohort, *, seed_protocol=SEED_PROTOCOL, seed_capabilities=CAPABILITIES):
    # Verify the received mapping before considering fields or normalization.
    payload = verify_signed(document, authority["public_key_pem"])
    fields = {"schema_version", "package_type", "product", "revision", "authority_generation", "seed_protocol",
              "state_schema", "required_seed_capabilities", "worker_protocol", "hardware_profiles", "os_codenames",
              "archive", "files", "entrypoints", "enable_units"}
    if set(payload) != fields or type(payload["schema_version"]) is not int or payload["schema_version"] != SUPPORT_SCHEMA:
        raise SeedError("Unsupported signed support schema")
    if payload["package_type"] != "shotdeck-support" or payload["product"] != "shotdeck":
        raise SeedError("Wrong signed package type or product")
    integer(payload["revision"])
    if integer(payload["authority_generation"]) != authority["generation"]:
        raise SeedError("Support package names a different current authority generation")
    for field in ("seed_protocol", "worker_protocol"):
        bounds = payload[field]
        if not isinstance(bounds, dict) or set(bounds) != {"minimum", "maximum"} or integer(bounds["minimum"]) > integer(bounds["maximum"]):
            raise SeedError("Invalid support protocol interval")
    if not payload["seed_protocol"]["minimum"] <= seed_protocol <= payload["seed_protocol"]["maximum"]:
        raise SeedError("Support requires an incompatible seed protocol")
    if type(payload["state_schema"]) is not int or payload["state_schema"] != 1:
        raise SeedError("Unsupported support state schema; no implicit migration")
    required = payload["required_seed_capabilities"]
    if (not isinstance(required, list) or not required or len(required) > 16
            or any(not isinstance(item, str) for item in required) or len(set(required)) != len(required)
            or not set(required).issubset(seed_capabilities)):
        raise SeedError("Seed lacks a required repair capability")
    for field, selected in (("hardware_profiles", cohort["hardware_profile"]), ("os_codenames", cohort["os_codename"])):
        values = payload[field]
        if (not isinstance(values, list) or not 1 <= len(values) <= 32 or any(not isinstance(item, str)
                or not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", item) for item in values) or len(set(values)) != len(values)
                or selected not in values):
            raise SeedError("Support package is incompatible with this installed profile")
    artifact = payload["archive"]
    if not isinstance(artifact, dict) or set(artifact) != {"sha256", "size"}:
        raise SeedError("Invalid support archive identity")
    sha(artifact["sha256"]); integer(artifact["size"], 1, MAX_ARCHIVE)
    inventory = payload["files"]
    if not isinstance(inventory, dict) or not 1 <= len(inventory) <= MAX_FILES:
        raise SeedError("Support inventory is empty or exceeds bound")
    total = 0
    for name, record in inventory.items():
        mode = allowed_file(name)
        if not isinstance(record, dict) or set(record) != {"sha256", "size", "mode"}:
            raise SeedError("Invalid support file inventory")
        sha(record["sha256"]); integer(record["size"], 0, MAX_FILE)
        if type(record["mode"]) is not int or record["mode"] != mode:
            raise SeedError("Unsupported support file permissions")
        total += record["size"]
    if total > MAX_CONTENT: raise SeedError("Support expanded content exceeds bound")
    if payload["entrypoints"] != ENTRYPOINTS:
        raise SeedError("Support entrypoints must match the fixed seed dispatch contract")
    for component, module in ENTRYPOINTS.items():
        if module.replace(".", "/") + ".py" not in inventory or module.split(".")[0] + "/__init__.py" not in inventory:
            raise SeedError("Support generation is missing its complete entrypoint surface")
    for name in SCRIPT_NAMES:
        if "scripts/" + name not in inventory: raise SeedError("Support generation omits a fixed compatibility launcher")
    for name in UNIT_NAMES:
        if "systemd/" + name not in inventory: raise SeedError("Support generation omits a fixed service file")
    enabled = payload["enable_units"]
    if (not isinstance(enabled, list) or len(enabled) != len(set(enabled)) or not set(enabled).issubset(ENABLE_UNITS)
            or any("systemd/" + name not in inventory for name in enabled)):
        raise SeedError("Support enables a unit outside its signed safe inventory")
    return payload


def worker_contract(source):
    """Read declarations without executing candidate package code."""
    try: tree = ast.parse(source.decode("utf-8"))
    except (ValueError, UnicodeError, SyntaxError) as exc: raise SeedError("Invalid worker source") from exc
    found = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            name = node.targets[0].id
            if name in {"SUPPORT_REVISION", "PROTOCOL_VERSION"}:
                if name in found or not isinstance(node.value, ast.Constant) or type(node.value.value) is not int:
                    raise SeedError("Worker protocol declarations are ambiguous")
                found[name] = integer(node.value.value)
    if set(found) != {"SUPPORT_REVISION", "PROTOCOL_VERSION"}: raise SeedError("Worker protocol declarations are missing")
    return found
