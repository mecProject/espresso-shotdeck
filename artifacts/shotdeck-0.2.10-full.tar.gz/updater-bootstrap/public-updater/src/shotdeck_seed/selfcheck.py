"""Pure isolated compatibility checks; no live records, network or GPIO."""
from __future__ import annotations

import base64

from . import CAPABILITIES, SEED_PROTOCOL, STATE_SCHEMA
from .authority import verify_signed
from .manifest import allowed_file
from .storage import SeedError, canonical, decode, digest


def run():
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from shotdeck_recovery_portal import PROTOCOL_VERSION
    from shotdeck_recovery_portal.auth import validate_context
    from shotdeck_recovery_portal.protected import AccessError
    from shotdeck_recovery_gateway import PROTOCOL
    if SEED_PROTOCOL != STATE_SCHEMA or SEED_PROTOCOL != PROTOCOL_VERSION or PROTOCOL != 1:
        raise SeedError("Recovery components disagree on their initial protocol")
    context = {"peer_ip": "192.0.2.1", "host": "shotdeck.local:8081", "origin": "https://shotdeck.local:8081",
               "secure": True, "method": "POST"}
    validate_context(context, [context["host"]], mutating=True)
    for bad in ({"origin": ""}, {"origin": "https://unrelated.local"}, {"secure": False}, {"method": "GET"}):
        try: validate_context({**context, **bad}, [context["host"]], mutating=True)
        except AccessError: pass
        else: raise SeedError("Recovery authentication boundary probe failed")
    # Ephemeral test authority only; no device key, policy, floor or auth state
    # is read or written by this pre-selection probe.
    private = Ed25519PrivateKey.generate()
    public = private.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    payload = {"selfcheck": 1}
    document = {**payload, "signature": {"algorithm": "ed25519", "key_id": digest(public)[:16],
                "value": base64.b64encode(private.sign(canonical(payload))).decode()}}
    if verify_signed(document, public) != payload: raise SeedError("Independent signature verification failed")
    try: verify_signed({**document, "selfcheck": 2}, public)
    except SeedError: pass
    else: raise SeedError("Independent signature verifier accepted changed content")
    for path in ("shotdeck_seed/storage.py", "scripts/shotdeck_seed_gate.py", "../escape"):
        try: allowed_file(path)
        except SeedError: pass
        else: raise SeedError("Helpers could replace the independent fallback boundary")
    try: decode(b'{"field":1,"field":2}')
    except SeedError: pass
    else: raise SeedError("Ambiguous protected state was accepted")
    return {"seed_protocol": SEED_PROTOCOL, "state_schema": STATE_SCHEMA, "capabilities": sorted(CAPABILITIES),
            "auth_boundary": True, "signature_boundary": True, "fallback_boundary": True}
