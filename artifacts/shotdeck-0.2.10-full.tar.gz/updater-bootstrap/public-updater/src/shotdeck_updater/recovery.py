"""Bounded stopped-application recovery with durable, one-use start authority.

Native safety is an explicit port: this module never treats missing health,
ownership of a brew lock, or a stale observation as safe hardware. Callers hold
the updater/brew/signing exclusions appropriate to their validated operation.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
import fcntl
import os
from pathlib import Path
import re
import stat
from uuid import uuid4

from shotdeck_security.storage import (
    MigrationError, boot_id, canonical, digest, directory, read, read_json,
    remove, version, write_json,
)

from .errors import InstallError

RECOVERY_PROTOCOL = 1
MAX_QUARANTINE = 256
_HEX = re.compile(r"[0-9a-f]{64}\Z")
_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._+\-]{0,199}\Z")
_PHASES = {"latched", "validated", "stopped", "attempt_started", "selected",
           "permit_issued", "started", "healthy", "completed", "failed"}
_STATE_FIELDS = {"schema_version", "incident_id", "authority_id", "reason", "failed", "target",
                 "activation_transaction_id", "phase", "latched", "attempts", "attempt_boot",
                 "owner", "capability_sha256", "error_code"}
_OWNER_FIELDS = {"pid", "start_ticks", "lock_fd", "lock_device", "lock_inode"}


class RecoveryError(InstallError):
    """Recovery cannot proceed without violating its durable safety contract."""


def _present(path):
    return os.path.lexists(path)


def _fields(value, fields, label):
    if not isinstance(value, dict) or set(value) != set(fields):
        raise RecoveryError(f"Invalid {label} fields")


def _sha(value):
    if not isinstance(value, str) or not _HEX.fullmatch(value):
        raise RecoveryError("Invalid recovery digest")
    return value


def validate_identity(value):
    _fields(value, {"directory", "version", "tree_sha256"}, "recovery release identity")
    if (not isinstance(value["directory"], str) or not _NAME.fullmatch(value["directory"])
            or not isinstance(value["version"], str) or len(value["version"]) > 80
            or str(version(value["version"])) != value["version"]):
        raise RecoveryError("Invalid recovery release identity")
    _sha(value["tree_sha256"])
    return value


def _validate_owner(owner):
    _fields(owner, _OWNER_FIELDS, "recovery owner")
    if any(type(owner[name]) is not int or owner[name] < (1 if name in {"pid", "start_ticks", "lock_inode"} else 0)
           for name in _OWNER_FIELDS):
        raise RecoveryError("Invalid recovery process identity")
    return owner


def _start_ticks(pid):
    # The command field may contain spaces and ')'; fields after its last ')'
    # begin at field 3. Linux process starttime is field 22.
    payload = read(Path(f"/proc/{pid}/stat"), 16384, protected=False).decode()
    return int(payload[payload.rfind(")") + 2:].split()[19])


def process_owner(descriptor):
    metadata = os.fstat(descriptor)
    try:
        ticks = _start_ticks(os.getpid())
    except FileNotFoundError:
        if os.uname().sysname == "Linux":
            raise
        # Development hosts may record journals, but this sentinel is never
        # admitted by owner_is_alive without Linux process/lease observations.
        ticks = 1
    return {"pid": os.getpid(), "start_ticks": ticks,
            "lock_fd": descriptor, "lock_device": metadata.st_dev, "lock_inode": metadata.st_ino}


def owner_is_alive(owner, lock_path):
    """The exact process still owns an open descriptor and an exclusive lease."""
    descriptor = None
    try:
        _validate_owner(owner)
        if _start_ticks(owner["pid"]) != owner["start_ticks"]:
            return False
        path = Path(lock_path)
        metadata = path.stat(follow_symlinks=False)
        opened = Path(f"/proc/{owner['pid']}/fd/{owner['lock_fd']}").stat()
        expected = (owner["lock_device"], owner["lock_inode"])
        if (not stat.S_ISREG(metadata.st_mode) or (metadata.st_dev, metadata.st_ino) != expected
                or (opened.st_dev, opened.st_ino) != expected):
            return False
        # A blocked flock probe alone proves only that *some* process owns the
        # inode. The original process could have unlocked its still-open fd
        # while another owner acquired it. Linux fdinfo binds the actual lease
        # to this open description, locking PID and device/inode.
        leases = read(Path(f"/proc/{owner['pid']}/fdinfo/{owner['lock_fd']}"), 16384,
                      protected=False).decode().splitlines()
        exact = False
        for line in leases:
            fields = line.split()
            if len(fields) != 9 or fields[0] != "lock:" or fields[2:5] != ["FLOCK", "ADVISORY", "WRITE"]:
                continue
            device = fields[6].split(":")
            if (len(device) == 3 and int(fields[5]) == owner["pid"]
                    and (int(device[0], 16), int(device[1], 16), int(device[2]))
                    == (os.major(owner["lock_device"]), os.minor(owner["lock_device"]), owner["lock_inode"])
                    and fields[7:] == ["0", "EOF"]):
                exact = True
        if not exact:
            return False
        descriptor = os.open(path, os.O_RDWR | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0))
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return True
        return False
    except (OSError, ValueError, IndexError, RecoveryError):
        return False
    finally:
        if descriptor is not None:
            os.close(descriptor)


@contextmanager
def _lock(path):
    directory(path.parent)
    fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        metadata = os.fstat(fd)
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_uid != os.geteuid() or metadata.st_mode & 0o022:
            raise RecoveryError("Invalid protected recovery lock")
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RecoveryError("Recovery ownership is busy") from exc
        yield fd
    finally:
        os.close(fd)


class RecoveryStore:
    """One exact recovery attempt per failed release; no toggling rollback."""

    def __init__(self, config, *, boot=boot_id, checkpoint=lambda stage: None, owner_factory=process_owner):
        self.config = config
        self.root = config.state_root / "recovery"
        self.path = self.root / "state.json"
        self.enrolled = self.root / "enrolled.json"
        self.permit = self.root / "permit.json"
        self.execution_lock = self.root / "execution.lock"
        self.record_lock = self.root / "record.lock"
        self.quarantine = self.root / "quarantine.json"
        self.receipts = self.root / "receipts"
        self.boot = boot
        self.checkpoint = checkpoint
        self.owner_factory = owner_factory

    def _read(self):
        if _present(self.root) and (self.root.is_symlink() or not self.root.is_dir()):
            raise RecoveryError("Aliased or invalid recovery directory")
        if not any(_present(path) for path in (self.enrolled, self.path, self.permit)):
            if _present(self.quarantine) or _present(self.receipts):
                raise RecoveryError("Recovery state is missing beside durable recovery evidence")
            return None
        try:
            if self.root.is_symlink():
                raise RecoveryError("Aliased recovery directory")
            enrolled = read_json(self.enrolled)
            if enrolled != {"schema_version": RECOVERY_PROTOCOL} or type(enrolled["schema_version"]) is not int:
                raise RecoveryError("Invalid recovery enrollment")
            envelope = read_json(self.path)
            _fields(envelope, {"record", "sha256"}, "recovery state envelope")
            state = envelope["record"]
            if digest(canonical(state)) != _sha(envelope["sha256"]):
                raise RecoveryError("Recovery state checksum differs")
            _fields(state, _STATE_FIELDS, "recovery state")
            if (type(state["schema_version"]) is not int or state["schema_version"] != RECOVERY_PROTOCOL
                    or state["phase"] not in _PHASES or type(state["latched"]) is not bool
                    or state["latched"] != (state["phase"] != "completed")
                    or type(state["attempts"]) is not int or state["attempts"] not in {0, 1}
                    or state["reason"] not in {"startup_failure", "startup_unready", "interrupted_activation", "manual_recovery"}
                    or not isinstance(state["attempt_boot"], str) or len(state["attempt_boot"]) > 128
                    or not isinstance(state["error_code"], str) or len(state["error_code"]) > 80
                    or not isinstance(state["activation_transaction_id"], str)
                    or (state["activation_transaction_id"] and re.fullmatch(r"[0-9a-f]{32}", state["activation_transaction_id"]) is None)):
                raise RecoveryError("Invalid recovery state")
            for name in ("incident_id", "authority_id"):
                _sha(state[name])
            validate_identity(state["failed"])
            validate_identity(state["target"])
            if state["owner"] is not None:
                _validate_owner(state["owner"])
            if state["capability_sha256"]:
                _sha(state["capability_sha256"])
            if (state["attempts"] == 0 and state["phase"] not in {"latched", "validated", "stopped"}
                    or state["attempts"] == 1 and (not state["attempt_boot"] or not state["capability_sha256"])):
                raise RecoveryError("Recovery attempt record is inconsistent")
            if state["attempts"] and self._quarantined().get(self._release_key(state["failed"])) != state["incident_id"]:
                raise RecoveryError("Recovery quarantine is missing the consumed attempt")
            if state["phase"] == "completed":
                self._completed_receipt(state)
            return state
        except (OSError, ValueError, KeyError, TypeError, MigrationError) as exc:
            raise RecoveryError("Recovery state requires protected review") from exc

    def _write(self, state, label):
        with _lock(self.record_lock):
            write_json(self.path, {"record": state, "sha256": digest(canonical(state))},
                       lambda step: self.checkpoint(label + "_" + step))

    def status(self):
        state = self._read()
        if state is None:
            return {"schema_version": RECOVERY_PROTOCOL, "phase": "unused", "latched": False,
                    "incident_id": None, "attempts": 0}
        return deepcopy(state)

    @staticmethod
    def _release_key(identity):
        validate_identity(identity)
        return digest(canonical({name: identity[name] for name in ("version", "tree_sha256")}))

    def _quarantined(self):
        if not _present(self.quarantine):
            return {}
        try:
            value = read_json(self.quarantine)
            _fields(value, {"schema_version", "releases"}, "recovery quarantine")
            entries = value["releases"]
            if type(value["schema_version"]) is not int or value["schema_version"] != 1 or not isinstance(entries, dict) or len(entries) > MAX_QUARANTINE:
                raise RecoveryError("Invalid bounded recovery quarantine")
            for key, incident in entries.items():
                _sha(key); _sha(incident)
            return entries
        except (OSError, ValueError, TypeError) as exc:
            raise RecoveryError("Recovery quarantine requires protected review") from exc

    def assert_offer_allowed(self, identity):
        if self._release_key(identity) in self._quarantined():
            raise RecoveryError("This failed release is quarantined; use a newer authorized release or reviewed recovery")

    def _completed_receipt(self, state):
        value = read_json(self.receipts / (state["incident_id"] + ".json"))
        expected = {"schema_version": RECOVERY_PROTOCOL, "incident_id": state["incident_id"],
            "authority_id": state["authority_id"], "failed": state["failed"], "target": state["target"],
            "activation_transaction_id": state["activation_transaction_id"], "outcome": "recovered",
            "attempts": 1, "boot_id": state["attempt_boot"], "capability_sha256": state["capability_sha256"]}
        if value != expected or type(value.get("schema_version")) is not int or type(value.get("attempts")) is not int:
            raise RecoveryError("Completed recovery lacks its exact durable receipt")
        return value

    def completion_evidence(self, incident_id, transaction_id, target_identity, receipt_sha256,
                            *, allow_historical=False):
        """Verify durable completion authority without needing a live capability.

        A journal can be reconciled just before core unlatching, so its matching
        healthy phase is valid evidence while the independent latch still blocks
        normal starts. Historical receipts survive later recovery incidents and
        capability expiry; their quarantine binding and current core state must
        remain intact. Creating reconciliation uses the current incident only.
        """
        _sha(incident_id); _sha(receipt_sha256); validate_identity(target_identity)
        if not isinstance(transaction_id, str) or re.fullmatch(r"[0-9a-f]{32}", transaction_id) is None:
            raise RecoveryError("Invalid activation identity for recovery completion")
        state = self._read()
        if state is None:
            raise RecoveryError("Recovery completion has no durable recovery state")
        try:
            receipt = read_json(self.receipts / (incident_id + ".json"))
        except (OSError, MigrationError) as exc:
            raise RecoveryError("Recovery completion receipt is missing or invalid") from exc
        _fields(receipt, {"schema_version", "incident_id", "authority_id", "failed", "target",
            "activation_transaction_id", "outcome", "attempts", "boot_id", "capability_sha256"}, "recovery receipt")
        validate_identity(receipt["failed"]); validate_identity(receipt["target"])
        _sha(receipt["authority_id"]); _sha(receipt["capability_sha256"])
        if (type(receipt["schema_version"]) is not int or receipt["schema_version"] != RECOVERY_PROTOCOL
                or receipt["incident_id"] != incident_id or receipt["activation_transaction_id"] != transaction_id
                or receipt["target"] != target_identity or receipt["outcome"] != "recovered"
                or type(receipt["attempts"]) is not int or receipt["attempts"] != 1
                or not isinstance(receipt["boot_id"], str) or not 1 <= len(receipt["boot_id"]) <= 128
                or digest(canonical(receipt)) != receipt_sha256
                or self._quarantined().get(self._release_key(receipt["failed"])) != incident_id):
            raise RecoveryError("Recovery receipt does not authorize this activation completion")
        if state["incident_id"] == incident_id:
            if state["phase"] not in {"healthy", "completed"} or state["attempts"] != 1:
                raise RecoveryError("Recovery has not durably verified a healthy target")
            if self._completed_receipt(state) != receipt:
                raise RecoveryError("Recovery receipt differs from the current incident")
        elif not allow_historical:
            raise RecoveryError("A different recovery incident owns completion")
        return deepcopy(state), deepcopy(receipt)

    def begin(self, failed_identity, target_identity, authority_id, reason, *, activation_transaction_id=""):
        failed, target = deepcopy(failed_identity), deepcopy(target_identity)
        validate_identity(failed); validate_identity(target); _sha(authority_id)
        if reason not in {"startup_failure", "startup_unready", "interrupted_activation", "manual_recovery"}:
            raise RecoveryError("Unsupported recovery reason")
        if activation_transaction_id and re.fullmatch(r"[0-9a-f]{32}", activation_transaction_id) is None:
            raise RecoveryError("Invalid activation transaction identity")
        if self._release_key(failed) == self._release_key(target):
            raise RecoveryError("Recovery needs a different verified target")
        incident = digest(canonical({"failed": self._release_key(failed), "authority_id": authority_id,
            "activation_transaction_id": activation_transaction_id, "reason": reason}))
        with _lock(self.record_lock):
            existing = self._read()
            if existing is not None and existing["latched"]:
                if (existing["incident_id"] == incident and existing["failed"] == failed and existing["target"] == target):
                    return incident
                raise RecoveryError("A different recovery incident is already latched")
            self.assert_offer_allowed(failed)
            self.assert_offer_allowed(target)
            state = {"schema_version": RECOVERY_PROTOCOL, "incident_id": incident, "authority_id": authority_id,
                "reason": reason, "failed": failed, "target": target, "activation_transaction_id": activation_transaction_id,
                "phase": "latched", "latched": True, "attempts": 0, "attempt_boot": "", "owner": None,
                "capability_sha256": "", "error_code": ""}
            if not _present(self.enrolled):
                write_json(self.enrolled, {"schema_version": RECOVERY_PROTOCOL},
                           lambda step: self.checkpoint("recovery_enrolled_" + step))
            write_json(self.path, {"record": state, "sha256": digest(canonical(state))},
                       lambda step: self.checkpoint("recovery_latched_" + step))
        return incident

    def revoke_permit(self):
        with _lock(self.record_lock):
            if _present(self.permit):
                remove(self.permit)
                self.checkpoint("recovery_permit_revoked")

    def check_start(self, target_identity=None, *, owner_alive=None, consume=True):
        with _lock(self.record_lock):
            state = self._read()
            if state is None or not state["latched"]:
                if _present(self.permit):
                    raise RecoveryError("An orphaned recovery start permit requires review")
                return True
            if not _present(self.permit):
                return False
            try:
                value = read_json(self.permit)
                _fields(value, {"schema_version", "incident_id", "target", "boot_id", "owner", "nonce"}, "controlled-start permit")
                validate_identity(value["target"]); _validate_owner(value["owner"])
                valid = (type(value["schema_version"]) is int and value["schema_version"] == 1
                    and value["incident_id"] == state["incident_id"] and value["target"] == state["target"] == target_identity
                    and value["boot_id"] == state["attempt_boot"] == self.boot()
                    and value["owner"] == state["owner"] and state["phase"] == "permit_issued"
                    and isinstance(value["nonce"], str) and re.fullmatch(r"[0-9a-f]{32}", value["nonce"]) is not None
                    and (owner_alive(value["owner"]) if owner_alive else owner_is_alive(value["owner"], self.execution_lock)))
                if not valid:
                    return False
                if consume:
                    remove(self.permit)
                    self.checkpoint("recovery_permit_consumed")
                return True
            except (OSError, ValueError, TypeError, KeyError) as exc:
                raise RecoveryError("Invalid controlled recovery start permit") from exc

    def _validate(self, port, state):
        proof = port.verify_capability(deepcopy(state))
        _fields(proof, {"authority_id", "capability_sha256", "scope", "recovery_enabled"}, "recovery capability")
        if (proof["authority_id"] != state["authority_id"] or proof["scope"] not in {"workshop", "customer"}
                or proof["recovery_enabled"] is not True):
            raise RecoveryError("Recovery mutation is not authorized by the qualified runtime capability")
        _sha(proof["capability_sha256"])
        if state["capability_sha256"] and proof["capability_sha256"] != state["capability_sha256"]:
            raise RecoveryError("Recovery capability changed during the incident")
        self.assert_offer_allowed(state["target"])
        port.assert_no_conflicts(deepcopy(state))
        port.verify_target(deepcopy(state))
        return proof["capability_sha256"]

    def _finish(self, port, state):
        if state["attempt_boot"] != self.boot():
            raise RecoveryError("An interrupted recovery cannot manufacture a new-boot start observation")
        port.verify_selected(deepcopy(state))
        port.health_check(deepcopy(state))
        state.update(phase="healthy", error_code="")
        self._write(state, "recovery_healthy")
        receipt = {"schema_version": RECOVERY_PROTOCOL, "incident_id": state["incident_id"],
            "authority_id": state["authority_id"], "failed": state["failed"], "target": state["target"],
            "activation_transaction_id": state["activation_transaction_id"], "outcome": "recovered",
            "attempts": 1, "boot_id": self.boot(), "capability_sha256": state["capability_sha256"]}
        path = self.receipts / (state["incident_id"] + ".json")
        if _present(path):
            existing = read_json(path)
            if existing != receipt:
                raise RecoveryError("Recovery receipt conflicts with this exact completion")
        else:
            write_json(path, receipt, lambda step: self.checkpoint("recovery_receipt_" + step))
        port.complete_activation(deepcopy(state), deepcopy(receipt))
        self.checkpoint("recovery_activation_reconciled")
        state.update(phase="completed", latched=False, owner=None)
        self._write(state, "recovery_completed")
        return deepcopy(receipt)

    def execute(self, port):
        """Attempt the selected target once; an uncertain attempt never restarts."""
        with _lock(self.execution_lock) as descriptor:
            state = self._read()
            if state is None or not state["latched"]:
                raise RecoveryError("No latched recovery is pending")
            if state["attempts"]:
                raise RecoveryError("The recovery attempt was already consumed; reconcile its observed outcome")
            self.revoke_permit()
            state["owner"] = _validate_owner(self.owner_factory(descriptor))
            try:
                state["capability_sha256"] = self._validate(port, state)
                state["phase"] = "validated"
                self._write(state, "recovery_validated")
                port.stop(deepcopy(state))
                port.assert_stopped(deepcopy(state))
                port.assert_safe_outputs(deepcopy(state))
                # Safety/target observations are live admissions, not reusable
                # flags. Recheck before consuming the single mutation attempt.
                self._validate(port, state)
                state["phase"] = "stopped"
                self._write(state, "recovery_stopped")
                entries = self._quarantined()
                key = self._release_key(state["failed"])
                if key not in entries and len(entries) >= MAX_QUARANTINE:
                    raise RecoveryError("Recovery quarantine is full; preserve and review its evidence")
                entries[key] = state["incident_id"]
                write_json(self.quarantine, {"schema_version": 1, "releases": entries},
                           lambda step: self.checkpoint("recovery_quarantine_" + step))
                state.update(phase="attempt_started", attempts=1, attempt_boot=self.boot())
                self._write(state, "recovery_attempt")
                port.select_target(deepcopy(state))
                port.verify_selected(deepcopy(state))
                state["phase"] = "selected"
                self._write(state, "recovery_selected")
                port.assert_stopped(deepcopy(state)); port.assert_safe_outputs(deepcopy(state))
                state["phase"] = "permit_issued"
                self._write(state, "recovery_start_intent")
                permit = {"schema_version": 1, "incident_id": state["incident_id"], "target": state["target"],
                          "boot_id": state["attempt_boot"], "owner": state["owner"], "nonce": uuid4().hex}
                with _lock(self.record_lock):
                    write_json(self.permit, permit, lambda step: self.checkpoint("recovery_permit_" + step))
                port.start(deepcopy(state))
                if _present(self.permit):
                    raise RecoveryError("Controlled start did not consume its protected admission permit")
                state["phase"] = "started"
                self._write(state, "recovery_started")
                return self._finish(port, state)
            except Exception:
                self.revoke_permit()
                if state["attempts"]:
                    state.update(phase="failed", latched=True, error_code="recovery_attempt_failed")
                    self._write(state, "recovery_failed")
                    port.stop(deepcopy(state))
                    port.assert_stopped(deepcopy(state)); port.assert_safe_outputs(deepcopy(state))
                else:
                    state.update(phase="latched", owner=None, error_code="recovery_admission_refused")
                    self._write(state, "recovery_refused")
                raise

    def reconcile(self, port, *, resume=False):
        """Observe an interrupted attempt; never execute a second target start.

        Read-only default provides a plan. Explicit reconciliation may finish a
        verified running target, or stop it and retain the latch. A pre-attempt
        incident may re-run full admission when ``resume`` is requested.
        """
        state = self._read()
        if state is None or not state["latched"]:
            return self.status()
        if not resume:
            return {**deepcopy(state), "next_action": "revalidate_admission" if not state["attempts"] else "verify_running_target_or_remain_latched"}
        if not state["attempts"]:
            return self.execute(port)
        with _lock(self.execution_lock):
            self.revoke_permit()
            state = self._read()
            self._validate(port, state)
            try:
                if state["attempt_boot"] != self.boot():
                    raise RecoveryError("Recovery was interrupted by reboot")
                port.verify_selected(deepcopy(state))
                port.health_check(deepcopy(state))
            except Exception:
                port.stop(deepcopy(state))
                port.assert_stopped(deepcopy(state)); port.assert_safe_outputs(deepcopy(state))
                state.update(phase="failed", latched=True, owner=None, error_code="recovery_interrupted")
                self._write(state, "recovery_interrupted")
                return deepcopy(state)
            return self._finish(port, state)
