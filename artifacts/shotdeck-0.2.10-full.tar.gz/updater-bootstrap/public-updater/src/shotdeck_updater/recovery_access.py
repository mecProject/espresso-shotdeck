"""Physical temporary recovery entry with a durable, one-use return permit.

This is separate from rollback: it never changes the selected application.
Only the verified gateway executor can request entry. An interrupted return
retains its latch and cannot turn a process restart into an implicit retry.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import uuid

from shotdeck_security.storage import guard
from shotdeck_recovery_gateway import environment as env
from shotdeck_recovery_gateway.barrier import assert_clear
from shotdeck_recovery_gateway.records import canonical, envelope, lock, remove, save, directory

from .activation import ActivationJournal, assert_no_conflicting_transaction
from .config import DEFAULT_CONFIG_PATH, UpdaterConfig
from .locking import exclusive_lock
from .recovery import RecoveryError, RecoveryStore, process_owner, owner_is_alive, validate_identity, _validate_owner
from .recovery_native import NativeRecoveryPort, assert_service_stopped, selected_identity
from . import recovery_safety as safety

ROOT = Path("/var/lib/shotdeck/recovery-access")
LATCH = ROOT / "access-latch.json"
LEASE = ROOT / "access-execution.lock"


def capability():
    value = env.require_support_qualified(fresh=True)
    return hashlib.sha256(canonical(value)).hexdigest()


def passive(config, *, start_condition=False):
    capability()
    safety._verify_topology(config)
    return safety.observe_connected_controls(config, start_condition=start_condition)


def read_latch():
    value = envelope(LATCH)
    if (set(value) != {"schema_version", "id", "phase", "identity", "data", "capability_sha256", "owner", "boot_id"}
            or type(value["schema_version"]) is not int or value["schema_version"] != 1
            or value["phase"] not in {"stopping", "stopped", "permit", "starting", "interrupted"}
            or not isinstance(value["id"], str) or not re.fullmatch(r"[0-9a-f]{32}", value["id"])
            or not isinstance(value["boot_id"], str) or not re.fullmatch(r"[0-9a-f-]{36}", value["boot_id"])
            or not isinstance(value["capability_sha256"], str) or not re.fullmatch(r"[0-9a-f]{64}", value["capability_sha256"])):
        raise RecoveryError("Recovery access latch needs attended review")
    validate_identity(value["identity"])
    if value["owner"] is not None:
        _validate_owner(value["owner"])
    if value["phase"] in {"stopping", "permit", "starting"} and value["owner"] is None:
        raise RecoveryError("Recovery access ownership is missing")
    data = value["data"]
    if data is None:
        if value["phase"] not in {"stopping", "interrupted"}:
            raise RecoveryError("Recovery access stopped-data contract is missing")
    else:
        safety._fields(data, {"contract", "history_schema", "history_schema_sha256", "files"}, "access data contract")
        if data["contract"] != safety.DATA_CONTRACT or type(data["history_schema"]) is not int or data["history_schema"] != 3:
            raise RecoveryError("Recovery access data format is unknown")
        safety._sha(data["history_schema_sha256"])
        safety._fields(data["files"], safety.DATA_FILES, "access data file contract")
        for identity in data["files"].values():
            if identity is not None:
                safety._sha(identity)
    return value


def no_native_incident(config):
    if RecoveryStore(config).status()["latched"] or ActivationJournal(config).inspect()["recovery_required"]:
        raise RecoveryError("An application recovery incident owns this installation")
    assert_no_conflicting_transaction(config)


def start_allowed(config):
    if not os.path.lexists(LATCH):
        return True
    value = read_latch()
    # A separately qualified native rollback has its own one-use permit,
    # consumed by the existing B start gate. Never consume it twice here.
    store = RecoveryStore(config)
    state = store.status()
    if state["latched"] and state["phase"] == "permit_issued":
        from .recovery_customer import load_capability
        _payload, proof = load_capability(config, state=state)
        if proof["capability_sha256"] == state["capability_sha256"]:
            return store.check_start(selected_identity(config), consume=False)
    if (value["phase"] != "permit" or value["boot_id"] != env.boot_id()
            or not owner_is_alive(value["owner"], LEASE)):
        return False
    no_native_incident(config)
    if (value["capability_sha256"] != capability() or selected_identity(config) != value["identity"]
            or safety.data_contract(config) != value["data"]):
        raise RecoveryError("Recovery access return identity or data changed")
    passive(config, start_condition=True)
    save(LATCH, {**value, "phase": "starting"})
    return True


def operate(config, action):
    if action not in {"enter", "resume", "start", "boot"}:
        raise RecoveryError("Unknown physical recovery action")
    if action == "start":
        return {"allowed": start_allowed(config)}
    directory(ROOT)
    if action == "boot":
        if os.path.lexists(LATCH):
            value = read_latch()
            if value["phase"] in {"permit", "starting", "stopping"}:
                save(LATCH, {**value, "phase": "interrupted", "owner": None})
        return {"latched": os.path.lexists(LATCH)}
    with ExitStack() as locks:
        locks.enter_context(exclusive_lock(config.lock_path))
        locks.enter_context(exclusive_lock(Path("/run/lock/shotdeck-backup-restore.lock")))
        locks.enter_context(exclusive_lock(config.brew_lock_path))
        locks.enter_context(guard(config.migration_root))
        lease = locks.enter_context(lock(LEASE))
        assert_clear(allow_owned=True, access_latch=False)
        no_native_incident(config)
        port = NativeRecoveryPort(config)
        if action == "enter":
            if os.path.lexists(LATCH):
                raise RecoveryError("Recovery access is already latched")
            health = env.health()
            if health.get("status") != "ready" or health.get("control_ready") is not True or health.get("brew_active") is not False:
                raise RecoveryError("Shotdeck must be ready and idle for physical recovery entry")
            identity = selected_identity(config)
            value = {"schema_version": 1, "id": uuid.uuid4().hex, "phase": "stopping", "identity": identity,
                "data": None, "capability_sha256": capability(), "owner": process_owner(lease), "boot_id": env.boot_id()}
            passive(config)
            save(LATCH, value)  # restart inhibition is durable before stopping
            port.service.stop()
            assert_service_stopped(port.show())
            passive(config)
            save(LATCH, {**value, "phase": "stopped", "data": safety.data_contract(config), "owner": None})
            return {"entered": True, "access_id": value["id"]}
        value = read_latch()
        if value["phase"] != "stopped" or value["data"] is None:
            raise RecoveryError("Interrupted recovery access requires attended review")
        assert_service_stopped(port.show())
        if (value["capability_sha256"] != capability() or selected_identity(config) != value["identity"]
                or safety.data_contract(config) != value["data"]):
            raise RecoveryError("Selected application or shared data changed during recovery access")
        # Same authenticated target, same licence, same format; no update or
        # application migration is performed by temporary entry/return.
        port.verify_target({"target": value["identity"]})
        passive(config)
        from shotdeck_recovery_access.network import RecoveryNetwork
        RecoveryNetwork().restore(held_activity=True)
        value = {**value, "phase": "permit", "owner": process_owner(lease), "boot_id": env.boot_id()}
        save(LATCH, value)
        try:
            port.service.start()
            if read_latch()["phase"] != "starting":
                raise RecoveryError("Application did not consume its one-use access permit")
            port.health_check({"target": value["identity"]})
            receipts = directory(ROOT / "access-receipts")
            receipt = {"schema_version": 1, "access_id": value["id"], "identity": value["identity"],
                "outcome": "returned", "boot_id": env.boot_id()}
            save(receipts / (value["id"] + ".json"), receipt)
            remove(LATCH)
            return receipt
        except BaseException:
            save(LATCH, {**value, "phase": "interrupted", "owner": None})
            # Never stop/restart a partially started application by inference.
            raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("enter", "resume", "start", "boot"))
    args = parser.parse_args(argv)
    try:
        if os.geteuid() != 0:
            raise RecoveryError("Protected recovery access requires root")
        result = operate(UpdaterConfig.from_file(DEFAULT_CONFIG_PATH), args.command)
        print(json.dumps(result, sort_keys=True))
        return 1 if result.get("allowed") is False else 0
    except Exception as exc:
        print(json.dumps({"blocked": str(exc)}), file=__import__("sys").stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
