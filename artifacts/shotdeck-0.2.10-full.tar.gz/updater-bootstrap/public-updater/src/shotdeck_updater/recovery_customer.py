"""Customer recovery authority, disabled until an exact signed qualification.

No capability is created by installation. Customer recovery shares the durable
one-attempt engine with workshop recovery, but never its disconnected-machine
exception. Local settings are captured only after complete service cessation;
the release-wide capability signs schema compatibility, not private data.
"""
from __future__ import annotations

import argparse
import base64
import json
import os
from pathlib import Path
import re
import sys

from shotdeck_security.storage import canonical, digest, unique, version, write_json, read
from shotdeck_security.updates import UpdateStore, tree_digest, MARKER

from .config import DEFAULT_CONFIG_PATH, UpdaterConfig
from .hardware import LEGACY_ID, assert_hardware_compatible
from .identity import collect_identity
from .recovery import RecoveryError, RecoveryStore, validate_identity
from .recovery_native import NativeRecoveryPort, assert_service_stopped, selected_identity
from . import recovery_safety as safety

DOMAIN = b"shotdeck-customer-recovery-capability-v1\0"
MAX_CAPABILITY_SECONDS = 366 * 86400
CHECKS = frozenset({"connected_safe_gpio", "retained_target_licence", "unchanged_data_format",
    "one_attempt", "power_cut", "startup_failure", "startup_unready", "missing_current",
    "corrupt_current", "one_app_restart", "connected_machine"})
FIELDS = {"schema_version", "capability_id", "scope", "issued_at", "expires_at",
    "authority_id", "policy_sha256", "runtime_sha256", "failed", "target",
    "device_fingerprint", "board", "os_codename", "hardware_profile", "topology", "data",
    "seed_sha256", "support_manifest_sha256", "seed_protocol", "support_protocol", "qualification_sha256", "checks", "reviewed_by"}


class CapabilityOutsideWindow(RecoveryError):
    """Valid signed qualification is not currently usable; never enables work."""


def validate_payload(payload):
    safety._fields(payload, FIELDS, "customer recovery capability")
    if (type(payload["schema_version"]) is not int or payload["schema_version"] != 1
            or payload["scope"] != "customer" or len(canonical(payload)) > safety.MAX_DOCUMENT_BYTES
            or not isinstance(payload["capability_id"], str)
            or not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,95}", payload["capability_id"])
            or not isinstance(payload["reviewed_by"], str)
            or not 1 <= len(payload["reviewed_by"].strip()) <= 200):
        raise RecoveryError("Invalid reviewed customer recovery capability")
    for name in ("authority_id", "policy_sha256", "runtime_sha256", "seed_sha256", "qualification_sha256"):
        safety._sha(payload[name])
    if payload["device_fingerprint"] is not None:
        safety._sha(payload["device_fingerprint"])
    if payload["support_manifest_sha256"] is not None:
        safety._sha(payload["support_manifest_sha256"])
    failed, target = validate_identity(payload["failed"]), validate_identity(payload["target"])
    if failed["tree_sha256"] == target["tree_sha256"] or failed["version"] == target["version"]:
        raise RecoveryError("Customer recovery requires distinct exact release identities")
    if (payload["board"] != safety.BOARD or payload["os_codename"] != "trixie"
            or payload["hardware_profile"] != LEGACY_ID or payload["topology"] != safety.TOPOLOGY
            or any(type(payload["topology"].get(key)) is not type(value) for key, value in safety.TOPOLOGY.items())):
        raise RecoveryError("Connected recovery hardware has not been qualified")
    for name in ("seed_protocol", "support_protocol"):
        if type(payload[name]) is not int or payload[name] != 1:
            raise RecoveryError("Customer recovery protocol is not supported")
    safety._fields(payload["checks"], CHECKS, "customer qualification checks")
    if any(value is not True for value in payload["checks"].values()):
        raise RecoveryError("Customer recovery qualification is incomplete")
    data = payload["data"]
    safety._fields(data, {"contract", "history_schema", "history_schema_sha256"}, "customer schema contract")
    if (data["contract"] != safety.DATA_CONTRACT or type(data["history_schema"]) is not int
            or data["history_schema"] != 3):
        raise RecoveryError("Customer recovery requires the unchanged shared data format")
    safety._sha(data["history_schema_sha256"])
    issued, expires = safety._timestamp(payload["issued_at"]), safety._timestamp(payload["expires_at"])
    if not 0 < expires - issued <= MAX_CAPABILITY_SECONDS:
        raise RecoveryError("Invalid customer recovery capability lifetime")
    return payload


def sign_capability(payload, private_key):
    """Host signing primitive; this never infers qualification or enables it."""
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    validate_payload(payload)
    if not isinstance(private_key, Ed25519PrivateKey):
        raise RecoveryError("Customer recovery requires the active Ed25519 authority")
    pem = private_key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    return {**payload, "signature": {"algorithm": "ed25519", "key_id": digest(pem)[:16],
        "value": base64.b64encode(private_key.sign(DOMAIN + canonical(payload))).decode("ascii")}}


def verify_capability(document, public_key):
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    safety._fields(document, FIELDS | {"signature"}, "signed customer capability")
    payload = validate_payload({key: value for key, value in document.items() if key != "signature"})
    signature = document["signature"]
    safety._fields(signature, {"algorithm", "key_id", "value"}, "customer capability signature")
    try:
        key = serialization.load_pem_public_key(public_key)
        raw = base64.b64decode(signature["value"], validate=True)
        if (not isinstance(key, Ed25519PublicKey) or signature["algorithm"] != "ed25519"
                or signature["key_id"] != digest(public_key)[:16] or len(raw) != 64
                or base64.b64encode(raw).decode("ascii") != signature["value"]):
            raise ValueError()
        key.verify(raw, DOMAIN + canonical(payload))
    except (InvalidSignature, ValueError, TypeError) as exc:
        raise RecoveryError("Customer recovery capability does not match the active authority") from exc
    return payload


def load_capability(config, state=None):
    document = safety._root_json(config.state_root / "recovery/customer-capability.json")
    active = UpdateStore(config.migration_root, config.install_root, config.manifest_security_state_file).active()
    if active is None:
        raise RecoveryError("Customer recovery requires enrolled signed update authority")
    payload = verify_capability(document, active["policy"]["public_key_pem"].encode())
    try:
        safety._window(payload, MAX_CAPABILITY_SECONDS)
    except RecoveryError as exc:
        raise CapabilityOutsideWindow("Customer recovery qualification is expired or not yet active") from exc
    authority = digest(canonical(active))
    runtime = Path(active["runtime"]).resolve(strict=True)
    if (payload["authority_id"] != authority or payload["policy_sha256"] != digest(canonical(active["policy"]))
            or payload["runtime_sha256"] != active["runtime_sha256"] or safety._runtime_path() != runtime):
        raise RecoveryError("Customer recovery belongs to different policy or pinned runtime")
    if (payload["device_fingerprint"] is not None
            and collect_identity(config.identity_policy).device_fingerprint != payload["device_fingerprint"]):
        raise RecoveryError("Customer recovery belongs to a different device")
    safety._verify_topology(config)
    from shotdeck_recovery_gateway.environment import require_memory_monitoring
    require_memory_monitoring()
    from shotdeck_seed.lifecycle import SeedManager
    from shotdeck_seed.storage import SeedPaths
    paths = SeedPaths(install=config.install_root, state=config.state_root, signing=config.migration_root)
    selected = SeedManager(paths).select()
    manifest = selected["manifest"]
    if (selected["sha256"] != payload["seed_sha256"] or manifest["seed_protocol"] != payload["seed_protocol"]
            or manifest["support_schema"] != payload["support_protocol"]):
        raise RecoveryError("Customer recovery seed differs from its signed qualification")
    from shotdeck_seed.support import SupportManager
    support = SupportManager(paths)
    if os.path.lexists(support.journal):
        raise RecoveryError("Customer recovery support transition needs reconciliation")
    markers = (support.enrolled, support.high_water, support.accepted)
    if any(os.path.lexists(path) for path in markers) and not all(os.path.lexists(path) for path in markers):
        raise RecoveryError("Customer recovery support enrollment is incomplete")
    support._history()
    accepted = support._accepted()
    if accepted["selected"] is None:
        if os.path.lexists(paths.support_current):
            # Before first C helper enrollment, the already installed A worker
            # retains its legacy selector. It is never executed as C support.
            if any(os.path.lexists(path) for path in markers) or not paths.support_current.is_symlink():
                raise RecoveryError("Customer recovery support selector needs review")
            raw = Path(os.readlink(paths.support_current))
            legacy = Path(os.path.abspath(raw if raw.is_absolute() else paths.support_current.parent / raw))
            if (legacy.parent != paths.support_releases or not re.fullmatch(r"[1-9][0-9]*-[0-9a-f]{12}", legacy.name)
                    or paths.support_releases.is_symlink() or legacy.is_symlink() or not legacy.is_dir()):
                raise RecoveryError("Unexpected legacy support selector beside the C seed")
        identity = None
    else:
        identity = support.selected_generation()["manifest_sha256"]
    if identity != payload["support_manifest_sha256"]:
        raise RecoveryError("Customer recovery helpers differ from their signed qualification")
    if state is not None and any(state[name] != payload[name] for name in ("authority_id", "failed", "target")):
        raise RecoveryError("Customer capability does not identify this incident")
    return payload, {"authority_id": authority, "capability_sha256": digest(canonical(document)),
        "scope": "customer", "recovery_enabled": True}


def assert_failed_selection(config, capability):
    """A missing/broken failed tree never supplies executable recovery authority."""
    link = config.current_link
    if not os.path.lexists(link):
        return  # exact failed identity is independently signed, never inferred
    if not link.is_symlink() or config.releases_dir.is_symlink():
        raise RecoveryError("Current application selection needs protected review")
    raw = Path(os.readlink(link))
    selected = Path(os.path.abspath(raw if raw.is_absolute() else link.parent / raw))
    expected = config.releases_dir / capability["failed"]["directory"]
    if selected != expected or selected.parent != config.releases_dir:
        raise RecoveryError("Customer capability does not identify the selected failed release")
    # Missing or damaged contents at this exact signed location are expressly
    # covered by the capability. They supply no authority and never execute.
    # Ordinary installation/rollback identity checks remain unchanged; only
    # this separately signed failed identity authorizes the recovery engine.


def _snapshot_path(config, state):
    return config.state_root / "recovery/customer-incidents" / (safety._sha(state["incident_id"]) + ".json")


def _verify_onward_selection(config, selected):
    metadata = safety._root_json(config.releases_dir / selected["directory"] / ".shotdeck-release.json")
    if metadata.get("version") != selected["version"] or metadata.get("tree_sha256") != selected["tree_sha256"]:
        raise RecoveryError("Selected onward release differs from its protected installation metadata")


def incident_data(capability, config, state, *, capture=False):
    current, proof = load_capability(config, state=state)
    if current != capability or state["capability_sha256"] != proof["capability_sha256"]:
        raise RecoveryError("Customer data admission authority changed")
    path = _snapshot_path(config, state)
    expected = {"schema_version": 1, "incident_id": state["incident_id"],
        "authority_id": state["authority_id"], "capability_sha256": proof["capability_sha256"],
        "failed": state["failed"], "target": state["target"]}
    observed = safety.data_contract(config)
    if {name: observed[name] for name in capability["data"]} != capability["data"]:
        raise RecoveryError("Local data requires an unqualified format change")
    if not os.path.lexists(path):
        if not capture or state["attempts"] != 0:
            raise RecoveryError("Customer incident data snapshot is missing")
        # Caller has proved stopped and owns updater/backup/brew exclusions.
        # An existing snapshot is immutable across all retries and reboots.
        record = {**expected, "data": observed}
        write_json(path, {"record": record, "sha256": digest(canonical(record))})
    envelope = safety._root_json(path)
    safety._fields(envelope, {"record", "sha256"}, "customer incident data envelope")
    record = envelope["record"]
    safety._fields(record, set(expected) | {"data"}, "customer incident data")
    if (digest(canonical(record)) != safety._sha(envelope["sha256"])
            or any(record[name] != value for name, value in expected.items()) or record["data"] != observed):
        raise RecoveryError("Customer data changed after stopped-app admission")
    return observed


class CustomerRecoveryPort(NativeRecoveryPort):
    def verify_capability(self, state):
        self.capability, proof = load_capability(self.config, state=state)
        if state["attempts"] == 0:
            # Automatic native recovery does not pass through the C dispatcher.
            # Apply the same pre-attempt reserve/pressure admission there too;
            # no attempt is consumed while waiting for resources.
            from shotdeck_recovery_gateway.admission import admit
            decision = admit("rollback")
            if not decision.admitted:
                raise RecoveryError("Customer recovery waits for safe memory/pressure admission: " + decision.reason)
        return proof

    def assert_stopped(self, state):
        assert_service_stopped(self.show())
        from .recovery_access import LATCH, read_latch
        if os.path.lexists(LATCH):
            access = read_latch()
            if access["identity"] != state["failed"]:
                raise RecoveryError("Temporary access belongs to a different selected application")
            if access["data"] is not None and safety.data_contract(self.config) != access["data"]:
                raise RecoveryError("Shared data changed during temporary access before recovery")
        incident_data(self.capability, self.config, state, capture=state["attempts"] == 0)

    def assert_safe_outputs(self, state):
        safety.verify_hardware(self.capability, self.config, connected_only=True)


def status(config):
    state = RecoveryStore(config).status()
    result = {"enabled": False, "available": False, "reason": "Customer recovery is not qualified.",
        "target": None, "capability_sha256": None, "recovery": state}
    if not os.path.lexists(config.state_root / "recovery/customer-capability.json"):
        return result
    try:
        capability, proof = load_capability(config, state=state if state["latched"] else None)
    except CapabilityOutsideWindow:
        result["reason"] = "Customer recovery qualification is expired or not yet active. The installed runtime is unaffected."
        return result
    result.update(enabled=True, target=capability["target"], capability_sha256=proof["capability_sha256"])
    if state.get("phase") == "completed" and state.get("capability_sha256") == proof["capability_sha256"]:
        # RecoveryStore.status already validated the exact durable completion
        # receipt and quarantine. Authenticate current bytes without offering
        # that consumed failed release again, including after an onward update.
        selected = selected_identity(config)
        if (state.get("authority_id") != proof["authority_id"] or state.get("failed") != capability["failed"]
                or state.get("target") != capability["target"]):
            raise RecoveryError("Completed customer recovery differs from its exact capability")
        if selected != state["target"]:
            if selected["directory"] == state["target"]["directory"]:
                raise RecoveryError("The completed recovery target has changed")
            _verify_onward_selection(config, selected)
        result["reason"] = ("This customer recovery completed successfully; its one attempt is already consumed."
                            if selected == state["target"] else "The selected release has changed since completed recovery; this capability is not offered again.")
        return result
    if state["latched"] and state["attempts"]:
        result["reason"] = "Recovery attempt already consumed; review its observed outcome."
        return result
    # An intact onward release is a normal unavailable offer, not evidence of a
    # damaged updater. Missing/corrupt bytes at the signed failed location still
    # use the separately qualified recovery path below.
    if config.current_link.is_symlink():
        raw = Path(os.readlink(config.current_link))
        selected_path = Path(os.path.abspath(raw if raw.is_absolute() else config.current_link.parent / raw))
        if selected_path != config.releases_dir / capability["failed"]["directory"]:
            _verify_onward_selection(config, selected_identity(config))
            result["reason"] = "The selected release is not covered by this recovery capability."
            return result
    assert_failed_selection(config, capability)
    target = config.releases_dir / capability["target"]["directory"]
    active = UpdateStore(config.migration_root, config.install_root, config.manifest_security_state_file).active()
    if (target.is_symlink() or not target.is_dir() or config.releases_dir.is_symlink()
            or read(target / MARKER, 16) != b"1\n"
            or read(target / ".shotdeck-version", 128).decode().strip() != capability["target"]["version"]
            or version(capability["target"]["version"]) < version(active["policy"]["minimum_app_version"])
            or tree_digest(target) != capability["target"]["tree_sha256"]):
        raise RecoveryError("Signed customer recovery target is missing or damaged")
    assert_hardware_compatible(target)
    RecoveryStore(config).assert_offer_allowed(capability["target"])
    result.update(available=True, reason="Exact retained target is available; live safety admission is required.")
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("status", "recover"))
    parser.add_argument("--expected-target")
    parser.add_argument("--expected-capability")
    args = parser.parse_args(argv)
    try:
        if os.geteuid() != 0:
            raise RecoveryError("Customer recovery requires its protected system service")
        config = UpdaterConfig.from_file(DEFAULT_CONFIG_PATH)
        if args.command == "status":
            if args.expected_target is not None or args.expected_capability is not None:
                raise RecoveryError("Status does not accept mutation authority")
            result = status(config)
        else:
            if not args.expected_target or len(args.expected_target) > 2048:
                raise RecoveryError("Confirm the exact customer recovery target")
            expected = validate_identity(json.loads(args.expected_target, object_pairs_hook=unique))
            safety._sha(args.expected_capability)
            from .recovery_native import operate
            result = operate(config, "recover", expected_target=expected,
                expected_capability=args.expected_capability, customer_only=True)
        print(json.dumps(result, sort_keys=True))
        return 0
    except Exception as exc:
        print(json.dumps({"blocked": str(exc)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
