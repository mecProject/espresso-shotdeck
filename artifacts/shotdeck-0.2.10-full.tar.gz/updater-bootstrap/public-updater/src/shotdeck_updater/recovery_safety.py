"""Workshop-only recovery authority and independent, read-only safety proofs.

Nothing in this module operates GPIO, migrates data, or enables customer
recovery. A signed capability authorizes one exact release pair and data
contract; a separate, short-lived local attestation can establish a physically
disconnected workshop machine. Missing health or a free brew lock is no proof.
"""
from __future__ import annotations

import base64
from datetime import datetime
import json
import mmap
import os
from pathlib import Path
import re
import shlex
import sqlite3
import stat
import struct
import sys
import time

from shotdeck_security.storage import boot_id, canonical, digest, read, read_json, unique
from shotdeck_security.updates import UpdateStore

from .hardware import LEGACY_ID, installed_profile
from .identity import collect_identity
from .recovery import RecoveryError, validate_identity
from .system import CommandRunner

DOMAIN = b"shotdeck-workshop-recovery-capability-v1\0"
MAX_DOCUMENT_BYTES = 65536
MAX_CAPABILITY_SECONDS = 24 * 60 * 60
MAX_ISOLATION_SECONDS = 4 * 60 * 60
BOARD = "Raspberry Pi Zero 2 W Rev 1.0"
DATA_CONTRACT = "shotdeck-shared-data-v3-no-migration"
DATA_FILES = ("memory.save", "mac.save", "scale_kind.save", "scale_name.save",
              "scale-settings.json", "wifi-settings.json", "brewing_users.json",
              "rotation.save", "bbw_enabled.save")
TOPOLOGY = {"relay_mode": "holding", "switch_mode": "latching",
            "relay_active_high": True, "paddle_off_high": True,
            "bbw_control": "physical_gpio6", "bbw_active_high": True,
            "software_selector": False}
ENV_FILES = {"/etc/default/shotdeck", "/etc/default/shotdeck-updates"}
HEX = re.compile(r"[0-9a-f]{64}")
_FIELDS = {"schema_version", "capability_id", "scope", "issued_at", "expires_at",
           "authority_id", "policy_sha256", "runtime_sha256", "failed", "target",
           "device_fingerprint", "board", "os_codename", "hardware_profile",
           "topology", "data", "reviewed_by"}

# The reviewed schema includes every startup migration column, not just the
# smaller backup validator subset. Its signed SQL digest also pins indices and
# constraints. This module never imports replaceable application validators.
TABLE_COLUMNS = {
    "shots": "id started_at ended_at profile_name roast target_weight_g target_time_min_s target_time_max_s final_weight_g duration_s average_flow_g_s user_id user_name settings_json created_at capture_run_id capture_key grinder_telemetry_json bean_id coffee_json review_revision".split(),
    "shot_samples": "id shot_id time_s weight_g flow_g_s".split(),
    "shot_feedback": "id shot_id created_at user_name rating issue taste visual prep grind_adjustment notes".split(),
    "intelligence_events": "id created_at profile_name roast intelligence_mode status predictor_version feature_schema_version predictor_config_json decision_history_json history_json decision_threshold_g cutoff_lateness_bias_g cutoff_execution_error_g cutoff_flow_last_g shadow_duration_prediction_g shadow_duration_error_g learning_diagnostics_json".split(),
    "beans": "id name roaster roast_type notes archived version created_at updated_at".split(),
    "shot_annotations": "shot_id overrides_json updated_at".split(),
    "shot_media": "shot_id id image thumbnail width height created_at".split(),
    "history_meta": "id revision".split(),
    "grinders": "id name notes burrs_json rpm_json archived version created_at updated_at".split(),
}


def _fields(value, fields, label):
    if not isinstance(value, dict) or set(value) != set(fields):
        raise RecoveryError(f"Invalid {label} fields")


def _sha(value):
    if not isinstance(value, str) or not HEX.fullmatch(value):
        raise RecoveryError("Invalid recovery authority digest")
    return value


def _timestamp(value):
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            raise ValueError()
        return parsed.timestamp()
    except (ValueError, TypeError, AttributeError) as exc:
        raise RecoveryError("Recovery authority requires timezone-qualified timestamps") from exc


def _window(value, maximum, *, now=None):
    issued, expires = _timestamp(value["issued_at"]), _timestamp(value["expires_at"])
    current = time.time() if now is None else now
    if not issued <= current < expires or not 0 < expires - issued <= maximum:
        raise RecoveryError("Workshop recovery authority is expired, premature or too long-lived")


def validate_payload(payload):
    _fields(payload, _FIELDS, "workshop capability")
    if (type(payload["schema_version"]) is not int or payload["schema_version"] != 1
            or payload["scope"] != "workshop"
            or not isinstance(payload["capability_id"], str)
            or not re.fullmatch(r"[a-z0-9][a-z0-9._-]{0,95}", payload["capability_id"])
            or len(canonical(payload)) > MAX_DOCUMENT_BYTES
            or not isinstance(payload["reviewed_by"], str)
            or not 1 <= len(payload["reviewed_by"].strip()) <= 200):
        raise RecoveryError("Only reviewed workshop recovery capabilities are supported")
    for name in ("authority_id", "policy_sha256", "runtime_sha256", "device_fingerprint"):
        _sha(payload[name])
    failed, target = validate_identity(payload["failed"]), validate_identity(payload["target"])
    if failed["tree_sha256"] == target["tree_sha256"] or failed["version"] == target["version"]:
        raise RecoveryError("Recovery must identify a distinct failed and target release")
    if (payload["board"] != BOARD or payload["os_codename"] != "trixie"
            or payload["hardware_profile"] != LEGACY_ID or payload["topology"] != TOPOLOGY
            or any(type(payload["topology"].get(key)) is not type(value) for key, value in TOPOLOGY.items())):
        raise RecoveryError("Recovery hardware topology has not been qualified")
    _fields(payload["data"], {"contract", "history_schema", "history_schema_sha256", "files"}, "data contract")
    data = payload["data"]
    if data["contract"] != DATA_CONTRACT or type(data["history_schema"]) is not int or data["history_schema"] != 3:
        raise RecoveryError("Recovery data contract would require an unknown format or migration")
    _sha(data["history_schema_sha256"])
    _fields(data["files"], DATA_FILES, "data file contract")
    for value in data["files"].values():
        if value is not None:
            _sha(value)
    issued, expires = _timestamp(payload["issued_at"]), _timestamp(payload["expires_at"])
    if not 0 < expires - issued <= MAX_CAPABILITY_SECONDS:
        raise RecoveryError("Invalid workshop capability lifetime")
    return payload


def sign_capability(payload, private_key):
    """Host helper. Callers separately establish/review every signed observation."""
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    validate_payload(payload)
    if not isinstance(private_key, Ed25519PrivateKey):
        raise RecoveryError("Recovery requires the active Ed25519 update signer")
    pem = private_key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo)
    return {**payload, "signature": {"algorithm": "ed25519", "key_id": digest(pem)[:16],
            "value": base64.b64encode(private_key.sign(DOMAIN + canonical(payload))).decode("ascii")}}


def verify_capability(document, public_key):
    from cryptography.exceptions import InvalidSignature
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    if not isinstance(document, dict) or len(canonical(document)) > MAX_DOCUMENT_BYTES:
        raise RecoveryError("Invalid bounded recovery capability")
    signature = document.get("signature")
    _fields(signature, {"algorithm", "key_id", "value"}, "capability signature")
    payload = {key: value for key, value in document.items() if key != "signature"}
    validate_payload(payload)
    try:
        key = serialization.load_pem_public_key(public_key)
        raw = base64.b64decode(signature["value"], validate=True)
        if (not isinstance(key, Ed25519PublicKey) or signature["algorithm"] != "ed25519"
                or signature["key_id"] != digest(public_key)[:16] or len(raw) != 64
                or base64.b64encode(raw).decode("ascii") != signature["value"]):
            raise ValueError()
        key.verify(raw, DOMAIN + canonical(payload))
    except (InvalidSignature, ValueError, TypeError) as exc:
        raise RecoveryError("Recovery capability does not match the active update authority") from exc
    return payload


def _root_read(path, limit=MAX_DOCUMENT_BYTES):
    path = Path(path)
    # All parents must be protected; a protected final inode in a replaceable
    # directory is insufficient. read() also uses O_NOFOLLOW on the final file.
    for parent in path.parents:
        info = parent.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or info.st_mode & 0o022:
            raise RecoveryError("Recovery authority path is not protected and root-owned")
    info = path.lstat()
    if info.st_uid != 0 or info.st_mode & 0o022:
        raise RecoveryError("Recovery authority must be protected and root-owned")
    return read(path, limit)


def _root_json(path):
    try:
        return json.loads(_root_read(path), object_pairs_hook=unique)
    except (ValueError, UnicodeError) as exc:
        raise RecoveryError("Invalid protected recovery document") from exc


def _runtime_path():
    runtime = Path(sys.prefix).resolve()
    return runtime if Path(__file__).resolve().is_relative_to(runtime) else None


def load_capability(config, state=None):
    active = UpdateStore(config.migration_root, config.install_root, config.manifest_security_state_file).active()
    if active is None:
        raise RecoveryError("Recovery requires enrolled signed update authority")
    document = _root_json(config.state_root / "recovery/capability.json")
    payload = verify_capability(document, active["policy"]["public_key_pem"].encode())
    _window(payload, MAX_CAPABILITY_SECONDS)
    authority = digest(canonical(active))
    runtime = Path(active["runtime"]).resolve(strict=True)
    if (payload["authority_id"] != authority or payload["policy_sha256"] != digest(canonical(active["policy"]))
            or payload["runtime_sha256"] != active["runtime_sha256"] or _runtime_path() != runtime
            or collect_identity(config.identity_policy).device_fingerprint != payload["device_fingerprint"]):
        raise RecoveryError("Recovery capability belongs to different authority, runtime or device")
    if state is not None and any(state[name] != payload[name] for name in ("authority_id", "failed", "target")):
        raise RecoveryError("Recovery capability does not identify this incident")
    return payload, {"authority_id": authority, "capability_sha256": digest(canonical(document)),
                     "scope": "workshop", "recovery_enabled": True}


def load_incident_capability(config, state=None):
    """Select an exact persisted scope; never convert workshop proof to customer."""
    customer = config.state_root / "recovery/customer-capability.json"
    workshop = config.state_root / "recovery/capability.json"
    identity = state.get("capability_sha256") if state else None
    if identity:
        candidates = []
        for scope, path in (("customer", customer), ("workshop", workshop)):
            if os.path.lexists(path) and digest(canonical(_root_json(path))) == identity:
                candidates.append(scope)
        if len(candidates) != 1:
            raise RecoveryError("Recovery incident lacks its exact scoped capability")
        scope = candidates[0]
    else:
        scope = "customer" if os.path.lexists(customer) else "workshop"
    if scope == "customer":
        from .recovery_customer import load_capability as load_customer
        return load_customer(config, state=state)
    return load_capability(config, state=state)


def _environment_file(path):
    """Conservative systemd EnvironmentFile subset: reject expansion/continuation."""
    result = {}
    for line in _root_read(path).decode().splitlines():
        line = line.strip()
        if not line or line.startswith(("#", ";")):
            continue
        if "\\" in line or "\x00" in line:
            raise RecoveryError("Unsupported recovery environment syntax")
        name, separator, raw = line.partition("=")
        if not separator or not re.fullmatch(r"[A-Z][A-Z0-9_]*", name):
            raise RecoveryError("Unsupported recovery environment assignment")
        # systemd does not expand shell variables; keep literal unquoted text.
        if raw.startswith(("'", '"')):
            if len(raw) < 2 or raw[-1] != raw[0] or raw[0] in raw[1:-1]:
                raise RecoveryError("Unsupported recovery environment quoting")
            raw = raw[1:-1]
        result[name] = raw
    return result


def _effective_environment(config):
    names = ("Environment", "EnvironmentFiles", "PassEnvironment", "UnsetEnvironment", "MainPID")
    result = CommandRunner().run(["systemctl", "show", config.service_name, "--property=" + ",".join(names)], timeout=15)
    # systemd may print EnvironmentFiles entries on separate physical lines.
    # Only those exact fixed-path entries may continue a property: splitting
    # every line at '=' would mistake '(ignore_errors=yes)' for a new key.
    values = {}
    current = None
    if len(result.stdout) > 256 * 1024:
        raise RecoveryError("Application environment observation is too large")
    for line in result.stdout.splitlines():
        if not line:
            continue
        name, separator, value = line.partition("=")
        if separator and name in names:
            if name in values:
                if name != "EnvironmentFiles" or not value:
                    raise RecoveryError("Duplicate application environment property")
                # Some systemd builds repeat the header for every file. The
                # fixed-path parser below still rejects duplicate file entries.
                values[name] += "\n" + value
            else:
                values[name] = value
            current = name
        elif (current == "EnvironmentFiles"
                and re.fullmatch(r"/etc/default/(?:shotdeck|shotdeck-updates) \(ignore_errors=(?:yes|no)\)", line)):
            values[current] += "\n" + line
        else:
            raise RecoveryError("Unknown application environment property or continuation")
    if set(values) != set(names) or values["PassEnvironment"] or values["UnsetEnvironment"]:
        raise RecoveryError("Application environment cannot be independently established")
    try:
        env = {}
        for item in shlex.split(values["Environment"]):
            key, separator, value = item.partition("=")
            if not separator:
                raise ValueError()
            env[key] = value
        remaining = values["EnvironmentFiles"]
        paths = []
        while remaining:
            match = re.match(r"(/[^ \t\r\n]+) \(ignore_errors=(yes|no)\)(?:[ \t\r\n]+|$)", remaining)
            if not match or match[1] not in ENV_FILES or match[1] in paths:
                raise ValueError()
            path = Path(match[1]); paths.append(str(path))
            if path.exists() or path.is_symlink():
                env.update(_environment_file(path))
            elif match[2] != "yes":
                raise ValueError()
            remaining = remaining[match.end():]
        if "/etc/default/shotdeck" not in paths:
            raise ValueError()
        if not re.fullmatch(r"[0-9]+", values["MainPID"]):
            raise ValueError()
        if int(values["MainPID"]):
            process = Path("/proc") / values["MainPID"]
            before = read(process / "stat", 8192, protected=False)
            actual = {}
            for item in read(process / "environ", 65536, protected=False).split(b"\0"):
                if not item:
                    continue
                key, separator, value = item.decode().partition("=")
                if not separator or key in actual:
                    raise ValueError()
                actual[key] = value
            if read(process / "stat", 8192, protected=False).rsplit(b")", 1)[1].split()[19] != before.rsplit(b")", 1)[1].split()[19]:
                raise ValueError()
            _validate_environment(actual, config)
        return env
    except (ValueError, UnicodeError, IndexError, OSError) as exc:
        raise RecoveryError("Unsupported effective application environment") from exc


def _verify_topology(config):
    model = read(Path("/proc/device-tree/model"), 256, protected=False).decode().strip("\x00\n")
    os_release = _root_read(Path("/etc/os-release").resolve(strict=True), 16384).decode()
    codename = dict(line.split("=", 1) for line in os_release.splitlines() if "=" in line).get("VERSION_CODENAME", "").strip('"')
    if model != BOARD or codename != "trixie" or installed_profile() != (LEGACY_ID, 1):
        raise RecoveryError("Native recovery hardware has not been qualified")
    _validate_environment(_effective_environment(config), config)


def _validate_environment(env, config):
    expected = {"RELAY_MODE": "holding", "SWITCH_MODE": "latching", "RELAY_ACTIVE_LOW": "0",
                "BBW_ENABLE_CONTROL": "physical_gpio6", "BBW_PHYSICAL_SWITCH_ACTIVE_HIGH": "1"}
    defaults = {"RELAY_MODE": "holding", "SWITCH_MODE": "latching", "RELAY_ACTIVE_LOW": "0"}
    if any(env.get(key, defaults.get(key)) != value for key, value in expected.items()) or env.get("SHOTDECK_ENABLE_GPIO", "").strip():
        raise RecoveryError("Application relay/switch topology is not qualified for passive recovery")
    # The authentic older recovery app must not depend on newer application
    # pin-ownership validation. GT911 initialization actively drives BOTH its
    # reset and interrupt lines; these may never alias paddle/BBW/brew pins.
    integers = {"TOUCH_GT911_RST_PIN": (22, 10), "TOUCH_GT911_INT_PIN": (17, 10),
                "TOUCH_I2C_BUS": (1, 10)}
    try:
        if any(int(env.get(name, str(value)), base) != value for name, (value, base) in integers.items()):
            raise ValueError()
        # Both supported GT911 addresses use the same reviewed wiring. The
        # production environment template specifies 0x14; Python defaults 0x5D.
        if int(env.get("TOUCH_I2C_ADDRESS", "0x5D"), 0) not in {0x14, 0x5D}:
            raise ValueError()
    except (ValueError, TypeError) as exc:
        raise RecoveryError("Application touch GPIO claims differ from the qualified 3.5F wiring") from exc
    if (env.get("DISPLAY_SIZE", "").strip().lower() not in {"", "3.5f", "3.5_f", "3.5-f", "3.5"}
            or env.get("TOUCH_CONTROLLER", "").strip().lower() not in {"", "gt911"}
            or env.get("PUMP_SENSOR_GPIO", "").strip()
            or env.get("DISPLAY_BACKLIGHT_PWM_SYSFS_ROOT", "/sys/class/pwm") != "/sys/class/pwm"
            or env.get("DISPLAY_BACKLIGHT_PWM_CHIP", "").strip()):
        raise RecoveryError("Application peripheral GPIO claims are not the qualified legacy 3.5F configuration")
    allowed_claims = set(integers) | {"TOUCH_I2C_ADDRESS", "SHOTDECK_ENABLE_GPIO", "PUMP_SENSOR_GPIO"}
    for name, value in env.items():
        if not value.strip() or name in allowed_claims:
            continue
        # The legacy LCD SPI bus and display pins are fixed in its signed
        # driver. No alternate GPIO backend, remote pigpio daemon, or extra
        # pin/bus override is part of this workshop qualification.
        hardware_name = name.startswith(("GPIO", "PIGPIO", "LGPIO", "RPI_GPIO", "SPI", "LCD_"))
        pin_name = (name.startswith(("SHOTDECK_", "DISPLAY_", "TOUCH_", "RELAY_", "BBW_", "PUMP_", "SWITCH_"))
                    and re.search(r"(?:^|_)(?:GPIO[0-9]*|PIN|PINS|SPI[0-9]*)(?:_|$)", name)
                    and name != "SHOTDECK_WEB_PIN_LENGTH")
        if hardware_name or pin_name:
            raise RecoveryError("Unsupported application GPIO claimant: " + name)
    if (str(config.lock_path) != "/run/lock/shotdeck-updater.lock"
            or str(config.brew_lock_path) != "/run/lock/shotdeck-brew.lock"
            or config.service_name not in {"shotdeck", "shotdeck.service"}):
        raise RecoveryError("Recovery ownership differs from the qualified application locks/service")
    if any(env.get(key, value) != value for key, value in {
        "SHOTDECK_INSTALL_DIR": str(config.install_root),
        "SHOTDECK_DATA_DIR": str(config.state_root.parent),
        "SHOTDECK_UPDATER_STATE_DIR": str(config.state_root),
        "SHOTDECK_WIFI_SETTINGS_FILE": str(config.state_root.parent / "wifi-settings.json"),
        "SHOTDECK_SCALE_SETTINGS_FILE": str(config.state_root.parent / "scale-settings.json"),
        "SHOTDECK_BACKUP_STATE_DIR": str(config.state_root.parent / "backups"),
        "SHOTDECK_BACKUP_RESTORE_LOCK_FILE": "/run/lock/shotdeck-backup-restore.lock",
        "SHOTDECK_RESTORE_STATE_DIR": "/var/lib/shotdeck-restore",
    }.items()):
        raise RecoveryError("Application data or ownership location differs from the reviewed contract")


def passive_gpio_snapshot():
    """BCM2837 registers only. No output register, line claim or write mapping."""
    descriptor = os.open("/dev/gpiomem", os.O_RDONLY | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0))
    try:
        if not stat.S_ISCHR(os.fstat(descriptor).st_mode):
            raise RecoveryError("GPIO observation requires the qualified hardware device")
        with mmap.mmap(descriptor, 4096, flags=mmap.MAP_SHARED, prot=mmap.PROT_READ, offset=0) as registers:
            level = struct.unpack_from("<I", registers, 0x34)[0]
            return {str(pin): {"level": (level >> pin) & 1,
                               "function": (struct.unpack_from("<I", registers, (pin // 10) * 4)[0] >> ((pin % 10) * 3)) & 7}
                    for pin in (6, 20, 26)}
    finally:
        os.close(descriptor)


def isolation_attestation(payload, capability_sha256, *, current_boot, issued_at, expires_at, confirmed_by):
    """Host helper for an explicitly confirmed, local disconnected-machine lease."""
    validate_payload(payload)
    result = {"schema_version": 1, "capability_sha256": _sha(capability_sha256),
              "device_fingerprint": payload["device_fingerprint"], "boot_id": current_boot,
              "issued_at": issued_at, "expires_at": expires_at, "machine_disconnected": True,
              "confirmed_by": confirmed_by}
    _validate_isolation(result, payload, capability_sha256, current_boot)
    return result


def _validate_isolation(value, payload, capability_sha256, current_boot):
    _fields(value, {"schema_version", "capability_sha256", "device_fingerprint", "boot_id", "issued_at", "expires_at", "machine_disconnected", "confirmed_by"}, "workshop isolation")
    if (type(value["schema_version"]) is not int or value["schema_version"] != 1
            or value["machine_disconnected"] is not True or value["capability_sha256"] != capability_sha256
            or value["device_fingerprint"] != payload["device_fingerprint"] or value["boot_id"] != current_boot
            or not isinstance(current_boot, str) or not re.fullmatch(r"[0-9a-f-]{36}", current_boot)
            or not isinstance(value["confirmed_by"], str) or not 1 <= len(value["confirmed_by"].strip()) <= 200):
        raise RecoveryError("Workshop isolation does not identify this device, boot and capability")
    _window(value, MAX_ISOLATION_SECONDS)


def verify_hardware(payload, config, *, connected_only=False, start_condition=False):
    # Re-read the signed capability rather than trusting an in-memory caller.
    if connected_only:
        from .recovery_customer import load_capability as load_customer
        current, proof = load_customer(config)
    else:
        current, proof = load_capability(config)
    if current != payload:
        raise RecoveryError("Recovery capability changed during hardware admission")
    _verify_topology(config)
    isolation = config.state_root / "recovery/workshop-isolation.json"
    # A workshop isolation record has no effect on customer recovery, even
    # when it remains on disk. Customer admission always proves connected pins.
    disconnected = not connected_only and os.path.lexists(isolation)
    if disconnected:
        _validate_isolation(_root_json(isolation), payload, proof["capability_sha256"], boot_id())
    else:
        return observe_connected_controls(config, start_condition=start_condition)
    observed = []
    for _ in range(2):
        pins = passive_gpio_snapshot()
        # On the disconnected bench, inputs may float; no GPIO output is
        # enabled to manufacture an apparently safe observation.
        if pins["26"]["function"] not in (0, 1) or pins["26"]["level"] != 0:
            raise RecoveryError("Independent GPIO observations do not prove safe recovery")
        observed.append(pins)
        time.sleep(0.05)
    return {"machine_disconnected": True, "gpio": observed}


def observe_connected_controls(config, *, start_condition=False):
    """Passive shared admission for qualified rollback and temporary access.

    Callers separately authenticate their capability and hardware topology.
    A released relay requires current PID1/cgroup proof; no pin is driven.
    """
    observed = []
    released = False
    for _ in range(2):
        pins = passive_gpio_snapshot()
        safe = pins == {"6": {"function": 0, "level": 1}, "20": {"function": 0, "level": 1}, "26": {"function": 1, "level": 0}}
        if pins == {"6": {"function": 0, "level": 1}, "20": {"function": 0, "level": 1}, "26": {"function": 0, "level": 0}}:
            # A running app still needs a driven inactive output.
            from .recovery_native import assert_released_relay_quiescent
            assert_released_relay_quiescent(config, start_condition=start_condition)
            released = True
            safe = True
        if not safe:
            raise RecoveryError("Independent GPIO observations do not prove safe recovery")
        observed.append(pins)
        time.sleep(0.05)
    if released:
        # Repeat process proof after the passive observations as well, so a
        # formerly stopped service cannot authorize a later running process.
        from .recovery_native import assert_released_relay_quiescent
        assert_released_relay_quiescent(config, start_condition=start_condition)
    return {"machine_disconnected": False, "gpio": observed}


def _history_schema(path):
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or info.st_size > 512 * 1024 * 1024:
        raise RecoveryError("Recovery history must be a bounded regular database")
    for suffix in ("-wal", "-journal"):
        pending = Path(str(path) + suffix)
        if os.path.lexists(pending) and (pending.is_symlink() or pending.stat().st_size):
            raise RecoveryError("Recovery history has pending writes; a clean stopped database is required")
    # immutable prevents SQLite creating/mutating SHM; pending WAL was refused.
    db = sqlite3.connect(path.resolve().as_uri() + "?mode=ro&immutable=1", uri=True, timeout=5)
    try:
        db.execute("PRAGMA query_only=ON")
        schema = db.execute("PRAGMA user_version").fetchone()[0]
        if schema != 3:
            raise RecoveryError("Recovery history schema is unknown or would require migration")
        rows = db.execute("SELECT type,name,tbl_name,sql FROM sqlite_schema ORDER BY type,name").fetchall()
        if any(row[0] not in ("table", "index") for row in rows):
            raise RecoveryError("Recovery history contains executable or unknown schema")
        tables = {row[1] for row in rows if row[0] == "table"}
        if tables - {"sqlite_sequence"} != set(TABLE_COLUMNS):
            raise RecoveryError("Recovery history has unknown or missing tables")
        for table, required in TABLE_COLUMNS.items():
            actual = {row[1] for row in db.execute(f'PRAGMA table_info("{table}")')}
            if not set(required) <= actual:
                raise RecoveryError("Recovery history is missing a required startup column")
        if db.execute("PRAGMA quick_check").fetchall() != [("ok",)] or db.execute("PRAGMA foreign_key_check").fetchone() is not None:
            raise RecoveryError("Recovery history integrity check failed")
        return schema, digest(canonical(rows))
    except sqlite3.DatabaseError as exc:
        raise RecoveryError("Recovery history database is invalid") from exc
    finally:
        db.close()


def data_contract(config):
    """Read-only workshop preparation helper; operator must review compatibility.

    The named contract asserts unchanged application formats for these exact
    signed release trees. A newly produced digest alone is not qualification.
    """
    root = config.state_root.parent
    if root.is_symlink() or root.resolve() != root.absolute():
        raise RecoveryError("Recovery data directory must not be aliased")
    schema, schema_sha = _history_schema(root / "shot-history.sqlite3")
    files = {}
    for name in DATA_FILES:
        path = root / name
        files[name] = digest(read(path, 4 * 1024 * 1024, protected=False)) if os.path.lexists(path) else None
    return {"contract": DATA_CONTRACT, "history_schema": schema, "history_schema_sha256": schema_sha, "files": files}


def verify_data(payload, config):
    current, _ = load_capability(config)
    if current != payload or data_contract(config) != payload["data"]:
        raise RecoveryError("Application data differs from the signed unchanged-format contract")
    return payload["data"]
