"""Fixed-path native adapter for qualified stopped-application recovery.

This entry point belongs to the policy-pinned updater, not the application.
Without an explicit workshop capability it only enforces existing start latches.
No endpoint, environment variable or missing health response enables recovery.
"""
from __future__ import annotations

import argparse
from contextlib import ExitStack
import json
import os
from pathlib import Path
import subprocess
import sys

from shotdeck_security.storage import canonical, digest, guard, read, read_json, write_json, version
from shotdeck_security.updates import UpdateStore, tree_digest, MARKER

from .activation import ActivationJournal, assert_no_conflicting_transaction
from .config import DEFAULT_CONFIG_PATH, UpdaterConfig
from .errors import InstallError, LockUnavailableError
from .hardware import assert_hardware_compatible
from .locking import exclusive_lock
from .recovery import RecoveryError, RecoveryStore, validate_identity
from .recovery_lifecycle import ReadinessTracker, classify_event, classify_stop_evidence, service_snapshot, _PROPERTIES
from .storage import atomic_symlink_swap
from .system import CommandRunner, SystemctlServiceController, _read_local_health

BACKUP_LOCK = Path("/run/lock/shotdeck-backup-restore.lock")


def selected_identity(config):
    """Authenticate the selected tree; metadata alone never identifies a target."""
    if not config.current_link.is_symlink():
        raise RecoveryError("Application selection is not a release link")
    target = config.current_link.resolve(strict=True)
    if config.releases_dir.is_symlink() or target.parent != config.releases_dir:
        raise RecoveryError("Application selection is outside the retained releases")
    result = {"directory": target.name,
              "version": read(target / ".shotdeck-version", 128).decode().strip(),
              "tree_sha256": tree_digest(target)}
    return validate_identity(result)


def assert_service_stopped(properties, *, cgroup_root=Path("/sys/fs/cgroup")):
    """Process state and every descendant cgroup must agree that the app stopped."""
    if (properties.get("ActiveState") not in {"inactive", "failed"}
            or str(properties.get("MainPID")) != "0"):
        raise RecoveryError("Application service has not fully stopped")
    group = properties.get("ControlGroup", "")
    if not isinstance(group, str) or not group.startswith("/") or group == "/" or ".." in Path(group).parts:
        # systemd removes empty service cgroups and reports an empty path.
        if group == "" and properties.get("SubState") in {"dead", "failed"}:
            return
        raise RecoveryError("Application control group is unknown")
    _assert_cgroup_processes(group, cgroup_root=cgroup_root)


def _assert_cgroup_processes(group, *, cgroup_root, sole_pid=None):
    root = cgroup_root / group.lstrip("/")
    if not root.exists():
        if sole_pid is not None:
            raise RecoveryError("Start condition control group is missing")
        return
    if root.is_symlink() or cgroup_root.resolve() not in root.resolve().parents:
        raise RecoveryError("Application control group is aliased")
    count = 0
    observed = set()
    for parent, folders, files in os.walk(root, followlinks=False):
        count += 1
        if count > 256 or any((Path(parent) / name).is_symlink() for name in folders):
            raise RecoveryError("Application control group is not bounded")
        if "cgroup.procs" not in files:
            raise RecoveryError("Application control group membership is unknown")
        members = read(Path(parent) / "cgroup.procs", 65536, protected=False).split()
        if any(not value.isdigit() or len(value) > 20 or int(value) < 1 for value in members):
            raise RecoveryError("Application control group membership is invalid")
        observed.update(int(value) for value in members)
        if observed - ({sole_pid} if sole_pid is not None else set()):
            raise RecoveryError("Application control group still owns processes")
    if sole_pid is not None and observed != {sole_pid}:
        raise RecoveryError("Start condition is not the sole application control process")


def assert_released_relay_quiescent(config, *, start_condition=False, cgroup_root=Path("/sys/fs/cgroup")):
    """A released input is admissible only with independent process cessation.

    PID1 runs ExecCondition inside the service cgroup. At that one boundary,
    only the current ControlPID may remain; a live app or descendant refuses.
    No GPIO is claimed or driven to manufacture an inactive observation.
    """
    names = {"ActiveState", "SubState", "MainPID", "ControlPID", "ControlGroup"}
    try:
        properties = NativeRecoveryPort(config).show(properties=names)
    except (OSError, InstallError, subprocess.SubprocessError) as exc:
        raise RecoveryError("Independent GPIO process-cessation proof is unavailable") from exc
    if properties["ActiveState"] in {"inactive", "failed"} and properties["ControlPID"] == "0":
        assert_service_stopped(properties, cgroup_root=cgroup_root)
        return
    pid = os.getpid()
    group = properties["ControlGroup"]
    if (not start_condition or properties["ActiveState"] != "activating"
            or properties["SubState"] != "condition" or properties["MainPID"] != "0"
            or properties["ControlPID"] != str(pid) or not isinstance(group, str) or not group.startswith("/")
            or group == "/" or ".." in Path(group).parts):
        raise RecoveryError("Released GPIO relay requires a stopped application or its sole start condition")
    _assert_cgroup_processes(group, cgroup_root=cgroup_root, sole_pid=pid)


class NativeRecoveryPort:
    def __init__(self, config, *, runner=None):
        self.config = config
        self.runner = runner or CommandRunner()
        self.service = SystemctlServiceController(config.service_name, self.runner)
        self.capability = None

    def show(self, unit=None, properties=None):
        names = properties or (_PROPERTIES | {"MainPID"})
        result = self.runner.run(["systemctl", "show", unit or self.config.service_name,
                                  "--property=" + ",".join(sorted(names))], timeout=15)
        values = dict(line.split("=", 1) for line in result.stdout.splitlines() if "=" in line)
        if set(values) != set(names):
            raise RecoveryError("Incomplete service observation")
        return values

    def verify_capability(self, state):
        from .recovery_safety import load_capability
        self.capability, proof = load_capability(self.config, state=state)
        return proof

    def assert_no_conflicts(self, state):
        from shotdeck_recovery.queue import JobStore
        from shotdeck_recovery.status import snapshot
        assert_no_conflicting_transaction(self.config)
        jobs = JobStore(self.config.state_root / "jobs", self.config.state_root / "dispatch")
        pending = snapshot(jobs)
        if pending["unknown"] or pending["active"] or jobs.mutation_barrier():
            raise RecoveryError("An update job needs review before recovery")
        activation = ActivationJournal(self.config).inspect()
        if activation["recovery_required"]:
            if activation["record"]["transaction_id"] != state["activation_transaction_id"]:
                raise RecoveryError("A different activation owns the application")
        elif state["activation_transaction_id"]:
            record = activation.get("record", {})
            if record.get("transaction_id") != state["activation_transaction_id"] or record.get("phase") != "reconciled":
                raise RecoveryError("Recovery activation identity is missing")

    def verify_target(self, state):
        identity = validate_identity(state["target"])
        target = self.config.releases_dir / identity["directory"]
        if self.config.releases_dir.is_symlink() or target.is_symlink() or not target.is_dir():
            raise RecoveryError("Recovery release is not an immutable retained tree")
        active = UpdateStore(self.config.migration_root, self.config.install_root,
                             self.config.manifest_security_state_file).active()
        if (active is None or version(identity["version"]) < version(active["policy"]["minimum_app_version"])
                or read(target / MARKER, 16) != b"1\n"
                or read(target / ".shotdeck-version", 128).decode().strip() != identity["version"]
                or tree_digest(target) != identity["tree_sha256"]):
            raise RecoveryError("Recovery release differs from its signed compatible identity")
        assert_hardware_compatible(target)
        result = self.runner.run([str(target / "shotdeck"), "--validate-license",
                                  str(self.config.install_root / "hardware.dat")], timeout=180)
        try:
            if json.loads(result.stdout).get("valid") is not True:
                raise ValueError()
        except (ValueError, AttributeError) as exc:
            raise RecoveryError("Recovery target cannot validate the current licence") from exc

    def stop(self, state):
        # No hardware command/pulse is emitted. Startup-unready recovery may
        # only stop a running process after a separately authorized passive proof.
        current = self.show()
        if current["ActiveState"] not in {"inactive", "failed"}:
            self.assert_safe_outputs(state)
        self.service.stop()

    def assert_stopped(self, state):
        assert_service_stopped(self.show())
        from .recovery_safety import verify_data
        verify_data(self.capability, self.config)

    def assert_safe_outputs(self, state):
        from .recovery_safety import verify_hardware
        verify_hardware(self.capability, self.config)

    def select_target(self, state):
        self.verify_target(state)
        atomic_symlink_swap(self.config.current_link, self.config.releases_dir / state["target"]["directory"])

    def verify_selected(self, state):
        if selected_identity(self.config) != state["target"]:
            raise RecoveryError("Selected application differs from the exact recovery target")

    def start(self, state):
        # ExecCondition consumes the live owner's one-use permit. The engine
        # refuses completion if the independently installed gate did not run.
        if (state["attempts"] != 1 or state["phase"] != "permit_issued"
                or not RecoveryStore(self.config).check_start(state["target"], consume=False)):
            raise RecoveryError("Recovery cannot reset start limits without its exact live permit")
        # Restore before asking PID1 to start the app: its independent startup
        # reconciler must not wait for locks held by this very parent process.
        from shotdeck_recovery_access.network import RecoveryNetwork
        RecoveryNetwork().restore(held_activity=True)
        # Exhausted starts belong to the failed release. This one bounded
        # target attempt gets admission; the persistent latch still blocks any
        # subsequent automatic restart if it fails.
        self.runner.run(["systemctl", "reset-failed", self.config.service_name], timeout=15)
        self.service.start()

    def health_check(self, state):
        self.service.health_check(180, expected_version=state["target"]["version"])
        health = _read_local_health(2)
        if health.get("brew_active") is not False:
            raise RecoveryError("Recovered application is not idle")

    def complete_activation(self, state, receipt):
        if state["activation_transaction_id"]:
            ActivationJournal(self.config).complete_recovery(state["activation_transaction_id"],
                state["target"], state["incident_id"], digest(canonical(receipt)))


def start_allowed(config):
    store = RecoveryStore(config)
    state = store.status()
    if state["latched"]:
        # Recovery alone can reconcile a pending normal activation. Its permit
        # must not additionally consume an unrelated normal-installer permit.
        if state["phase"] != "permit_issued" or not store.check_start(state["target"], consume=False):
            return False
        target = selected_identity(config)
        from .recovery_safety import load_incident_capability, verify_data, verify_hardware
        capability, proof = load_incident_capability(config, state=state)
        if proof["capability_sha256"] != state["capability_sha256"]:
            raise RecoveryError("Controlled start authority changed after admission")
        if proof["scope"] == "customer":
            from .recovery_customer import incident_data
            incident_data(capability, config, state)
        else:
            verify_data(capability, config)
        # Runtime/target hashing can take time on small devices. Repeat the
        # passive proof at the actual start boundary, immediately before the
        # one-use permit is consumed; a former safe observation is insufficient.
        verify_hardware(capability, config, connected_only=proof["scope"] == "customer", start_condition=True)
        return store.check_start(target)
    return store.check_start() and ActivationJournal(config).check_start()


def lifecycle_context(config, port, state, activation, health, command):
    dependencies = {unit: port.show(unit, {"ActiveState"})["ActiveState"]
                    for unit in ("bluetooth.service", "bluetooth.target")}
    return {"dependencies": dependencies, "transaction_active": activation["recovery_required"],
            "maintenance": os.path.lexists(config.migration_root / "maintenance.json"),
            "recovery_latched": state["latched"], "expected_stop": False,
            "licence_recovery": health.get("status") in {"license_recovery", "licence_recovery"},
            "event_invocation": (os.environ.get("INVOCATION_ID", "") if command == "observe-stop"
                                 else os.environ.get("MONITOR_INVOCATION_ID", "") if command == "failure" else "")}


def operate(config, command, *, expected_target=None, expected_capability=None, customer_only=False):
    if command == "start":
        return {"allowed": start_allowed(config)}
    store = RecoveryStore(config)
    if command == "status":
        return {"recovery": store.status(), "activation": ActivationJournal(config).inspect()}
    # No automatic recovery can be enabled by installation of support alone.
    if not any(os.path.lexists(store.root / name) for name in ("capability.json", "customer-capability.json")):
        if customer_only:
            raise RecoveryError("Customer recovery is not enabled")
        return {"enabled": False, "recovery": store.status()}
    with ExitStack() as locks:
        locks.enter_context(exclusive_lock(config.lock_path))
        # Customer snapshots must not race portable backup/restore. Respect
        # the established updater -> backup -> brew order on both paths.
        locks.enter_context(exclusive_lock(BACKUP_LOCK))
        locks.enter_context(exclusive_lock(config.brew_lock_path))
        locks.enter_context(guard(config.migration_root))
        state = store.status()
        from shotdeck_recovery_gateway.barrier import assert_clear
        assert_clear(allow_owned=True, access_latch=False)
        from .recovery_safety import load_incident_capability
        capability, proof = load_incident_capability(config, state=state if state["latched"] else None)
        if customer_only and proof["scope"] != "customer":
            raise RecoveryError("Workshop recovery cannot authorize a customer request")
        if proof["scope"] == "customer":
            from .recovery_customer import CustomerRecoveryPort
            port = CustomerRecoveryPort(config)
            if command == "recover" and (expected_target != capability["target"]
                    or expected_capability != proof["capability_sha256"]):
                raise RecoveryError("Customer recovery confirmation no longer identifies the exact target and capability")
        else:
            port = NativeRecoveryPort(config)
        if (proof["scope"] == "customer" and state.get("phase") == "completed"
                and state.get("capability_sha256") == proof["capability_sha256"]):
            return {"classification": "recovery_completed", "recovery_candidate": False,
                    "reason": "This exact customer recovery attempt is already complete."}
        activation = ActivationJournal(config).inspect()
        if state["latched"]:
            if command == "boot":
                store.revoke_permit()
                return {**store.status(), "next_action": "independent_watchdog_revalidation"}
            if command == "observe-stop":
                return {"classification": "recovery_latched"}
            return store.reconcile(port, resume=True)
        try:
            health = _read_local_health(1)
        except Exception:
            health = {}
        context = lifecycle_context(config, port, state, activation, health, command)
        observation = service_snapshot(port.show(properties=_PROPERTIES))
        decision = (ReadinessTracker(config.state_root).observe(observation, context,
                    health=health, expected_version=capability["failed"]["version"])
                    if command == "watchdog" else classify_event(observation, context).to_dict())
        if decision["classification"] == "start_inhibited" and os.path.lexists(store.root / "stop-observation.json"):
            decision = classify_stop_evidence(observation, context,
                read_json(store.root / "stop-observation.json")).to_dict()
        write_json(store.root / "last-observation.json", {"schema_version": 1, "command": command,
                   "service": observation, "decision": decision})
        if command == "observe-stop":
            return decision  # never synchronously restart from ExecStopPost
        interrupted = activation["recovery_required"] and command in {"boot", "reconcile"}
        if not interrupted and command != "recover" and not decision.get("recovery_candidate"):
            return decision
        # A signed failed identity also authenticates the selected tree. Corrupt
        # trees need a separate reviewed authority, never an inferred version.
        if proof["scope"] == "customer":
            from .recovery_customer import assert_failed_selection
            assert_failed_selection(config, capability)
        elif selected_identity(config) != capability["failed"]:
            raise RecoveryError("Recovery capability does not identify the selected failing application")
        transaction = activation.get("record", {}).get("transaction_id", "") if interrupted else ""
        reason = ("interrupted_activation" if interrupted else "manual_recovery" if command == "recover"
                  else "startup_unready" if decision["classification"] == "startup_unready" else "startup_failure")
        store.begin(capability["failed"], capability["target"], proof["authority_id"], reason,
                    activation_transaction_id=transaction)
        if command == "boot":
            # This unit orders before the application. Never synchronously
            # start/stop that unit while it is waiting for this boot job.
            store.revoke_permit()
            return {**store.status(), "next_action": "independent_watchdog_revalidation"}
        return store.execute(port)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("start", "observe-stop", "failure", "watchdog", "boot", "status", "reconcile", "recover"))
    args = parser.parse_args(argv)
    try:
        if os.geteuid() != 0:
            raise RecoveryError("Native recovery requires the protected system service")
        result = operate(UpdaterConfig.from_file(DEFAULT_CONFIG_PATH), args.command)
        print(json.dumps(result, sort_keys=True))
        return 1 if args.command == "start" and not result["allowed"] else 0
    except LockUnavailableError as exc:
        print(json.dumps({"deferred": str(exc)}))
        return 0 if args.command in {"observe-stop", "failure", "watchdog", "boot"} else 1
    except Exception as exc:
        print(json.dumps({"blocked": str(exc)}), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
