"""Independent classification of application lifecycle observations.

Classification never performs recovery or treats an unavailable health endpoint
as physical-safety evidence. The native adapter supplies transaction/dependency
observations and separately qualifies any stopped-app mutation.
"""
from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import re
import time

from shotdeck_security.storage import MigrationError, boot_id, read_json, write_json


LIFECYCLE_PROTOCOL = 1
READINESS_SECONDS = 180
_INVOCATION = re.compile(r"[0-9a-f]{32}\Z")
_BOOT = re.compile(r"[A-Za-z0-9-]{1,64}\Z")
_STATE = {"active", "reloading", "inactive", "failed", "activating", "deactivating", "maintenance", "refreshing"}
_FAILURE_RESULTS = {"exit-code", "signal", "core-dump", "watchdog", "oom-kill", "resources", "protocol"}
_PROPERTIES = {
    "InvocationID", "ActiveState", "SubState", "Result", "ExecMainCode",
    "ExecMainStatus", "NRestarts", "ExecMainStartTimestampMonotonic",
    "ActiveEnterTimestampMonotonic", "InactiveEnterTimestampMonotonic",
    "ControlGroup",
}


@dataclass(frozen=True)
class Decision:
    classification: str
    recovery_candidate: bool = False
    reason: str = ""

    def to_dict(self):
        return {"classification": self.classification,
                "recovery_candidate": self.recovery_candidate, "reason": self.reason}


def service_snapshot(properties):
    """Normalize bounded ``systemctl show`` properties without shell parsing."""
    if not isinstance(properties, dict) or set(properties) - _PROPERTIES:
        raise MigrationError("Unexpected service lifecycle properties")
    result = {}
    for key in _PROPERTIES:
        value = properties.get(key, "")
        if not isinstance(value, (str, int)) or isinstance(value, bool) or len(str(value)) > 256:
            raise MigrationError("Invalid service lifecycle property")
        if key in {"ExecMainCode", "ExecMainStatus", "NRestarts", "ExecMainStartTimestampMonotonic",
                   "ActiveEnterTimestampMonotonic", "InactiveEnterTimestampMonotonic"}:
            text = str(value)
            if not re.fullmatch(r"[0-9]{1,20}", text or "0"):
                raise MigrationError("Invalid numeric service lifecycle property")
            result[key] = int(text or "0")
        else:
            result[key] = str(value)
    if result["ActiveState"] not in _STATE:
        raise MigrationError("Unknown application service state")
    if result["InvocationID"] and not _INVOCATION.fullmatch(result["InvocationID"]):
        raise MigrationError("Invalid service invocation identity")
    if any(ord(c) < 32 for key, value in result.items() if isinstance(value, str) for c in value):
        raise MigrationError("Control characters in lifecycle observation")
    return result


def _context(context):
    fields = {"dependencies", "transaction_active", "maintenance", "recovery_latched",
              "expected_stop", "licence_recovery", "event_invocation"}
    if not isinstance(context, dict) or set(context) != fields:
        raise MigrationError("Incomplete application lifecycle context")
    for key in fields - {"dependencies", "event_invocation"}:
        if type(context[key]) is not bool:
            raise MigrationError("Lifecycle ownership observations must be boolean")
    deps = context["dependencies"]
    if (not isinstance(deps, dict) or set(deps) != {"bluetooth.service", "bluetooth.target"}
            or any(value not in _STATE | {"unknown", "not-found"} for value in deps.values())):
        raise MigrationError("Incomplete Bluetooth dependency observation")
    event = context["event_invocation"]
    if not isinstance(event, str) or (event and not _INVOCATION.fullmatch(event)):
        raise MigrationError("Invalid lifecycle event identity")
    return context


def classify_event(snapshot, context):
    """Decide whether an observed exit is even eligible for recovery admission.

    ``recovery_candidate`` is never a mutation authorization. In particular,
    start-limit exhaustion, timeout, stale events and dependency loss cannot
    turn themselves into evidence that an application release is defective.
    """
    service = service_snapshot(snapshot)
    context = _context(context)
    if context["recovery_latched"]:
        return Decision("recovery_latched", reason="The persistent recovery owner controls application starts")
    if context["transaction_active"] or context["maintenance"]:
        return Decision("owned_operation", reason="An update, signing or restore operation owns this lifecycle")
    if any(value != "active" for value in context["dependencies"].values()):
        return Decision("dependency_stop", reason="Bluetooth service/target is unavailable or changing")
    if (context["event_invocation"] and context["event_invocation"] != service["InvocationID"]):
        return Decision("stale_event", reason="The observed event belongs to another application invocation")
    if context["expected_stop"]:
        return Decision("planned_stop", reason="An explicit maintenance stop is recorded")
    if context["licence_recovery"]:
        return Decision("licence_recovery", reason="Licence recovery is not an application rollback incident")
    if service["Result"] in {"exec-condition", "start-limit-hit"}:
        return Decision("start_inhibited", reason="An admission/start limit is not evidence of a corrupt release")
    if service["ActiveState"] in {"activating", "deactivating", "reloading", "refreshing"}:
        return Decision("lifecycle_changing", reason="A service transition is still in progress")
    if service["Result"] == "timeout":
        return Decision("ambiguous_timeout", reason="A startup/stop timeout needs classified lifecycle evidence")
    if service["ActiveState"] == "active":
        return Decision("running", reason="Readiness must be checked separately from process state")
    if service["Result"] in {"", "success"} and service["ExecMainStatus"] == 0:
        return Decision("normal_stop", reason="No application failure was observed")
    if not service["InvocationID"]:
        return Decision("unknown", reason="The failed application invocation cannot be identified")
    if service["ActiveState"] == "failed" and service["Result"] in _FAILURE_RESULTS:
        return Decision("application_failure", True, "A specific unowned application invocation failed")
    return Decision("unknown", reason="The available service result does not establish a release failure")


def classify_stop_evidence(snapshot, context, receipt, *, boot=boot_id, clock=time.monotonic):
    """Recover a crash result hidden by start-limit exhaustion, never by guess.

    Only a recent, same-boot receipt from this exact app invocation can refine
    a start-limit result. It still passes all dependency/ownership exclusions.
    """
    service = service_snapshot(snapshot)
    baseline = classify_event(service, context)
    if service["Result"] != "start-limit-hit" or baseline.classification != "start_inhibited":
        return baseline
    fields = {"schema_version", "boot_id", "invocation_id", "service_result", "exit_code", "exit_status", "recorded_monotonic_usec"}
    if (not isinstance(receipt, dict) or set(receipt) != fields
            or type(receipt["schema_version"]) is not int or receipt["schema_version"] != 1
            or not isinstance(receipt["boot_id"], str) or not _BOOT.fullmatch(receipt["boot_id"])
            or not isinstance(receipt["invocation_id"], str) or not _INVOCATION.fullmatch(receipt["invocation_id"])
            or type(receipt["recorded_monotonic_usec"]) is not int
            or any(not isinstance(receipt[key], str) or len(receipt[key]) > 64
                   for key in ("service_result", "exit_code", "exit_status"))):
        raise MigrationError("Invalid application stop observation")
    age = int(clock() * 1_000_000) - receipt["recorded_monotonic_usec"]
    if (receipt["boot_id"] != boot() or not 0 <= age <= 300_000_000
            or receipt["invocation_id"] != service["InvocationID"]
            or receipt["service_result"] not in {"exit-code", "signal", "core-dump", "watchdog", "oom-kill"}
            or receipt["exit_code"] not in {"exited", "killed", "dumped"}
            or receipt["exit_status"] in {"", "0"}):
        return baseline
    refined = dict(service, Result=receipt["service_result"])
    return classify_event(refined, context)


class ReadinessTracker:
    """Persist a bounded startup deadline for one exact boot/invocation.

    A process that was already healthy is not rolled back merely because a later
    health request fails. Timer invocation frequency never extends a startup
    deadline, and rebooted/stale monotonic observations cannot trigger recovery.
    """

    def __init__(self, state_root, *, boot=boot_id, clock=time.monotonic, readiness_seconds=READINESS_SECONDS):
        if type(readiness_seconds) is not int or not 30 <= readiness_seconds <= 600:
            raise MigrationError("Unsupported application readiness deadline")
        self.path = Path(state_root) / "recovery" / "readiness.json"
        self.boot = boot
        self.clock = clock
        self.readiness_seconds = readiness_seconds

    def _read(self):
        if not os.path.lexists(self.path):
            return None
        value = read_json(self.path)
        if (set(value) != {"schema_version", "boot_id", "invocation_id", "started_usec", "deadline_usec", "ever_ready", "reported"}
                or type(value["schema_version"]) is not int or value["schema_version"] != LIFECYCLE_PROTOCOL
                or not isinstance(value["boot_id"], str) or not _BOOT.fullmatch(value["boot_id"])
                or not isinstance(value["invocation_id"], str) or not _INVOCATION.fullmatch(value["invocation_id"])
                or any(type(value[name]) is not int or value[name] < 0 for name in ("started_usec", "deadline_usec"))
                or value["deadline_usec"] - value["started_usec"] != self.readiness_seconds * 1_000_000
                or any(type(value[name]) is not bool for name in ("ever_ready", "reported"))):
            raise MigrationError("Corrupt application readiness observation")
        return value

    def observe(self, snapshot, context, *, health=None, expected_version):
        snapshot = service_snapshot(snapshot)
        decision = classify_event(snapshot, context)
        if decision.classification != "running":
            return {**decision.to_dict(), "first_report": False}
        invocation = snapshot["InvocationID"]
        started = snapshot["ExecMainStartTimestampMonotonic"]
        current_boot = self.boot()
        now = int(self.clock() * 1_000_000)
        if (not isinstance(current_boot, str) or not _BOOT.fullmatch(current_boot)
                or not invocation or not started or started > now):
            return {**Decision("unknown", reason="Startup clock or invocation is unavailable").to_dict(), "first_report": False}
        record = self._read()
        if record is None or record["boot_id"] != current_boot or record["invocation_id"] != invocation:
            record = {"schema_version": LIFECYCLE_PROTOCOL, "boot_id": current_boot,
                "invocation_id": invocation, "started_usec": started,
                "deadline_usec": started + self.readiness_seconds * 1_000_000,
                "ever_ready": False, "reported": False}
        elif record["started_usec"] != started:
            raise MigrationError("Application start identity changed within the same invocation")
        healthy = (isinstance(health, dict) and health.get("status") == "ready"
                   and health.get("control_ready") is True and str(health.get("version") or "") == expected_version)
        first_report = False
        if healthy:
            record["ever_ready"] = True
            decision = Decision("healthy", reason="The exact application invocation is ready")
        elif record["ever_ready"]:
            decision = Decision("runtime_unready", reason="An already-ready application needs diagnosis, not startup rollback")
        elif now < record["deadline_usec"]:
            decision = Decision("startup_pending", reason="The bounded application readiness deadline has not elapsed")
        else:
            decision = Decision("startup_unready", True, "The same running application never became ready before its deadline")
            first_report = not record["reported"]
            record["reported"] = True
        write_json(self.path, record)
        return {**decision.to_dict(), "first_report": first_report}
