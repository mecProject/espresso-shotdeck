"""Durable normal-activation journal and read-only interruption inspection.

This is the journal foundation for a future qualified recovery runtime. It
does not authorize stopped-app recovery, clear interrupted operations, or
infer successful startup from a symlink. Callers hold the updater, brew and
signing writer locks before mutating it. Fixed files live in ``state_root``;
an enrollment sentinel makes a subsequently missing journal fail closed.
"""
from __future__ import annotations

import os
import re
import fcntl
import stat
from contextlib import contextmanager
from itertools import islice
from pathlib import Path
from uuid import uuid4

from shotdeck_security.storage import (
    MigrationError, boot_id, canonical, digest, directory, read_json, remove, write_json,
)
from shotdeck_security.updates import tree_digest

from .errors import InstallError
from .storage import directory_tree_sha256
from .recovery import RecoveryStore, process_owner, owner_is_alive, _validate_owner, validate_identity


class ActivationJournalError(InstallError):
    """Journal uncertainty must not initiate another unrecorded mutation."""


ACTIVATION_PROTOCOL = 1
METADATA = ".shotdeck-release.json"
TERMINAL = {"completed", "rolled_back", "reconciled"}
FORWARD_PHASES = (
    "prepared", "stop_intent", "stopped", "pre_install_complete",
    "previous_selected", "candidate_selected", "start_intent", "started",
    "health_confirmed", "hooks_complete", "completed",
)
ROLLBACK_PHASES = (
    "rollback_intent", "rollback_stop_intent", "rollback_stopped",
    "rollback_selected", "rollback_start_intent", "rollback_started",
    "rollback_health_confirmed", "rollback_hooks_complete", "rolled_back",
)
PHASES = set(FORWARD_PHASES + ROLLBACK_PHASES) | {"reconciled"}
_HEX = re.compile(r"[0-9a-f]{64}\Z")
_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._+\-]{0,199}\Z")
_FIELDS = {"schema_version", "transaction_id", "operation", "service_name",
           "phase", "candidate", "current_before", "previous_before", "boot_id", "owner", "recovery"}
_LEGACY_FIELDS = _FIELDS - {"boot_id", "owner", "recovery"}


def _recording_boot():
    try:
        return boot_id()
    except FileNotFoundError:
        if os.uname().sysname == "Linux":
            raise
        # Host tests can record an operation but cannot authorize a Linux start.
        return "non-linux-development-host"


@contextmanager
def _admission_lock(path):
    directory(path.parent)
    descriptor = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0), 0o600)
    try:
        info = os.fstat(descriptor)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022:
            raise ActivationJournalError("Invalid activation admission lock")
        fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield
    finally:
        os.close(descriptor)


def _present(path: Path) -> bool:
    return os.path.lexists(path)


class ActivationJournal:
    """One durable transaction, never automatically resumed or acknowledged."""

    def __init__(self, config, *, checkpoint=lambda phase: None, boot=_recording_boot, owner_factory=process_owner):
        self.config = config
        self.path = config.state_root / "activation-journal.json"
        self.enrolled = config.state_root / "activation-enrolled.json"
        self.checkpoint = checkpoint
        self.boot = boot
        self.owner_factory = owner_factory
        self.owner_lock = config.state_root / "activation-owner.lock"
        self.admission_lock = config.state_root / "activation-admission.lock"
        self.permit = config.state_root / "activation-start-permit.json"
        self._owner_fd = None

    def _read(self):
        try:
            if self.config.state_root.is_symlink():
                raise ValueError("activation state directory must not be aliased")
            if not _present(self.enrolled) and not _present(self.path):
                if _present(self.permit):
                    raise ValueError("activation state is missing beside a start permit")
                return None
            marker = read_json(self.enrolled)
            if marker != {"schema_version": 1} or type(marker["schema_version"]) is not int:
                raise ValueError("invalid activation enrollment")
            envelope = read_json(self.path)
            if (set(envelope) != {"record", "sha256"}
                    or not isinstance(envelope["record"], dict)
                    or digest(canonical(envelope["record"])) != envelope["sha256"]):
                raise ValueError("activation journal checksum mismatch")
            record = envelope["record"]
            legacy_terminal = set(record) == _LEGACY_FIELDS and record.get("phase") in {"completed", "rolled_back"}
            if ((set(record) != _FIELDS and not legacy_terminal) or type(record["schema_version"]) is not int
                    or record["schema_version"] != ACTIVATION_PROTOCOL
                    or not isinstance(record["transaction_id"], str)
                    or re.fullmatch(r"[0-9a-f]{32}", record["transaction_id"]) is None
                    or record["operation"] not in {"install", "manual_rollback"}
                    or record["service_name"] != self.config.service_name
                    or record["phase"] not in PHASES):
                raise ValueError("invalid activation journal fields")
            if not legacy_terminal and (not isinstance(record["boot_id"], str) or not 0 < len(record["boot_id"]) <= 64):
                raise ValueError("invalid activation boot identity")
            if not legacy_terminal:
                _validate_owner(record["owner"])
            recovery = record.get("recovery")
            if record["phase"] == "reconciled":
                if (not isinstance(recovery, dict) or set(recovery) != {"incident_id", "receipt_sha256", "target"}
                        or _HEX.fullmatch(recovery["incident_id"]) is None
                        or _HEX.fullmatch(recovery["receipt_sha256"]) is None):
                    raise ValueError("invalid activation recovery receipt")
                self._validate_identity(recovery["target"], required=True)
                RecoveryStore(self.config).completion_evidence(recovery["incident_id"], record["transaction_id"],
                    {key: recovery["target"][key] for key in ("directory", "version", "tree_sha256")},
                    recovery["receipt_sha256"], allow_historical=True)
            elif recovery is not None:
                raise ValueError("unexpected activation recovery receipt")
            for name in ("candidate", "current_before", "previous_before"):
                self._validate_identity(record[name], required=name == "candidate")
            return record
        except (OSError, ValueError, KeyError, TypeError, InstallError) as exc:
            raise ActivationJournalError(f"Activation journal requires protected recovery: {exc}") from exc

    @staticmethod
    def _validate_identity(value, *, required=False):
        if value is None and not required:
            return
        if (not isinstance(value, dict)
                or set(value) != {"directory", "version", "tree_sha256", "metadata_matches"}
                or not isinstance(value["directory"], str)
                or _NAME.fullmatch(value["directory"]) is None
                or not isinstance(value["version"], str) or not 0 < len(value["version"]) <= 128
                or not isinstance(value["tree_sha256"], str) or _HEX.fullmatch(value["tree_sha256"]) is None
                or type(value["metadata_matches"]) is not bool):
            raise ValueError("invalid release identity")

    def _identity(self, release):
        if release is None:
            return None
        path = Path(release.path)
        root = self.config.releases_dir
        if (root.is_symlink() or path.is_symlink() or not path.is_dir()
                or path.resolve().parent != root.resolve()):
            raise InstallError("Activation release must be a direct immutable release directory")
        actual = directory_tree_sha256(path, ignore_names={METADATA})
        # Legacy normal updates historically allowed release metadata to be
        # absent or stale. Record that limitation instead of granting recovery
        # trust to a newly calculated digest. Recovery eligibility requires a
        # matching authenticated identity in the future capability layer.
        matches = False
        try:
            metadata = read_json(path / METADATA)
            matches = metadata.get("version") == release.version and metadata.get("tree_sha256") == actual
        except (OSError, ValueError):
            pass
        identity = {"directory": path.name, "version": release.version,
                    "tree_sha256": actual, "metadata_matches": matches}
        self._validate_identity(identity, required=True)
        return identity

    def _link(self, path: Path):
        if not _present(path):
            return None
        if not path.is_symlink():
            raise InstallError("Activation link is not a symlink")
        try:
            target = path.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            raise ActivationJournalError("Activation link target is unavailable") from exc
        if target.parent != self.config.releases_dir.resolve() or not target.is_dir():
            raise InstallError("Activation link is outside the releases directory")
        return target.name

    def assert_clear(self):
        record = self._read()
        if record is not None and record["phase"] not in TERMINAL:
            raise ActivationJournalError("An interrupted activation requires reviewed recovery before another update or rollback")
        if _present(self.permit):
            raise ActivationJournalError("An orphan activation start permit requires protected review")
        return record

    def _write(self, record):
        try:
            write_json(self.path, {"record": record, "sha256": digest(canonical(record))})
        except (OSError, MigrationError) as exc:
            raise ActivationJournalError(f"Cannot persist activation journal: {exc}") from exc
        self.checkpoint(record["phase"])

    def begin(self, operation, *, candidate, current, previous):
        self.assert_clear()
        if operation not in {"install", "manual_rollback"}:
            raise InstallError("Unsupported activation operation")
        # Manual rollback names the same tree as candidate and previous;
        # initial installations may name the same current/previous tree.
        # Hash each distinct immutable tree once within this locked snapshot.
        identities = {}

        def snapshot(release):
            if release is None:
                return None
            key = (str(release.path), release.version)
            if key not in identities:
                identities[key] = self._identity(release)
            return dict(identities[key])

        self._acquire_owner()
        record = {"schema_version": ACTIVATION_PROTOCOL, "transaction_id": uuid4().hex,
                  "operation": operation, "service_name": self.config.service_name,
                  "phase": "prepared", "candidate": snapshot(candidate),
                  "current_before": snapshot(current), "previous_before": snapshot(previous),
                  "boot_id": self.boot(), "owner": self.owner_factory(self._owner_fd), "recovery": None}
        if record["candidate"] is None:
            raise InstallError("Activation requires a candidate identity")
        if operation == "install" and not record["candidate"]["metadata_matches"]:
            raise InstallError("Candidate release identity differs from verified metadata")
        RecoveryStore(self.config).assert_offer_allowed({key: record["candidate"][key]
            for key in ("directory", "version", "tree_sha256")})
        for link, role in ((self.config.current_link, "current_before"),
                           (self.config.previous_link, "previous_before")):
            identity = record[role]
            if self._link(link) != (identity["directory"] if identity else None):
                raise InstallError("Activation links changed before journal preparation")
        # Once this marker exists, deletion/truncation of the transaction file
        # cannot masquerade as a first installation. A cut between these two
        # writes safely requires review, before any application stop occurred.
        if not _present(self.enrolled):
            write_json(self.enrolled, {"schema_version": ACTIVATION_PROTOCOL})
        self._write(record)
        return record["transaction_id"]

    def advance(self, transaction_id, phase):
        record = self._read()
        if record is None or record["transaction_id"] != transaction_id or record["phase"] in TERMINAL:
            raise ActivationJournalError("Activation transaction is stale or already complete")
        before = record["phase"]
        valid = False
        if before in FORWARD_PHASES and phase in FORWARD_PHASES:
            valid = FORWARD_PHASES.index(phase) == FORWARD_PHASES.index(before) + 1
        elif phase == "rollback_intent" and before in FORWARD_PHASES:
            valid = record["operation"] == "install" and record["current_before"] is not None
        elif before in ROLLBACK_PHASES and phase in ROLLBACK_PHASES:
            valid = ROLLBACK_PHASES.index(phase) == ROLLBACK_PHASES.index(before) + 1
        if not valid:
            raise ActivationJournalError(f"Invalid activation phase transition {before} -> {phase}")
        if phase in TERMINAL:
            self._verify_terminal(record, phase)
        record["phase"] = phase
        self._write(record)
        if phase in {"start_intent", "rollback_start_intent"}:
            if self._owner_fd is None or self.owner_factory(self._owner_fd) != record["owner"]:
                raise ActivationJournalError("Activation start owner is unavailable")
            target = record["candidate" if phase == "start_intent" else "current_before"]
            write_json(self.permit, {"schema_version": 1, "transaction_id": transaction_id,
                "phase": phase, "target": target, "boot_id": record["boot_id"],
                "owner": record["owner"], "nonce": uuid4().hex})
        elif _present(self.permit):
            remove(self.permit)
        if phase in TERMINAL:
            self.release_owner()

    def _acquire_owner(self):
        if self._owner_fd is not None:
            raise ActivationJournalError("Activation owner is already held")
        directory(self.owner_lock.parent)
        fd = os.open(self.owner_lock, os.O_RDWR | os.O_CREAT | os.O_NONBLOCK | getattr(os, "O_NOFOLLOW", 0), 0o600)
        try:
            info = os.fstat(fd)
            if not stat.S_ISREG(info.st_mode) or info.st_uid != os.geteuid() or info.st_mode & 0o022:
                raise ActivationJournalError("Invalid activation owner lock")
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BaseException:
            os.close(fd)
            raise
        self._owner_fd = fd

    def release_owner(self):
        if self._owner_fd is not None:
            os.close(self._owner_fd)
            self._owner_fd = None

    def __del__(self):
        self.release_owner()

    def check_start(self, *, owner_alive=None, consume=True):
        """Admit one exact normal start while its installer retains its lease.

        The recovery latch is an independent gate and must be checked first.
        A terminal journal does not grant any bypass of that latch.
        """
        with _admission_lock(self.admission_lock):
            record = self._read()
            if record is None or record["phase"] in TERMINAL:
                return not _present(self.permit)
            phase = record["phase"]
            if phase not in {"start_intent", "rollback_start_intent"} or not _present(self.permit):
                return False
            permit = read_json(self.permit)
            role = "candidate" if phase == "start_intent" else "current_before"
            expected = {"schema_version": 1, "transaction_id": record["transaction_id"],
                "phase": phase, "target": record[role], "boot_id": record["boot_id"], "owner": record["owner"]}
            if (set(permit) != set(expected) | {"nonce"}
                    or any(permit[key] != value for key, value in expected.items())
                    or type(permit["schema_version"]) is not int
                    or not isinstance(permit["nonce"], str) or re.fullmatch(r"[0-9a-f]{32}", permit["nonce"]) is None
                    or record["boot_id"] != self.boot()
                    or not (owner_alive or (lambda owner: owner_is_alive(owner, self.owner_lock)))(record["owner"])):
                return False
            self.verify_identity(record["transaction_id"], role)
            if self._link(self.config.current_link) != record[role]["directory"]:
                return False
            if consume:
                remove(self.permit)
            return True

    def complete_recovery(self, transaction_id, target_identity, incident_id, receipt_sha256):
        """Bind independently authorized healthy recovery, including retained targets.

        Historical activation roles are observations, not the authority for a
        different fallback. The protected core receipt and active signed recovery
        capability provide that authority; caller-supplied hashes never do.
        """
        with _admission_lock(self.admission_lock):
            record = self._read()
            if record is None or record["transaction_id"] != transaction_id:
                raise ActivationJournalError("Recovery refers to a different activation")
            if (not isinstance(incident_id, str) or _HEX.fullmatch(incident_id) is None
                    or not isinstance(receipt_sha256, str) or _HEX.fullmatch(receipt_sha256) is None):
                raise ActivationJournalError("Invalid activation recovery receipt identity")
            validate_identity(target_identity)
            # Recovery authority comes from its signature/receipt. Do not claim
            # that legacy release metadata independently authenticated this tree.
            target = {**target_identity, "metadata_matches": False}
            evidence = {"incident_id": incident_id, "receipt_sha256": receipt_sha256, "target": target}
            if record["phase"] == "reconciled" and record["recovery"] == evidence:
                # A cut after journal persistence may precede revocation of an
                # obsolete normal-installer permit. The validated receipt lets
                # the same completion finish only that cleanup.
                if _present(self.permit):
                    remove(self.permit)
                return
            if record["phase"] in TERMINAL:
                raise ActivationJournalError("Recovery cannot change a terminal activation")
            state, receipt = RecoveryStore(self.config).completion_evidence(
                incident_id, transaction_id, target_identity, receipt_sha256)
            from .recovery_safety import load_incident_capability
            capability, proof = load_incident_capability(self.config, state=state)
            if (capability["target"] != target_identity or proof["authority_id"] != state["authority_id"]
                    or proof["capability_sha256"] != receipt["capability_sha256"]
                    or proof["scope"] not in {"workshop", "customer"} or proof["recovery_enabled"] is not True):
                raise ActivationJournalError("Recovery completion lacks its exact signed capability")
            path = self.config.releases_dir / target["directory"]
            if self.config.releases_dir.is_symlink() or tree_digest(path) != target["tree_sha256"]:
                raise ActivationJournalError("Authorized recovery target changed before reconciliation")
            if self._link(self.config.current_link) != target["directory"]:
                raise ActivationJournalError("Recovered current link differs from the receipt")
            record["phase"] = "reconciled"
            record["recovery"] = evidence
            self._write(record)
            if _present(self.permit):
                remove(self.permit)

    def _verify_terminal(self, record, phase):
        """A successful hook cannot silently replace the selected identities."""
        self._verify_selected_links(record, phase)
        active_role = "current_before" if phase == "rolled_back" else "candidate"
        self.verify_identity(record["transaction_id"], active_role)

    def verify_selection(self, transaction_id):
        """Check both links before housekeeping can remove unused releases."""
        record = self._read()
        if record is None or record["transaction_id"] != transaction_id or record["phase"] != "hooks_complete":
            raise ActivationJournalError("Activation selection is not ready for completion")
        self._verify_selected_links(record, "completed")

    def _verify_selected_links(self, record, phase):
        active_role = "current_before" if phase == "rolled_back" else "candidate"
        active = record[active_role]
        if active is None or self._link(self.config.current_link) != active["directory"]:
            raise ActivationJournalError("Selected current link differs from the completed activation")
        if phase == "rolled_back":
            # A synchronous failure can precede or follow the previous-link
            # swap. Both recorded identities are legitimate; nothing else is.
            previous_targets = (record["current_before"], record["previous_before"])
        else:
            previous_targets = (record["current_before"] or record["previous_before"],)
        expected = {identity["directory"] if identity else None for identity in previous_targets}
        if self._link(self.config.previous_link) not in expected:
            raise ActivationJournalError("Selected previous link differs from the completed activation")

    def verify_identity(self, transaction_id, role):
        record = self._read()
        if record is None or record["transaction_id"] != transaction_id or role not in {
                "candidate", "current_before", "previous_before"}:
            raise ActivationJournalError("Activation identity is not part of this transaction")
        identity = record[role]
        if identity is None:
            raise ActivationJournalError("Activation recovery target is absent")
        path = self.config.releases_dir / identity["directory"]
        if (self.config.releases_dir.is_symlink() or path.is_symlink() or not path.is_dir()
                or directory_tree_sha256(path, ignore_names={METADATA}) != identity["tree_sha256"]):
            raise ActivationJournalError("Activation release tree changed during the transaction")
        return path

    def inspect(self):
        """Return evidence only; matching links never establish successful boot.

        ``recovery_capability`` stays false until the independently qualified
        WP4/Release C safety layer provides stopped-app admission and bounded
        reconciliation. No acknowledgement or clearing operation is exposed.
        """
        record = self._read()
        if record is None:
            return {"schema_version": 1, "state": "unused", "recovery_required": False,
                    "recovery_capability": False}
        identities = {}
        checked = {}
        for role in ("candidate", "current_before", "previous_before"):
            identity = record[role]
            if identity is None:
                identities[role] = "absent"
                continue
            try:
                key = (identity["directory"], identity["tree_sha256"])
                if key not in checked:
                    try:
                        self.verify_identity(record["transaction_id"], role)
                        checked[key] = True
                    except (OSError, InstallError):
                        checked[key] = False
                if not checked[key]:
                    raise ActivationJournalError("Recorded tree is missing or changed")
                identities[role] = "unchanged" if identity["metadata_matches"] else "unverified_metadata"
            except (OSError, InstallError):
                identities[role] = "missing_or_changed"
        links = {}
        for role, path in (("current", self.config.current_link), ("previous", self.config.previous_link)):
            try:
                links[role] = self._link(path)
            except (OSError, InstallError):
                links[role] = "invalid"
        return {"schema_version": 1, "state": record["phase"], "record": record,
                "identities": identities, "links": links,
                "recovery_required": record["phase"] not in TERMINAL,
                "recovery_capability": False}


def assert_no_conflicting_transaction(config):
    """The caller already owns the updater and shared signing writer locks."""
    for path in (config.migration_root / "updates/pending.json",
                 config.migration_root / "updates/runtime-transition.json"):
        if _present(path):
            raise InstallError("Finish the pending signing transition before activation")
    assert_no_pending_restore(config)


def assert_no_pending_restore(config):
    """Check restore journals without rejecting an owner's transition journal."""
    root = Path(os.environ.get("SHOTDECK_RESTORE_STATE_DIR", "/var/lib/shotdeck-restore")) / "jobs"
    if not _present(root):
        return
    if root.is_symlink() or not root.is_dir():
        raise InstallError("Restore transaction location requires repair")
    entries = list(islice(root.iterdir(), 1025))
    if len(entries) > 1024:
        raise InstallError("Too many restore records to verify safely")
    for entry in entries:
        if re.fullmatch(r"[0-9a-f]{32}", entry.name) is None:
            continue
        if entry.is_symlink() or not entry.is_dir():
            raise InstallError("Unsafe restore transaction directory")
        path = entry / "transaction.json"
        if not _present(path):
            continue
        try:
            value = read_json(path)
            if (set(value) != {"schema_version", "restore_id", "state", "rollback_path", "updated_at", "error"}
                    or type(value["schema_version"]) is not int or value["schema_version"] != 1
                    or value["restore_id"] != entry.name or value["rollback_path"] != "rollback.sdbak"
                    or value["state"] not in {"committed", "rolled_back"}):
                raise ValueError("restore transaction is not terminal")
        except (OSError, ValueError, KeyError, TypeError) as exc:
            raise InstallError("An unfinished restore requires recovery before activation") from exc
