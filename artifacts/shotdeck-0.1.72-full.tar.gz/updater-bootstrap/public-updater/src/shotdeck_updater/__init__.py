"""Runtime updater package for Shotdeck."""

# Single source of truth consumed by packaging, User-Agent reporting, and
# manifest applicability checks.
__version__ = "0.2.1"
